"""Core logic for splitting audio into parts with ffmpeg."""

import json
import math
import os
import subprocess
from pathlib import Path
from typing import List, Optional, Tuple


def _json_or_null(json_str: str) -> Optional[dict]:
    if not json_str or not json_str.strip():
        return None
    try:
        return json.loads(json_str)
    except (json.JSONDecodeError, ValueError):
        return None


def probe_audio_file(file_path: str, ffprobe_bin: str) -> Optional[dict]:
    """Probe audio file using ffprobe. Returns stream/format dict or None."""
    try:
        cmd = [
            ffprobe_bin,
            "-v",
            "error",
            "-select_streams",
            "a:0",
            "-show_entries",
            "stream=codec_name,channels,sample_rate,bit_rate",
            "-show_entries",
            "format=duration",
            "-of",
            "json",
            file_path,
        ]
        result = subprocess.run(
            cmd, capture_output=True, text=True, check=False, timeout=30
        )
        if result.returncode == 0:
            return _json_or_null(result.stdout)
    except (subprocess.SubprocessError, FileNotFoundError):
        pass
    return None


def get_duration(file_path: str, ffprobe_bin: str) -> Optional[float]:
    """Get audio file duration in seconds."""
    probe_data = probe_audio_file(file_path, ffprobe_bin)
    if probe_data and "format" in probe_data and "duration" in probe_data["format"]:
        try:
            return float(probe_data["format"]["duration"])
        except (ValueError, TypeError):
            pass
    try:
        cmd = [
            ffprobe_bin,
            "-v",
            "error",
            "-show_entries",
            "format=duration",
            "-of",
            "default=nokey=1:noprint_wrappers=1",
            file_path,
        ]
        result = subprocess.run(
            cmd, capture_output=True, text=True, check=False, timeout=30
        )
        if result.returncode == 0 and result.stdout.strip():
            return float(result.stdout.strip())
    except (subprocess.SubprocessError, FileNotFoundError, ValueError):
        pass
    return None


def needs_conversion(probe_data: Optional[dict]) -> bool:
    """True if audio should be converted to optimal MP3 (mono 16kHz 64k)."""
    if not probe_data or "streams" not in probe_data:
        return True
    streams = probe_data.get("streams", [])
    if not streams:
        return True
    s = streams[0]
    is_mp3 = s.get("codec_name") == "mp3"
    is_mono = s.get("channels") == 1
    sr = s.get("sample_rate")
    is_16k = sr == "16000" or sr == 16000
    br = s.get("bit_rate")
    is_64k = br == 64000
    return not (is_mp3 and is_mono and is_16k and is_64k)


def convert_audio(
    input_path: str,
    output_path: str,
    ffmpeg_bin: str,
    target_ar: int = 16000,
    target_ac: int = 1,
    target_br: str = "64k",
) -> bool:
    """Convert audio to MP3 (mono, 16kHz, 64k). Returns True on success."""
    try:
        cmd = [
            ffmpeg_bin,
            "-hide_banner",
            "-y",
            "-i",
            input_path,
            "-ac",
            str(target_ac),
            "-ar",
            str(target_ar),
            "-c:a",
            "libmp3lame",
            "-b:a",
            target_br,
            "-movflags",
            "+faststart",
            output_path,
        ]
        subprocess.run(cmd, capture_output=True, text=True, check=True)
        return True
    except (subprocess.CalledProcessError, FileNotFoundError):
        return False


def split_audio(
    input_path: str,
    output_pattern: str,
    segment_time_sec: int,
    ffmpeg_bin: str,
) -> bool:
    """Split audio into segments. output_pattern e.g. dir/name_part%02d.mp3. Returns True on success."""
    try:
        cmd = [
            ffmpeg_bin,
            "-hide_banner",
            "-y",
            "-i",
            input_path,
            "-f",
            "segment",
            "-segment_time",
            str(segment_time_sec),
            "-c",
            "copy",
            "-reset_timestamps",
            "1",
            output_pattern,
        ]
        subprocess.run(cmd, capture_output=True, text=True, check=True)
        return True
    except (subprocess.CalledProcessError, FileNotFoundError):
        return False


# 20 MB target, 64k CBR -> ~16000 bytes/sec -> 1280 sec per 20 MB
LIMIT_BYTES = 20 * 1024 * 1024
TARGET_BPS = 64000
SAFETY = 0.97


def compute_segment_time(
    duration_sec: float,
    size_bytes: int,
    limit_bytes: int = LIMIT_BYTES,
    safety: float = SAFETY,
) -> int:
    """
    Compute segment time (seconds) so parts stay under limit_bytes.
    Returns segment time in seconds (at least 60).
    """
    max_per_part = limit_bytes * safety
    parts = max(1, math.ceil(size_bytes / max_per_part))
    seg = max(60, math.floor((duration_sec / parts) * safety))
    est_bytes = (TARGET_BPS // 8) * seg
    while est_bytes > max_per_part and seg > 30:
        seg -= 1
        est_bytes = (TARGET_BPS // 8) * seg
    return seg
