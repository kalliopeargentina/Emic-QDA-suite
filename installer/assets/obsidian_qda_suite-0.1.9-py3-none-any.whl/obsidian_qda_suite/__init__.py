"""Obsidian QDA Suite: CLI for transcription, analysis, and audio tools."""
import os
# Evitar conflictos TF/transformers (cannot import Trainer). USE_TF es la var que transformers 4.57 respeta.
os.environ["USE_TF"] = "0"
os.environ["USE_TORCH"] = "1"
os.environ["TF_ENABLE_ONEDNN_OPTS"] = "0"

__version__ = "0.1.9"
