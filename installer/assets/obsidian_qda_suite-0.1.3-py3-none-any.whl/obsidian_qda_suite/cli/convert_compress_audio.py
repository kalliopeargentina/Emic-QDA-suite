"""CLI for converting/compressing audio to MP3 or video to MP4."""

import argparse
import os
import shutil
import sys
from datetime import datetime
from pathlib import Path

from . import common
from ..audio.ffmpeg_utils import get_ffmpeg_path
from ..audio.split import convert_audio, convert_video

VIDEO_EXTENSIONS = {
    ".mp4",
    ".mkv",
    ".mov",
    ".avi",
    ".webm",
    ".m4v",
    ".mpeg",
    ".mpg",
}


def main() -> None:
    common.setup_console_encoding()
    parser = argparse.ArgumentParser(
        description="Convert/compress audio to MP3 or video to MP4."
    )
    parser.add_argument("--vault-path", type=str, help="Obsidian vault path (Obsidian mode)")
    parser.add_argument("--file-path", type=str, help="Absolute path to audio file (Obsidian mode)")
    parser.add_argument("--file-name", type=str, help="Name of the audio file (Obsidian mode)")
    parser.add_argument("file", type=str, nargs="?", help="Audio file (direct mode)")
    parser.add_argument("--output-dir", type=str, help="Output directory (direct mode; default: in-place)")
    parser.add_argument(
        "--media-type",
        choices=["auto", "audio", "video"],
        default="auto",
        help="Auto-detect by extension or force audio/video path.",
    )
    parser.add_argument("--audio-ar", type=int, default=16000, help="Audio sample rate.")
    parser.add_argument("--audio-ac", type=int, default=1, help="Audio channels.")
    parser.add_argument("--audio-br", type=str, default="64k", help="Audio bitrate.")
    parser.add_argument("--video-scale", type=int, default=1280, help="Video width.")
    parser.add_argument("--video-crf", type=int, default=28, help="Video CRF quality.")
    parser.add_argument(
        "--video-preset", type=str, default="veryfast", help="Video encoder preset."
    )
    parser.add_argument(
        "--video-vcodec", type=str, default="libx264", help="Video codec."
    )
    parser.add_argument(
        "--video-acodec", type=str, default="aac", help="Video audio codec."
    )
    parser.add_argument("--video-abr", type=str, default="96k", help="Video audio bitrate.")
    parser.add_argument(
        "--video-fps",
        type=int,
        default=None,
        help="Video fps (omit to keep source).",
    )
    args = parser.parse_args()

    vault_path = common.get_optional_param(args.vault_path)
    file_path_arg = common.get_optional_param(args.file_path)
    file_name_arg = common.get_optional_param(args.file_name)
    direct_file = common.get_optional_param(args.file)
    output_dir_arg = common.get_optional_param(args.output_dir)

    if vault_path and file_path_arg and file_name_arg:
        vault = common.fix_path(vault_path)
        file_abs = common.fix_path(file_path_arg)
        file_name = common.sanitize_name(file_name_arg)
        if not os.path.isdir(vault):
            common.safe_print(f"Error: Vault path not found: {vault}", file=sys.stderr)
            sys.exit(1)
        media_dir = os.path.join(vault, "Attachments", "Medios")
        backup_dir = os.path.join(media_dir, "pre-process-backup")
        os.makedirs(backup_dir, exist_ok=True)
        out_dir = media_dir
    elif direct_file:
        file_abs = common.fix_path(direct_file)
        if not os.path.isfile(file_abs):
            common.safe_print(f"Error: File not found: {file_abs}", file=sys.stderr)
            sys.exit(1)
        file_name = os.path.basename(file_abs)
        if output_dir_arg:
            out_dir = common.fix_path(output_dir_arg)
            os.makedirs(out_dir, exist_ok=True)
            backup_dir = os.path.dirname(file_abs)
        else:
            out_dir = os.path.dirname(file_abs)
            backup_dir = os.path.dirname(file_abs)
    else:
        common.safe_print(
            "Error: Use --vault-path, --file-path, --file-name (Obsidian) or pass audio file (direct).",
            file=sys.stderr,
        )
        parser.print_help(sys.stderr)
        sys.exit(1)

    if not os.path.isfile(file_abs):
        common.safe_print(f"Error: File not found: {file_abs}", file=sys.stderr)
        sys.exit(1)

    stem = Path(file_name).stem
    ext = Path(file_name).suffix or ".mp3"
    is_video = args.media_type == "video" or (
        args.media_type == "auto" and ext.lower() in VIDEO_EXTENSIONS
    )
    output_ext = ".mp4" if is_video else ".mp3"
    out_file = os.path.join(out_dir, f"{stem}{output_ext}")
    timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
    backup_file = os.path.join(backup_dir, f"{stem}_orig_{timestamp}{ext}")

    try:
        shutil.move(file_abs, backup_file)
    except Exception as e:
        common.safe_print(f"Error: Failed to create backup: {e}", file=sys.stderr)
        sys.exit(1)

    ffmpeg_bin = get_ffmpeg_path()
    if is_video:
        ok = convert_video(
            backup_file,
            out_file,
            ffmpeg_bin,
            target_width=args.video_scale,
            target_crf=args.video_crf,
            target_preset=args.video_preset,
            target_vcodec=args.video_vcodec,
            target_acodec=args.video_acodec,
            target_abr=args.video_abr,
            target_fps=args.video_fps,
        )
    else:
        ok = convert_audio(
            backup_file,
            out_file,
            ffmpeg_bin,
            target_ar=args.audio_ar,
            target_ac=args.audio_ac,
            target_br=args.audio_br,
        )
    if not ok:
        try:
            shutil.move(backup_file, file_abs)
        except Exception:
            common.safe_print(f"Warning: Could not restore original from {backup_file}", file=sys.stderr)
        common.safe_print("Error: ffmpeg failed to convert/compress media.", file=sys.stderr)
        sys.exit(1)

    common.safe_print(f"Converted and compressed: {out_file}")
    common.safe_print(f"Backup: {backup_file}")

