"""
Report generation for topic analysis.

This package contains report generation and templating functionality.
"""

from .templates import generate_markdown_report

# Try to import generate_report for single-file analysis
try:
    from .generator import generate_report
    __all__ = ['generate_markdown_report', 'generate_report']
except ImportError:
    # If generator.py doesn't exist or has import errors, just export templates
    __all__ = ['generate_markdown_report']

