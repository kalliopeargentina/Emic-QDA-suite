"""Parse and normalize model outputs."""

from __future__ import annotations

import json
import sys

from ontology_explorer.domain.spec import DomainSpec


def _normalize_evidence(evidence) -> list[dict]:
    """Normaliza evidencia a formato de array. Puede recibir objeto único, array, o None."""
    if evidence is None:
        return []
    if isinstance(evidence, dict):
        return [evidence]
    if isinstance(evidence, list):
        return [e for e in evidence if isinstance(e, dict)]
    return []


def parse_json_output(
    raw_output: str,
    model_name: str,
    domain_spec: DomainSpec | None = None,
) -> dict:
    """Intenta parsear el JSON del output, limpiando texto extra si es necesario."""
    import re

    cleaned = raw_output.strip()

    # Buscar bloques de código marcados con ```json o ```
    json_block_pattern = r"```(?:json)?\s*\n(.*?)\n```"
    json_block_match = re.search(json_block_pattern, cleaned, re.DOTALL)
    if json_block_match:
        cleaned = json_block_match.group(1).strip()
        print("JSON extraído de bloque de código marcado", file=sys.stderr, flush=True)
    elif cleaned.startswith("```"):
        lines = cleaned.split("\n")
        if lines[0].startswith("```"):
            lines = lines[1:]
        if lines and lines[-1].strip() == "```":
            lines = lines[:-1]
        cleaned = "\n".join(lines)

    cleaned = re.sub(r"\\\s*\n\s*", "\n", cleaned)
    cleaned = re.sub(r"\\\s*$", "", cleaned, flags=re.MULTILINE)

    for _ in range(5):
        new_cleaned = re.sub(r",\s*([}\]])", r"\1", cleaned)
        if new_cleaned == cleaned:
            break
        cleaned = new_cleaned

    try:
        data = json.loads(cleaned)
        if "model" not in data:
            data["model"] = model_name
        if "entities" in data:
            normalized_entities = []
            for ent in data["entities"]:
                if isinstance(ent, list):
                    if len(ent) >= 3:
                        evidence = ent[2] if len(ent) > 2 else None
                        normalized_ent = [ent[0], ent[1], _normalize_evidence(evidence)]
                        normalized_entities.append(normalized_ent)
                    elif len(ent) == 2:
                        normalized_entities.append([ent[0], ent[1], []])
                    else:
                        normalized_entities.append(ent)
                else:
                    normalized_entities.append(ent)
            data["entities"] = normalized_entities
        if "relations" in data:
            normalized_relations = []
            for rel in data["relations"]:
                if isinstance(rel, list):
                    if len(rel) >= 4:
                        evidence = rel[3] if len(rel) > 3 else None
                        normalized_rel = [rel[0], rel[1], rel[2], _normalize_evidence(evidence)]
                        normalized_relations.append(normalized_rel)
                    elif len(rel) == 3:
                        normalized_relations.append([rel[0], rel[1], rel[2], []])
                    else:
                        normalized_relations.append(rel)
                else:
                    normalized_relations.append(rel)
            data["relations"] = normalized_relations
        if domain_spec:
            data = _normalize_with_domain_spec(data, domain_spec)
        return data
    except json.JSONDecodeError:
        pass

    start = cleaned.find("{")
    end = cleaned.rfind("}")

    if start != -1 and end != -1 and end > start:
        json_str = cleaned[start:end + 1]
        try:
            data = json.loads(json_str)
            if "model" not in data:
                data["model"] = model_name
            print("JSON extraído del output (había texto adicional)", file=sys.stderr, flush=True)
            if domain_spec:
                data = _normalize_with_domain_spec(data, domain_spec)
            return data
        except json.JSONDecodeError:
            pass

    brace_count = 0
    start_idx = cleaned.find("{")
    if start_idx != -1:
        in_string = False
        escape_next = False

        for i in range(start_idx, len(cleaned)):
            char = cleaned[i]

            if escape_next:
                escape_next = False
                continue

            if char == "\\":
                escape_next = True
                continue

            if char == '"' and not escape_next:
                in_string = not in_string
                continue

            if not in_string:
                if char == "{":
                    brace_count += 1
                elif char == "}":
                    brace_count -= 1
                    if brace_count == 0:
                        try:
                            json_str = cleaned[start_idx:i + 1]
                            for _ in range(5):
                                new_json_str = re.sub(r",\s*([}\]])", r"\1", json_str)
                                if new_json_str == json_str:
                                    break
                                json_str = new_json_str
                            data = json.loads(json_str)
                            if "model" not in data:
                                data["model"] = model_name
                            print("JSON extraído usando balanceo de llaves", file=sys.stderr, flush=True)
                            if domain_spec:
                                data = _normalize_with_domain_spec(data, domain_spec)
                            return data
                        except json.JSONDecodeError:
                            break

    # Buscar el primer objeto JSON válido de manera más agresiva
    # Buscar patrones que indiquen el inicio de un JSON ({"model" o {"entities")
    json_start_patterns = [
        r'\{[\s\n]*"model"',
        r'\{[\s\n]*"entities"',
        r'\{[\s\n]*"relations"',
    ]
    
    for pattern in json_start_patterns:
        match = re.search(pattern, cleaned, re.IGNORECASE | re.MULTILINE)
        if match:
            start_pos = match.start()
            # Intentar extraer JSON desde esta posición
            json_candidate = cleaned[start_pos:]
            # Buscar el cierre balanceado
            brace_count = 0
            in_string = False
            escape_next = False
            end_pos = -1
            
            for i, char in enumerate(json_candidate):
                if escape_next:
                    escape_next = False
                    continue
                if char == "\\":
                    escape_next = True
                    continue
                if char == '"' and not escape_next:
                    in_string = not in_string
                    continue
                if not in_string:
                    if char == "{":
                        brace_count += 1
                    elif char == "}":
                        brace_count -= 1
                        if brace_count == 0:
                            end_pos = i + 1
                            break
            
            if end_pos > 0:
                json_str = json_candidate[:end_pos]
                # Limpiar comas finales
                for _ in range(5):
                    new_json_str = re.sub(r",\s*([}\]])", r"\1", json_str)
                    if new_json_str == json_str:
                        break
                    json_str = new_json_str
                try:
                    data = json.loads(json_str)
                    if "model" not in data:
                        data["model"] = model_name
                    print(f"JSON extraído usando patrón de inicio ({pattern[:20]}...)", file=sys.stderr, flush=True)
                    if domain_spec:
                        data = _normalize_with_domain_spec(data, domain_spec)
                    return data
                except json.JSONDecodeError:
                    continue

    partial_json_match = re.search(r"{.*}", cleaned, re.DOTALL)
    if partial_json_match:
        partial_str = partial_json_match.group(0)
        if not partial_str.strip().startswith("{"):
            partial_str = "{" + partial_str + "}"
        try:
            data = json.loads(partial_str)
            if "model" not in data:
                data["model"] = model_name
            print("JSON parcial extraído y reconstruido", file=sys.stderr, flush=True)
            return data
        except json.JSONDecodeError:
            pass

    print("Error: No se pudo parsear JSON", file=sys.stderr, flush=True)
    print(f"Output recibido (primeros 500 chars): {raw_output[:500]}", file=sys.stderr, flush=True)
    raise SystemExit("No se pudo parsear el JSON del output del modelo.")


def _normalize_with_domain_spec(data: dict, domain_spec: DomainSpec) -> dict:
    """Apply canonicalization and properties mapping using domain spec."""
    entities = data.get("entities", [])
    relations = data.get("relations", [])

    entities_by_name: dict[str, str] = {}
    for ent in entities:
        if isinstance(ent, list) and len(ent) >= 2:
            entities_by_name[str(ent[0])] = str(ent[1])

    normalized_relations: list[list] = []
    for rel in relations:
        if not isinstance(rel, list) or len(rel) < 3:
            normalized_relations.append(rel)
            continue
        rel_type, source, target = rel[0], rel[1], rel[2]
        canonical = domain_spec.canonicalize_relation(str(rel_type))
        normalized_rel = [canonical, source, target, rel[3] if len(rel) > 3 else []]
        normalized_relations.append(normalized_rel)

    # Convert properties to relations if present
    properties = data.get("properties", [])
    for prop in properties:
        if not isinstance(prop, list) or len(prop) < 3:
            continue
        entity_name = prop[0]
        property_name = prop[1]
        value = prop[2]
        evidence = _normalize_evidence(prop[3] if len(prop) > 3 else None)

        source_type = entities_by_name.get(str(entity_name))
        relation_type = None

        if source_type:
            # If property_name is a nested property, map to its relation
            relation_type = domain_spec.relation_for_nested_property(
                source_type, str(property_name)
            )

            # If still missing, try mapping property label via property relations
            if not relation_type:
                for rel in domain_spec.property_relations:
                    if rel.target_types and rel.target_types[0].lower() == str(property_name).lower():
                        relation_type = rel.name
                        break

        if not relation_type:
            relation_type = str(property_name)

        relation_type = domain_spec.canonicalize_relation(str(relation_type))

        normalized_relations.append([relation_type, entity_name, value, evidence])

    data["relations"] = normalized_relations
    # Mantener contrato de salida (sin campo properties)
    if "properties" in data:
        data.pop("properties", None)
    return data
