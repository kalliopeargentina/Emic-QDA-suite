"""
Single-file topic analysis report generator.

This module generates topic analysis reports for individual markdown files,
performing section-level topic analysis.
"""

import sys
import re
import numpy as np
from pathlib import Path
from collections import Counter

# Import from our modules - handle both relative and absolute imports
try:
    # Try relative imports first (when running as package)
    from ..text_processing import extract_text_from_markdown_content, extract_sections_with_headers, preprocess_text, analyze_text_statistics
    from ..nlp_utils import (
        get_stopwords_set,
        detect_language,
        load_spacy_model,
        load_custom_stopwords,
        load_seed_words_from_markdown,
        log_language_info,
        determine_optimal_topics
    )
    from ..methods.modeling import perform_topic_modeling
    from ..config import DEFAULT_CONFIG, VERBOSE, DEBUG_MODE
    from ..visualizations import (
        create_topic_distribution_chart,
        create_topic_word_chart,
        create_topic_heatmap,
        create_word_frequency_chart,
        create_word_cloud,
        create_topic_map,
        create_word_topic_network,
        create_topic_cooccurrence_network,
        create_word_cooccurrence_network
    )
    from .templates import generate_markdown_report
except ImportError:
    # Fallback to absolute imports (when running directly)
    import sys
    from pathlib import Path
    current_file = Path(__file__).resolve()
    parent_dir = current_file.parent.parent
    
    # Add parent directory to path if not already there
    if str(parent_dir) not in sys.path:
        sys.path.insert(0, str(parent_dir))
    
    from text_processing import extract_text_from_markdown_content, extract_sections_with_headers, preprocess_text, analyze_text_statistics
    from nlp_utils import (
        get_stopwords_set,
        detect_language,
        load_spacy_model,
        load_custom_stopwords,
        load_seed_words_from_markdown,
        log_language_info,
        determine_optimal_topics
    )
    from methods.modeling import perform_topic_modeling
    from config import DEFAULT_CONFIG, VERBOSE, DEBUG_MODE
    from visualizations import (
        create_topic_distribution_chart,
        create_topic_word_chart,
        create_topic_heatmap,
        create_word_frequency_chart,
        create_word_cloud,
        create_topic_map,
        create_word_topic_network,
        create_topic_cooccurrence_network,
        create_word_cooccurrence_network
    )
    from report.templates import generate_markdown_report

from nltk.stem import WordNetLemmatizer


def generate_report(input_file, output_path, n_topics=None, method='lda', language='auto',
                   images_dir=None, custom_stopwords_file=None, seed_words_file=None,
                   hdp_gamma=1.0, hdp_alpha=1.0, top2vec_embedding_model='all-MiniLM-L6-v2',
                   bertopic_min_topic_size=10, bertopic_top_n_words=10,
                   bertopic_diversity=0.0, bertopic_calculate_probabilities=True,
                   bertopic_embedding_model=None):
    """
    Generate topic analysis report for a single markdown file.
    
    This function performs section-level topic analysis on a markdown file,
    extracting topics from different sections (headings) of the document.
    
    Args:
        input_file: Path to the input markdown file
        output_path: Path where the report should be saved
        n_topics: Number of topics to extract (None for auto-detection)
        method: Topic modeling method ('lda', 'nmf', 'guided-lda', 'hdp', 'corex', 'lsi', 'lsa', 'top2vec', 'bertopic')
        language: Language for stopwords ('auto' for auto-detection)
        images_dir: Directory where images should be saved
        custom_stopwords_file: Path to custom stopwords file
        seed_words_file: Path to seed words file (for guided-lda)
        hdp_gamma: HDP gamma parameter
        hdp_alpha: HDP alpha parameter
        top2vec_embedding_model: Top2Vec embedding model name
        bertopic_min_topic_size: BERTopic minimum cluster size
        bertopic_top_n_words: BERTopic number of top words per topic
        bertopic_diversity: BERTopic MMR diversity (0.0-1.0)
        bertopic_calculate_probabilities: BERTopic calculate probabilities
        bertopic_embedding_model: BERTopic embedding model name
    """
    input_path = Path(input_file)
    output_path_obj = Path(output_path)
    
    # Ensure output directory exists
    output_path_obj.parent.mkdir(parents=True, exist_ok=True)
    
    if not input_path.exists():
        print(f"Error: Input file not found: {input_file}", file=sys.stderr)
        sys.exit(1)
    
    print(f"Reading markdown file: {input_file}")
    
    # Read and extract text sections from markdown (by headings)
    try:
        from ..text_processing import extract_sections_with_headers
    except ImportError:
        from text_processing import extract_sections_with_headers
    
    sections = extract_sections_with_headers(input_path)
    
    if not sections:
        print("Error: No text sections found in markdown file", file=sys.stderr)
        sys.exit(1)
    
    print(f"Found {len(sections)} sections in document")
    
    # Extract clean text from each section
    section_texts = []
    for section in sections:
        raw_section_text = section.get('raw_text', '')
        # Extract clean text from markdown
        clean_section_text = extract_text_from_markdown_content(raw_section_text)
        section_texts.append(clean_section_text)
        # Update section with clean text
        section['text'] = clean_section_text
        section['heading'] = section.get('header', 'Section')
    
    # Combine all sections for full text
    raw_text = ' '.join(section_texts)
    
    # Validate text length
    min_text_len = DEFAULT_CONFIG['text_processing']['min_text_length']
    if len(raw_text.strip()) < min_text_len:
        print(f"Error: Document text content is too short for meaningful topic analysis (minimum {min_text_len} characters)", file=sys.stderr)
        sys.exit(1)
    
    # Load custom stopwords if provided
    custom_stopwords = None
    if custom_stopwords_file:
        print(f"Loading custom stopwords from: {custom_stopwords_file}")
        custom_stopwords = load_custom_stopwords(custom_stopwords_file)
        print(f"Loaded {len(custom_stopwords)} custom stopwords")
    
    # Auto-detect language if not specified
    if language == 'auto' or language is None:
        print("Auto-detecting language...")
        detected_lang = detect_language(raw_text)
        language = detected_lang
        log_language_info(language, detected=True, verbose=VERBOSE)
    else:
        log_language_info(language, detected=False, verbose=VERBOSE)
    
    # Load spaCy model for lemmatization if available
    lemmatizer = None
    try:
        import spacy
        HAS_SPACY = True
    except (ImportError, OSError):
        HAS_SPACY = False
    
    if HAS_SPACY:
        if VERBOSE:
            print(f"Loading spaCy model for {language}...")
        lemmatizer = load_spacy_model(language)
        if lemmatizer:
            if VERBOSE:
                print(f"Using spaCy model for lemmatization")
        else:
            if VERBOSE:
                print(f"spaCy model not available, using NLTK WordNetLemmatizer")
            lemmatizer = WordNetLemmatizer()
    else:
        if VERBOSE:
            print("spaCy not available, using NLTK WordNetLemmatizer")
        lemmatizer = WordNetLemmatizer()
    
    # Preprocess each section
    print("Preprocessing text...")
    processed_sections = []
    section_labels = []
    
    min_processed_len = DEFAULT_CONFIG['text_processing']['min_processed_length']
    
    for section in sections:
        section_text = section.get('text', '')
        section_title = section.get('heading', 'Section')
        processed = preprocess_text(section_text, language, custom_stopwords, lemmatizer)
        
        if len(processed.strip()) > min_processed_len:
            processed_sections.append(processed)
            section_labels.append(section_title)
    
    if len(processed_sections) < 2:
        print("Error: Not enough processed text sections for topic analysis", file=sys.stderr)
        sys.exit(1)
    
    # Process full text if needed for topic detection
    processed_text = None
    min_processed_text_len = DEFAULT_CONFIG['text_processing']['min_processed_text_length']
    
    needs_full_text = (n_topics is None and 
                      method.lower() not in ['hdp', 'top2vec', 'bertopic'])
    
    if needs_full_text:
        processed_text = preprocess_text(raw_text, language, custom_stopwords, lemmatizer)
        if len(processed_text.strip()) < min_processed_text_len:
            print("Error: After preprocessing, document text is too short for analysis", file=sys.stderr)
            sys.exit(1)
    
    # Load seed words if using guided-lda or corex
    seed_topics = None
    if method.lower() in ['guided-lda', 'corex']:
        if seed_words_file:
            seed_topics = load_seed_words_from_markdown(seed_words_file)
            print(f"Loaded seed words for {len(seed_topics)} topics")
            for topic_name, words in seed_topics.items():
                print(f"  - {topic_name}: {', '.join(words[:5])}{'...' if len(words) > 5 else ''}")
        elif method.lower() == 'guided-lda':
            print("Error: Guided LDA requires --seed-words-file parameter", file=sys.stderr)
            sys.exit(1)
        elif method.lower() == 'corex':
            print("Note: CorEx can work without seed words, but seed words (anchors) improve topic quality")
    
    # Determine optimal number of topics
    if n_topics is None:
        if method.lower() == 'hdp':
            print("Using HDP - number of topics will be discovered automatically")
        elif method.lower() == 'corex':
            if seed_topics:
                num_seed_topics = len(seed_topics)
                print(f"Found {num_seed_topics} topics with seed words (anchors)")
                n_topics = num_seed_topics
                print(f"Using {n_topics} topics based on seed words")
            else:
                n_topics = determine_optimal_topics(processed_text)
                print(f"Auto-detected optimal number of topics for CorEx: {n_topics}")
        elif method.lower() == 'lsi' or method.lower() == 'lsa':
            if n_topics is None:
                n_topics = determine_optimal_topics(processed_text)
                print(f"Auto-detected optimal number of topics for LSI/LSA: {n_topics}")
            else:
                print(f"Using {n_topics} topics for LSI/LSA")
        elif method.lower() == 'top2vec':
            print(f"Top2Vec using embedding model: {top2vec_embedding_model}")
            if n_topics is None:
                print("Top2Vec will discover topics automatically")
                n_topics = None
            else:
                print(f"Using Top2Vec with target of {n_topics} topics")
        elif method.lower() == 'bertopic':
            if n_topics is None:
                bertopic_nr_topics = 'auto'
                print("BERTopic will discover topics automatically")
            else:
                bertopic_nr_topics = n_topics
                print(f"BERTopic will target {n_topics} topics")
        else:
            # For LDA, NMF, Guided LDA
            n_topics = determine_optimal_topics(processed_text)
            print(f"Auto-detected optimal number of topics: {n_topics}")
    else:
        print(f"Using {n_topics} topics")
    
    # Perform topic modeling
    print(f"Performing {method.upper()} topic modeling...")
    
    try:
        topics, model, vectorizer, W = perform_topic_modeling(
            processed_sections,
            method=method,
            n_topics=n_topics,
            language=language,
            custom_stopwords=custom_stopwords,
            seed_topics=seed_topics,
            hdp_gamma=hdp_gamma,
            hdp_alpha=hdp_alpha,
            top2vec_embedding_model=top2vec_embedding_model,
            bertopic_min_topic_size=bertopic_min_topic_size,
            bertopic_top_n_words=bertopic_top_n_words,
            bertopic_diversity=bertopic_diversity,
            bertopic_calculate_probabilities=bertopic_calculate_probabilities,
            bertopic_embedding_model=bertopic_embedding_model
        )
    except Exception as e:
        print(f"Error during topic modeling: {str(e)}", file=sys.stderr)
        import traceback
        traceback.print_exc(file=sys.stderr)
        sys.exit(1)
    
    # W is the document-topic matrix (shape: n_sections x n_topics)
    doc_topic_matrix = W
    
    print(f"Extracted {len(topics)} topics")
    
    # Calculate statistics
    stats = analyze_text_statistics(raw_text)
    
    # Prepare images directory
    if images_dir is None:
        images_dir = output_path_obj.parent / 'images'
    else:
        images_dir = Path(images_dir)
    images_dir.mkdir(parents=True, exist_ok=True)
    
    # Generate visualizations
    print("Generating visualizations...")
    chart_paths = {}
    
    # Calculate word frequencies for top words list
    all_words = ' '.join(processed_sections).split()
    word_freq = Counter(all_words)
    top_words_list = word_freq.most_common(50)  # Get top 50 for report
    
    try:
        # Topic distribution chart
        if doc_topic_matrix is not None and len(doc_topic_matrix) > 0:
            dist_chart_path = images_dir / 'topic_distribution.png'
            chart_paths['distribution'] = create_topic_distribution_chart(
                doc_topic_matrix, str(dist_chart_path)
            )
        
        # Topic words chart
        topic_words_path = images_dir / 'topic_words.png'
        chart_paths['words'] = create_topic_word_chart(
            topics, str(topic_words_path)
        )
        
        # Heatmap - showing topic distribution across sections
        if doc_topic_matrix is not None and len(doc_topic_matrix) > 0:
            # Truncate section labels if needed
            section_labels_truncated = [label[:40] + '...' if len(label) > 40 else label 
                                       for label in section_labels]
            heatmap_path = images_dir / 'topic_heatmap.png'
            chart_paths['heatmap'] = create_topic_heatmap(
                doc_topic_matrix, str(heatmap_path), section_labels=section_labels_truncated
            )
        
        # Word frequency chart
        word_freq_chart_path = images_dir / 'word_frequency.png'
        chart_paths['word_freq'] = create_word_frequency_chart(
            top_words_list, str(word_freq_chart_path)
        )
        
        # Word cloud
        wordcloud_path = images_dir / 'word_cloud.png'
        chart_paths['wordcloud'] = create_word_cloud(
            top_words_list, str(wordcloud_path), title="Word Cloud - Most Frequent Words"
        )
        
        # Topic map (if we have enough topics)
        if len(topics) >= 2 and doc_topic_matrix is not None:
            topic_map_path = images_dir / 'topic_map.png'
            chart_paths['topic_map'] = create_topic_map(
                topics, doc_topic_matrix, str(topic_map_path)
            )
        
        # Word-Topic Network
        word_topic_network_path = images_dir / 'word_topic_network.png'
        chart_paths['word_topic_network'] = create_word_topic_network(
            topics, str(word_topic_network_path)
        )
        
        # Topic Co-occurrence Network
        if len(topics) >= 2 and doc_topic_matrix is not None:
            topic_cooccurrence_path = images_dir / 'topic_cooccurrence_network.png'
            chart_paths['topic_cooccurrence_network'] = create_topic_cooccurrence_network(
                topics, doc_topic_matrix, str(topic_cooccurrence_path)
            )
        
        # Word Co-occurrence Network
        word_cooccurrence_path = images_dir / 'word_cooccurrence_network.png'
        chart_paths['word_cooccurrence_network'] = create_word_cooccurrence_network(
            topics, str(word_cooccurrence_path)
        )
        
    except Exception as e:
        print(f"Warning: Some visualizations could not be generated: {str(e)}", file=sys.stderr)
        if VERBOSE:
            import traceback
            traceback.print_exc(file=sys.stderr)
    
    # Generate markdown report
    print(f"Generating markdown report: {output_path}")
    
    try:
        generate_markdown_report(
            output_path=str(output_path_obj),
            topics=topics,
            stats=stats,
            top_words=top_words_list[:20],  # Pass list of (word, freq) tuples
            chart_paths=chart_paths,
            source_file=str(input_path),
            images_dir=str(images_dir),
            method=method,
            n_topics=n_topics,
            custom_stopwords_file=custom_stopwords_file,
            seed_words_file=seed_words_file,
            hdp_gamma=hdp_gamma,
            hdp_alpha=hdp_alpha,
            top2vec_embedding_model=top2vec_embedding_model,
            bertopic_min_topic_size=bertopic_min_topic_size,
            bertopic_top_n_words=bertopic_top_n_words,
            bertopic_diversity=bertopic_diversity,
            bertopic_calculate_probabilities=bertopic_calculate_probabilities,
            bertopic_embedding_model=bertopic_embedding_model
        )
    except Exception as e:
        print(f"Error generating report: {str(e)}", file=sys.stderr)
        import traceback
        traceback.print_exc(file=sys.stderr)
        sys.exit(1)
    
    print("Topic analysis completed successfully!")
    print(f"Report saved to: {output_path}")
    print(f"Images saved to: {images_dir}")

