"""CLI for extracting audio from video to MP3. Obsidian or direct args."""

import argparse
import os
import sys
from pathlib import Path

from . import common
from ..audio.extract import extract_audio as run_extract_audio
from ..audio.extract import is_video_file
from ..audio.ffmpeg_utils import get_ffmpeg_path


def main() -> None:
    common.setup_console_encoding()
    parser = argparse.ArgumentParser(
        description="Extract audio from video to MP3 (16kHz, mono, 64k)."
    )
    parser.add_argument("--vault-path", type=str, help="Obsidian vault path (Obsidian mode)")
    parser.add_argument("--file-path", type=str, help="Absolute path to video file (Obsidian mode)")
    parser.add_argument("--file-name", type=str, help="Name of the video file (Obsidian mode)")
    parser.add_argument("file", type=str, nargs="?", help="Video file (direct mode)")
    parser.add_argument("--output-dir", type=str, help="Output directory for MP3 (direct mode)")
    args = parser.parse_args()

    vault_path = common.get_optional_param(args.vault_path)
    file_path_arg = common.get_optional_param(args.file_path)
    file_name_arg = common.get_optional_param(args.file_name)
    direct_file = common.get_optional_param(args.file)
    output_dir_arg = common.get_optional_param(args.output_dir)

    if vault_path and file_path_arg and file_name_arg:
        vault = common.fix_path(vault_path)
        file_abs = common.fix_path(file_path_arg)
        file_name = common.sanitize_name(file_name_arg)
        if not os.path.isdir(vault):
            common.safe_print(f"Error: Vault path not found: {vault}", file=sys.stderr)
            sys.exit(1)
        out_dir = os.path.dirname(file_abs)
        stem = Path(file_name).stem
        out_file = os.path.join(out_dir, f"{stem}.mp3")
    elif direct_file:
        file_abs = common.fix_path(direct_file)
        if not os.path.isfile(file_abs):
            common.safe_print(f"Error: File not found: {file_abs}", file=sys.stderr)
            sys.exit(1)
        file_name = os.path.basename(file_abs)
        stem = Path(file_name).stem
        if output_dir_arg:
            out_dir = common.fix_path(output_dir_arg)
            os.makedirs(out_dir, exist_ok=True)
            out_file = os.path.join(out_dir, f"{stem}.mp3")
        else:
            out_dir = os.path.dirname(file_abs)
            out_file = os.path.join(out_dir, f"{stem}.mp3")
    else:
        common.safe_print(
            "Error: Use --vault-path, --file-path, --file-name (Obsidian) or pass video file (direct).",
            file=sys.stderr,
        )
        parser.print_help(sys.stderr)
        sys.exit(1)

    if not os.path.isfile(file_abs):
        common.safe_print(f"Error: File not found: {file_abs}", file=sys.stderr)
        sys.exit(1)

    ext = Path(file_name).suffix if file_name else Path(file_abs).suffix or ""
    if not is_video_file(ext):
        common.safe_print(f"Error: Not a video file (extension: {ext}).", file=sys.stderr)
        sys.exit(1)

    ffmpeg_bin = get_ffmpeg_path()
    if not run_extract_audio(file_abs, out_file, ffmpeg_bin):
        common.safe_print("Error: ffmpeg failed to extract audio.", file=sys.stderr)
        sys.exit(1)

    common.safe_print(f"Extracted audio: {out_file}")
