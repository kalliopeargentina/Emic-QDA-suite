"""Emotion analysis CLI. Env vars must be set before algorithms (transformers/pysentimiento) load."""
import os
os.environ["USE_TF"] = "0"
os.environ["USE_TORCH"] = "1"
os.environ["TF_ENABLE_ONEDNN_OPTS"] = "0"

import argparse
from pathlib import Path
from typing import Dict

from .config import DEFAULTS
from .corpus_processing import extract_documents_from_folder
from .text_processing import extract_text_from_markdown_content, split_sentences, split_paragraphs
from .algorithms import BACKENDS, _get_backend_class
from .algorithms.base import aggregate_labels
from .visualizations import (
    create_emotion_bar_chart, 
    create_emotion_radar_chart, 
    create_emotion_wordclouds,
    create_emotion_sankey_diagram,
    create_emotion_heatmap,
    create_corpus_emotion_heatmap
)
from .explanations import get_emotion_analysis_explanation
import torch

try:
    from ..topic_analysis.nlp_utils import detect_language
except Exception:
    from langdetect import detect as _ld_detect
    def detect_language(text: str) -> str:
        try:
            code = _ld_detect(text[:1000] if len(text) > 1000 else text)
        except Exception:
            return "english"
        mapping = {"es": "spanish", "en": "english", "fr": "french", "de": "german", "it": "italian", "pt": "portuguese"}
        return mapping.get(code, "english")


def _load_backend(name: str, **params):
    cls = _get_backend_class(name)
    return cls(**params)


def _aggregate_mode(text: str, aggregate: str, backend, lang_hint: str | None) -> Dict:
    if aggregate == "document":
        lang = lang_hint
        if backend.name.startswith("pysentimiento"):
            short = {"spanish":"es","english":"en","french":"fr","german":"de","italian":"it","portuguese":"pt"}.get(lang or "spanish","es")
            return backend.predict(text, lang=short)
        else:
            return backend.predict(text, lang=lang)
    parts = split_sentences(text) if aggregate == "sentence" else split_paragraphs(text)
    results = []
    for part in parts:
        lang = detect_language(part)
        if backend.name.startswith("pysentimiento"):
            short = {"spanish":"es","english":"en","french":"fr","german":"de","italian":"it","portuguese":"pt"}.get(lang,"es")
            results.append(backend.predict(part, lang=short))
        else:
            results.append(backend.predict(part, lang=lang))
    dist = aggregate_labels(results)
    label = max(dist.items(), key=lambda x: x[1])[0] if dist else "neutral"
    return {"label": label, "distribution": dist, "parts": len(parts)}


def run_file(md_file: Path, backend_name: str, params: Dict, aggregate: str) -> Dict:
    text = extract_text_from_markdown_content(md_file.read_text(encoding="utf-8"))
    backend = _load_backend(backend_name, **params)
    lang_name = detect_language(text)
    return _aggregate_mode(text, aggregate, backend, lang_name)


def run_folder(folder: Path, backend_name: str, params: Dict, aggregate: str,
               recursive: bool, file_pattern: str, min_document_length: int) -> Dict:
    docs = extract_documents_from_folder(folder, recursive, file_pattern, min_document_length)
    backend = _load_backend(backend_name, **params)
    results = []
    for d in docs:
        lang_name = detect_language(d["clean_text"])
        res = _aggregate_mode(d["clean_text"], aggregate, backend, lang_name)
        results.append({"file_name": d["file_name"], **res, "detected_language": lang_name})
    if aggregate == "document":
        corpus_dist = aggregate_labels(results)
    else:
        from collections import Counter
        acc = Counter()
        for r in results:
            for k, v in r["distribution"].items():
                acc[k] += v
        total = sum(acc.values()) or 1
        corpus_dist = {k: v / total for k, v in acc.items()}
    return {"results": results, "corpus_distribution": corpus_dist}


def main():
    p = argparse.ArgumentParser(description="Emotion analysis (joy, sadness, anger, fear, etc.) with language autodetect")
    p.add_argument("input_path", type=str)
    p.add_argument("--algo", type=lambda x: x.strip(), choices=["pysentimiento-emotion", "transformers-emotion"], default="pysentimiento-emotion")
    p.add_argument("--model", default=None)
    p.add_argument("--device", type=str, default=None, help="Dispositivo: 0/1... | cuda | cpu | -1 (transformers usa entero)")
    p.add_argument("--max-length", type=int, default=DEFAULTS["max_length"])
    p.add_argument("--aggregate", choices=["document", "sentence", "paragraph"], default=DEFAULTS["aggregate"])
    p.add_argument("--file-pattern", default="*.md")
    p.add_argument("--no-recursive", action="store_true")
    p.add_argument("--min-document-length", type=int, default=DEFAULTS["min_document_length"])
    p.add_argument("--output", type=str, default=None, help="Ruta del archivo Markdown o carpeta de salida para el informe")
    p.add_argument("--top-k", type=int, default=5, help="Número de párrafos por emoción a incluir en el informe")
    p.add_argument("--min-score", type=float, default=0.0, help="Puntaje mínimo para incluir un párrafo (0.0-1.0, default: 0.0)")
    p.add_argument("--min-confidence", type=float, default=0.0, help="Confianza mínima de la etiqueta predicha (0.0-1.0, default: 0.0)")
    p.add_argument("--min-score-diff", type=float, default=0.0, help="Diferencia mínima entre la mejor y segunda mejor etiqueta (0.0-1.0, default: 0.0)")
    p.add_argument("--min-paragraph-length", type=int, default=20, help="Longitud mínima del párrafo en caracteres (default: 20)")
    p.add_argument("--corpus-report", action="store_true", help="Generar reporte consolidado del corpus completo (solo cuando se procesa una carpeta)")
    args = p.parse_args()

    params = {}
    if "transformers" in args.algo:
        if args.model: params["model"] = args.model
        if args.device is not None:
            dv = str(args.device).lower()
            if dv in ("cpu", "-1"):
                params["device"] = -1
            elif dv in ("cuda", "gpu"):
                # Verify CUDA is available before using device 0
                if torch.cuda.is_available():
                    params["device"] = 0
                else:
                    print("⚠️ CUDA requested but not available. Using CPU instead.")
                    params["device"] = -1
            else:
                try:
                    device_num = int(args.device)
                    # Verify the specific device exists
                    if device_num >= 0:
                        if torch.cuda.is_available() and device_num < torch.cuda.device_count():
                            params["device"] = device_num
                        else:
                            if not torch.cuda.is_available():
                                print(f"⚠️ CUDA device {device_num} requested but CUDA is not available. Using CPU instead.")
                            else:
                                print(f"⚠️ CUDA device {device_num} requested but only {torch.cuda.device_count()} device(s) available. Using CPU instead.")
                            params["device"] = -1
                    else:
                        params["device"] = -1
                except Exception:
                    params["device"] = 0 if torch.cuda.is_available() else -1
        params["max_length"] = args.max_length
    else:
        if args.model: params["model"] = args.model
        if args.device is not None:
            dv = str(args.device).lower()
            if dv in ("cpu", "-1"):
                params["device"] = "cpu"
            elif dv in ("cuda", "gpu") or dv.isdigit():
                params["device"] = "cuda" if torch.cuda.is_available() else "cpu"
            else:
                params["device"] = "cuda" if torch.cuda.is_available() else "cpu"

    path = Path(args.input_path)
    def _ensure_output_path(base_input: Path, output_opt: str | None, suffix: str) -> Path:
        if not output_opt:
            return base_input.with_suffix(suffix)
        outp = Path(output_opt)
        if outp.exists() and outp.is_dir():
            return outp / (base_input.stem + suffix)
        outp.parent.mkdir(parents=True, exist_ok=True)
        return outp

    def _get_relative_path_str(image_path: Path, md_path: Path) -> str:
        """
        Obtiene la ruta relativa de una imagen respecto al markdown y la convierte a string
        con barras diagonales para compatibilidad con markdown.
        
        Args:
            image_path: Path completo de la imagen
            md_path: Path del archivo markdown
            
        Returns:
            String con la ruta relativa usando barras diagonales
        """
        try:
            rel_path = image_path.relative_to(md_path.parent)
            return str(rel_path).replace("\\", "/")
        except (ValueError, AttributeError):
            # Fallback: usar solo el nombre del archivo
            return image_path.name

    def _generate_image_filename(base_path: Path, operation_type: str, chart_type: str, images_dir: Path | None = None) -> Path:
        """
        Genera un nombre corto para imágenes siguiendo el formato:
        primeros 10 caracteres del archivo + "_" + tipo operación + "_" + tipo gráfico
        
        Args:
            base_path: Path base del archivo (ej: "documento.md")
            operation_type: Tipo de operación ("sentiment" o "emotion")
            chart_type: Tipo de gráfico ("chart", "sankey", "heatmap", "radar", "wordcloud", etc.)
            images_dir: Directorio donde guardar la imagen (opcional, por defecto mismo directorio que el markdown)
        
        Returns:
            Path completo del archivo de imagen
        """
        # Obtener el nombre del archivo sin extensión y sin espacios
        stem = base_path.stem.replace(" ", "_")
        
        # Tomar primeros 10 caracteres (o menos si el nombre es más corto)
        short_name = stem[:10] if len(stem) > 10 else stem
        
        # Construir el nombre: short_name_operation_chart.png
        image_name = f"{short_name}_{operation_type}_{chart_type}.png"
        
        # Si se especifica un directorio de imágenes, usar ese; sino usar el directorio del markdown
        target_dir = images_dir if images_dir else base_path.parent
        
        return target_dir / image_name

    def _write_markdown_report(md_path: Path, doc_title: str, text: str, backend_name: str, params: dict, top_k: int, source_path: Path | None = None, min_score: float = 0.0, min_confidence: float = 0.0, min_score_diff: float = 0.0, min_paragraph_length: int = 20):
        backend = _load_backend(backend_name, **params)
        lang_name = detect_language(text)
        # Document-level using backend directly
        if backend.name.startswith("pysentimiento"):
            short = {"spanish":"es","english":"en","french":"fr","german":"de","italian":"it","portuguese":"pt"}.get(lang_name or "spanish","es")
            doc_pred = backend.predict(text, lang=short)
        else:
            doc_pred = backend.predict(text, lang=lang_name)
        label = doc_pred.get("label")
        scores = doc_pred.get("scores")
        # Paragraph-level scoring
        paragraphs = split_paragraphs(text)
        # Map paragraph to nearest section header
        header_by_paragraph = {}
        try:
            from ..topic_analysis.text_processing import extract_sections_with_headers as _extract_sections
            if source_path and source_path.exists():
                secs = _extract_secs_with_clean(source_path)
            else:
                secs = []
        except Exception:
            secs = []
        if not secs:
            secs = [{"header": "Documento", "paragraphs": paragraphs}]
        p_idx = 1
        for sec in secs:
            for _ in sec["paragraphs"]:
                header_by_paragraph[p_idx] = sec["header"]
                p_idx += 1
        # Discover label set
        label_keys = set()
        for ptxt in paragraphs[: min(len(paragraphs), 10)]:
            clang = detect_language(ptxt)
            lang_arg = {"spanish":"es","english":"en","french":"fr","german":"de","italian":"it","portuguese":"pt"}.get(clang, "es")
            # Ensure lang_arg is supported by backend (fallback to "es" if not)
            if lang_arg not in ("es", "en", "it", "pt"):
                lang_arg = "es"
            pred = backend.predict(ptxt, lang=lang_arg)
            label_keys.update(pred["scores"].keys())
        # Score all paragraphs with filtering
        scored = []
        for idx, ptxt in enumerate(paragraphs, start=1):
            if not ptxt.strip():
                continue
            # Filter by minimum length
            if len(ptxt.strip()) < min_paragraph_length:
                continue
            
            clang = detect_language(ptxt)
            lang_arg = {"spanish":"es","english":"en","french":"fr","german":"de","italian":"it","portuguese":"pt"}.get(clang, "es")
            # Ensure lang_arg is supported by backend (fallback to "es" if not)
            if lang_arg not in ("es", "en", "it", "pt"):
                lang_arg = "es"
            pred = backend.predict(ptxt, lang=lang_arg)
            scores = pred.get("scores", {})
            label = pred.get("label", "others")
            
            # Handle label if it's a list
            if isinstance(label, list):
                label = label[0] if label else "others"
            
            # Ensure scores is a dict
            if not isinstance(scores, dict):
                if isinstance(scores, list):
                    scores = {f"class_{i}": score for i, score in enumerate(scores)}
                else:
                    scores = {}
            
            # Get top two scores for difference check
            sorted_scores = sorted(scores.items(), key=lambda x: x[1], reverse=True) if scores else []
            top_score = sorted_scores[0][1] if sorted_scores else 0.0
            second_score = sorted_scores[1][1] if len(sorted_scores) > 1 else 0.0
            
            # Apply filters
            label_score = scores.get(label, 0.0) if isinstance(scores, dict) and isinstance(label, str) else 0.0
            
            # Check minimum score threshold
            if min_score > 0 and label_score < min_score:
                continue
            
            # Check minimum confidence (top score must be above threshold)
            if min_confidence > 0 and top_score < min_confidence:
                continue
            
            # Check minimum score difference
            if min_score_diff > 0 and (top_score - second_score) < min_score_diff:
                continue
            
            # Store with predicted label for word cloud generation
            scored.append((idx, ptxt, scores, label))
        # Top-K per emotion
        selected = {}
        for lab in sorted(label_keys):
            ranked = sorted(scored, key=lambda t: float(t[2].get(lab, 0.0)), reverse=True)
            # Apply min_score filter when selecting top-K per emotion
            top = [(i, p, float(s.get(lab, 0.0))) for i, p, s, _ in ranked[:top_k] 
                   if float(s.get(lab, 0.0)) > 0.0 and float(s.get(lab, 0.0)) >= min_score]
            if top:
                selected[lab] = top
        # Build markdown
        lines = []
        lines.append(f"# Informe de análisis de emociones - {doc_title}")
        lines.append("")
        lines.append(f"- Backend: `{backend_name}`")
        lines.append(f"- Idioma detectado: `{lang_name}`")
        lines.append("")
        
        # Add methodology explanation
        model_name = params.get("model") or (backend.model_name if hasattr(backend, "model_name") else None)
        explanation_lines = get_emotion_analysis_explanation(backend_name, model_name)
        lines.extend(explanation_lines)
        lines.append("")
        lines.append("---")
        lines.append("")
        
        # Create images directory for all visualizations (chart, radar, sankey, heatmap, wordclouds)
        stem_short = md_path.stem.replace(" ", "_")[:10] if len(md_path.stem) > 10 else md_path.stem.replace(" ", "_")
        images_dir = md_path.parent / f"{stem_short}_emotion_images"
        images_dir.mkdir(parents=True, exist_ok=True)
        
        lines.append("## Predicción a nivel documento")
        lines.append("")
        lines.append(f"- Etiqueta: **{label}**")
        if scores:
            lines.append("- Distribución:")
            for k, v in sorted(scores.items()):
                lines.append(f"  - {k}: {v:.4f}")
            
            # Generate and include bar chart
            chart_path = _generate_image_filename(md_path, "emotion", "chart", images_dir)
            chart_rel_path_str = _get_relative_path_str(chart_path, md_path)
            chart_created = create_emotion_bar_chart(scores, chart_path, title=f"Distribución de Emociones - {doc_title}")
            if chart_created:
                lines.append("")
                lines.append("### Gráfico de Barras")
                lines.append("")
                lines.append("Este gráfico muestra la distribución proporcional de emociones en el documento completo. Cada barra horizontal representa la probabilidad o proporción de cada categoría emocional (joy, sadness, anger, fear, surprise, disgust, others). Los valores se muestran al lado de cada barra para facilitar la lectura. Las emociones están ordenadas por frecuencia descendente.")
                lines.append("")
                lines.append(f"![Distribución de Emociones]({chart_rel_path_str})")
            
            # Generate and include radar chart
            radar_path = _generate_image_filename(md_path, "emotion", "radar", images_dir)
            radar_rel_path_str = _get_relative_path_str(radar_path, md_path)
            radar_created = create_emotion_radar_chart(scores, radar_path, title=f"Radar de Emociones - {doc_title}")
            if radar_created:
                lines.append("")
                lines.append("### Gráfico Radar")
                lines.append("")
                lines.append("El gráfico radar (o gráfico de araña) muestra el perfil emocional del documento en un formato circular. Cada eje representa una emoción (joy, sadness, anger, fear, surprise, disgust, others) y la distancia desde el centro indica la proporción de esa emoción. El gráfico siempre usa el mismo orden de emociones para facilitar la comparación entre documentos. Los valores se muestran en cada eje con colores específicos para cada emoción.")
                lines.append("")
                lines.append(f"![Radar de Emociones]({radar_rel_path_str})")
        lines.append("")
        lines.append(f"## Top {top_k} párrafos por emoción")
        lines.append("")
        for lab in sorted(selected.keys()):
            lines.append(f"### {lab}")
            for idx, ptxt, sc in selected[lab]:
                lines.append(f"- Párrafo {idx} (puntaje: {sc:.4f})")
                lines.append("")
                # Fix: can't use backslashes in f-string expressions, extract to variable
                newline = '\n'
                formatted_text = ptxt.strip().replace(newline, f'{newline}> ')
                lines.append(f"> {formatted_text}")
                if source_path:
                    header = header_by_paragraph.get(idx, "Documento")
                    anchor = header.strip().lower().replace(' ', '-')
                    lines.append("")
                    lines.append(f"[Abrir sección en documento original]({source_path}#{anchor})")
                lines.append("")
        
        # Generate word clouds for each emotion (use all paragraphs that passed filters, grouped by predicted emotion)
        paragraphs_by_emotion = {}
        for idx, ptxt, scores, pred_label in scored:
            if pred_label:
                if pred_label not in paragraphs_by_emotion:
                    paragraphs_by_emotion[pred_label] = []
                paragraphs_by_emotion[pred_label].append(ptxt)
        
        if paragraphs_by_emotion:
            # Use the same images directory for wordclouds
            wordcloud_paths = create_emotion_wordclouds(paragraphs_by_emotion, images_dir, lang=lang_name)
            
            if any(wordcloud_paths.values()):
                lines.append("")
                lines.append("## Nubes de palabras por emoción")
                lines.append("")
                lines.append("Las nubes de palabras muestran las palabras más relevantes y específicas para cada categoría emocional. El tamaño de cada palabra es proporcional a su frecuencia e importancia para esa emoción específica.")
                lines.append("")
                lines.append("**Metodología de filtrado inteligente:**")
                lines.append("- Se utiliza un enfoque similar a TF-IDF para calcular la especificidad de cada palabra a cada emoción")
                lines.append("- Las palabras que aparecen en múltiples categorías emocionales son filtradas o penalizadas")
                lines.append("- Solo se incluyen palabras con alta especificidad a la emoción correspondiente")
                lines.append("- Esto asegura que cada nube de palabras muestre únicamente términos relevantes y distintivos para esa emoción")
                lines.append("")
                for lab in sorted(paragraphs_by_emotion.keys()):
                    if wordcloud_paths.get(lab) and wordcloud_paths[lab]:
                        try:
                            wc_rel_path = wordcloud_paths[lab].relative_to(md_path.parent)
                            # Convert to string with forward slashes for markdown compatibility
                            wc_rel_path_str = str(wc_rel_path).replace("\\", "/")
                        except (ValueError, AttributeError):
                            # Fallback: use the directory name + filename
                            wc_rel_path_str = f"{images_dir.name}/{wordcloud_paths[lab].name}".replace("\\", "/")
                        lines.append(f"### {lab}")
                        lines.append("")
                        lines.append(f"![Nube de palabras - {lab}]({wc_rel_path_str})")
                        lines.append("")
        
        # Generate temporal visualizations (Sankey and heatmap)
        if scored:
            # Sort by paragraph index to maintain temporal order
            sorted_scored = sorted(scored, key=lambda x: x[0])
            
            # Prepare data for Sankey diagram (paragraph labels in order)
            paragraph_labels = []
            for idx, ptxt, scores, pred_label in sorted_scored:
                if pred_label:
                    paragraph_labels.append(pred_label)
            
            if len(paragraph_labels) >= 2:
                # Create Sankey diagram
                sankey_path = _generate_image_filename(md_path, "emotion", "sankey", images_dir)
                sankey_created = create_emotion_sankey_diagram(paragraph_labels, sankey_path, title=f"Flujo de Emociones - {doc_title}")
                if sankey_created:
                    # Check if it's HTML or PNG
                    if str(sankey_created).endswith('.html'):
                        sankey_rel_path_str = _get_relative_path_str(sankey_created, md_path)
                        lines.append("")
                        lines.append("## Visualización Temporal de Emociones")
                        lines.append("")
                        lines.append("### Diagrama Sankey")
                        lines.append("")
                        lines.append("El diagrama Sankey muestra el flujo de emociones a lo largo del documento. Cada párrafo (P1, P2, P3...) está conectado a su emoción predicha, permitiendo visualizar cómo cambian las emociones a medida que se avanza en la lectura del documento. El grosor de las conexiones indica la cantidad de párrafos con cada transición emocional.")
                        lines.append("")
                        lines.append(f"[Ver diagrama Sankey interactivo]({sankey_rel_path_str})")
                        lines.append("")
                    else:
                        sankey_rel_path_str = _get_relative_path_str(sankey_created, md_path)
                        lines.append("")
                        lines.append("## Visualización Temporal de Emociones")
                        lines.append("")
                        lines.append("### Diagrama Sankey")
                        lines.append("")
                        lines.append("El diagrama Sankey muestra el flujo de emociones a lo largo del documento. Cada párrafo (P1, P2, P3...) está conectado a su emoción predicha, permitiendo visualizar cómo cambian las emociones a medida que se avanza en la lectura del documento. El grosor de las conexiones indica la cantidad de párrafos con cada transición emocional.")
                        lines.append("")
                        lines.append(f"![Flujo de Emociones]({sankey_rel_path_str})")
                        lines.append("")
            
            # Prepare data for heatmap
            paragraph_data = []
            for idx, ptxt, scores, pred_label in sorted_scored:
                if pred_label:
                    paragraph_data.append({
                        'index': idx,
                        'label': pred_label,
                        'scores': scores
                    })
            
            if paragraph_data:
                # Create heatmap
                heatmap_path = _generate_image_filename(md_path, "emotion", "heatmap", images_dir)
                heatmap_rel_path_str = _get_relative_path_str(heatmap_path, md_path)
                heatmap_created = create_emotion_heatmap(paragraph_data, heatmap_path, title=f"Distribución de Emociones - {doc_title}")
                if heatmap_created:
                    if len(paragraph_labels) < 2:
                        lines.append("")
                        lines.append("## Visualización Temporal de Emociones")
                        lines.append("")
                    lines.append("### Heatmap")
                    lines.append("")
                    lines.append("El heatmap muestra la distribución de emociones a lo largo del documento de forma matricial. Cada fila representa un párrafo (ordenados secuencialmente) y cada columna representa una emoción (joy, sadness, anger, fear, surprise, disgust, others). Los colores indican la intensidad de la emoción: colores más intensos indican mayor probabilidad. Los valores numéricos muestran los scores de confianza del modelo para cada emoción en cada párrafo.")
                    lines.append("")
                    lines.append(f"![Distribución de Emociones]({heatmap_rel_path_str})")
                    lines.append("")
        
        md_path.parent.mkdir(parents=True, exist_ok=True)
        md_path.write_text("\n".join(lines), encoding="utf-8")

    def _write_corpus_report(md_path: Path, corpus_name: str, docs: list, backend_name: str, params: dict, top_k: int, min_score: float = 0.0, min_confidence: float = 0.0, min_score_diff: float = 0.0, min_paragraph_length: int = 20):
        """Generate consolidated corpus report from multiple documents."""
        backend = _load_backend(backend_name, **params)
        
        # Combine all documents
        all_paragraphs = []
        for doc in docs:
            text = doc["clean_text"]
            paragraphs = split_paragraphs(text)
            for para in paragraphs:
                if para.strip() and len(para.strip()) >= min_paragraph_length:
                    all_paragraphs.append({
                        "text": para,
                        "doc_name": doc["file_name"],
                        "doc_path": doc.get("file_path")
                    })
        
        if not all_paragraphs:
            md_path.parent.mkdir(parents=True, exist_ok=True)
            md_path.write_text(f"# Informe consolidado de emociones - {corpus_name}\n\nNo se encontraron párrafos válidos.", encoding="utf-8")
            return
        
        # Corpus-level prediction (combine all text)
        combined_text = "\n\n".join([p["text"] for p in all_paragraphs])
        lang_name = detect_language(combined_text)
        
        if backend.name.startswith("pysentimiento"):
            short = {"spanish":"es","english":"en","french":"fr","german":"de","italian":"it","portuguese":"pt"}.get(lang_name or "spanish","es")
            if short not in ("es", "en", "it", "pt"):
                short = "es"
            corpus_pred = backend.predict(combined_text, lang=short)
        else:
            corpus_pred = backend.predict(combined_text, lang=lang_name)
        
        corpus_label = corpus_pred.get("label")
        corpus_scores = corpus_pred.get("scores")
        
        # Score all paragraphs
        scored = []
        for para_info in all_paragraphs:
            ptxt = para_info["text"]
            clang = detect_language(ptxt)
            lang_arg = {"spanish":"es","english":"en","french":"fr","german":"de","italian":"it","portuguese":"pt"}.get(clang, "es")
            if lang_arg not in ("es", "en", "it", "pt"):
                lang_arg = "es"
            
            pred = backend.predict(ptxt, lang=lang_arg)
            scores = pred.get("scores", {})
            label = pred.get("label", "others")
            
            if isinstance(label, list):
                label = label[0] if label else "others"
            
            if not isinstance(scores, dict):
                if isinstance(scores, list):
                    scores = {f"class_{i}": score for i, score in enumerate(scores)}
                else:
                    scores = {}
            
            sorted_scores = sorted(scores.items(), key=lambda x: x[1], reverse=True) if scores else []
            top_score = sorted_scores[0][1] if sorted_scores else 0.0
            second_score = sorted_scores[1][1] if len(sorted_scores) > 1 else 0.0
            label_score = scores.get(label, 0.0) if isinstance(scores, dict) and isinstance(label, str) else 0.0
            
            # Apply filters
            if min_score > 0 and label_score < min_score:
                continue
            if min_confidence > 0 and top_score < min_confidence:
                continue
            if min_score_diff > 0 and (top_score - second_score) < min_score_diff:
                continue
            
            # Store with predicted label for word cloud generation
            scored.append((para_info, scores, label))
        
        # Discover label set
        label_keys = set()
        for _, scores, _ in scored[:min(len(scored), 20)]:
            label_keys.update(scores.keys())
        
        # Top-K per emotion across corpus
        selected = {}
        for lab in sorted(label_keys):
            ranked = sorted(scored, key=lambda t: float(t[1].get(lab, 0.0)), reverse=True)
            top = [(para_info, float(s.get(lab, 0.0))) for para_info, s, _ in ranked[:top_k] 
                   if float(s.get(lab, 0.0)) > 0.0 and float(s.get(lab, 0.0)) >= min_score]
            if top:
                selected[lab] = top
        
        # Calculate individual document predictions
        doc_predictions = []
        for doc in docs:
            doc_text = doc["clean_text"]
            doc_lang = detect_language(doc_text)
            if backend.name.startswith("pysentimiento"):
                short = {"spanish":"es","english":"en","french":"fr","german":"de","italian":"it","portuguese":"pt"}.get(doc_lang or "spanish","es")
                if short not in ("es", "en", "it", "pt"):
                    short = "es"
                doc_pred = backend.predict(doc_text, lang=short)
            else:
                doc_pred = backend.predict(doc_text, lang=doc_lang)
            doc_predictions.append({
                "name": doc["file_name"],
                "path": doc.get("file_path"),
                "label": doc_pred.get("label"),
                "scores": doc_pred.get("scores")
            })
        
        # Build markdown
        lines = []
        lines.append(f"# Informe consolidado de análisis de emociones - {corpus_name}")
        lines.append("")
        lines.append(f"- Backend: `{backend_name}`")
        lines.append(f"- Total de documentos: {len(docs)}")
        lines.append(f"- Total de párrafos analizados: {len(all_paragraphs)}")
        lines.append(f"- Párrafos que pasaron los filtros: {len(scored)}")
        lines.append(f"- Idioma detectado: `{lang_name}`")
        lines.append("")
        
        # Add methodology explanation
        model_name = params.get("model") or (backend.model_name if hasattr(backend, "model_name") else None)
        explanation_lines = get_emotion_analysis_explanation(backend_name, model_name)
        lines.extend(explanation_lines)
        lines.append("")
        lines.append("---")
        lines.append("")
        
        # Create images directory for all visualizations (chart, radar, heatmap, wordclouds)
        stem_short = md_path.stem.replace(" ", "_")[:10] if len(md_path.stem) > 10 else md_path.stem.replace(" ", "_")
        images_dir = md_path.parent / f"{stem_short}_emotion_images"
        images_dir.mkdir(parents=True, exist_ok=True)
        
        lines.append("## Predicción a nivel de corpus")
        lines.append("")
        lines.append(f"- Etiqueta: **{corpus_label}**")
        if corpus_scores:
            lines.append("- Distribución:")
            for k, v in sorted(corpus_scores.items()):
                lines.append(f"  - {k}: {v:.4f}")
            
            # Generate and include bar chart for corpus
            chart_path = _generate_image_filename(md_path, "emotion", "corpus_chart", images_dir)
            chart_rel_path_str = _get_relative_path_str(chart_path, md_path)
            chart_created = create_emotion_bar_chart(corpus_scores, chart_path, title=f"Distribución de Emociones - Corpus {corpus_name}")
            if chart_created:
                lines.append("")
                lines.append("### Gráfico de Barras del Corpus")
                lines.append("")
                lines.append("Este gráfico muestra la distribución proporcional de emociones en todo el corpus. Cada barra horizontal representa la probabilidad o proporción de cada categoría emocional calculada a partir de todos los documentos analizados.")
                lines.append("")
                lines.append(f"![Distribución de Emociones del Corpus]({chart_rel_path_str})")
            
            # Generate and include radar chart for corpus
            radar_path = _generate_image_filename(md_path, "emotion", "corpus_radar", images_dir)
            radar_rel_path_str = _get_relative_path_str(radar_path, md_path)
            radar_created = create_emotion_radar_chart(corpus_scores, radar_path, title=f"Radar de Emociones - Corpus {corpus_name}")
            if radar_created:
                lines.append("")
                lines.append("### Gráfico Radar del Corpus")
                lines.append("")
                lines.append("El gráfico radar muestra el perfil emocional de todo el corpus en un formato circular. Cada eje representa una emoción y la distancia desde el centro indica la proporción de esa emoción en el corpus completo.")
                lines.append("")
                lines.append(f"![Radar de Emociones del Corpus]({radar_rel_path_str})")
        lines.append("")
        lines.append("## Predicciones por documento")
        lines.append("")
        for doc_pred in doc_predictions:
            lines.append(f"### {doc_pred['name']}")
            lines.append("")
            lines.append(f"- Etiqueta: **{doc_pred['label']}**")
            if doc_pred['scores']:
                lines.append("- Distribución:")
                for k, v in sorted(doc_pred['scores'].items()):
                    lines.append(f"  - {k}: {v:.4f}")
            if doc_pred.get('path'):
                lines.append("")
                lines.append(f"[Abrir documento original]({doc_pred['path']})")
            lines.append("")
        lines.append("")
        lines.append(f"## Top {top_k} párrafos por emoción (corpus completo)")
        lines.append("")
        for lab in sorted(selected.keys()):
            lines.append(f"### {lab}")
            for para_info, sc in selected[lab]:
                lines.append(f"- Párrafo de **{para_info['doc_name']}** (puntaje: {sc:.4f})")
                lines.append("")
                lines.append(f"> {para_info['text'].strip().replace(chr(10), chr(10) + '> ')}")
                if para_info.get("doc_path"):
                    lines.append("")
                    lines.append(f"[Abrir documento original]({para_info['doc_path']})")
                lines.append("")
        
        # Generate word clouds for corpus (use all paragraphs that passed filters, grouped by predicted emotion)
        paragraphs_by_emotion = {}
        for para_info, scores, pred_label in scored:
            if pred_label:
                if pred_label not in paragraphs_by_emotion:
                    paragraphs_by_emotion[pred_label] = []
                paragraphs_by_emotion[pred_label].append(para_info['text'])
        
        if paragraphs_by_emotion:
            # Use the same images directory for wordclouds
            wordcloud_paths = create_emotion_wordclouds(paragraphs_by_emotion, images_dir, lang=lang_name)
            
            if any(wordcloud_paths.values()):
                lines.append("")
                lines.append("## Nubes de palabras por emoción (corpus completo)")
                lines.append("")
                lines.append("Las nubes de palabras muestran las palabras más relevantes y específicas para cada categoría emocional en todo el corpus. El tamaño de cada palabra es proporcional a su frecuencia e importancia para esa emoción específica.")
                lines.append("")
                lines.append("**Metodología de filtrado inteligente:**")
                lines.append("- Se utiliza un enfoque similar a TF-IDF para calcular la especificidad de cada palabra a cada emoción")
                lines.append("- Las palabras que aparecen en múltiples categorías emocionales son filtradas o penalizadas")
                lines.append("- Solo se incluyen palabras con alta especificidad a la emoción correspondiente")
                lines.append("- Esto asegura que cada nube de palabras muestre únicamente términos relevantes y distintivos para esa emoción")
                lines.append("")
                for lab in sorted(paragraphs_by_emotion.keys()):
                    if wordcloud_paths.get(lab) and wordcloud_paths[lab]:
                        try:
                            wc_rel_path = wordcloud_paths[lab].relative_to(md_path.parent)
                            # Convert to string with forward slashes for markdown compatibility
                            wc_rel_path_str = str(wc_rel_path).replace("\\", "/")
                        except (ValueError, AttributeError):
                            # Fallback: use the directory name + filename
                            wc_rel_path_str = f"{images_dir.name}/{wordcloud_paths[lab].name}".replace("\\", "/")
                        lines.append(f"### {lab}")
                        lines.append("")
                        lines.append(f"![Nube de palabras - {lab}]({wc_rel_path_str})")
                        lines.append("")
        
        # Generate corpus-level heatmap (emotion distribution by document)
        if doc_predictions:
            document_data = []
            for doc_pred in doc_predictions:
                document_data.append({
                    'name': doc_pred['name'],
                    'scores': doc_pred.get('scores', {})
                })
            
            if document_data:
                heatmap_path = _generate_image_filename(md_path, "emotion", "corpus_heatmap", images_dir)
                heatmap_rel_path_str = _get_relative_path_str(heatmap_path, md_path)
                heatmap_created = create_corpus_emotion_heatmap(document_data, heatmap_path, title=f"Distribución de Emociones por Documento - {corpus_name}")
                if heatmap_created:
                    lines.append("")
                    lines.append("## Distribución de Emociones por Documento")
                    lines.append("")
                    lines.append("### Heatmap")
                    lines.append("")
                    lines.append("El heatmap muestra la distribución de emociones para cada documento del corpus. Cada fila representa un documento y cada columna representa una emoción (joy, sadness, anger, fear, surprise, disgust, others). Los colores indican la intensidad de la emoción: colores más intensos indican mayor probabilidad. Los valores numéricos muestran los scores de confianza del modelo para cada emoción en cada documento. Esto permite comparar fácilmente el perfil emocional entre diferentes documentos del corpus.")
                    lines.append("")
                    lines.append(f"![Distribución de Emociones por Documento]({heatmap_rel_path_str})")
                    lines.append("")
        
        md_path.parent.mkdir(parents=True, exist_ok=True)
        md_path.write_text("\n".join(lines), encoding="utf-8")

    def _extract_secs_with_clean(src_path: Path):
        from ..topic_analysis.text_processing import extract_sections_with_headers as _extract_sections
        raw_secs = _extract_sections(src_path)
        out = []
        for s in raw_secs:
            clean = extract_text_from_markdown_content(s["raw_text"])
            paras = split_paragraphs(clean)
            out.append({"header": s["header"], "paragraphs": paras})
        return out

    if path.is_file():
        if args.output:
            out_md = _ensure_output_path(path, args.output, suffix=".emotion.md")
            text = extract_text_from_markdown_content(path.read_text(encoding="utf-8"))
            _write_markdown_report(out_md, path.stem, text, args.algo, params, top_k=args.top_k, source_path=path, min_score=args.min_score, min_confidence=args.min_confidence, min_score_diff=args.min_score_diff, min_paragraph_length=args.min_paragraph_length)
            print(f"Wrote report: {out_md}")
        else:
            out = run_file(path, args.algo, params, args.aggregate)
            print(out)
    elif path.is_dir():
        if args.output:
            out_dir = Path(args.output)
            out_dir.mkdir(parents=True, exist_ok=True)
            docs = extract_documents_from_folder(path, recursive=not args.no_recursive, file_pattern=args.file_pattern, min_document_length=args.min_document_length)
            
            # Generate individual reports
            for d in docs:
                out_md = out_dir / f"{d['file_name']}.emotion.md"
                _write_markdown_report(out_md, d["file_name"], d["clean_text"], args.algo, params, top_k=args.top_k, source_path=d["file_path"] if "file_path" in d else None, min_score=args.min_score, min_confidence=args.min_confidence, min_score_diff=args.min_score_diff, min_paragraph_length=args.min_paragraph_length)
            
            # Generate consolidated corpus report if requested
            if args.corpus_report:
                corpus_name = path.stem or "Corpus"
                corpus_md = out_dir / f"{corpus_name}.corpus.emotion.md"
                _write_corpus_report(corpus_md, corpus_name, docs, args.algo, params, top_k=args.top_k, min_score=args.min_score, min_confidence=args.min_confidence, min_score_diff=args.min_score_diff, min_paragraph_length=args.min_paragraph_length)
                print(f"Wrote {len(docs)} individual reports and 1 consolidated corpus report to: {out_dir}")
            else:
                print(f"Wrote {len(docs)} reports to: {out_dir}")
        else:
            out = run_folder(path, args.algo, params, args.aggregate,
                             recursive=not args.no_recursive,
                             file_pattern=args.file_pattern,
                             min_document_length=args.min_document_length)
            print(out)
    else:
        raise SystemExit(f"No existe la ruta: {path}")


if __name__ == "__main__":
    main()


