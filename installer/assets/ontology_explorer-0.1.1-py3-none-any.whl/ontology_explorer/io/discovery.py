"""File discovery for multi-source extraction."""

from __future__ import annotations

import fnmatch
from pathlib import Path


def discover_files(
    input_dir: Path,
    extensions: tuple[str, ...] = (".txt", ".md"),
    exclude_patterns: list[str] | None = None,
) -> list[Path]:
    """
    List files in input_dir (non-recursive) filtered by extension and exclusions.

    - Only regular files with one of the given extensions (case-insensitive) are included.
    - If .ontologyignore exists in input_dir, its lines (glob patterns) are used to exclude files.
    - exclude_patterns from CLI are combined with .ontologyignore.
    - Patterns match against the file name; use path separators for relative paths if needed.
    - Returns a deterministically sorted list (by str(path)).
    """
    if not input_dir.is_dir():
        return []

    patterns: list[str] = []
    if exclude_patterns:
        patterns.extend(p.strip() for p in exclude_patterns if p.strip())

    ignore_file = input_dir / ".ontologyignore"
    if ignore_file.is_file():
        try:
            for line in ignore_file.read_text(encoding="utf-8").splitlines():
                line = line.strip()
                if line and not line.startswith("#"):
                    patterns.append(line)
        except OSError:
            pass

    ext_set = {e.lower() for e in extensions}
    candidates: list[Path] = []
    for p in input_dir.iterdir():
        if not p.is_file():
            continue
        if p.suffix.lower() not in ext_set:
            continue
        try:
            rel = p.relative_to(input_dir)
        except ValueError:
            rel = p
        rel_str = str(rel).replace("\\", "/")
        name = p.name
        if any(
            fnmatch.fnmatch(name, pat) or fnmatch.fnmatch(rel_str, pat)
            for pat in patterns
        ):
            continue
        candidates.append(p)

    candidates.sort(key=lambda x: str(x))
    return candidates
