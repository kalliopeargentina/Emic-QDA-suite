"""Cache for per-file extraction results (resume after interruption)."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path


def get_cache_path(cache_dir: Path, file_path: Path) -> Path:
    """
    Return the cache file path for a given source file.

    Uses a stable hash of the file's absolute path so the same file always
    maps to the same cache entry.
    """
    resolved = file_path.resolve()
    key = hashlib.sha256(str(resolved).encode()).hexdigest()[:16]
    return cache_dir / f"{key}.json"


def load_cached_result(cache_path: Path) -> dict | None:
    """
    Load cached extraction result from disk.

    Returns the parsed JSON dict, or None if the file does not exist or
    cannot be read/parsed.
    """
    if not cache_path.is_file():
        return None
    try:
        data = json.loads(cache_path.read_text(encoding="utf-8"))
        if isinstance(data, dict) and ("entities" in data or "model" in data):
            return data
        return None
    except (OSError, json.JSONDecodeError):
        return None


def save_cached_result(cache_path: Path, data: dict) -> None:
    """
    Save extraction result to cache.

    Creates parent directory if needed. Overwrites existing file.
    """
    cache_path.parent.mkdir(parents=True, exist_ok=True)
    cache_path.write_text(
        json.dumps(data, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
