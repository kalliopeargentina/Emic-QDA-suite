"""
Check availability of embedding models used by Top2Vec and BERTopic.
Run: python -m obsidian_qda_suite.analysis.topic_analysis.embeddings_check
Or use: obsidianqda topic --check-embeddings
"""

from .config import TOP2VEC_EMBEDDING_OPTIONS, BERTOPIC_EMBEDDING_OPTIONS

# Models that are loaded via SentenceTransformer (we can test availability).
SENTENCE_TRANSFORMER_MODELS = {
    "all-MiniLM-L6-v2",
    "all-mpnet-base-v2",
    "distiluse-base-multilingual-cased",
    "paraphrase-multilingual-MiniLM-L12-v2",
}

# Top2Vec-only: loaded by Top2Vec (TensorFlow Hub or trained on data).
TOP2VEC_ONLY = {"doc2vec", "universal-sentence-encoder", "universal-sentence-encoder-large",
                "universal-sentence-encoder-multilingual", "universal-sentence-encoder-multilingual-large"}


def check_sentence_transformer(model_name: str) -> tuple[bool, str]:
    """Try loading a model with SentenceTransformer. Returns (ok, message)."""
    try:
        from sentence_transformers import SentenceTransformer
        SentenceTransformer(model_name)
        return True, "OK"
    except Exception as e:
        return False, str(e)


def check_embeddings(verbose: bool = True) -> dict[str, dict[str, str]]:
    """
    Check availability of all documented embedding models.
    Returns a dict: { "Top2Vec": { model_name: status_msg }, "BERTopic": { ... } }.
    """
    results = {"Top2Vec": {}, "BERTopic": {}}

    for name in TOP2VEC_EMBEDDING_OPTIONS:
        if name in TOP2VEC_ONLY:
            if name == "doc2vec":
                results["Top2Vec"][name] = "OK (Top2Vec trains on your data; no download)"
            else:
                results["Top2Vec"][name] = "Top2Vec-only (TensorFlow Hub); run with --method top2vec to test"
        elif name in SENTENCE_TRANSFORMER_MODELS:
            ok, msg = check_sentence_transformer(name)
            results["Top2Vec"][name] = "OK" if ok else f"Load error: {msg}"
        else:
            ok, msg = check_sentence_transformer(name)
            results["Top2Vec"][name] = "OK" if ok else f"Load error: {msg}"

    for name in BERTOPIC_EMBEDDING_OPTIONS:
        ok, msg = check_sentence_transformer(name)
        results["BERTopic"][name] = "OK" if ok else f"Load error: {msg}"

    if verbose:
        print("Embedding availability check")
        print("=" * 50)
        for backend, models in results.items():
            print(f"\n{backend}:")
            for model, status in models.items():
                marker = "✓" if status.startswith("OK") else "✗"
                print(f"  {marker} {model}: {status}")
        print()

    return results


def main() -> None:
    check_embeddings(verbose=True)


if __name__ == "__main__":
    main()
