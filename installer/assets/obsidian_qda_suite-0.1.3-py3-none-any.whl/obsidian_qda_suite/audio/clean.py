"""Core logic for cleaning audio with ffmpeg filters."""

import subprocess
from pathlib import Path
from typing import List, Tuple


def get_codec_settings(ext: str) -> Tuple[str, List[str], List[str]]:
    """
    Get codec and settings based on file extension.
    Returns: (codec, bitrate_args, extra_flags)
    """
    ext_lower = ext.lower()
    bitrate_args: List[str] = []
    extra_flags: List[str] = []

    if ext_lower == ".wav":
        codec = "pcm_s16le"
    elif ext_lower == ".flac":
        codec = "flac"
    elif ext_lower == ".mp3":
        codec = "libmp3lame"
        bitrate_args = ["-b:a", "192k"]
    elif ext_lower == ".m4a":
        codec = "aac"
        bitrate_args = ["-b:a", "128k"]
        extra_flags = ["-movflags", "+faststart"]
    elif ext_lower == ".mp4":
        codec = "aac"
        bitrate_args = ["-b:a", "128k"]
        extra_flags = ["-movflags", "+faststart"]
    elif ext_lower == ".aac":
        codec = "aac"
        bitrate_args = ["-b:a", "128k"]
    elif ext_lower == ".ogg":
        codec = "libvorbis"
        bitrate_args = ["-b:a", "160k"]
    elif ext_lower == ".opus":
        codec = "libopus"
        bitrate_args = ["-b:a", "96k"]
    else:
        codec = "aac"
        bitrate_args = ["-b:a", "128k"]

    return codec, bitrate_args, extra_flags


DEFAULT_FILTER_CHAIN = (
    "highpass=f=80,lowpass=f=8000,afftdn=nf=-25,deesser,loudnorm=I=-19:TP=-1.5:LRA=11"
)


def clean_audio(
    input_path: str,
    output_path: str,
    codec: str,
    bitrate_args: List[str],
    extra_flags: List[str],
    filter_chain: str,
    ffmpeg_bin: str,
) -> bool:
    """Run ffmpeg to clean audio. Returns True on success, False on failure."""
    try:
        cmd = [
            ffmpeg_bin,
            "-hide_banner",
            "-y",
            "-i",
            input_path,
            "-vn",
            "-af",
            filter_chain,
            "-map_metadata",
            "0",
            "-c:a",
            codec,
        ]
        cmd.extend(bitrate_args)
        cmd.extend(extra_flags)
        cmd.append(output_path)

        subprocess.run(cmd, capture_output=True, text=True, check=True)
        return True
    except subprocess.CalledProcessError:
        return False
    except FileNotFoundError:
        return False
