from typing import Dict, List, Any


class SentimentBackend:
    name: str = "base"

    def __init__(self, **kwargs):
        ...

    def predict(self, text: str, lang: str | None = None) -> Dict[str, Any]:
        raise NotImplementedError

    def predict_batch(self, texts: List[str], lang: str | None = None) -> List[Dict[str, Any]]:
        return [self.predict(t, lang=lang) for t in texts]


def aggregate_labels(results: List[Dict[str, Any]]) -> Dict[str, float]:
    from collections import Counter
    if not results:
        return {}
    c = Counter(r["label"] for r in results if "label" in r)
    total = sum(c.values()) or 1
    return {k: v / total for k, v in c.items()}


def normalize_sentiment_label(label: str) -> str:
    """
    Normalize sentiment labels to standard POS/NEG/NEU format.
    
    Handles various label formats:
    - Standard: positive/negative/neutral -> POS/NEG/NEU
    - Star ratings: 1-2 stars -> NEG, 3 stars -> NEU, 4-5 stars -> POS
    - Already normalized: POS/NEG/NEU -> unchanged
    
    Args:
        label: Input label string
        
    Returns:
        Normalized label (POS, NEG, or NEU)
    """
    if not isinstance(label, str):
        label = str(label)
    
    label_lower = label.lower().strip()
    
    # Standard label mappings
    standard_mapping = {
        "positive": "POS",
        "negative": "NEG", 
        "neutral": "NEU",
        "pos": "POS",
        "neg": "NEG",
        "neu": "NEU"
    }
    
    if label_lower in standard_mapping:
        return standard_mapping[label_lower]
    
    # Handle star ratings (nlptown model: "1 star", "2 stars", etc.)
    if "star" in label_lower:
        # Extract number from "1 star", "2 stars", etc.
        star_num = label_lower.replace("stars", "").replace("star", "").strip()
        try:
            star_value = int(star_num)
            if star_value <= 2:
                return "NEG"
            elif star_value == 3:
                return "NEU"
            else:  # 4 or 5 stars
                return "POS"
        except ValueError:
            pass
    
    # If already uppercase and looks like POS/NEG/NEU, return as-is
    if label.upper() in ("POS", "NEG", "NEU"):
        return label.upper()
    
    # Default: return original label (may be used by other models)
    return label


