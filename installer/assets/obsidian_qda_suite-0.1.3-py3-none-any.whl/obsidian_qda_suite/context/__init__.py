"""Context analysis (KWIC, etc.)."""

from .kwic_analysis import generate_kwic_table, main as kwic_main

__all__ = ["generate_kwic_table", "kwic_main"]
