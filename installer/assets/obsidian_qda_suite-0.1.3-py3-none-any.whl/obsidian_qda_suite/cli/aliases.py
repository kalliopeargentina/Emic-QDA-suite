"""Entry points for script aliases (obsidianqda-transcribe, etc.). Prepend subcommand to argv and call main."""
import os
os.environ["USE_TF"] = "0"
os.environ["USE_TORCH"] = "1"
os.environ["TF_ENABLE_ONEDNN_OPTS"] = "0"

import sys


def _alias(subcommand: str) -> None:
    argv = sys.argv
    sys.argv = ["obsidianqda", subcommand] + (argv[1:] if len(argv) > 1 else [])
    from .main import main
    main()


def run_transcribe() -> None:
    _alias("transcribe")


def run_transcribex() -> None:
    _alias("transcribex")


def run_regenerate_srt() -> None:
    _alias("regenerate-srt")


def run_emotion() -> None:
    _alias("emotion")


def run_sentiment() -> None:
    _alias("sentiment")


def run_topic() -> None:
    _alias("topic")


def run_kwic() -> None:
    _alias("kwic")


def run_extract_audio() -> None:
    _alias("extract-audio")


def run_split_audio() -> None:
    _alias("split-audio")


def run_convert_compress_audio() -> None:
    _alias("convert-compress-audio")


def run_clean_audio() -> None:
    _alias("clean-audio")


def run_transcribe_youtube() -> None:
    _alias("transcribe-youtube")
