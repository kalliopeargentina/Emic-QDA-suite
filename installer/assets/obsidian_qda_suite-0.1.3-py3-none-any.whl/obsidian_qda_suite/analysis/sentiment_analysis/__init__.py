"""Sentiment and emotion analysis. Set env vars before any transformers/TF imports."""
import os
os.environ["USE_TF"] = "0"
os.environ["USE_TORCH"] = "1"
os.environ["TF_ENABLE_ONEDNN_OPTS"] = "0"

__all__ = []
