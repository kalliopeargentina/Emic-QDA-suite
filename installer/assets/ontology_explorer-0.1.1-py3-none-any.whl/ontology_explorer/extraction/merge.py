"""Merge outputs from multiple chunks."""

from __future__ import annotations

from .parse import _normalize_evidence


def merge_json_outputs(results: list[dict], model_name: str) -> dict:
    """Consolida resultados JSON de múltiples segmentos, fusionando evidencias de entidades/relaciones duplicadas."""
    entities_map: dict[tuple[str, str], list[dict]] = {}
    relations_map: dict[tuple[str, str, str], list[dict]] = {}

    for result in results:
        for ent in result.get("entities", []):
            if isinstance(ent, list) and len(ent) >= 2:
                name, ent_type = ent[0], ent[1]
                key = (name, ent_type)
                evidences = []
                if len(ent) >= 3:
                    evidences = _normalize_evidence(ent[2])

                if key not in entities_map:
                    entities_map[key] = []
                for ev in evidences:
                    ev_key = (ev.get("document", ""), ev.get("sentence", ""))
                    if ev_key not in [(e.get("document", ""), e.get("sentence", "")) for e in entities_map[key]]:
                        entities_map[key].append(ev)

        for rel in result.get("relations", []):
            if isinstance(rel, list) and len(rel) >= 3:
                rel_type, source, target = rel[0], rel[1], rel[2]
                key = (rel_type, source, target)
                evidences = []
                if len(rel) >= 4:
                    evidences = _normalize_evidence(rel[3])

                if key not in relations_map:
                    relations_map[key] = []
                for ev in evidences:
                    ev_key = (ev.get("document", ""), ev.get("sentence", ""))
                    if ev_key not in [(e.get("document", ""), e.get("sentence", "")) for e in relations_map[key]]:
                        relations_map[key].append(ev)

    entities: list[list] = []
    for (name, ent_type), evidences in entities_map.items():
        entities.append([name, ent_type, evidences])

    relations: list[list] = []
    for (rel_type, source, target), evidences in relations_map.items():
        relations.append([rel_type, source, target, evidences])

    return {"model": model_name, "entities": entities, "relations": relations}
