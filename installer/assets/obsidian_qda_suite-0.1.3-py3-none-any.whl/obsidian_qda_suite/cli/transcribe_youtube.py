"""CLI for transcribing YouTube videos with Whisper. Direct args only."""

import argparse
import os
import sys

from . import common
from ..audio.youtube_transcribe import run_youtube_transcribe


def main() -> None:
    common.setup_console_encoding()
    parser = argparse.ArgumentParser(
        description="Download YouTube audio and transcribe with OpenAI Whisper."
    )
    parser.add_argument("url", type=str, nargs="?", help="YouTube URL")
    parser.add_argument("--output-dir", type=str, default=".", help="Output directory")
    parser.add_argument("--output-name", type=str, help="Base name for output files")
    parser.add_argument("--api-key", type=str, help="OpenAI API key (or set OPENAI_API_KEY)")
    parser.add_argument("--language", type=str, help="Language code (e.g. es, en)")
    parser.add_argument("--model", type=str, default="whisper-1", help="Whisper model")
    args = parser.parse_args()

    url = (args.url or "").strip()
    if not url:
        common.safe_print("Error: YouTube URL required. Pass URL as argument or use --url.", file=sys.stderr)
        parser.print_help(sys.stderr)
        sys.exit(1)

    output_dir = common.fix_path(args.output_dir or ".")
    os.makedirs(output_dir, exist_ok=True)
    output_name = common.get_optional_param(args.output_name)

    try:
        srt_path, md_path = run_youtube_transcribe(
            url,
            output_dir,
            output_name=output_name,
            api_key=common.get_optional_param(args.api_key),
            language=common.get_optional_param(args.language),
            model=args.model or "whisper-1",
        )
    except Exception as e:
        common.safe_print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)

    common.safe_print(f"SRT: {srt_path}")
    common.safe_print(f"MD:  {md_path}")
