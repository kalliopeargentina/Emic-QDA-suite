"""
Central configuration for default output paths.

Paths can be overridden via obsidianqda.toml (cwd, vault root, or XDG config).
Precedence: built-in < cwd < vault < XDG (later overrides earlier).
"""

from __future__ import annotations

import os
import sys
from pathlib import Path
from typing import Any

if sys.version_info >= (3, 11):
    import tomllib
else:
    tomllib = None  # type: ignore[assignment]

# Built-in defaults (Spanish folder names)
DEFAULT_PATHS = {
    "context_analysis_dir": "Análisis/Análisis de Contexto",
    "emotion_analysis_dir": "Análisis/Análisis de Emociones",
    "sentiment_analysis_dir": "Análisis/Análisis de Sentimiento",
    "topic_analysis_dir": "Análisis/Análisis de Tópicos",
    "topic_stopwords_file": "Análisis/Análisis de Tópicos/Stopwords.md",
    "topic_seedwords_file": "Análisis/Análisis de Tópicos/SeedWordsLDA.md",
    "interviews_dir": "Data/Entrevistas",
}

CONFIG_FILENAME = "obsidianqda.toml"
XDG_CONFIG_DIR = "obsidianqda"
XDG_CONFIG_FILENAME = "config.toml"


def _load_toml_paths(path: Path) -> dict[str, str] | None:
    """Load [paths] from a TOML file. Returns None if file missing or invalid."""
    if not path.is_file():
        return None
    if tomllib is None:
        return None
    try:
        with open(path, "rb") as f:
            data = tomllib.load(f)
        paths = data.get("paths")
        if not isinstance(paths, dict):
            return None
        return {k: str(v) for k, v in paths.items() if k in DEFAULT_PATHS and isinstance(v, str)}
    except (OSError, ValueError):
        return None


def _xdg_config_home() -> Path:
    if sys.platform == "win32":
        base = os.environ.get("APPDATA", os.path.expanduser("~"))
        return Path(base) / XDG_CONFIG_DIR
    return Path(os.environ.get("XDG_CONFIG_HOME", os.path.expanduser("~/.config"))) / XDG_CONFIG_DIR


def get_paths_config(vault_path: str | None = None) -> dict[str, str]:
    """
    Return effective paths config (default output dirs).

    Merges in order: built-in -> cwd/obsidianqda.toml -> vault/obsidianqda.toml
    -> XDG config. Later sources override earlier.

    vault_path: optional vault root; if set, vault's obsidianqda.toml is loaded.
    """
    result = dict(DEFAULT_PATHS)
    cwd = Path.cwd()

    # 1) cwd
    cwd_config = cwd / CONFIG_FILENAME
    layer = _load_toml_paths(cwd_config)
    if layer:
        result.update(layer)

    # 2) vault
    if vault_path:
        vault = Path(vault_path).resolve()
        vault_config = vault / CONFIG_FILENAME
        layer = _load_toml_paths(vault_config)
        if layer:
            result.update(layer)

    # 3) XDG
    xdg_dir = _xdg_config_home()
    xdg_config = xdg_dir / XDG_CONFIG_FILENAME
    layer = _load_toml_paths(xdg_config)
    if layer:
        result.update(layer)

    return result
