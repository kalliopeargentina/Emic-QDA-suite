"""CLI for converting and compressing audio to MP3 (16kHz, mono, 64k). Obsidian or direct args."""

import argparse
import os
import shutil
import sys
from datetime import datetime
from pathlib import Path

from . import common
from ..audio.ffmpeg_utils import get_ffmpeg_path
from ..audio.split import convert_audio


def main() -> None:
    common.setup_console_encoding()
    parser = argparse.ArgumentParser(
        description="Convert and compress audio to MP3 (16kHz, mono, 64k) for transcription."
    )
    parser.add_argument("--vault-path", type=str, help="Obsidian vault path (Obsidian mode)")
    parser.add_argument("--file-path", type=str, help="Absolute path to audio file (Obsidian mode)")
    parser.add_argument("--file-name", type=str, help="Name of the audio file (Obsidian mode)")
    parser.add_argument("file", type=str, nargs="?", help="Audio file (direct mode)")
    parser.add_argument("--output-dir", type=str, help="Output directory (direct mode; default: in-place)")
    args = parser.parse_args()

    vault_path = common.get_optional_param(args.vault_path)
    file_path_arg = common.get_optional_param(args.file_path)
    file_name_arg = common.get_optional_param(args.file_name)
    direct_file = common.get_optional_param(args.file)
    output_dir_arg = common.get_optional_param(args.output_dir)

    if vault_path and file_path_arg and file_name_arg:
        vault = common.fix_path(vault_path)
        file_abs = common.fix_path(file_path_arg)
        file_name = common.sanitize_name(file_name_arg)
        if not os.path.isdir(vault):
            common.safe_print(f"Error: Vault path not found: {vault}", file=sys.stderr)
            sys.exit(1)
        media_dir = os.path.join(vault, "Attachments", "Medios")
        backup_dir = os.path.join(media_dir, "pre-process-backup")
        os.makedirs(backup_dir, exist_ok=True)
        stem = Path(file_name).stem
        out_file = os.path.join(media_dir, f"{stem}.mp3")
    elif direct_file:
        file_abs = common.fix_path(direct_file)
        if not os.path.isfile(file_abs):
            common.safe_print(f"Error: File not found: {file_abs}", file=sys.stderr)
            sys.exit(1)
        file_name = os.path.basename(file_abs)
        stem = Path(file_name).stem
        if output_dir_arg:
            out_dir = common.fix_path(output_dir_arg)
            os.makedirs(out_dir, exist_ok=True)
            out_file = os.path.join(out_dir, f"{stem}.mp3")
            backup_dir = os.path.dirname(file_abs)
        else:
            out_file = os.path.join(os.path.dirname(file_abs), f"{stem}.mp3")
            backup_dir = os.path.dirname(file_abs)
    else:
        common.safe_print(
            "Error: Use --vault-path, --file-path, --file-name (Obsidian) or pass audio file (direct).",
            file=sys.stderr,
        )
        parser.print_help(sys.stderr)
        sys.exit(1)

    if not os.path.isfile(file_abs):
        common.safe_print(f"Error: File not found: {file_abs}", file=sys.stderr)
        sys.exit(1)

    stem = Path(file_name).stem
    ext = Path(file_name).suffix or ".mp3"
    timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
    backup_file = os.path.join(backup_dir, f"{stem}_orig_{timestamp}{ext}")

    try:
        shutil.move(file_abs, backup_file)
    except Exception as e:
        common.safe_print(f"Error: Failed to create backup: {e}", file=sys.stderr)
        sys.exit(1)

    ffmpeg_bin = get_ffmpeg_path()
    if not convert_audio(backup_file, out_file, ffmpeg_bin):
        try:
            shutil.move(backup_file, file_abs)
        except Exception:
            common.safe_print(f"Warning: Could not restore original from {backup_file}", file=sys.stderr)
        common.safe_print("Error: ffmpeg failed to convert/compress audio.", file=sys.stderr)
        sys.exit(1)

    common.safe_print(f"Converted and compressed: {out_file}")
    common.safe_print(f"Backup: {backup_file}")

