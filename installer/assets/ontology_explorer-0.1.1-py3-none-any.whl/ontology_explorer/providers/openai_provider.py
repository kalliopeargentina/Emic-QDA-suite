"""OpenAI provider."""

from __future__ import annotations

import os
import sys

from .base import Provider, ProviderConfig


class OpenAIProvider(Provider):
    def run(self, prompt: str, model: str, config: ProviderConfig) -> str:
        api_key = config.api_key or os.getenv("OPENAI_API_KEY")
        if not api_key:
            raise SystemExit(
                "Proporcioná la clave de OpenAI con --api-key o definí OPENAI_API_KEY."
            )

        try:
            from openai import OpenAI
        except ImportError as exc:
            raise SystemExit(
                "No se encuentra el paquete 'openai'. Instalalo con 'pip install openai'."
            ) from exc

        client = OpenAI(api_key=api_key)

        try:
            print(f"Consultando OpenAI con modelo: {model}", file=sys.stderr, flush=True)

            messages = [{"role": "user", "content": prompt}]
            kwargs = {"model": model, "messages": messages}

            if config.temperature is not None:
                kwargs["temperature"] = config.temperature
            timeout_sec = 300 if config.timeout is None else config.timeout
            kwargs["timeout"] = timeout_sec
            # Prefer structured output when available
            if config.response_schema:
                kwargs["response_format"] = {
                    "type": "json_schema",
                    "json_schema": {
                        "name": "ontology_extraction",
                        "schema": config.response_schema,
                        "strict": True,
                    },
                }
            else:
                kwargs["response_format"] = {"type": "json_object"}

            try:
                response = client.chat.completions.create(**kwargs)
            except Exception as exc:
                # Fallback: retry without response_format if unsupported
                if "response_format" in str(exc) or "json_schema" in str(exc):
                    kwargs.pop("response_format", None)
                    response = client.chat.completions.create(**kwargs)
                else:
                    raise
            text = response.choices[0].message.content
            if not text:
                raise SystemExit("OpenAI no devolvió contenido de texto.")

            print(f"Output recibido ({len(text)} caracteres)", file=sys.stderr, flush=True)
            return text.strip()
        except Exception as exc:
            raise SystemExit(f"OpenAI devolvió un error: {exc}") from exc
