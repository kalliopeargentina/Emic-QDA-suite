from typing import Dict, Any, List
from pysentimiento import create_analyzer
from .base import SentimentBackend
import torch


class PySentimientoEmotionBackend(SentimentBackend):
    name = "pysentimiento-emotion"

    def __init__(self, model: str | None = None, device: str | None = None, **_):
        self._model_override = model
        self._device = device  # "cuda", "cpu", or None (auto)
        self._cache: dict[str, Any] = {}

    def _get_analyzer(self, lang: str):
        key = lang or "es"
        if key not in self._cache:
            # Avoid passing model to prevent argument conflicts across versions
            self._cache[key] = create_analyzer(task="emotion", lang=key)
            try:
                if (self._device == "cuda") or (self._device is None and torch.cuda.is_available()):
                    self._cache[key].model.to("cuda")
            except Exception:
                pass
        return self._cache[key]

    def predict(self, text: str, lang: str | None = None) -> Dict[str, Any]:
        analyzer = self._get_analyzer(lang or "es")
        out = analyzer.predict(text)
        return {"label": out.output, "scores": dict(out.probas), "lang": lang or "es"}

    def predict_batch(self, texts: List[str], lang: str | None = None) -> List[Dict[str, Any]]:
        analyzer = self._get_analyzer(lang or "es")
        res = []
        for t in texts:
            out = analyzer.predict(t)
            res.append({"label": out.output, "scores": dict(out.probas), "lang": lang or "es"})
        return res


