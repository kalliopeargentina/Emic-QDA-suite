from typing import Dict, Any, List
from pysentimiento import create_analyzer
from .base import SentimentBackend
import torch


class PySentimientoBackend(SentimentBackend):
    name = "pysentimiento"

    def __init__(self, model: str | None = None, device: str | None = None, **_):
        self._model_override = model
        self._device = device  # "cuda", "cpu", or None (auto)
        self._cache: dict[str, Any] = {}

    def _get_analyzer(self, lang: str):
        # pysentimiento soporta 'es', 'en', 'it', 'pt' (según versiones)
        key = lang or "es"
        if key not in self._cache:
            # Evitar pasar 'model' porque algunas versiones generan conflicto de argumentos
            self._cache[key] = create_analyzer(task="sentiment", lang=key)
            # Move model to CUDA if requested/available
            try:
                if (self._device == "cuda") or (self._device is None and torch.cuda.is_available()):
                    self._cache[key].model.to("cuda")
            except Exception:
                pass
        return self._cache[key]

    def predict(self, text: str, lang: str | None = None) -> Dict[str, Any]:
        analyzer = self._get_analyzer(lang or "es")
        out = analyzer.predict(text)
        return {"label": out.output, "scores": dict(out.probas), "lang": lang or "es"}

    def predict_batch(self, texts: List[str], lang: str | None = None) -> List[Dict[str, Any]]:
        analyzer = self._get_analyzer(lang or "es")
        results = []
        for t in texts:
            out = analyzer.predict(t)
            results.append({"label": out.output, "scores": dict(out.probas), "lang": lang or "es"})
        return results


