"""Download YouTube audio and transcribe with Whisper."""

import re
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import List, Optional, Tuple

from .whisper_transcribe import (
    get_api_key,
    run_whisper_transcribe,
)


def _get_yt_dlp_command() -> Optional[List[str]]:
    try:
        r = subprocess.run(
            [sys.executable, "-m", "yt_dlp", "--version"],
            capture_output=True,
            text=True,
            check=True,
            timeout=10,
        )
        if r.returncode == 0:
            return [sys.executable, "-m", "yt_dlp"]
    except (subprocess.CalledProcessError, FileNotFoundError, subprocess.TimeoutExpired):
        pass
    try:
        r = subprocess.run(
            ["yt-dlp", "--version"],
            capture_output=True,
            text=True,
            check=True,
            timeout=10,
        )
        if r.returncode == 0:
            return ["yt-dlp"]
    except (subprocess.CalledProcessError, FileNotFoundError, subprocess.TimeoutExpired):
        pass
    return None


def download_youtube_audio(url: str, temp_dir: Optional[Path] = None) -> Path:
    """Download audio from YouTube URL. Returns path to downloaded file."""
    cmd = _get_yt_dlp_command()
    if not cmd:
        raise RuntimeError(
            "yt-dlp not found. Install with: pip install yt-dlp"
        )
    if temp_dir is None:
        temp_dir = Path(tempfile.mkdtemp())
    out_tpl = temp_dir / "youtube_audio.%(ext)s"
    full_cmd = cmd + [
        "-x",
        "--audio-format", "mp3",
        "--audio-quality", "0",
        "-o", str(out_tpl),
        url,
    ]
    subprocess.run(full_cmd, check=True, capture_output=True, text=True, timeout=600)
    downloaded = list(temp_dir.glob("youtube_audio.*"))
    if not downloaded:
        raise FileNotFoundError("yt-dlp did not produce an audio file")
    return downloaded[0]


def _sanitize_filename(name: str) -> str:
    name = re.sub(r'[<>:"/\\|?*]', "", name)
    name = name.replace(" ", "_").strip("_")
    return name[:100] if len(name) > 100 else name


def run_youtube_transcribe(
    url: str,
    output_dir: str,
    output_name: Optional[str] = None,
    api_key: Optional[str] = None,
    language: Optional[str] = None,
    model: str = "whisper-1",
) -> Tuple[str, str]:
    """Download YouTube audio and transcribe to SRT and MD in output_dir. Returns (srt_path, md_path)."""
    key = get_api_key(api_key)
    if not key or not key.strip():
        raise RuntimeError("OpenAI API key required. Use --api-key or set OPENAI_API_KEY.")
    temp_dir = Path(tempfile.mkdtemp())
    try:
        audio_path = download_youtube_audio(url, temp_dir=temp_dir)
        name = output_name or "youtube_video"
        srt_path, md_path = run_whisper_transcribe(
            str(audio_path),
            output_dir,
            name,
            key,
            language=language,
            model=model,
        )
        return srt_path, md_path
    finally:
        import shutil
        shutil.rmtree(temp_dir, ignore_errors=True)
