"""Provider registry and factory."""

from __future__ import annotations

from .base import Provider
from .gemini import GeminiProvider
from .ollama import OllamaProvider
from .ollama_cloud import OllamaCloudProvider
from .openai_provider import OpenAIProvider


def get_provider(name: str) -> Provider:
    normalized = name.lower().strip()
    if normalized == "ollama":
        return OllamaProvider()
    if normalized == "ollama-cloud":
        return OllamaCloudProvider()
    if normalized == "openai":
        return OpenAIProvider()
    if normalized == "gemini":
        return GeminiProvider()
    raise SystemExit(f"Proveedor desconocido: {name}")
