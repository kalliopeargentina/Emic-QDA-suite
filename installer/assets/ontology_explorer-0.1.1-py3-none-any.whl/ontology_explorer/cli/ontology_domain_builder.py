"""CLI para validar, corregir y exportar archivos de dominio."""

from __future__ import annotations

import argparse
import json
import sys
import subprocess
from pathlib import Path
from typing import Any

from ontology_explorer.exporters.domain_export import (
    export_domain_to_json,
    export_domain_to_jsonld,
    export_domain_to_rdf,
)
from ontology_explorer.prompt.loader import load_domain, parse_frontmatter


def _parse_frontmatter_local(content: str) -> tuple[dict[str, Any], str]:
    """Parsea frontmatter usando el parser compartido."""
    return parse_frontmatter(content)
from ontology_explorer.providers.base import ProviderConfig
from ontology_explorer.providers.registry import get_provider

# Temperature por defecto para respuestas deterministas
DEFAULT_TEMPERATURE = 0.0

# Prompt para validación con LLM
VALIDATION_PROMPT_TEMPLATE = """Eres un experto en validación de dominios ontológicos. Analiza el siguiente archivo de dominio y:

1. Identifica errores de formato, estructura o sintaxis
2. Verifica que todas las secciones requeridas estén presentes
3. Verifica coherencia entre entidades y relaciones
4. Verifica que la estructura de anidamiento sea consistente (soporta hasta 3 niveles)
5. Sugiere mejoras y correcciones mínimas para que sea consistente

ESTRUCTURA REQUERIDA DEL DOMINIO:
El archivo debe tener exactamente estas secciones en este orden:
- Frontmatter YAML (opcional pero recomendado) con --- al inicio y final
- CONTEXTO DEL DOMINIO:
- TIPOS DE ENTIDADES DISPONIBLES:
- RELACIONES DISPONIBLES:
  - RELACIONES ENTRE ENTIDADES: (subsección dentro de RELACIONES DISPONIBLES)
  - RELACIONES PARA PROPIEDADES: (subsección dentro de RELACIONES DISPONIBLES)

ESTRUCTURA DE ANIDAMIENTO:
El dominio soporta hasta 3 niveles de anidamiento usando indentación:
- Nivel 0 (0-2 espacios): Entidad principal
- Nivel 1 (4-6 espacios): Propiedad anidada nivel 1
- Nivel 2 (8-10 espacios): Propiedad anidada nivel 2
- Nivel 3 (12+ espacios): Sub-propiedades de nivel 2

La indentación debe ser consistente dentro de cada nivel. Si se usan sub-propiedades de nivel 3, debe haber propiedades de nivel 2 correspondientes.

IMPORTANTE: En el campo "corrected_domain":
- Debes mantener el formato Markdown existente (no inventes un formato nuevo).
- Conserva el estilo, redacción y orden originales cuando sea posible.
- Solo realiza cambios mínimos para corregir errores estructurales o completar secciones faltantes.
- No reescribas el contenido si ya es válido.
- Mantén la indentación por niveles (0-2, 4-6, 8-10, 12+ espacios).
- Si agregas algo, hazlo de la forma más simple y consistente con el resto del archivo.
Especialmente, dentro de "RELACIONES DISPONIBLES:" DEBES incluir las dos subsecciones:
- "RELACIONES ENTRE ENTIDADES:" (para relaciones entre tipos de entidades principales)
- "RELACIONES PARA PROPIEDADES:" (para relaciones que conectan entidades con propiedades/atributos)

Formato de respuesta (JSON):
{{
  "valid": true/false,
  "errors": ["error1", "error2"],
  "warnings": ["warning1", "warning2"],
  "suggestions": ["sugerencia1", "sugerencia2"],
  "corrected_domain": "contenido corregido completo del dominio con TODAS las secciones requeridas, incluyendo RELACIONES DISPONIBLES: con sus subsecciones RELACIONES ENTRE ENTIDADES: y RELACIONES PARA PROPIEDADES:"
}}

Archivo de dominio a validar:
```
{domain_content}
```
"""


def parse_args() -> argparse.Namespace:
    """Parsea los argumentos de línea de comandos."""
    parser = argparse.ArgumentParser(
        description=(
            "Valida, corrige y exporta archivos de dominio ontológico. "
            "Puede validar la estructura del dominio, usar una LLM para sugerir correcciones, "
            "y exportar el dominio en formatos RDF/TTL, JSON o JSON-LD."
        )
    )
    parser.add_argument(
        "domain_file",
        type=Path,
        help="Ruta al archivo de dominio (.md) a validar.",
    )
    parser.add_argument(
        "--validate",
        action="store_true",
        help="Solo validar (no reescribir el archivo).",
    )
    parser.add_argument(
        "--fix",
        action="store_true",
        help="Reescribir el archivo con las correcciones sugeridas por la LLM.",
    )
    parser.add_argument(
        "--output",
        type=Path,
        help="Guardar salida en archivo diferente (para --fix o --export).",
    )
    parser.add_argument(
        "--export",
        choices=("rdf", "json", "jsonld"),
        help="Exportar dominio a formato especificado (rdf, json, jsonld).",
    )
    parser.add_argument(
        "--provider",
        choices=("ollama", "ollama-cloud", "openai", "gemini"),
        default="ollama",
        help="Proveedor LLM a utilizar (por defecto: ollama).",
    )
    parser.add_argument(
        "--model",
        default=None,
        help=(
            "Nombre del modelo a utilizar. Por defecto usa 'qwen3' para Ollama, "
            "'llama3' para Ollama Cloud, 'gpt-4o' para OpenAI y 'gemini-1.5-pro' para Gemini."
        ),
    )
    parser.add_argument(
        "--api-key",
        help=(
            "Clave de API para el proveedor seleccionado (si aplica). "
            "Para OpenAI usa esta opción o la variable de entorno OPENAI_API_KEY. "
            "Para Gemini usa esta opción o la variable de entorno GEMINI_API_KEY. "
            "Para Ollama Cloud usa esta opción o la variable de entorno OLLAMA_API_KEY."
        ),
    )
    parser.add_argument(
        "--no-backup",
        action="store_true",
        help="No crear backup al reescribir el archivo con --fix.",
    )
    parser.add_argument(
        "--temperature",
        type=float,
        default=None,
        help=(
            f"Temperatura a utilizar en la generación del modelo (por defecto: {DEFAULT_TEMPERATURE}). "
            "Valores más bajos (0.0-0.3) producen respuestas más deterministas y precisas. "
            "Valores más altos (0.7-1.0) producen respuestas más creativas pero menos consistentes."
        ),
    )
    return parser.parse_args()


def validate_domain_structure(domain_content: str, domain_file: Path) -> tuple[bool, list[str], list[str]]:
    """
    Valida la estructura básica del dominio (sin LLM).
    
    Args:
        domain_content: Contenido del dominio a validar
        domain_file: Ruta al archivo de dominio (para mensajes de error)
    
    Returns:
        Tupla (es_válido, errores, warnings)
    """
    errors: list[str] = []
    warnings: list[str] = []
    
    # Verificar secciones requeridas
    content_upper = domain_content.upper()
    
    if "CONTEXTO DEL DOMINIO" not in content_upper:
        errors.append("Falta la sección 'CONTEXTO DEL DOMINIO:'")
    
    if "TIPOS DE ENTIDADES DISPONIBLES" not in content_upper:
        errors.append("Falta la sección 'TIPOS DE ENTIDADES DISPONIBLES:'")
    
    if "RELACIONES DISPONIBLES" not in content_upper:
        errors.append("Falta la sección 'RELACIONES DISPONIBLES:'")
    else:
        # Verificar subsecciones de relaciones
        if "RELACIONES ENTRE ENTIDADES" not in content_upper:
            errors.append("Falta la subsección 'RELACIONES ENTRE ENTIDADES:' dentro de 'RELACIONES DISPONIBLES:'")
        
        if "RELACIONES PARA PROPIEDADES" not in content_upper:
            errors.append("Falta la subsección 'RELACIONES PARA PROPIEDADES:' dentro de 'RELACIONES DISPONIBLES:'")
    
    # Verificar frontmatter (opcional pero recomendado)
    if not domain_content.strip().startswith("---"):
        warnings.append("El archivo no tiene frontmatter YAML (opcional pero recomendado)")
    else:
        # Intentar parsear frontmatter
        try:
            _parse_frontmatter_local(domain_content)
        except Exception as e:
            warnings.append(f"Frontmatter YAML puede tener problemas: {e}")
    
    # Verificaciones básicas de formato y estructura de anidamiento
    lines = domain_content.split("\n")
    in_entities_section = False
    entity_count = 0
    indent_levels_seen = set()
    
    for i, line in enumerate(lines, 1):
        stripped = line.strip()
        
        if "TIPOS DE ENTIDADES" in stripped.upper() or "ENTIDADES DISPONIBLES" in stripped.upper():
            in_entities_section = True
            continue
        
        if in_entities_section and (stripped.startswith("RELACIONES") or stripped.startswith("PATRONES")):
            break
        
        if in_entities_section and stripped.startswith("- "):
            leading_spaces = len(line) - len(line.lstrip())
            indent_levels_seen.add(leading_spaces)
            
            # Entidad principal (pocos espacios)
            if leading_spaces <= 2:
                entity_count += 1
                entity_part = stripped[2:].split(":")[0].strip()
                if not entity_part:
                    errors.append(f"Línea {i}: Entidad sin nombre")
            
            # Validar consistencia de indentación (genérico, sin asumir dominio específico)
            # Los niveles esperados son: 0-2 (entidad), 4-6 (nivel 1), 8-10 (nivel 2), 12+ (sub-propiedades)
            # Advertir si hay niveles intermedios inesperados
            if leading_spaces == 3 or leading_spaces == 7 or leading_spaces == 11:
                warnings.append(
                    f"Línea {i}: Indentación inusual ({leading_spaces} espacios). "
                    "Los niveles esperados son: 0-2 (entidad), 4-6 (propiedad nivel 1), "
                    "8-10 (propiedad nivel 2), 12+ (sub-propiedades)."
                )
    
    if entity_count == 0:
        errors.append("No se encontraron entidades definidas en 'TIPOS DE ENTIDADES DISPONIBLES:'")
    
    # Verificar que la estructura de anidamiento sea consistente
    # Si hay niveles de 12+ espacios, debería haber niveles de 8-10 también
    has_level2 = any(8 <= level <= 10 for level in indent_levels_seen)
    has_level3 = any(level >= 12 for level in indent_levels_seen)
    
    if has_level3 and not has_level2:
        warnings.append(
            "Se detectaron sub-propiedades de nivel 3 (12+ espacios) pero no se encontraron "
            "propiedades de nivel 2 (8-10 espacios). Verifique la estructura de anidamiento."
        )
    
    return len(errors) == 0, errors, warnings


def validate_domain_with_llm(
    domain_content: str,
    provider_name: str,
    model: str | None,
    api_key: str | None,
    temperature: float | None = None,
) -> dict[str, Any]:
    """
    Valida el dominio usando una LLM.
    
    Args:
        domain_content: Contenido del dominio a validar
        provider_name: Nombre del provider LLM
        model: Nombre del modelo (None para usar default)
        api_key: API key si es necesario
        temperature: Temperatura para la generación (None para usar DEFAULT_TEMPERATURE)
    
    Returns:
        Diccionario con valid, errors, warnings, suggestions, corrected_domain
    """
    # Determinar modelo por defecto si no se especifica
    if model is None:
        if provider_name == "ollama":
            model = "qwen3"
        elif provider_name == "ollama-cloud":
            model = "llama3"
        elif provider_name == "openai":
            model = "gpt-4o"
        elif provider_name == "gemini":
            model = "gemini-1.5-pro"
        else:
            model = "qwen3"  # Default
    
    # Construir prompt
    prompt = VALIDATION_PROMPT_TEMPLATE.format(domain_content=domain_content)
    
    # Obtener provider
    provider = get_provider(provider_name)
    
    # Usar temperature proporcionado o el valor por defecto
    final_temperature = temperature if temperature is not None else DEFAULT_TEMPERATURE
    
    # Configurar provider
    config = ProviderConfig(api_key=api_key, temperature=final_temperature)
    
    # Invocar LLM
    # Para tests, verificar disponibilidad de Ollama primero para evitar cuelgues
    is_test_mode = "pytest" in sys.modules or "test" in str(sys.argv[0]).lower()
    
    if is_test_mode and provider_name == "ollama":
        # Verificar rápidamente si Ollama está disponible antes de intentar usarlo
        try:
            # Verificar que ollama está instalado
            result = subprocess.run(
                ["ollama", "list"],
                capture_output=True,
                timeout=2,
                text=True
            )
            if result.returncode != 0:
                # Ollama no está disponible, retornar error inmediatamente
                return {
                    "valid": False,
                    "errors": ["Ollama no está disponible o no responde"],
                    "warnings": [],
                    "suggestions": [],
                    "corrected_domain": None,
                }
            
            # Verificar que la API de Ollama está respondiendo (timeout corto para tests)
            try:
                import requests
                response = requests.get("http://localhost:11434/api/tags", timeout=2)
                if response.status_code != 200:
                    return {
                        "valid": False,
                        "errors": ["Ollama API no está disponible"],
                        "warnings": [],
                        "suggestions": [],
                        "corrected_domain": None,
                    }
            except (requests.exceptions.ConnectionError, requests.exceptions.Timeout):
                # API no responde, retornar error inmediatamente
                return {
                    "valid": False,
                    "errors": ["Ollama API no está disponible o no responde"],
                    "warnings": [],
                    "suggestions": [],
                    "corrected_domain": None,
                }
        except (FileNotFoundError, subprocess.TimeoutExpired):
            # Ollama no está instalado o no responde, retornar error inmediatamente
            return {
                "valid": False,
                "errors": ["Ollama no está disponible o no responde"],
                "warnings": [],
                "suggestions": [],
                "corrected_domain": None,
            }
    
    try:
        response = provider.run(prompt, model, config)
    except Exception as e:
        return {
            "valid": False,
            "errors": [f"Error al invocar LLM: {e}"],
            "warnings": [],
            "suggestions": [],
            "corrected_domain": None,
        }
    
    # Parsear respuesta JSON
    try:
        # Limpiar respuesta (puede tener markdown code blocks)
        cleaned = response.strip()
        if cleaned.startswith("```"):
            lines = cleaned.split("\n")
            if lines[0].startswith("```"):
                lines = lines[1:]
            if lines and lines[-1].strip() == "```":
                lines = lines[:-1]
            cleaned = "\n".join(lines)
        
        # Buscar JSON en la respuesta
        start = cleaned.find("{")
        end = cleaned.rfind("}")
        
        if start != -1 and end != -1 and end > start:
            json_str = cleaned[start:end+1]
            result = json.loads(json_str)
            
            # Validar estructura
            if not isinstance(result, dict):
                raise ValueError("La respuesta no es un objeto JSON")
            
            # Asegurar campos requeridos
            corrected_domain = result.get("corrected_domain")
            return {
                "valid": result.get("valid", False),
                "errors": result.get("errors", []),
                "warnings": result.get("warnings", []),
                "suggestions": result.get("suggestions", []),
                "corrected_domain": corrected_domain,
            }
        else:
            raise ValueError("No se encontró JSON en la respuesta")
    except json.JSONDecodeError as e:
        return {
            "valid": False,
            "errors": [f"Error al parsear respuesta JSON de LLM: {e}", f"Respuesta recibida: {response[:500]}"],
            "warnings": [],
            "suggestions": [],
            "corrected_domain": None,
        }
    except Exception as e:
        return {
            "valid": False,
            "errors": [f"Error al procesar respuesta de LLM: {e}"],
            "warnings": [],
            "suggestions": [],
            "corrected_domain": None,
        }


def rewrite_domain(
    domain_file: Path,
    corrected_content: str,
    output_file: Path | None = None,
    create_backup: bool = True,
) -> None:
    """
    Reescribe el archivo de dominio con el contenido corregido.
    
    Args:
        domain_file: Archivo original
        corrected_content: Contenido corregido
        output_file: Archivo de salida (si es None, sobrescribe el original)
        create_backup: Si True, crea backup del archivo original
    """
    target_file = output_file if output_file else domain_file
    
    # Crear backup si es necesario
    if create_backup and not output_file:
        backup_file = domain_file.with_suffix(domain_file.suffix + ".backup")
        backup_file.write_text(domain_file.read_text(encoding="utf-8"), encoding="utf-8")
        print(f"Backup creado: {backup_file}", file=sys.stderr, flush=True)
    
    # Escribir contenido corregido
    target_file.write_text(corrected_content, encoding="utf-8")
    print(f"Archivo {'actualizado' if not output_file else 'guardado'}: {target_file}", file=sys.stderr, flush=True)


def print_validation_results(
    is_valid: bool,
    errors: list[str],
    warnings: list[str],
    suggestions: list[str],
) -> None:
    """Imprime los resultados de la validación en consola."""
    print("\n" + "=" * 60)
    print("RESULTADOS DE VALIDACIÓN")
    print("=" * 60)
    
    if is_valid:
        print("Estado: VALIDO")
    else:
        print("Estado: INVALIDO")
    
    if errors:
        print("\nERRORES ENCONTRADOS:")
        for error in errors:
            print(f"  - {error}")
    
    if warnings:
        print("\nWARNINGS:")
        for warning in warnings:
            print(f"  - {warning}")
    
    if suggestions:
        print("\nSUGERENCIAS:")
        for suggestion in suggestions:
            print(f"  - {suggestion}")
    
    print("=" * 60 + "\n")


def main() -> None:
    """Función principal del CLI."""
    args = parse_args()
    
    # Verificar que el archivo existe
    if not args.domain_file.exists():
        print(f"Error: El archivo '{args.domain_file}' no existe.", file=sys.stderr)
        sys.exit(1)
    
    # Cargar contenido del dominio
    try:
        domain_content = args.domain_file.read_text(encoding="utf-8")
    except Exception as e:
        print(f"Error al leer el archivo: {e}", file=sys.stderr)
        sys.exit(1)
    
    # Validación estructural
    is_valid_structure, structure_errors, structure_warnings = validate_domain_structure(
        domain_content, args.domain_file
    )
    
    # Mostrar resultados de validación estructural
    if not is_valid_structure:
        print_validation_results(False, structure_errors, structure_warnings, [])
        if not args.fix:
            sys.exit(1)
    
    # Validación con LLM (si se requiere validación o fix)
    llm_result = None
    if args.validate or args.fix:
        print("Validando con LLM...", file=sys.stderr, flush=True)
        llm_result = validate_domain_with_llm(
            domain_content,
            args.provider,
            args.model,
            args.api_key,
            args.temperature,
        )
        
        # Combinar errores y warnings
        all_errors = structure_errors + llm_result.get("errors", [])
        all_warnings = structure_warnings + llm_result.get("warnings", [])
        all_suggestions = llm_result.get("suggestions", [])
        
        is_valid = is_valid_structure and llm_result.get("valid", False)
        
        # Mostrar resultados
        print_validation_results(is_valid, all_errors, all_warnings, all_suggestions)
    elif not args.export:
        # Si solo se ejecuta sin flags, mostrar validación estructural
        print_validation_results(is_valid_structure, structure_errors, structure_warnings, [])
    
    # Reescritura si se solicita
    if args.fix:
        if llm_result and llm_result.get("corrected_domain"):
            rewrite_domain(
                args.domain_file,
                llm_result["corrected_domain"],
                args.output,
                create_backup=not args.no_backup,
            )
        else:
            print("Advertencia: No se pudo obtener contenido corregido de la LLM.", file=sys.stderr)
            if not is_valid_structure:
                print("El archivo no será reescrito debido a errores estructurales.", file=sys.stderr)
    
    # Exportación si se solicita
    if args.export:
        try:
            # Parsear dominio para exportación
            metadata, domain_content_only = _parse_frontmatter_local(domain_content)
            
            if args.export == "rdf":
                output = export_domain_to_rdf(domain_content_only, metadata, args.domain_file.stem)
            elif args.export == "json":
                output = export_domain_to_json(domain_content_only, metadata)
            elif args.export == "jsonld":
                output = export_domain_to_jsonld(domain_content_only, metadata, args.domain_file.stem)
            else:
                print(f"Error: Formato de exportación desconocido: {args.export}", file=sys.stderr)
                sys.exit(1)
            
            # Guardar exportación
            if args.output:
                output_file = args.output
            else:
                ext_map = {"rdf": ".ttl", "json": ".json", "jsonld": ".jsonld"}
                output_file = args.domain_file.with_suffix(ext_map[args.export])
            
            output_file.write_text(output, encoding="utf-8")
            print(f"Exportación guardada en: {output_file}", file=sys.stderr, flush=True)
        except Exception as e:
            print(f"Error al exportar: {e}", file=sys.stderr)
            import traceback
            traceback.print_exc()
            sys.exit(1)


if __name__ == "__main__":
    main()
