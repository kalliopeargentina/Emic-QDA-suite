"""CLI for sentiment analysis. File(s) or folder. Obsidian or direct args."""
import os
os.environ["USE_TF"] = "0"
os.environ["USE_TORCH"] = "1"
os.environ["TF_ENABLE_ONEDNN_OPTS"] = "0"

import argparse
import sys

from . import common


def _is_truthy(s: str | None) -> bool:
    if not s or not str(s).strip():
        return False
    return str(s).strip().lower() in ("true", "1", "yes", "on")


def _is_unreplaced_template(s: str | None) -> bool:
    """True if value looks like an unreplaced template placeholder (e.g. {{_VarName}})."""
    if not s:
        return False
    t = str(s).strip()
    return len(t) >= 4 and t.startswith("{{") and t.endswith("}}")


def main() -> None:
    common.setup_console_encoding()
    parser = argparse.ArgumentParser(description="Sentiment analysis on file(s) or folder.")
    parser.add_argument("--vault-path", type=str, help="Obsidian vault path (Obsidian mode)")
    parser.add_argument("--file-path", type=str, help="Path to file (Obsidian mode)")
    parser.add_argument("--file-name", type=str, help="Name of file (Obsidian mode)")
    parser.add_argument("--folder-path", type=str, help="Path to folder (Obsidian folder mode)")
    parser.add_argument("--folder-name", type=str, help="Name of folder (Obsidian folder mode)")
    parser.add_argument("--algo", type=str, default="pysentimiento", help="Algorithm")
    parser.add_argument("--model", type=str, help="Model name")
    parser.add_argument("--device", type=str, help="Device: cpu, cuda, cuda:0")
    parser.add_argument("--max-length", type=str, help="Max text length for transformers")
    parser.add_argument("--aggregate", type=str, help="document | sentence | paragraph")
    parser.add_argument("--file-pattern", type=str, help="Glob for folder mode (default: *.md)")
    parser.add_argument("--no-recursive", type=str, help="true/1/yes to disable recursive folder search")
    parser.add_argument("--min-document-length", type=str, help="Min document length (folder mode)")
    parser.add_argument("--output", type=str, help="Output path")
    parser.add_argument("--top-k", type=str, help="Top K")
    parser.add_argument("--min-score", type=str, help="Min score")
    parser.add_argument("--min-confidence", type=str, help="Min confidence")
    parser.add_argument("--min-score-diff", type=str, help="Min score diff")
    parser.add_argument("--min-paragraph-length", type=str, help="Min paragraph length in chars")
    parser.add_argument("--corpus-report", type=str, help="true/1/yes to generate corpus report (folder mode)")
    parser.add_argument("--input-dir", type=str, help="Input folder (direct)")
    parser.add_argument("files", type=str, nargs="*", help="Files (direct mode)")
    args = parser.parse_args()

    vault_path = common.get_optional_param(args.vault_path)
    file_path_arg = common.get_optional_param(args.file_path)
    file_name_arg = common.get_optional_param(args.file_name)
    folder_path_arg = common.get_optional_param(args.folder_path)
    direct_files = getattr(args, "files", []) or []
    input_dir = common.get_optional_param(args.input_dir)

    file_abs = None
    vault = None
    if vault_path and file_path_arg and file_name_arg:
        vault = common.fix_path(vault_path)
        file_abs = common.fix_path(file_path_arg)
        if not os.path.isdir(vault):
            common.safe_print(f"Error: Vault path not found: {vault}", file=sys.stderr)
            sys.exit(1)
        if not os.path.isfile(file_abs):
            common.safe_print(f"Error: File not found: {file_abs}", file=sys.stderr)
            sys.exit(1)
    elif vault_path and folder_path_arg:
        vault = common.fix_path(vault_path)
        file_abs = common.fix_path(folder_path_arg)
        if not os.path.isdir(vault):
            common.safe_print(f"Error: Vault path not found: {vault}", file=sys.stderr)
            sys.exit(1)
        if not os.path.isdir(file_abs):
            common.safe_print(f"Error: Folder not found: {file_abs}", file=sys.stderr)
            sys.exit(1)
    elif direct_files:
        file_abs = common.fix_path(direct_files[0])
        if not os.path.isfile(file_abs):
            common.safe_print(f"Error: File not found: {file_abs}", file=sys.stderr)
            sys.exit(1)
    elif input_dir:
        input_abs = common.fix_path(input_dir)
        if not os.path.isdir(input_abs):
            common.safe_print(f"Error: Input dir not found: {input_abs}", file=sys.stderr)
            sys.exit(1)
        file_abs = input_abs
    else:
        common.safe_print(
            "Error: Use --vault-path with --file-path/--file-name or --folder-path (Obsidian), or pass file(s) / --input-dir.",
            file=sys.stderr,
        )
        parser.print_help(sys.stderr)
        sys.exit(1)

    output_val = common.get_optional_param(args.output)
    if output_val and vault:
        output_val = common.output_path_relative_to_vault(output_val, vault)

    algo_val = (args.algo or "pysentimiento").strip()
    if _is_unreplaced_template(algo_val):
        algo_val = "pysentimiento"
    argv = ["sentiment_main", str(file_abs), "--algo", algo_val]
    for opt, val in [
        ("--model", args.model),
        ("--device", args.device),
        ("--max-length", args.max_length),
        ("--aggregate", args.aggregate),
        ("--file-pattern", args.file_pattern),
        ("--min-document-length", args.min_document_length),
        ("--output", output_val),
        ("--top-k", args.top_k),
        ("--min-score", args.min_score),
        ("--min-confidence", args.min_confidence),
        ("--min-score-diff", args.min_score_diff),
        ("--min-paragraph-length", args.min_paragraph_length),
    ]:
        if val is not None and str(val).strip() and not _is_unreplaced_template(val):
            argv.extend([opt, str(val).strip()])
    no_rec = getattr(args, "no_recursive", None)
    if _is_truthy(no_rec) and not _is_unreplaced_template(no_rec):
        argv.append("--no-recursive")
    corp = getattr(args, "corpus_report", None)
    if _is_truthy(corp) and not _is_unreplaced_template(corp):
        argv.append("--corpus-report")

    orig_argv = sys.argv
    try:
        sys.argv = argv
        from ..analysis.sentiment_analysis import main as sentiment_main
        sentiment_main.main()
    except SystemExit as e:
        if e.code != 0:
            sys.exit(e.code if e.code is not None else 1)
    except Exception as e:
        common.safe_print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
    finally:
        sys.argv = orig_argv
