"""Resolve ffmpeg/ffprobe paths: env var, PATH, optional Windows fallback."""

import os
import subprocess
import sys
from pathlib import Path


def get_ffmpeg_path() -> str:
    """Return path or name for ffmpeg. Order: FFMPEG_BIN env, PATH, Windows fallback."""
    env_bin = os.environ.get("FFMPEG_BIN")
    if env_bin and env_bin.strip():
        return env_bin.strip()
    try:
        r = subprocess.run(
            ["ffmpeg", "-version"],
            capture_output=True,
            text=True,
            check=False,
            timeout=5,
        )
        if r.returncode == 0:
            return "ffmpeg"
    except FileNotFoundError:
        pass
    if sys.platform == "win32":
        for p in [
            r"C:\ffmpeg\bin\ffmpeg.exe",
            r"C:\Program Files\ffmpeg\bin\ffmpeg.exe",
            r"C:\Program Files (x86)\ffmpeg\bin\ffmpeg.exe",
        ]:
            if Path(p).is_file():
                return p
    raise RuntimeError(
        "ffmpeg not found. Install from https://ffmpeg.org/download.html or set FFMPEG_BIN."
    )


def get_ffprobe_path() -> str:
    """Return path or name for ffprobe. Order: FFPROBE_BIN env, PATH, Windows fallback."""
    env_bin = os.environ.get("FFPROBE_BIN")
    if env_bin and env_bin.strip():
        return env_bin.strip()
    try:
        r = subprocess.run(
            ["ffprobe", "-version"],
            capture_output=True,
            text=True,
            check=False,
            timeout=5,
        )
        if r.returncode == 0:
            return "ffprobe"
    except FileNotFoundError:
        pass
    if sys.platform == "win32":
        for p in [
            r"C:\ffmpeg\bin\ffprobe.exe",
            r"C:\Program Files\ffmpeg\bin\ffprobe.exe",
            r"C:\Program Files (x86)\ffmpeg\bin\ffprobe.exe",
        ]:
            if Path(p).is_file():
                return p
    raise RuntimeError(
        "ffprobe not found. Install from https://ffmpeg.org/download.html or set FFPROBE_BIN."
    )
