"""
Configuration and constants for topic analysis.

This module contains all configuration constants, debug flags, and caches
used throughout the topic analysis package.
"""

# ============================================================================
# CONFIGURATION CONSTANTS
# ============================================================================

DEFAULT_CONFIG = {
    'vectorizer': {
        'max_features': 1000,
        'min_df': 2,
        'max_df': 0.95,
        'ngram_range': (1, 2),
    },
    'vectorizer_fallback': {
        'max_features': 500,
        'min_df': 1,
        'max_df': 0.95,
    },
    'text_processing': {
        'min_word_length': 2,
        'min_sentence_length': 50,
        'min_processed_length': 20,
        'min_text_length': 100,
        'min_processed_text_length': 50,
    },
    'topic_extraction': {
        'top_n_words': 10,
        'candidate_words': 50,  # For filtering
    },
    'coherence': {
        'passes': 10,
        'no_below': 2,
        'no_above': 0.8,
        'min_vocab_size': 10,
        'min_sentence_words': 3,
    },
    'corpus_processing': {
        'min_documents': 2,  # Minimum documents for corpus analysis
        'max_documents': None,  # None = unlimited
        'min_document_length': 100,  # Minimum characters per document
        'recursive': True,  # Process subdirectories by default
        'file_patterns': ['*.md', '*.markdown'],  # File extensions to process
    }
}

# Debug/verbose mode (set to True for detailed logging)
DEBUG_MODE = False
VERBOSE = False

# ============================================================================
# EMBEDDING MODELS (Topic analysis: Top2Vec, BERTopic)
# ============================================================================
# Single source of truth for documented embedding options.
# Top2Vec: https://top2vec.readthedocs.io/en/latest/api.html
# BERTopic custom embedding: any SentenceTransformer model name.

TOP2VEC_EMBEDDING_OPTIONS = [
    "all-MiniLM-L6-v2",  # default; sentence-transformers
    "universal-sentence-encoder",
    "universal-sentence-encoder-large",
    "universal-sentence-encoder-multilingual",
    "universal-sentence-encoder-multilingual-large",
    "distiluse-base-multilingual-cased",  # sentence-transformers
    "doc2vec",  # Top2Vec trains from scratch; no pre-download
]

BERTOPIC_EMBEDDING_OPTIONS = [
    "all-MiniLM-L6-v2",
    "paraphrase-multilingual-MiniLM-L12-v2",
    "distiluse-base-multilingual-cased",
    "all-mpnet-base-v2",
]

# ============================================================================
# CACHES
# ============================================================================

_stopwords_cache = {}  # Cache for loaded stopwords
_spacy_model_cache = {}  # Cache for loaded spaCy models

