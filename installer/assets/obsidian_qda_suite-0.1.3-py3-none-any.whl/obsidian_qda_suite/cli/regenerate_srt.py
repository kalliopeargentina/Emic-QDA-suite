"""CLI for regenerating SRT from Markdown. Accepts Obsidian or direct args."""

import argparse
import os
import re
import sys
from pathlib import Path

from obsidian_qda_suite.audio.md_to_srt import run as md_to_srt_run
from . import common


def main() -> None:
    common.setup_console_encoding()
    parser = argparse.ArgumentParser(
        description="Regenerate SRT file from corrected Markdown transcript.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    # Obsidian mode
    parser.add_argument("--vault-path", type=str, default=None, help="Path to Obsidian vault")
    parser.add_argument("--file-path", type=str, default=None, help="Absolute path to Markdown file")
    parser.add_argument("--media-path", type=str, default=None, help="Media path (relative to vault or absolute)")
    # Direct mode
    parser.add_argument("markdown_file", type=str, nargs="?", default=None, help="Path to Markdown file (direct mode)")
    parser.add_argument("--srt-output", type=str, default=None, help="SRT output path or directory")
    args = parser.parse_args()

    if args.vault_path and args.file_path and args.media_path:
        # Obsidian mode
        vault = common.fix_path(args.vault_path.strip().replace("`", "").replace('"', ""))
        src = common.fix_path(args.file_path.strip().replace("`", "").replace('"', ""))
        root = common.fix_path(args.media_path.strip().replace("`", "").replace('"', ""))
        if not vault or not os.path.isdir(vault):
            common.safe_print("Error: invalid or missing vault path.", file=sys.stderr)
            sys.exit(1)
        if not src or not os.path.isfile(src):
            common.safe_print("Error: invalid or missing file path.", file=sys.stderr)
            sys.exit(1)
        if not root:
            common.safe_print("Error: media path required.", file=sys.stderr)
            sys.exit(1)
        if not os.path.isabs(root):
            root = os.path.join(vault, root)
        base_no_ext = Path(src).stem
        dir_name = re.sub(r"_part\d+$", "", base_no_ext)
        dest = os.path.join(root, dir_name)
        os.makedirs(dest, exist_ok=True)
        try:
            srt_path = md_to_srt_run(Path(src), srt_output=Path(dest), output_basename=base_no_ext)
            common.safe_print(f"SRT created: {srt_path}")
        except Exception as e:
            common.safe_print(f"Error: {e}", file=sys.stderr)
            sys.exit(1)
        return

    # Direct mode: positional markdown file
    md_file = args.markdown_file or (args.file_path if args.file_path else None)
    if not md_file:
        parser.error("Provide markdown file (positional) or use Obsidian mode (--vault-path --file-path --media-path).")
    md_path = Path(common.fix_path(md_file))
    if not md_path.is_file():
        common.safe_print(f"Error: file not found: {md_path}", file=sys.stderr)
        sys.exit(1)
    srt_out = Path(common.fix_path(args.srt_output)) if args.srt_output else None
    try:
        srt_path = md_to_srt_run(md_path, srt_output=srt_out)
        common.safe_print(f"SRT created: {srt_path}")
    except Exception as e:
        common.safe_print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
