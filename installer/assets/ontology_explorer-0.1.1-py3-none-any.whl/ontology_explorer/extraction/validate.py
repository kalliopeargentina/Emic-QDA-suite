"""Validation helpers for extraction outputs."""

from __future__ import annotations


def validate_result(result: dict) -> list[str]:
    """Returns a list of warning messages. Does not raise."""
    warnings: list[str] = []

    if not isinstance(result, dict):
        return ["Resultado no es un dict."]

    entities = result.get("entities", [])
    relations = result.get("relations", [])

    if not isinstance(entities, list):
        warnings.append("entities no es una lista.")
    if not isinstance(relations, list):
        warnings.append("relations no es una lista.")

    for ent in entities:
        if not isinstance(ent, list) or len(ent) < 2:
            warnings.append("Entidad con formato inválido.")
            continue
        name = ent[0]
        ent_type = ent[1]
        if not name or not ent_type:
            warnings.append("Entidad con nombre o tipo vacío.")

    for rel in relations:
        if not isinstance(rel, list) or len(rel) < 3:
            warnings.append("Relación con formato inválido.")
            continue
        rel_type, source, target = rel[0], rel[1], rel[2]
        if not rel_type or not source or not target:
            warnings.append("Relación con campos vacíos.")

    return warnings
