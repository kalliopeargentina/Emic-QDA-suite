"""File I/O helpers."""

from __future__ import annotations

import sys
from pathlib import Path


OUTPUTS_DIR = Path("outputs")


def read_article_text(article_path: Path) -> str:
    return article_path.read_text(encoding="utf-8")


def read_article_text_safe(article_path: Path) -> tuple[str | None, str | None]:
    """
    Read file as UTF-8 text. Returns (content, None) on success,
    (None, error_message) on encoding or I/O error.
    """
    try:
        content = article_path.read_text(encoding="utf-8")
        return (content, None)
    except UnicodeDecodeError as e:
        return (None, f"encoding error: {e}")
    except OSError as e:
        return (None, f"no se pudo leer: {e}")


def ensure_outputs_dir() -> Path:
    OUTPUTS_DIR.mkdir(parents=True, exist_ok=True)
    return OUTPUTS_DIR


def _resolve_output_base(output_dir: Path | None) -> Path:
    """Devuelve el directorio base de salida; si no se pasa, usa outputs/."""
    if output_dir is not None:
        base = output_dir.resolve()
        base.mkdir(parents=True, exist_ok=True)
        return base
    return ensure_outputs_dir()


def write_text_output(
    content: str, filename: str, output_dir: Path | None = None
) -> Path:
    base = _resolve_output_base(output_dir)
    output_path = base / filename
    output_path.write_text(content, encoding="utf-8")
    print(f"Output guardado en: {output_path}", file=sys.stderr, flush=True)
    return output_path


def write_vault_output(
    files: dict[str, str], base_dir_name: str, output_dir: Path | None = None
) -> Path:
    """
    Escribe múltiples archivos en un subdirectorio de outputs.

    Crea outputs/base_dir_name/ (o output_dir/base_dir_name si se pasa output_dir)
    y escribe cada entrada (ruta_relativa, contenido) en ese directorio,
    creando subcarpetas según sea necesario.

    Returns:
        Path al directorio base creado.
    """
    base = _resolve_output_base(output_dir)
    base_dir = base / base_dir_name
    base_dir.mkdir(parents=True, exist_ok=True)
    for rel_path, content in files.items():
        file_path = base_dir / rel_path
        file_path.parent.mkdir(parents=True, exist_ok=True)
        file_path.write_text(content, encoding="utf-8")
    print(f"Vault exportado en: {base_dir} ({len(files)} archivos)", file=sys.stderr, flush=True)
    return base_dir
