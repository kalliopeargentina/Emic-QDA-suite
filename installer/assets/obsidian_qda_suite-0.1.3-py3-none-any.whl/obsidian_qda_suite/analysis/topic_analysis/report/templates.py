"""
Report template generation for topic analysis.

This module provides functions for generating markdown reports
with topic analysis results.
"""

import os
from pathlib import Path
from datetime import datetime


def generate_markdown_report(output_path, topics, stats, top_words, chart_paths, 
                             source_file=None, images_dir=None, method='lda', 
                             n_topics=None, custom_stopwords_file=None, 
                             seed_words_file=None, hdp_gamma=1.0, hdp_alpha=1.0,
                             top2vec_embedding_model='all-MiniLM-L6-v2',
                             bertopic_min_topic_size=10, bertopic_top_n_words=10,
                             bertopic_diversity=0.0, bertopic_calculate_probabilities=True,
                             bertopic_embedding_model=None, corpus_stats=None,
                             document_labels=None):
    """Generate the markdown report file."""
    with open(output_path, 'w', encoding='utf-8') as f:
        # Write YAML frontmatter
        if source_file:
            source_path = Path(source_file)
            source_wikilink = f"[[{source_path.stem}]]"
        else:
            source_wikilink = "Corpus Analysis"
        
        num_topics = n_topics if n_topics is not None else len(topics)
        
        # Format method name
        method_name = method.upper() if method else 'LDA'
        method_names = {
            'LDA': 'Latent Dirichlet Allocation (LDA)',
            'NMF': 'Non-negative Matrix Factorization (NMF)',
            'GUIDED-LDA': 'Guided Latent Dirichlet Allocation (Guided LDA)',
            'HDP': 'Hierarchical Dirichlet Process (HDP)',
            'COREX': 'Correlation Explanation (CorEx)',
            'LSI': 'Latent Semantic Indexing/Analysis (LSI/LSA)',
            'LSA': 'Latent Semantic Indexing/Analysis (LSI/LSA)',
            'TOP2VEC': 'Top2Vec',
            'BERTOPIC': 'BERTopic'
        }
        method_name = method_names.get(method_name, method_name)
        
        f.write("---\n")
        f.write(f"date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f'source: "{source_wikilink}"\n')
        f.write(f'method: {method_name}\n')
        f.write(f'topics: {num_topics}\n')
        if custom_stopwords_file:
            stopwords_path = Path(custom_stopwords_file)
            stopwords_wikilink = f"[[{stopwords_path.stem}]]"
            f.write(f'stopwords-file: "{stopwords_wikilink}"\n')
        if seed_words_file:
            seed_path = Path(seed_words_file)
            seed_wikilink = f"[[{seed_path.stem}]]"
            f.write(f'seed-words-file: "{seed_wikilink}"\n')
        f.write("tags:\n")
        f.write("---\n\n")
        
        # Title
        f.write("# Reporte de Análisis de Temas\n\n")
        f.write(f"**Generado:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f"**Fuente:** {source_wikilink}\n\n")
        
        # Executive Summary
        f.write("## Resumen Ejecutivo\n\n")
        if corpus_stats:
            f.write(f"Este reporte analiza {len(topics)} temas principales identificados en un corpus de ")
            f.write(f"{corpus_stats.get('total_documents', corpus_stats.get('num_documents', 0))} documentos. ")
            f.write(f"El análisis se basa en {stats['total_words']:,} palabras distribuidas en ")
            f.write(f"{stats['total_sentences']:,} oraciones.\n\n")
        else:
            f.write(f"Este reporte analiza {len(topics)} temas principales identificados en el documento fuente. ")
            f.write(f"El análisis se basa en {stats['total_words']:,} palabras distribuidas en ")
            f.write(f"{stats['total_sentences']:,} oraciones.\n\n")
        
        # Corpus Statistics (if corpus analysis)
        if corpus_stats:
            f.write("## Estadísticas del Corpus\n\n")
            f.write("| Métrica | Valor |\n")
            f.write("|---------|-------|\n")
            f.write(f"| Total de Documentos | {corpus_stats.get('total_documents', 0):,} |\n")
            f.write(f"| Total de Palabras | {corpus_stats.get('total_words', 0):,} |\n")
            f.write(f"| Total de Oraciones | {corpus_stats.get('total_sentences', 0):,} |\n")
            f.write(f"| Promedio de Palabras por Documento | {corpus_stats.get('avg_words_per_document', 0):.0f} |\n")
            f.write(f"| Promedio de Oraciones por Documento | {corpus_stats.get('avg_sentences_per_document', 0):.1f} |\n\n")
        
        # Text Statistics
        f.write("## Estadísticas del Texto\n\n")
        f.write("| Métrica | Valor |\n")
        f.write("|---------|-------|\n")
        f.write(f"| Total de Palabras | {stats['total_words']:,} |\n")
        f.write(f"| Palabras Únicas | {stats['unique_words']:,} |\n")
        f.write(f"| Riqueza del Vocabulario | {stats['vocabulary_richness']:.2%} |\n")
        f.write(f"| Total de Oraciones | {stats['total_sentences']:,} |\n")
        f.write(f"| Total de Párrafos | {stats['total_paragraphs']:,} |\n")
        f.write(f"| Long. Promedio de Oración | {stats['avg_sentence_length']:.1f} palabras |\n")
        f.write(f"| Long. Promedio de Palabra | {stats['avg_word_length']:.1f} caracteres |\n\n")
        
        # Topics
        f.write("## Temas Identificados\n\n")
        for topic in topics:
            f.write(f"### Tema {topic['topic_id']+1}\n\n")
            
            if 'seed_words' in topic and topic.get('seed_words'):
                f.write("**Palabras Semilla/Ancla:** ")
                f.write(f"{', '.join(topic['seed_words'][:10])}\n\n")
            
            f.write("**Palabras Clave Principales:**\n\n")
            for i, (word, weight) in enumerate(zip(topic['words'][:10], topic['weights'][:10]), 1):
                f.write(f"{i}. {word} (peso: {weight:.4f})\n")
            f.write("\n")
        
        # Top Words
        f.write("## Palabras Más Frecuentes\n\n")
        f.write("| Rango | Palabra | Frecuencia |\n")
        f.write("|-------|---------|------------|\n")
        for rank, (word, freq) in enumerate(top_words[:20], 1):
            f.write(f"| {rank} | {word} | {freq} |\n")
        f.write("\n")
        
        # Document-Topic Distribution (if corpus analysis)
        if document_labels and len(document_labels) > 0:
            f.write("## Distribución de Temas por Documento\n\n")
            f.write("Esta sección muestra cómo se distribuyen los temas a través de los diferentes documentos del corpus.\n\n")
            # Note: This would need topic_distributions passed as parameter
            # For now, we'll just note it in the report
        
        # Visualizations
        f.write("## Visualizaciones\n\n")
        
        def get_wikilink_path(image_path):
            """Get the path to use in Obsidian wikilink format."""
            md_dir = Path(output_path).parent
            img_path = Path(image_path)
            
            try:
                rel_path = os.path.relpath(img_path, md_dir)
            except ValueError:
                rel_path = str(img_path)
            
            rel_path = rel_path.replace('\\', '/')
            
            if rel_path.startswith('../'):
                return rel_path
            elif '/' not in rel_path or rel_path.startswith('./'):
                return rel_path.lstrip('./')
            else:
                return rel_path
        
        if chart_paths.get('distribution'):
            link_path = get_wikilink_path(chart_paths['distribution'])
            f.write(f"### Distribución de Temas\n\n")
            f.write(f"Este gráfico muestra la distribución promedio de temas. ")
            f.write(f"Cada barra representa un tema y su altura indica la proporción promedio ")
            if corpus_stats:
                f.write(f"de ese tema en todo el corpus.\n\n")
            else:
                f.write(f"de ese tema en todo el documento.\n\n")
            f.write(f"![[{link_path}]]\n\n")
        
        if chart_paths.get('words'):
            link_path = get_wikilink_path(chart_paths['words'])
            f.write(f"### Palabras Principales por Tema\n\n")
            f.write(f"Este gráfico presenta las palabras clave principales asociadas a cada tema identificado.\n\n")
            f.write(f"![[{link_path}]]\n\n")
        
        if chart_paths.get('heatmap'):
            link_path = get_wikilink_path(chart_paths['heatmap'])
            f.write(f"### Mapa de Calor de Distribución de Temas\n\n")
            f.write(f"Este mapa de calor visualiza la presencia de temas a lo largo de los documentos o secciones.\n\n")
            f.write(f"![[{link_path}]]\n\n")
        
        if chart_paths.get('word_freq'):
            link_path = get_wikilink_path(chart_paths['word_freq'])
            f.write(f"### Gráfico de Frecuencia de Palabras\n\n")
            if corpus_stats:
                f.write(f"Este gráfico muestra las 20 palabras más frecuentes en el corpus.\n\n")
            else:
                f.write(f"Este gráfico muestra las 20 palabras más frecuentes en el documento.\n\n")
            f.write(f"![[{link_path}]]\n\n")
        
        if chart_paths.get('wordcloud'):
            link_path = get_wikilink_path(chart_paths['wordcloud'])
            f.write(f"### Nube de Palabras\n\n")
            if corpus_stats:
                f.write(f"La siguiente nube de palabras muestra las palabras más frecuentes en el corpus.\n\n")
            else:
                f.write(f"La siguiente nube de palabras muestra las palabras más frecuentes en el documento.\n\n")
            f.write(f"![[{link_path}]]\n\n")
        
        if chart_paths.get('topic_map'):
            link_path = get_wikilink_path(chart_paths['topic_map'])
            f.write(f"### Mapa Semántico de Temas\n\n")
            f.write(f"Este mapa muestra las relaciones entre los temas identificados.\n\n")
            f.write(f"![[{link_path}]]\n\n")
        
        if chart_paths.get('word_topic_network'):
            link_path = get_wikilink_path(chart_paths['word_topic_network'])
            f.write(f"### Red Palabra-Tema\n\n")
            f.write(f"Esta red bipartita muestra las conexiones entre palabras y temas.\n\n")
            f.write(f"![[{link_path}]]\n\n")
        
        if chart_paths.get('topic_cooccurrence_network'):
            link_path = get_wikilink_path(chart_paths['topic_cooccurrence_network'])
            f.write(f"### Red de Co-ocurrencia de Temas\n\n")
            f.write(f"Esta red muestra cómo se relacionan los temas entre sí basándose en su similitud semántica.\n\n")
            f.write(f"![[{link_path}]]\n\n")
        
        if chart_paths.get('word_cooccurrence_network'):
            link_path = get_wikilink_path(chart_paths['word_cooccurrence_network'])
            f.write(f"### Red de Co-ocurrencia de Palabras\n\n")
            f.write(f"Esta red visualiza las relaciones entre palabras que aparecen juntas en los mismos temas.\n\n")
            f.write(f"![[{link_path}]]\n\n")
        
        # Methodology
        f.write("## Metodología\n\n")
        if corpus_stats:
            f.write(f"Este análisis utiliza **{method_name}** para identificar temas principales en el corpus.\n\n")
        else:
            f.write(f"Este análisis utiliza **{method_name}** para identificar temas principales en el documento.\n\n")
        f.write(f"**Parámetros de configuración:**\n\n")
        f.write(f"- Método: `{method}`\n")
        if n_topics is not None:
            f.write(f"- Número de temas: `{n_topics}`\n")
        else:
            f.write(f"- Número de temas: `auto` (detectado: {num_topics})\n")
        
        if method.lower() == 'hdp':
            f.write(f"- Gamma: `{hdp_gamma}`\n")
            f.write(f"- Alpha: `{hdp_alpha}`\n")
        elif method.lower() == 'top2vec':
            f.write(f"- Modelo de embeddings: `{top2vec_embedding_model}`\n")
        elif method.lower() == 'bertopic':
            f.write(f"- Tamaño mínimo de tema: `{bertopic_min_topic_size}`\n")
            f.write(f"- Palabras por tema: `{bertopic_top_n_words}`\n")
            f.write(f"- Diversidad: `{bertopic_diversity}`\n")
        
        f.write("\n")

