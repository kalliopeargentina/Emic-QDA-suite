from typing import Dict, Any, List
import torch
from transformers import AutoTokenizer, AutoModelForSequenceClassification, TextClassificationPipeline
from .base import SentimentBackend


DEFAULT_EMOTION_MODEL = "cardiffnlp/twitter-roberta-base-emotion"


class TransformersEmotionBackend(SentimentBackend):
    name = "transformers-emotion"

    def __init__(self, model: str = DEFAULT_EMOTION_MODEL,
                 device: int | None = None, max_length: int = 4000, **_):
        self.model_name = model
        self.tokenizer = AutoTokenizer.from_pretrained(model)
        self.model = AutoModelForSequenceClassification.from_pretrained(model)
        if device is None:
            device = 0 if torch.cuda.is_available() else -1
        else:
            # Validate device number if CUDA is requested
            if device >= 0:
                if not torch.cuda.is_available():
                    print("⚠️ CUDA device requested but CUDA is not available. Using CPU instead.")
                    device = -1
                elif device >= torch.cuda.device_count():
                    print(f"⚠️ CUDA device {device} requested but only {torch.cuda.device_count()} device(s) available. Using CPU instead.")
                    device = -1
        self.pipe = TextClassificationPipeline(
            model=self.model, tokenizer=self.tokenizer, device=device, top_k=None
        )
        self.max_length = max_length

    def _best(self, scores):
        best = max(scores, key=lambda x: x["score"])
        return best["label"], {s["label"]: float(s["score"]) for s in scores}

    def predict(self, text: str, lang: str | None = None) -> Dict[str, Any]:
        res = self.pipe(text[: self.max_length], truncation=True, max_length=512)
        label, scores = self._best(res[0])
        return {"label": label, "scores": scores, "lang": lang}

    def predict_batch(self, texts: List[str], lang: str | None = None) -> List[Dict[str, Any]]:
        batched = self.pipe([t[: self.max_length] for t in texts], truncation=True, max_length=512)
        out = []
        for scores in batched:
            label, sc = self._best(scores)
            out.append({"label": label, "scores": sc, "lang": lang})
        return out


