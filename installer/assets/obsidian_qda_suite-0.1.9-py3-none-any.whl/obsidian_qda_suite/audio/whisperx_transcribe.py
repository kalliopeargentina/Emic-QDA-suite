#!/usr/bin/env python3
"""
Audio Transcription Script using Local WhisperX

Transcribes audio files to SRT and markdown formats for use in Obsidian.
Uses local WhisperX models for transcription with optional speaker diarization.
"""
# PyTorch 2.6+ defaults to weights_only=True; pyannote/whisperx checkpoints need weights_only=False.
# Set before any torch import so torch.load uses legacy (safe for trusted checkpoints).
import os
os.environ.setdefault("TORCH_FORCE_NO_WEIGHTS_ONLY_LOAD", "1")

import argparse
import sys
import gc
from pathlib import Path
from datetime import timedelta, datetime

from .speechbrain_compat import apply_windows_lazy_import_patch
from .transcription_errors import TORCHAUDIO_COMPAT_ERROR, format_transcription_error

apply_windows_lazy_import_patch()


def check_torchaudio_compat() -> None:
    """Exit with a user-facing message if torchaudio is too new for pyannote/WhisperX."""
    if not hasattr(torchaudio, "AudioMetaData"):
        print(TORCHAUDIO_COMPAT_ERROR, file=sys.stderr)
        sys.exit(1)


# Try to import WhisperX and related libraries
try:
    import torch
    import torchaudio
    check_torchaudio_compat()
    import whisperx
except ImportError:
    print("Error: WhisperX is not installed.")
    print("Install it with: pip install whisperx")
    print("You may also need: pip install torch torchaudio")
    sys.exit(1)

# Try to load .env file if python-dotenv is available
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

from ..config import get_paths_config

# Global debug mode flag
DEBUG_MODE = False

def debug_print(*args, **kwargs):
    """Print only if debug mode is enabled."""
    if DEBUG_MODE:
        print(*args, **kwargs)

def info_print(*args, **kwargs):
    """Print always - for important progress messages."""
    print(*args, **kwargs)

def progress_print(*args, **kwargs):
    """Print progress messages - visible even in quiet mode."""
    print(*args, **kwargs)


def format_timestamp(seconds):
    """Convert seconds to SRT timestamp format (HH:MM:SS,mmm)."""
    td = timedelta(seconds=seconds)
    total_seconds = int(td.total_seconds())
    hours, remainder = divmod(total_seconds, 3600)
    minutes, seconds = divmod(remainder, 60)
    milliseconds = int((td.total_seconds() - total_seconds) * 1000)
    return f"{hours:02d}:{minutes:02d}:{seconds:02d},{milliseconds:03d}"


def format_timestamp_markdown(seconds):
    """Convert seconds to markdown timestamp format (HH:MM:SS)."""
    td = timedelta(seconds=seconds)
    total_seconds = int(td.total_seconds())
    hours, remainder = divmod(total_seconds, 3600)
    minutes, seconds = divmod(remainder, 60)
    return f"{hours:02d}:{minutes:02d}:{seconds:02d}"


def get_device(device_arg=None):
    """Determine device to use (CPU or CUDA)."""
    if device_arg:
        # Validate device format (allow cuda:0, cuda:1, etc.)
        if device_arg.startswith('cuda:'):
            # Extract GPU number
            try:
                gpu_num = int(device_arg.split(':')[1])
                if torch.cuda.is_available() and gpu_num < torch.cuda.device_count():
                    return device_arg
                else:
                    print(f"Warning: GPU {gpu_num} not available. Using default CUDA device.")
                    return "cuda" if torch.cuda.is_available() else "cpu"
            except (ValueError, IndexError):
                print(f"Warning: Invalid device format '{device_arg}'. Using default.")
        elif device_arg in ["cpu", "cuda", "mps"]:
            return device_arg
        else:
            print(f"Warning: Unknown device '{device_arg}'. Using default.")
    
    # Auto-detect device
    if torch.cuda.is_available():
        return "cuda"
    elif hasattr(torch.backends, 'mps') and torch.backends.mps.is_available():
        return "mps"  # Apple Silicon
    else:
        return "cpu"


def get_hf_token(hf_token_arg=None):
    """Get HuggingFace token from command line argument, environment variable, or config file."""
    # Priority: command line > environment variable > config file
    hf_token = None
    if hf_token_arg:
        return hf_token_arg
    
    hf_token = os.getenv("HUGGINGFACE_TOKEN") or os.getenv("HF_TOKEN")
    if hf_token:
        return hf_token
    
    # Try to read from config file in current directory or home directory
    config_paths = [
        Path(".huggingface_token"),
        Path.home() / ".huggingface_token",
        Path(".hf_token"),
        Path.home() / ".hf_token",
        Path("config.txt")
    ]
    
    for config_path in config_paths:
        if config_path.exists():
            try:
                with open(config_path, "r") as f:
                    token = f.read().strip()
                    if token:
                        return token
            except Exception:
                pass
    
    return None


def _timestamps_cli_enabled(timestamps_arg: str) -> bool:
    """CLI --timestamps: empty default means on; false/0/no/off disables MD wikilinks only (SRT always has timecodes)."""
    if not timestamps_arg:
        return True
    d = (timestamps_arg or "").strip().lower()
    return d not in ("false", "0", "no", "off")


def _normalize_segment_time_bounds(result):
    """Ensure each segment has float start/end after transcribe-only (no align)."""
    if not isinstance(result, dict):
        result = {"segments": result}
    segments = result.get("segments", [])
    for seg in segments:
        if not isinstance(seg, dict):
            continue
        if "start" in seg:
            seg["start"] = float(seg["start"])
        if "end" not in seg or seg.get("end") is None:
            if seg.get("words"):
                last_word = seg["words"][-1]
                if isinstance(last_word, dict) and "end" in last_word:
                    seg["end"] = float(last_word["end"])
                else:
                    text = seg.get("text", "")
                    seg["end"] = float(seg.get("start", 0)) + max(1.0, len(text) * 0.1)
            else:
                text = seg.get("text", "")
                seg["end"] = float(seg.get("start", 0)) + max(1.0, len(text) * 0.1)
        else:
            seg["end"] = float(seg["end"])
    result["segments"] = segments
    return result


def transcribe_audio(file_path, model_size="large-v3", device="cuda", language=None, 
                     diarize=False, hf_token=None, min_speakers=None, max_speakers=None,
                     batch_size=16, align_timestamps=True):
    """Transcribe audio file using local WhisperX."""
    progress_print(f"Transcribing {file_path}...")
    debug_print(f"Device: {device}, Model: {model_size}")
    
    # Load audio
    debug_print("Loading audio file...")
    audio = whisperx.load_audio(file_path)
    
    # Load model
    progress_print(f"Loading WhisperX model '{model_size}'...")
    # Check if device is cuda (with or without GPU number)
    is_cuda = device.startswith("cuda") if isinstance(device, str) else (device == "cuda")
    model = whisperx.load_model(model_size, device, compute_type="float16" if is_cuda else "int8")
    
    # Transcribe
    progress_print("Transcribing audio...")
    result = model.transcribe(audio, batch_size=batch_size, language=language)
    
    # Detect language if not specified
    detected_language = result.get("language", language)
    if not language:
        debug_print(f"Detected language: {detected_language}")
    
    # Free model from memory
    del model
    gc.collect()
    is_cuda = device.startswith("cuda") if isinstance(device, str) else (device == "cuda")
    if is_cuda:
        torch.cuda.empty_cache()
    
    if align_timestamps:
        progress_print("Aligning timestamps...")
        align_model, metadata = whisperx.load_align_model(language_code=detected_language, device=device)
        result = whisperx.align(result["segments"], align_model, metadata, audio, device, return_char_alignments=False)

        if not isinstance(result, dict):
            result = {"segments": result}

        segments = result.get("segments", [])
        if segments:
            for seg in segments:
                if isinstance(seg, dict):
                    if "start" in seg:
                        seg["start"] = float(seg["start"])
                    if "end" not in seg:
                        if "words" in seg and seg["words"] and len(seg["words"]) > 0:
                            last_word = seg["words"][-1]
                            if isinstance(last_word, dict) and "end" in last_word:
                                seg["end"] = float(last_word["end"])
                            else:
                                text = seg.get("text", "")
                                estimated_duration = max(1.0, len(text) * 0.1)
                                seg["end"] = float(seg["start"]) + estimated_duration
                        else:
                            seg["end"] = float(seg.get("start", 0)) + 5.0
                    else:
                        seg["end"] = float(seg["end"])
            result["segments"] = segments

        del align_model
        gc.collect()
        is_cuda = device.startswith("cuda") if isinstance(device, str) else (device == "cuda")
        if is_cuda:
            torch.cuda.empty_cache()
    else:
        progress_print("Skipping word-level alignment (--timestamps false).")
        result = _normalize_segment_time_bounds(result)

    # Perform speaker diarization if requested
    if diarize:
        if not hf_token:
            print("Error: HuggingFace token is required for speaker diarization.")
            print("\nPlease provide your HF token using one of these methods:")
            print("  1. Command line: --hf-token YOUR_TOKEN")
            print("  2. Environment variable: set HUGGINGFACE_TOKEN=YOUR_TOKEN")
            print("  3. Config file: Create .huggingface_token in current directory or home directory")
            print("\nYou also need to accept the user agreements for:")
            print("  - pyannote/segmentation")
            print("  - pyannote/speaker-diarization-3.1")
            print("\nVisit: https://huggingface.co/pyannote/segmentation")
            print("       https://huggingface.co/pyannote/speaker-diarization-3.1")
            sys.exit(1)
        
        progress_print("Performing speaker diarization...")
        try:
            # Use pyannote.audio Pipeline directly (as shown in the example)
            from pyannote.audio import Pipeline
            
            debug_print("Loading pyannote speaker diarization pipeline...")
            # Try both parameter names for compatibility with different versions
            diarize_model = None
            try:
                # Newer versions use 'token'
                diarize_model = Pipeline.from_pretrained(
                    "pyannote/speaker-diarization-3.1",
                    token=hf_token
                )
            except TypeError:
                # Older versions use 'use_auth_token'
                try:
                    diarize_model = Pipeline.from_pretrained(
                        "pyannote/speaker-diarization-3.1",
                        use_auth_token=hf_token
                    )
                except Exception as e:
                    # Try logging in with huggingface_hub first
                    debug_print("Attempting to login to HuggingFace...")
                    try:
                        from huggingface_hub import login
                        login(token=hf_token)
                        # Try again after login
                        diarize_model = Pipeline.from_pretrained(
                            "pyannote/speaker-diarization-3.1",
                            token=hf_token
                        )
                    except ImportError:
                        debug_print("huggingface_hub not available, skipping login")
                        raise e
            except Exception as e:
                # If both fail, try login and retry
                if "Could not download" in str(e) or "gated" in str(e).lower():
                    debug_print("Authentication issue detected. Attempting to login to HuggingFace...")
                    try:
                        from huggingface_hub import login
                        login(token=hf_token)
                        # Try again after login
                        diarize_model = Pipeline.from_pretrained(
                            "pyannote/speaker-diarization-3.1",
                            token=hf_token
                        )
                    except ImportError:
                        debug_print("huggingface_hub not available")
                        raise e
                else:
                    raise
            
            if diarize_model is None:
                raise ValueError(
                    "Failed to load diarization pipeline. Please ensure:\n"
                    "1. Your HuggingFace token is correct\n"
                    "2. You have accepted user agreements for:\n"
                    "   - https://huggingface.co/pyannote/speaker-diarization-3.1\n"
                    "   - https://huggingface.co/pyannote/segmentation-3.0\n"
                    "3. Your token has read access to gated models"
                )
            
            diarize_model.to(torch.device(device))
            
            # Configure pipeline parameters to handle variable-length segments
            # This helps avoid tensor size mismatch errors by processing one segment at a time
            debug_print("Configuring diarization pipeline for variable-length segments...")
            try:
                # Try to access and configure the embedding model directly
                # The error occurs in get_embeddings, so we need to configure the embedding component
                if hasattr(diarize_model, 'embedding'):
                    embedding_model = diarize_model.embedding
                    if hasattr(embedding_model, 'batch_size'):
                        embedding_model.batch_size = 1
                        debug_print("Set embedding batch_size to 1")
                elif hasattr(diarize_model, '_embedding'):
                    embedding_model = diarize_model._embedding
                    if hasattr(embedding_model, 'batch_size'):
                        embedding_model.batch_size = 1
                        debug_print("Set embedding batch_size to 1")
                
                # Also configure segmentation if available
                if hasattr(diarize_model, 'segmentation'):
                    seg_model = diarize_model.segmentation
                    if hasattr(seg_model, 'batch_size'):
                        seg_model.batch_size = 1
                elif hasattr(diarize_model, '_segmentation'):
                    seg_model = diarize_model._segmentation
                    if hasattr(seg_model, 'batch_size'):
                        seg_model.batch_size = 1
            except Exception as e:
                debug_print(f"Note: Could not configure batch sizes automatically: {e}")
                debug_print("Will attempt to process with default settings...")
            
            # Run the pipeline on the audio file
            # Try loading audio as waveform first to avoid tensor size mismatch issues
            progress_print(f"Running diarization on {file_path}...")
            
            # Prepare parameters
            call_kwargs = {}
            if min_speakers is not None:
                call_kwargs['min_speakers'] = min_speakers
            if max_speakers is not None:
                call_kwargs['max_speakers'] = max_speakers
            
            # Try loading audio as waveform first (this often fixes tensor size mismatches)
            # By loading the audio ourselves, we ensure consistent format
            try:
                debug_print("Loading audio as waveform to ensure consistent format...")
                waveform, sample_rate = torchaudio.load(str(file_path))
                # Convert to mono if stereo
                if waveform.shape[0] > 1:
                    waveform = torch.mean(waveform, dim=0, keepdim=True)
                
                # Pass as dict format (more reliable than file path)
                audio_input = {"waveform": waveform, "sample_rate": sample_rate}
                debug_print(f"Audio loaded: {waveform.shape}, sample_rate={sample_rate}")
                
                diarization = diarize_model(audio_input, **call_kwargs)
                debug_print("Diarization completed successfully with waveform input")
            except (RuntimeError, TypeError, AttributeError) as e:
                if "Sizes of tensors must match" in str(e) or "unexpected keyword" in str(e).lower():
                    debug_print(f"Waveform input failed ({type(e).__name__}): {str(e)}")
                    debug_print("Trying with file path instead...")
                    
                    # Fallback to file path
                    try:
                        diarization = diarize_model(str(file_path), **call_kwargs)
                    except RuntimeError as path_error:
                        if "Sizes of tensors must match" in str(path_error):
                            debug_print("Warning: Tensor size mismatch detected with file path input.")
                            debug_print("Attempting to configure embedding model batch processing...")
                            
                            # Try to configure batch sizes more aggressively
                            try:
                                # Try multiple ways to access and configure embedding
                                embedding_configured = False
                                
                                # Method 1: Direct embedding access
                                for attr_name in ['_embedding', 'embedding']:
                                    if hasattr(diarize_model, attr_name):
                                        embedding = getattr(diarize_model, attr_name)
                                        # Try to set batch_size on inference
                                        if hasattr(embedding, 'inference'):
                                            inference = embedding.inference
                                            if hasattr(inference, 'batch_size'):
                                                inference.batch_size = 1
                                                debug_print(f"Set {attr_name}.inference.batch_size to 1")
                                                embedding_configured = True
                                        # Also try setting batch_size directly
                                        if hasattr(embedding, 'batch_size'):
                                            embedding.batch_size = 1
                                            debug_print(f"Set {attr_name}.batch_size to 1")
                                            embedding_configured = True
                                
                                # Method 2: Try to patch get_embeddings to process one at a time
                                # This is more complex but might work
                                if not embedding_configured:
                                    debug_print("Note: Could not configure batch sizes via standard methods")
                                
                            except Exception as config_error:
                                debug_print(f"Could not configure batch size: {config_error}")
                            
                            # Final retry with file path
                            try:
                                diarization = diarize_model(str(file_path), **call_kwargs)
                            except RuntimeError as final_error:
                                if "Sizes of tensors must match" in str(final_error):
                                    print(f"\nError: Could not resolve tensor size mismatch.")
                                    print("This is a known issue with variable-length audio segments in pyannote.audio")
                                    print("\nPossible solutions:")
                                    print("1. Use CPU: --device cpu (often more reliable for this issue)")
                                    print("2. Update pyannote.audio: pip install --upgrade pyannote.audio")
                                    print("3. Try a different audio file or pre-process to normalize segment lengths")
                                    print("4. Consider using CPU for diarization even if GPU is available")
                                    raise RuntimeError(
                                        f"Tensor size mismatch could not be resolved. "
                                        f"This often happens with variable-length audio segments. "
                                        f"Try: --device cpu"
                                    ) from final_error
                                else:
                                    raise
                        else:
                            raise
                else:
                    # Re-raise if it's not a tensor size mismatch
                    raise
            
            # Convert pyannote diarization to format expected by WhisperX
            # pyannote returns a Diarization object with itertracks method
            # WhisperX assign_word_speakers expects a dict with 'segments' key
            # Each segment should have 'start', 'end', and 'speaker' keys
            diarize_segments = {"segments": []}
            for turn, _, speaker in diarization.itertracks(yield_label=True):
                segment = {
                    "start": float(turn.start),
                    "end": float(turn.end),
                    "speaker": str(speaker)
                }
                diarize_segments["segments"].append(segment)
            
            # Sort segments by start time (required by assign_word_speakers)
            diarize_segments["segments"].sort(key=lambda x: x["start"])
            
            debug_print(f"Diarization found {len(diarize_segments['segments'])} speaker segments")
            # Check if diarization segments have speaker info
            speakers_in_diarize = set()
            for seg in diarize_segments['segments'][:10]:
                speaker = seg.get('speaker')
                if speaker:
                    speakers_in_diarize.add(speaker)
            if speakers_in_diarize:
                debug_print(f"Speakers detected in diarization: {', '.join(sorted(speakers_in_diarize))}")
            
            # Ensure result is in correct format for assign_word_speakers
            if not isinstance(result, dict):
                result = {"segments": result}
            
            # Verify and fix ALL segments have required keys (start, end)
            debug_print("Verifying transcription segments format...")
            segments = result.get("segments", [])
            if not segments:
                debug_print("Warning: No segments found in result!")
            else:
                fixed_count = 0
                missing_end = []
                for i, seg in enumerate(segments):
                    if not isinstance(seg, dict):
                        debug_print(f"Warning: Segment {i} is not a dict: {type(seg)}")
                        continue
                    
                    # Ensure 'start' key exists and is float
                    if 'start' not in seg:
                        debug_print(f"Error: Segment {i} missing 'start' key - skipping")
                        missing_end.append(i)
                        continue
                    else:
                        seg['start'] = float(seg['start'])
                    
                    # Ensure 'end' key exists - this is CRITICAL for assign_word_speakers
                    if 'end' not in seg:
                        # Try to get end from last word
                        if 'words' in seg and seg['words'] and len(seg['words']) > 0:
                            last_word = seg['words'][-1]
                            if isinstance(last_word, dict) and 'end' in last_word:
                                seg['end'] = float(last_word['end'])
                                fixed_count += 1
                            else:
                                # Use start + estimated duration based on text length
                                text = seg.get('text', '')
                                estimated_duration = max(1.0, len(text) * 0.1)  # ~0.1 seconds per character
                                seg['end'] = float(seg['start']) + estimated_duration
                                fixed_count += 1
                        else:
                            # No words, use start + default duration
                            seg['end'] = float(seg['start']) + 5.0
                            fixed_count += 1
                    else:
                        # Ensure end is a float
                        try:
                            seg['end'] = float(seg['end'])
                        except (ValueError, TypeError):
                            # If end is invalid, recalculate
                            if 'words' in seg and seg['words'] and len(seg['words']) > 0:
                                last_word = seg['words'][-1]
                                if isinstance(last_word, dict) and 'end' in last_word:
                                    seg['end'] = float(last_word['end'])
                                else:
                                    seg['end'] = float(seg['start']) + 5.0
                            else:
                                seg['end'] = float(seg['start']) + 5.0
                            fixed_count += 1
                
                # Final verification - check ALL segments one more time
                all_have_end = all(isinstance(seg, dict) and 'end' in seg and isinstance(seg.get('end'), (int, float)) for seg in segments)
                
                if fixed_count > 0:
                    debug_print(f"[OK] Fixed {fixed_count} segments missing or invalid 'end' keys")
                
                if all_have_end:
                    debug_print(f"[OK] Verified: All {len(segments)} segments have valid 'end' keys")
                else:
                    # Find which segments are still missing end
                    still_missing = [i for i, seg in enumerate(segments) if not (isinstance(seg, dict) and 'end' in seg)]
                    debug_print(f"[ERROR] {len(still_missing)} segments still missing 'end' keys: {still_missing[:10]}")
                    # Force fix them
                    for i in still_missing:
                        if isinstance(segments[i], dict) and 'start' in segments[i]:
                            segments[i]['end'] = float(segments[i]['start']) + 5.0
                
                # Update result with fixed segments
                result["segments"] = segments
                
                # Verify one final time
                sample_keys = list(segments[0].keys()) if segments else []
                debug_print(f"Sample segment keys: {sample_keys}")
                if segments[0].get('end') is not None:
                    debug_print(f"Sample segment end value: {segments[0].get('end')} (type: {type(segments[0].get('end'))})")
            
            # Final safety check - create a fresh copy of result with guaranteed 'end' keys
            if not isinstance(result, dict):
                result = {"segments": result}
            
            # Create a completely fresh copy of segments to avoid any reference issues
            final_segments = []
            original_segments = result.get("segments", [])
            
            for i, seg in enumerate(original_segments):
                if not isinstance(seg, dict):
                    debug_print(f"Warning: Segment {i} is not a dict, skipping")
                    continue
                
                # Create a new dict with all keys, ensuring 'end' exists
                new_seg = dict(seg)  # Copy all existing keys
                
                # Ensure 'start' is a float
                if 'start' in new_seg:
                    new_seg['start'] = float(new_seg['start'])
                else:
                    debug_print(f"Error: Segment {i} missing 'start' key - skipping")
                    continue
                
                # Ensure 'end' exists and is a float
                if 'end' not in new_seg:
                    # Calculate from last word if available
                    if 'words' in new_seg and new_seg['words'] and len(new_seg['words']) > 0:
                        last_word = new_seg['words'][-1]
                        if isinstance(last_word, dict) and 'end' in last_word:
                            new_seg['end'] = float(last_word['end'])
                        else:
                            text = new_seg.get('text', '')
                            estimated_duration = max(1.0, len(text) * 0.1)
                            new_seg['end'] = float(new_seg['start']) + estimated_duration
                    else:
                        new_seg['end'] = float(new_seg['start']) + 5.0
                else:
                    try:
                        new_seg['end'] = float(new_seg['end'])
                    except (ValueError, TypeError):
                        new_seg['end'] = float(new_seg['start']) + 5.0
                
                final_segments.append(new_seg)
            
            # Create a completely fresh result dict with ALL original keys preserved
            # assign_word_speakers might expect certain keys to be present
            new_result = {
                "segments": final_segments,
                "language": result.get("language", detected_language)
            }
            # Preserve any other keys from original result (in case assign_word_speakers needs them)
            for key in result.keys():
                if key not in ["segments"]:  # Don't overwrite our fixed segments
                    new_result[key] = result[key]
            
            result = new_result
            
            # Final verification
            segments_with_end = sum(1 for seg in final_segments if isinstance(seg, dict) and 'end' in seg and isinstance(seg.get('end'), (int, float)))
            debug_print(f"Final check: {segments_with_end}/{len(final_segments)} segments have valid 'end' keys")
            
            # Verify one more time by actually accessing 'end' on each segment
            for i, seg in enumerate(final_segments[:3]):
                try:
                    end_val = seg['end']
                    debug_print(f"  Segment {i}: 'end' = {end_val} (type: {type(end_val)})")
                except KeyError:
                    debug_print(f"  Segment {i}: MISSING 'end' key!")
            
            progress_print("Assigning speakers to words...")
            try:
                result = whisperx.assign_word_speakers(diarize_segments, result)
            except KeyError as e:
                if "'end'" in str(e):
                    debug_print(f"WARNING: assign_word_speakers failed with KeyError for 'end'.")
                    debug_print(f"Attempting manual speaker assignment as fallback...")
                    
                    # Manual fallback: assign speakers based on time overlap
                    import numpy as np
                    
                    diarize_list = diarize_segments.get("segments", [])
                    transcription_segments = result.get("segments", [])
                    
                    # Create a simple time-based assignment
                    for trans_seg in transcription_segments:
                        if not isinstance(trans_seg, dict):
                            continue
                        
                        trans_start = float(trans_seg.get('start', 0))
                        trans_end = float(trans_seg.get('end', trans_start + 5.0))
                        
                        # Find overlapping diarization segments
                        best_speaker = None
                        max_overlap = 0
                        
                        for diar_seg in diarize_list:
                            if not isinstance(diar_seg, dict):
                                continue
                            
                            diar_start = float(diar_seg.get('start', 0))
                            diar_end = float(diar_seg.get('end', diar_start + 5.0))
                            
                            # Calculate overlap
                            overlap_start = max(trans_start, diar_start)
                            overlap_end = min(trans_end, diar_end)
                            overlap = max(0, overlap_end - overlap_start)
                            
                            if overlap > max_overlap:
                                max_overlap = overlap
                                best_speaker = diar_seg.get('speaker')
                        
                        # Assign speaker to segment and words
                        if best_speaker:
                            trans_seg['speaker'] = best_speaker
                            # Also assign to words if they exist
                            if 'words' in trans_seg and trans_seg['words']:
                                for word in trans_seg['words']:
                                    if isinstance(word, dict):
                                        word['speaker'] = best_speaker
                    
                    debug_print(f"[OK] Manually assigned speakers to {len(transcription_segments)} segments")
                    result["segments"] = transcription_segments
                else:
                    raise
            except Exception as e:
                print(f"Error in assign_word_speakers: {e}")
                import traceback
                traceback.print_exc()
                raise
            
            # Verify assignment worked by checking a sample of segments
            test_segments = result.get("segments", [])
            if test_segments:
                speakers_found = 0
                for s in test_segments[:20]:
                    if get_segment_speaker(s):
                        speakers_found += 1
                debug_print(f"Speaker assignment verification: {speakers_found}/20 segments have speaker labels")
                if speakers_found == 0:
                    debug_print("Warning: assign_word_speakers may not have assigned speakers correctly")
            
            # Free diarization model
            del diarize_model
            gc.collect()
            if device == "cuda":
                torch.cuda.empty_cache()
            
            progress_print("Speaker diarization completed.")
        except Exception as e:
            print(f"Error during speaker diarization: {str(e)}")
            if DEBUG_MODE:
                import traceback
                traceback.print_exc()
            print("Continuing without speaker labels...")
            diarize = False
    
    return result, diarize


def get_segment_speaker(segment):
    """Extract speaker from segment, checking both segment-level and word-level."""
    # First check if speaker is directly on the segment
    if "speaker" in segment:
        speaker = segment.get("speaker")
        if speaker:
            return speaker
    
    # If not, check words within the segment
    words = segment.get("words", [])
    if words:
        # Count speaker occurrences in words
        speaker_counts = {}
        for word in words:
            word_speaker = word.get("speaker")
            if word_speaker:
                speaker_counts[word_speaker] = speaker_counts.get(word_speaker, 0) + 1
        
        # Return the most common speaker in this segment
        if speaker_counts:
            return max(speaker_counts, key=speaker_counts.get)
    
    return None


def debug_speaker_structure(segments, sample_size=5):
    """Debug function to print the structure of segments to understand speaker storage."""
    debug_print("\n=== DEBUG: Checking segment structure for speaker information ===")
    segments_with_speakers = 0
    for i, segment in enumerate(segments[:sample_size]):
        has_speaker = False
        speaker_info = []
        
        if "speaker" in segment:
            speaker = segment.get("speaker")
            if speaker:
                has_speaker = True
                speaker_info.append(f"segment-level: {speaker}")
        
        if "words" in segment:
            words = segment.get("words", [])
            if words:
                speakers_in_words = [w.get("speaker") for w in words if w.get("speaker")]
                if speakers_in_words:
                    has_speaker = True
                    unique_word_speakers = list(set(speakers_in_words))
                    speaker_info.append(f"word-level: {unique_word_speakers}")
        
        if has_speaker:
            segments_with_speakers += 1
            debug_print(f"Segment {i}: [OK] Has speaker - {', '.join(speaker_info)}")
        else:
            debug_print(f"Segment {i}: [ERROR] No speaker found")
            debug_print(f"  Segment keys: {list(segment.keys())}")
            if "words" in segment and segment.get("words"):
                debug_print(f"  First word keys: {list(segment['words'][0].keys())}")
    
    debug_print(f"\nSummary: {segments_with_speakers}/{min(sample_size, len(segments))} segments have speaker labels")
    debug_print("=" * 60 + "\n")


def generate_srt(segments, output_path, include_speaker=False):
    """Generate SRT subtitle file from transcription segments (always includes start/end timecodes)."""
    with open(output_path, "w", encoding="utf-8") as f:
        for i, segment in enumerate(segments, start=1):
            start_time = format_timestamp(segment.get("start", 0))
            end_time = format_timestamp(segment.get("end", 0))
            text = segment.get("text", "").strip()
            
            # Add speaker label if available
            if include_speaker:
                speaker = get_segment_speaker(segment)
                if speaker:
                    text = f"[{speaker}] {text}"
            
            f.write(f"{i}\n")
            f.write(f"{start_time} --> {end_time}\n")
            f.write(f"{text}\n")
            f.write("\n")


def generate_markdown(segments, output_path, title=None, link_target=None, include_speaker=False,
                      include_timestamps=True):
    """Generate markdown file for Obsidian.

    With include_timestamps (default), each line uses a wikilink with media offset:
    [[<relative_audio_path>#t=SECONDS|HH:MM(:SS)]]
    If include_timestamps is False, lines are plain list items (no time links).
    """
    with open(output_path, "w", encoding="utf-8") as f:
        # Write YAML frontmatter
        f.write("---\n")
        f.write(f"date: {datetime.now().strftime('%Y-%m-%d')}\n")
        if link_target:
            f.write(f'audio: "[[{link_target}]]"\n')
        else:
            f.write('audio: ""\n')
        
        # Extract unique speakers if diarization was performed
        speakers = []
        if include_speaker:
            for segment in segments:
                speaker = get_segment_speaker(segment)
                if speaker and speaker not in speakers:
                    speakers.append(speaker)
        
        if speakers:
            f.write(f"speakers: {len(speakers)}\n")
            for speaker in sorted(speakers):
                f.write(f"  - {speaker}\n")
        else:
            f.write("speaker: \n")
        
        f.write("tags:\n")
        f.write("  - transcripción\n")
        if include_speaker:
            f.write("  - diarización\n")
        f.write("data-type: transcripcion\n")
        f.write("read: false\n")
        f.write("---\n\n")
        
        # Write title if provided
        if title:
            f.write(f"# {title}\n\n")
        
        f.write("## Transcription\n\n")
        for segment in segments:
            text = segment.get("text", "").strip()
            speaker_label = ""
            if include_speaker:
                speaker = get_segment_speaker(segment)
                if speaker:
                    speaker_label = f"**[{speaker}]** "

            if include_timestamps:
                start_time = segment.get("start", 0)
                total_seconds = int(start_time)
                hours, remainder = divmod(total_seconds, 3600)
                minutes, seconds = divmod(remainder, 60)
                display_time = (
                    f"{hours:02d}:{minutes:02d}:{seconds:02d}"
                    if hours > 0
                    else f"{minutes:02d}:{seconds:02d}"
                )
                target = link_target if link_target is not None else ""
                f.write(f"- [[{target}#t={total_seconds}|{display_time}]] {speaker_label}{text}\n")
            else:
                f.write(f"- {speaker_label}{text}\n")
        f.write("\n")


def main():
    parser = argparse.ArgumentParser(
        description="Transcribe audio files using local WhisperX",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python transcribe_whisperx.py audio.mp3
  python transcribe_whisperx.py audio.mp3 --model medium --device cpu
  python transcribe_whisperx.py audio.mp3 --timestamps false  # plain MD lines; SRT unchanged
  python transcribe_whisperx.py audio.mp3 --diarize --min-speakers 2 --max-speakers 2
  python transcribe_whisperx.py audio.mp3 --output-dir ./transcripts
  python transcribe_whisperx.py audio.mp3 --title "Meeting Notes" --language es
        """
    )
    
    parser.add_argument(
        "audio_file",
        type=str,
        help="Path to the audio file to transcribe"
    )
    
    parser.add_argument(
        "--model",
        type=str,
        default="large-v3",
        choices=["tiny", "base", "small", "medium", "large", "large-v2", "large-v3"],
        help="WhisperX model size (default: large-v2). Larger models are more accurate but slower."
    )
    
    parser.add_argument(
        "--device",
        type=str,
        default=None,
        help="Device to use (cpu, cuda, cuda:0, cuda:1, mps). Auto-detected if not specified. Use cuda:1 for GPU 1."
    )
    
    parser.add_argument(
        "--language",
        type=str,
        default=None,
        help="Language code (e.g., 'en', 'es', 'fr'). Auto-detected if not specified."
    )

    parser.add_argument(
        "--timestamps",
        type=str,
        default="",
        help="Obsidian time wikilinks in markdown only (default: on; false/0/no/off uses plain list lines). SRT always has timecodes.",
    )
    
    parser.add_argument(
        "--diarize",
        action="store_true",
        help="Perform speaker diarization (requires HuggingFace token)"
    )
    
    parser.add_argument(
        "--min-speakers",
        type=int,
        default=None,
        help="Minimum number of speakers (for diarization)"
    )
    
    parser.add_argument(
        "--max-speakers",
        type=int,
        default=None,
        help="Maximum number of speakers (for diarization)"
    )
    
    parser.add_argument(
        "--hf-token",
        type=str,
        default=None,
        help="HuggingFace token for speaker diarization (alternative to environment variable)"
    )
    
    parser.add_argument(
        "--batch-size",
        type=int,
        default=8,
        help="Batch size for transcription (default: 16). Increase for faster processing if you have GPU memory."
    )
    
    parser.add_argument(
        "--output-dir",
        type=str,
        default=None,
        help="Directory to save output files (default: same as input file for SRT, 'Data/Entrevistas' for markdown)"
    )
    
    parser.add_argument(
        "--output-name",
        type=str,
        default=None,
        help="Base name for output files (default: input file name without extension)"
    )
    
    parser.add_argument(
        "--title",
        type=str,
        default=None,
        help="Title for markdown file (default: output name)"
    )
    
    parser.add_argument(
        "--srt-output",
        type=str,
        default=None,
        help="Full path for SRT output file (overrides --output-dir and --output-name)"
    )
    
    parser.add_argument(
        "--md-output",
        type=str,
        default=None,
        help="Full path for markdown output file (overrides --output-dir and --output-name)"
    )

    parser.add_argument(
        "--interviews-dir",
        type=str,
        default=None,
        help="Default output directory for generated files when --output-dir is not provided (default from obsidianqda.toml or 'Data/Entrevistas')"
    )
    
    parser.add_argument(
        "--debug",
        action="store_true",
        help="Enable verbose debug output"
    )
    
    args = parser.parse_args()
    
    # Set global debug mode
    global DEBUG_MODE
    DEBUG_MODE = args.debug
    
    # Check if file exists
    audio_path = Path(args.audio_file)
    if not audio_path.exists():
        print(f"Error: File not found: {args.audio_file}")
        sys.exit(1)
    
    # Determine device
    device = get_device(args.device)
    debug_print(f"Using device: {device}")
    
    # Get HuggingFace token if diarization is requested
    hf_token = None
    if args.diarize:
        hf_token = get_hf_token(args.hf_token)
    
    # Determine output paths for SRT and markdown files
    # When --output-dir is set, use it for both SRT and MD (so run_transcribex gets both in src_dir).
    if args.output_dir:
        output_dir = Path(args.output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
    else:
        interviews_dir = args.interviews_dir
        if interviews_dir is None:
            interviews_dir = get_paths_config(None)["interviews_dir"]
        output_dir = Path(interviews_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
    base_name = args.output_name if args.output_name else audio_path.stem

    if args.srt_output:
        srt_path = Path(args.srt_output)
        srt_path.parent.mkdir(parents=True, exist_ok=True)
    else:
        srt_path = output_dir / f"{base_name}.srt"

    if args.md_output:
        markdown_path = Path(args.md_output)
        markdown_path.parent.mkdir(parents=True, exist_ok=True)
    else:
        markdown_path = output_dir / f"{base_name}.md"
    
    markdown_timestamps = _timestamps_cli_enabled(getattr(args, "timestamps", "") or "")

    # Transcribe audio (alignment always on so SRT keeps accurate segment times; --timestamps only affects MD wikilinks)
    try:
        result, has_speakers = transcribe_audio(
            str(audio_path),
            model_size=args.model,
            device=device,
            language=args.language,
            diarize=args.diarize,
            hf_token=hf_token,
            min_speakers=args.min_speakers,
            max_speakers=args.max_speakers,
            batch_size=args.batch_size,
            align_timestamps=True,
        )
    except Exception as e:
        print(format_transcription_error(e), file=sys.stderr)
        if DEBUG_MODE:
            import traceback
            traceback.print_exc()
        sys.exit(1)
    
    # Extract segments
    segments = result.get("segments", [])
    if not segments:
        print("Warning: No segments found in transcription result")
        sys.exit(1)
    
    info_print(f"\nTranscription complete: {len(segments)} segments")
    
    # Check if speakers are actually present in segments
    unique_speakers = set()
    segments_with_speakers = 0
    for segment in segments:
        speaker = get_segment_speaker(segment)
        if speaker:
            unique_speakers.add(speaker)
            segments_with_speakers += 1
    
    # Update has_speakers based on actual presence of speaker labels
    has_speakers = len(unique_speakers) > 0
    
    if has_speakers:
        info_print(f"Detected {len(unique_speakers)} speaker(s): {', '.join(sorted(unique_speakers))}")
        info_print(f"Speaker labels found in {segments_with_speakers}/{len(segments)} segments ({segments_with_speakers/len(segments)*100:.1f}%)")
    elif args.diarize:
        print("Warning: Diarization was requested but no speaker labels found in segments")
        if not DEBUG_MODE:
            print("Run with --debug for detailed troubleshooting information")
        else:
            print("\nTroubleshooting steps:")
            print("1. Check that your HuggingFace token has access to pyannote models:")
            print("   - Visit https://huggingface.co/pyannote/segmentation")
            print("   - Visit https://huggingface.co/pyannote/speaker-diarization-3.1")
            print("   - Accept the user agreements for both models")
            print("2. Try running with explicit speaker counts:")
            print("   --min-speakers 2 --max-speakers 2")
            print("3. Check the debug output above to see if diarization found speakers")
            print("4. Verify that assign_word_speakers completed successfully")
        
        # Run debug to show structure only in debug mode
        if DEBUG_MODE:
            debug_speaker_structure(segments, sample_size=10)
    
    # Generate output files
    generate_srt(segments, srt_path, include_speaker=has_speakers)
    info_print(f"SRT file created: {srt_path}")
    
    title = args.title if args.title else base_name
    # Build link target relative to markdown file location
    try:
        link_target = os.path.relpath(audio_path, markdown_path.parent)
    except Exception:
        link_target = audio_path.name
    
    generate_markdown(
        segments,
        markdown_path,
        title,
        link_target,
        include_speaker=has_speakers,
        include_timestamps=markdown_timestamps,
    )
    info_print(f"Markdown file created: {markdown_path}")
    
    info_print("\nTranscription complete!")


if __name__ == "__main__":
    main()

