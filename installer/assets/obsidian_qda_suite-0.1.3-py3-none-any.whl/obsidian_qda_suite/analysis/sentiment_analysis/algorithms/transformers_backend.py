from typing import Dict, Any, List
import torch
from transformers import AutoTokenizer, AutoModelForSequenceClassification, TextClassificationPipeline
from .base import SentimentBackend

# Models that need slow tokenizer (XLMRobertaTokenizer) due to tiktoken/SentencePiece issues
_SLOW_TOKENIZER_MODELS = frozenset({
    "cardiffnlp/twitter-xlm-roberta-base-sentiment",
})


def _load_tokenizer(model: str):
    """Load tokenizer; use slow XLMRobertaTokenizer for known problematic models."""
    if model in _SLOW_TOKENIZER_MODELS:
        from transformers import XLMRobertaTokenizer
        return XLMRobertaTokenizer.from_pretrained(model)
    try:
        return AutoTokenizer.from_pretrained(model)
    except (ValueError, AttributeError, OSError):
        from transformers import XLMRobertaTokenizer
        return XLMRobertaTokenizer.from_pretrained(model)


class TransformersBackend(SentimentBackend):
    name = "transformers"

    def __init__(self, model: str = "cardiffnlp/twitter-xlm-roberta-base-sentiment",
                 device: int | None = None, max_length: int = 4000, **_):
        self.model_name = model
        self.tokenizer = _load_tokenizer(model)
        self.model = AutoModelForSequenceClassification.from_pretrained(model)
        if device is None:
            device = 0 if torch.cuda.is_available() else -1
        self.pipe = TextClassificationPipeline(
            model=self.model, tokenizer=self.tokenizer, device=device, return_all_scores=True
        )
        self.max_length = max_length

    def _best(self, scores):
        best = max(scores, key=lambda x: x["score"])
        return best["label"], {s["label"]: float(s["score"]) for s in scores}

    def predict(self, text: str, lang: str | None = None) -> Dict[str, Any]:
        res = self.pipe(text[: self.max_length], truncation=True, max_length=512)
        label, scores = self._best(res[0])
        return {"label": label, "scores": scores, "lang": lang}

    def predict_batch(self, texts: List[str], lang: str | None = None) -> List[Dict[str, Any]]:
        batched = self.pipe([t[: self.max_length] for t in texts], truncation=True, max_length=512)
        out = []
        for scores in batched:
            label, sc = self._best(scores)
            out.append({"label": label, "scores": sc, "lang": lang})
        return out


