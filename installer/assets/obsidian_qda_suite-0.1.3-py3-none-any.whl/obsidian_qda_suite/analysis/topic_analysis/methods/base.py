"""
Base class for topic modeling methods.

This module provides the abstract base class that all topic modeling
methods should inherit from.
"""

from abc import ABC, abstractmethod
import numpy as np


class TopicModelingMethod(ABC):
    """Base class for all topic modeling methods."""
    
    def __init__(self, **kwargs):
        """Initialize the method with configuration parameters."""
        self.config = kwargs
    
    @abstractmethod
    def fit(self, texts, vectorizer, feature_names, **kwargs):
        """Fit the model to texts.
        
        Parameters:
        -----------
        texts : list of str
            Preprocessed texts
        vectorizer : sklearn vectorizer
            Fitted vectorizer
        feature_names : array
            Feature names from vectorizer
        **kwargs
            Additional method-specific parameters
        
        Returns:
        --------
        object
            Fitted model
        """
        pass
    
    @abstractmethod
    def get_topics(self, feature_names, n_words=10):
        """Extract topics with top words.
        
        Parameters:
        -----------
        feature_names : array
            Feature names
        n_words : int
            Number of top words per topic
        
        Returns:
        --------
        list of dict
            List of topics, each with 'words' and 'weights'
        """
        pass
    
    @abstractmethod
    def transform(self, texts, vectorizer):
        """Transform texts to topic distributions.
        
        Parameters:
        -----------
        texts : list of str
            Texts to transform
        vectorizer : sklearn vectorizer
            Fitted vectorizer
        
        Returns:
        --------
        numpy.ndarray
            Topic distributions (n_documents x n_topics)
        """
        pass
    
    def get_n_topics(self):
        """Get the number of topics discovered by the model.
        
        Returns:
        --------
        int
            Number of topics
        """
        return getattr(self, 'n_topics', 0)

