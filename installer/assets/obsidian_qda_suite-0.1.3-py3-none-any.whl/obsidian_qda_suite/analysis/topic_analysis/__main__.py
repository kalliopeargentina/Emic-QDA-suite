"""
Entry point for running topic_analysis as a module.

Allows invocation as: python -m topic_analysis
"""

from .main import main

if __name__ == "__main__":
    main()

