DEFAULTS = {
    "min_document_length": 100,
    "aggregate": "document",  # document|sentence|paragraph
    "batch_size": 8,
    "max_length": 4000,
}


