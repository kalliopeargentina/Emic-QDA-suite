"""Text chunking utilities with overlap."""

from __future__ import annotations


def estimate_tokens(text: str | int, chars_per_token: int = 4) -> int:
    if chars_per_token <= 0:
        chars_per_token = 4
    length = text if isinstance(text, int) else len(text)
    return (length + chars_per_token - 1) // chars_per_token


def _is_separator_line(line: str) -> bool:
    stripped = line.strip()
    if not stripped:
        return False
    return all(char in ".-–—*_#" for char in stripped)


def _split_sentences(text: str) -> list[str]:
    import re

    parts = re.split(r"(?<=[.!?;:])\s+", text.strip())
    return [part.strip() for part in parts if part.strip()]


def _chunk_units(units: list[str], separator: str, max_chars: int) -> list[str]:
    chunks: list[str] = []
    current = ""

    for unit in units:
        if not unit:
            continue
        if len(unit) > max_chars:
            if current:
                chunks.append(current)
                current = ""
            start = 0
            while start < len(unit):
                chunks.append(unit[start:start + max_chars])
                start += max_chars
            continue

        candidate = unit if not current else f"{current}{separator}{unit}"
        if len(candidate) <= max_chars:
            current = candidate
        else:
            if current:
                chunks.append(current)
            current = unit

    if current:
        chunks.append(current)

    return chunks


def _get_last_sentences(text: str, num_sentences: int = 3) -> str:
    """Extrae las últimas N oraciones de un texto para usar como overlap."""
    sentences = _split_sentences(text)
    if len(sentences) <= num_sentences:
        return text
    return " ".join(sentences[-num_sentences:])


def split_text_by_chars(text: str, max_chars: int, overlap_sentences: int = 3) -> list[str]:
    if max_chars <= 0:
        return []

    normalized = text.replace("\r\n", "\n").replace("\r", "\n").strip()
    if not normalized:
        return []

    paragraphs: list[str] = []
    current_lines: list[str] = []

    for line in normalized.split("\n"):
        if not line.strip() or _is_separator_line(line):
            if current_lines:
                paragraph = "\n".join(current_lines).strip()
                if paragraph:
                    paragraphs.append(paragraph)
                current_lines = []
            continue
        current_lines.append(line.rstrip())

    if current_lines:
        paragraph = "\n".join(current_lines).strip()
        if paragraph:
            paragraphs.append(paragraph)

    if len(paragraphs) > 1:
        chunks = _chunk_units(paragraphs, "\n\n", max_chars)
    else:
        sentences = _split_sentences(normalized)
        chunks = _chunk_units(sentences, " ", max_chars)

    if len(chunks) > 1 and overlap_sentences > 0:
        overlapped_chunks = [chunks[0]]
        for i in range(1, len(chunks)):
            prev_chunk = chunks[i - 1]
            current_chunk = chunks[i]

            overlap_text = _get_last_sentences(prev_chunk, overlap_sentences)
            combined = f"{overlap_text} {current_chunk}"

            if len(combined) > max_chars:
                for num in range(overlap_sentences - 1, 0, -1):
                    smaller_overlap = _get_last_sentences(prev_chunk, num)
                    combined = f"{smaller_overlap} {current_chunk}"
                    if len(combined) <= max_chars:
                        break
                if len(combined) > max_chars:
                    combined = current_chunk

            overlapped_chunks.append(combined)

        return overlapped_chunks

    return chunks
