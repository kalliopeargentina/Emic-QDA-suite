"""Core logic for extracting audio from video with ffmpeg."""

import subprocess
from typing import List

VIDEO_EXTENSIONS = (
    ".mp4",
    ".mkv",
    ".mov",
    ".avi",
    ".webm",
    ".m4v",
    ".mts",
    ".m2ts",
    ".ts",
    ".flv",
)


def is_video_file(ext: str) -> bool:
    """Return True if extension is a supported video format."""
    return ext.lower() in VIDEO_EXTENSIONS


def extract_audio(input_path: str, output_path: str, ffmpeg_bin: str) -> bool:
    """
    Extract audio from video and encode as MP3 (16kHz, mono, 64k).
    Returns True on success, False on failure.
    """
    try:
        cmd: List[str] = [
            ffmpeg_bin,
            "-hide_banner",
            "-loglevel",
            "error",
            "-y",
            "-i",
            input_path,
            "-vn",
            "-ac",
            "1",
            "-ar",
            "16000",
            "-b:a",
            "64k",
            "-c:a",
            "libmp3lame",
            "-movflags",
            "+faststart",
            output_path,
        ]
        subprocess.run(cmd, capture_output=True, text=True, check=True, timeout=600)
        return True
    except (subprocess.CalledProcessError, FileNotFoundError, subprocess.TimeoutExpired):
        return False
