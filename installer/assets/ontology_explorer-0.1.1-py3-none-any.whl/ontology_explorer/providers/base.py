"""Provider interfaces."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol


@dataclass
class ProviderConfig:
    api_key: str | None = None
    temperature: float | None = None
    response_schema: dict | None = None
    timeout: int | None = None  # seconds; None means use provider default (300)


class Provider(Protocol):
    def run(self, prompt: str, model: str, config: ProviderConfig) -> str:
        """Runs a model and returns raw text output."""
        raise NotImplementedError
