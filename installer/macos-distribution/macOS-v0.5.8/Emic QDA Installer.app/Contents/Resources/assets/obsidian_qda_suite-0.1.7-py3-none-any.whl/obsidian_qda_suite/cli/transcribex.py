"""CLI for WhisperX transcription. Obsidian or direct args."""
# PyTorch 2.6+ defaults to weights_only=True in torch.load; pyannote/whisperx checkpoints need weights_only=False.
# Set before any import that could load torch so transcribex always works.
import os
os.environ.setdefault("TORCH_FORCE_NO_WEIGHTS_ONLY_LOAD", "1")

import argparse
import re
import sys
from pathlib import Path

from . import common
from ..audio.ffmpeg_utils import get_ffmpeg_path, get_ffprobe_path
from ..audio.split import convert_audio, needs_conversion, probe_audio_file


def _should_diarize(diarizar_arg: str) -> bool:
    if not diarizar_arg:
        return True
    d = (diarizar_arg or "").strip().lower()
    return d not in ("false", "0", "no", "off")


def _update_markdown_links(md_file: str, original_file_name: str, mp3_stem: str) -> None:
    if not os.path.isfile(md_file):
        return
    try:
        with open(md_file, "r", encoding="utf-8") as f:
            content = f.read()
        original_link = original_file_name
        mp3_name_with_ext = f"{mp3_stem}.mp3"
        content = content.replace(f'audio: "[[{mp3_name_with_ext}]]"', f'audio: "[[{original_link}]]"')
        content = content.replace(f'audio: "[[{mp3_stem}]]"', f'audio: "[[{original_link}]]"')
        frontmatter_pattern = re.compile(r'(audio:\s*"\[\[)([^\]]+)(\]\]")')

        def replace_frontmatter(match):
            link_path = match.group(2)
            if (link_path == mp3_stem or link_path == mp3_name_with_ext or
                link_path.endswith("/" + mp3_stem) or link_path.endswith("/" + mp3_name_with_ext) or
                link_path.endswith("\\" + mp3_stem) or link_path.endswith("\\" + mp3_name_with_ext)):
                return f"{match.group(1)}{original_link}{match.group(3)}"
            return match.group(0)

        content = frontmatter_pattern.sub(replace_frontmatter, content)
        pattern = re.compile(r"\[\[([^\]#|]+)(#t=\d+\|[^\]]+)\]\]")

        def replace_link(match):
            file_part = match.group(1)
            fn = file_part.replace("\\", "/")
            ms = mp3_stem.replace("\\", "/")
            mn = mp3_name_with_ext.replace("\\", "/")
            if (file_part == mp3_stem or file_part == mp3_name_with_ext or
                fn.endswith("/" + ms) or fn.endswith("/" + mn) or
                fn.endswith("\\" + ms) or fn.endswith("\\" + mn)):
                return f"[[{original_link}{match.group(2)}]]"
            return match.group(0)

        content = pattern.sub(replace_link, content)
        with open(md_file, "w", encoding="utf-8") as f:
            f.write(content)
    except Exception as e:
        common.safe_print(f"Warning: Could not update markdown links: {e}", file=sys.stderr)


def main() -> None:
    common.setup_console_encoding()
    parser = argparse.ArgumentParser(description="Transcribe audio with WhisperX.")
    parser.add_argument("--vault-path", type=str, help="Obsidian vault path (Obsidian mode)")
    parser.add_argument("--file-path", type=str, help="Path to audio/video file (Obsidian mode)")
    parser.add_argument("--file-name", type=str, help="Name of the file (Obsidian mode)")
    parser.add_argument("--diarizar", type=str, default="", help="Enable diarization (default: yes; set false/0/no/off to disable)")
    parser.add_argument(
        "--timestamps",
        type=str,
        default="",
        help="Time wikilinks in markdown only (default: on; false/0/no/off = plain list lines). SRT always has timecodes.",
    )
    parser.add_argument("--hf-token", type=str, help="HuggingFace token for diarization")
    parser.add_argument("--device", type=str, help="Device: cpu, cuda, cuda:0, mps")
    parser.add_argument("--language", type=str, help="Language code (e.g. es, en)")
    parser.add_argument("file", type=str, nargs="?", help="Audio file (direct mode)")
    parser.add_argument("--output-dir", type=str, help="Output directory (direct mode)")
    args = parser.parse_args()

    vault_path = common.get_optional_param(args.vault_path)
    file_path_arg = common.get_optional_param(args.file_path)
    file_name_arg = common.get_optional_param(args.file_name)
    direct_file = common.get_optional_param(args.file)
    output_dir_arg = common.get_optional_param(args.output_dir)
    diarize = _should_diarize(getattr(args, "diarizar", "") or "")
    hf_token = common.get_optional_param(args.hf_token)
    if diarize and (not hf_token or not hf_token.strip()):
        hf_token = os.environ.get("HUGGINGFACE_TOKEN") or os.environ.get("HF_TOKEN") or ""

    if vault_path and file_path_arg and file_name_arg:
        vault = common.fix_path(vault_path)
        file_abs = common.fix_path(file_path_arg)
        file_name = common.sanitize_name(file_name_arg)
        if not os.path.isdir(vault):
            common.safe_print(f"Error: Vault path not found: {vault}", file=sys.stderr)
            sys.exit(1)
        if not os.path.isfile(file_abs):
            common.safe_print(f"Error: File not found: {file_abs}", file=sys.stderr)
            sys.exit(1)
        stem = Path(file_name).stem
        src_dir = os.path.dirname(file_abs)
        medios_dir = os.path.join(vault, "Attachments", "Medios")
        os.makedirs(medios_dir, exist_ok=True)
        out_mp3 = os.path.join(medios_dir, f"{stem}.mp3")
        try:
            ffmpeg_bin = get_ffmpeg_path()
            ffprobe_bin = get_ffprobe_path()
        except RuntimeError as e:
            common.safe_print(f"Error: {e}", file=sys.stderr)
            sys.exit(1)
        probe_data = probe_audio_file(file_abs, ffprobe_bin)
        transcribe_path = file_abs
        remove_derived_mp3 = False
        if needs_conversion(probe_data):
            if not convert_audio(file_abs, out_mp3, ffmpeg_bin):
                common.safe_print("Error: Failed to convert audio to MP3.", file=sys.stderr)
                sys.exit(1)
            transcribe_path = out_mp3
            remove_derived_mp3 = True
        if diarize and (not hf_token or not hf_token.strip()):
            common.safe_print("Error: Diarization enabled but no HuggingFace token. Use --hf-token or set HUGGINGFACE_TOKEN.", file=sys.stderr)
            sys.exit(1)
        argv = ["whisperx", transcribe_path, "--output-dir", src_dir, "--output-name", stem]
        if diarize:
            argv.append("--diarize")
            argv.extend(["--hf-token", hf_token])
        if args.device:
            argv.extend(["--device", args.device])
        if args.language:
            argv.extend(["--language", args.language])
        ts_arg = (getattr(args, "timestamps", "") or "").strip()
        if ts_arg:
            argv.extend(["--timestamps", ts_arg])
        orig_argv = sys.argv
        try:
            sys.argv = argv
            from ..audio import whisperx_transcribe
            whisperx_transcribe.main()
        except SystemExit:
            if remove_derived_mp3 and os.path.isfile(out_mp3):
                try:
                    os.remove(out_mp3)
                except OSError:
                    pass
            raise
        except Exception as e:
            if remove_derived_mp3 and os.path.isfile(out_mp3):
                try:
                    os.remove(out_mp3)
                except OSError:
                    pass
            common.safe_print(f"Error: WhisperX failed: {e}", file=sys.stderr)
            sys.exit(1)
        finally:
            sys.argv = orig_argv
        md_path = os.path.join(src_dir, f"{stem}.md")
        _update_markdown_links(md_path, file_name, stem)
        if remove_derived_mp3 and os.path.isfile(out_mp3):
            try:
                os.remove(out_mp3)
            except OSError as e:
                common.safe_print(f"Warning: Could not remove derived MP3: {e}", file=sys.stderr)
        common.safe_print(f"SRT: {os.path.join(src_dir, stem + '.srt')}")
        common.safe_print(f"MD:  {md_path}")
        return

    if direct_file:
        file_abs = common.fix_path(direct_file)
        if not os.path.isfile(file_abs):
            common.safe_print(f"Error: File not found: {file_abs}", file=sys.stderr)
            sys.exit(1)
        stem = Path(file_abs).stem
        output_dir = common.fix_path(output_dir_arg) if output_dir_arg else os.path.dirname(file_abs)
        os.makedirs(output_dir, exist_ok=True)
        argv = ["whisperx", file_abs, "--output-dir", output_dir, "--output-name", stem]
        if diarize and hf_token:
            argv.append("--diarize")
            argv.extend(["--hf-token", hf_token])
        if args.device:
            argv.extend(["--device", args.device])
        if args.language:
            argv.extend(["--language", args.language])
        ts_arg = (getattr(args, "timestamps", "") or "").strip()
        if ts_arg:
            argv.extend(["--timestamps", ts_arg])
        orig_argv = sys.argv
        try:
            sys.argv = argv
            from ..audio import whisperx_transcribe
            whisperx_transcribe.main()
        except SystemExit:
            raise
        except Exception as e:
            common.safe_print(f"Error: WhisperX failed: {e}", file=sys.stderr)
            sys.exit(1)
        finally:
            sys.argv = orig_argv
        common.safe_print(f"SRT: {os.path.join(output_dir, stem + '.srt')}")
        common.safe_print(f"MD:  {os.path.join(output_dir, stem + '.md')}")
        return

    common.safe_print(
        "Error: Use --vault-path, --file-path, --file-name (Obsidian) or pass <file> (direct).",
        file=sys.stderr,
    )
    parser.print_help(sys.stderr)
    sys.exit(1)
