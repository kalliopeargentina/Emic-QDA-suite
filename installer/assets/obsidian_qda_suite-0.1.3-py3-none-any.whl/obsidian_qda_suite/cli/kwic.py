"""CLI for KWIC (keyword-in-context) analysis. Obsidian or direct args."""

import os
import re
import sys
from pathlib import Path
from typing import Optional

from . import common


def _generate_output_filename(keywords: str, is_file_path: bool) -> str:
    if is_file_path:
        return "ContextAnalysis.md"
    keyword_list = [kw.strip() for kw in keywords.split(",") if kw.strip()]
    if not keyword_list:
        return "ContextAnalysis.md"
    first = keyword_list[0]
    return f"Contexto {first} y otras.md" if len(keyword_list) > 1 else f"Contexto {first}.md"


def main() -> None:
    common.setup_console_encoding()
    import argparse

    parser = argparse.ArgumentParser(
        description="Keyword-in-context (KWIC) analysis for markdown files."
    )
    parser.add_argument("--vault-path", type=str, help="Obsidian vault path (Obsidian mode)")
    parser.add_argument("--folder-path", type=str, help="Folder to analyze (Obsidian mode)")
    parser.add_argument("--folder", type=str, help="Folder to analyze (direct mode)")
    parser.add_argument("--keywords", type=str, default="", help="Keywords (comma-separated or file path)")
    parser.add_argument("--context-size", type=str, default="", help="Words before/after keyword")
    parser.add_argument("--case-sensitive", type=str, default="", help="true/1/yes to enable")
    parser.add_argument("--max-per-file", type=str, default="", help="Max results per file")
    parser.add_argument("--lemmatize", type=str, default="", help="true/1/yes to enable")
    parser.add_argument("--language", type=str, default="", help="Language for lemmatization")
    parser.add_argument("--output", type=str, default="", help="Output file (direct mode)")
    args = parser.parse_args()

    vault_path = common.get_optional_param(args.vault_path)
    folder_path_arg = common.get_optional_param(args.folder_path)
    folder_direct = common.get_optional_param(args.folder)
    keywords_raw = (args.keywords or "").strip()
    context_size_raw = common.get_optional_param(args.context_size)
    case_sensitive_raw = (args.case_sensitive or "").strip().lower()
    max_per_file_raw = common.get_optional_param(args.max_per_file)
    lemmatize_raw = (args.lemmatize or "").strip().lower()
    language_raw = common.get_optional_param(args.language)
    output_raw = common.get_optional_param(args.output)

    if vault_path and folder_path_arg:
        vault = common.fix_path(vault_path)
        folder_abs = common.fix_path(folder_path_arg)
        if not os.path.isdir(vault):
            common.safe_print(f"Error: Vault path not found: {vault}", file=sys.stderr)
            sys.exit(1)
        if not os.path.isdir(folder_abs):
            common.safe_print(f"Error: Folder not found: {folder_abs}", file=sys.stderr)
            sys.exit(1)
        if not keywords_raw:
            common.safe_print("Error: --keywords required.", file=sys.stderr)
            sys.exit(1)
        folder_name = os.path.basename(folder_abs)
        safe_folder_name = common.sanitize_name(folder_name)
        base_dir = os.path.join(vault, "Analysis", "Context Analysis", safe_folder_name)
        os.makedirs(base_dir, exist_ok=True)
        keywords_fixed = common.fix_path(keywords_raw)
        is_file_path = (
            (os.path.isabs(keywords_fixed) and os.path.isfile(keywords_fixed))
            or os.path.isfile(os.path.join(folder_abs, keywords_raw))
        )
        if is_file_path:
            keywords_arg = os.path.join(folder_abs, keywords_raw) if not os.path.isabs(keywords_fixed) else keywords_fixed
        else:
            keywords_arg = keywords_raw
        output_filename = _generate_output_filename(keywords_arg if not is_file_path else "file", is_file_path)
        output_path = os.path.join(base_dir, output_filename)
        vault_root = vault
    elif folder_direct:
        folder_abs = common.fix_path(folder_direct)
        if not os.path.isdir(folder_abs):
            common.safe_print(f"Error: Folder not found: {folder_abs}", file=sys.stderr)
            sys.exit(1)
        if not keywords_raw:
            common.safe_print("Error: --keywords required.", file=sys.stderr)
            sys.exit(1)
        keywords_arg = common.fix_path(keywords_raw)
        if not os.path.isfile(keywords_arg):
            keywords_arg = keywords_raw
        output_path = output_raw or os.path.join(folder_abs, "kwic_analysis.md")
        if output_path and not os.path.isabs(output_path):
            output_path = os.path.join(folder_abs, output_path)
        os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
        vault_root = None
    else:
        common.safe_print(
            "Error: Use --vault-path and --folder-path (Obsidian) or --folder (direct).",
            file=sys.stderr,
        )
        parser.print_help(sys.stderr)
        sys.exit(1)

    context_size = 10
    if context_size_raw:
        try:
            context_size = int(common.sanitize_text(context_size_raw).strip() or 10)
        except (ValueError, AttributeError):
            pass
    case_sensitive = case_sensitive_raw in ("true", "1", "yes", "on")
    max_per_file = 50
    if max_per_file_raw:
        try:
            max_per_file = int(common.sanitize_text(max_per_file_raw).strip() or 50)
        except (ValueError, AttributeError):
            pass
    lemmatize = lemmatize_raw in ("true", "1", "yes", "on")
    language = None
    if language_raw:
        lang_clean = (common.sanitize_text(language_raw) or "").strip().lower()
        if lang_clean and lang_clean not in ("autodetectar", "auto", "automatic", ""):
            language = lang_clean

    from ..context import kwic_main

    argv = [
        "obsidianqda",
        "--folder",
        folder_abs,
        "--keywords",
        keywords_arg,
        "--output",
        output_path,
        "--context-size",
        str(context_size),
        "--max-per-file",
        str(max_per_file),
    ]
    if vault_root:
        argv.extend(["--vault-root", vault_root])
    if case_sensitive:
        argv.append("--case-sensitive")
    if lemmatize:
        argv.append("--lemmatize")
    if language:
        argv.extend(["--language", language])

    orig_argv = sys.argv
    try:
        sys.argv = argv
        kwic_main()
    finally:
        sys.argv = orig_argv

    common.safe_print(f"KWIC output: {output_path}")
