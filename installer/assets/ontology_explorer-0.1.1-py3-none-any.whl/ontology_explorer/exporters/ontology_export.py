"""Ontology exporters and helpers.

Incluye exportación a Markdown, JSON, GraphML y RDF (TTL, RDF/XML, JSON-LD)
vía rdf_export, además de parseo de dominio y construcción de mapas
entidad-relación.
"""

from __future__ import annotations

import json
import re

from ontology_explorer.domain.normalize import load_domain_spec
from ontology_explorer.domain.spec import DomainSpec
from ontology_explorer.extraction.parse import _normalize_evidence


def parse_domain_structure(
    domain_text: str | None = None,
    domain_name: str | None = None,
    config_dir: str | None = None,
) -> dict[str, dict[str, object]]:
    """
    Parsea la estructura del dominio para extraer entidades y sus propiedades.
    Esta función usa la normalización de dominio en runtime y devuelve la
    estructura compatible con exportadores existentes.
    """
    spec = load_domain_spec(
        domain_name=domain_name,
        config_dir=config_dir,
        domain_text=domain_text,
    )
    return spec.domain_structure


def is_entity_reference(
    prop_name: str,
    prop_value: str,
    domain_structure: dict[str, dict[str, dict[str, str | None] | list[str] | None]] | dict[str, list[str]],
    entities: list[list],
) -> tuple[bool, str | None]:
    """
    Determina si una sub-propiedad es una referencia a una entidad.
    Lógica genérica: verifica si el valor de la sub-propiedad es una entidad extraída.
    
    Args:
        prop_name: Nombre de la sub-propiedad
        prop_value: Valor de la sub-propiedad
        domain_structure: Estructura del dominio parseada
        entities: Lista de entidades extraídas
    
    Returns:
        Tupla (es_referencia, tipo_entidad) donde tipo_entidad es el tipo de entidad si es referencia
    """
    # Verificar si el valor de la sub-propiedad es una entidad en la lista de entidades extraídas
    # Esto es genérico y no depende del nombre de la sub-propiedad ni del dominio
    for ent in entities:
        if isinstance(ent, list) and len(ent) >= 2:
            ent_name, ent_type = ent[0], ent[1]
            if ent_name == prop_value:
                # El valor coincide con una entidad extraída, por lo tanto es una referencia a entidad
                return (True, ent_type)
    
    return (False, None)


def _generate_inverse_relation_name(relation_type: str) -> str:
    """
    Genera un nombre genérico para la relación inversa sin asumir dominio ni idioma.
    Esta función es completamente genérica y no contiene lógica específica del dominio.
    
    Args:
        relation_type: Tipo de relación original
    
    Returns:
        Nombre genérico para la relación inversa
    """
    # Si la relación ya es inversa, remover el prefijo antes de generar la nueva inversa
    # para evitar "inverse_of_inverse_of_..."
    normalized = relation_type.lower().replace(' ', '_')
    if normalized.startswith("inverse_of_"):
        # Ya es una relación inversa, remover el prefijo primero
        if hasattr(str, "removeprefix"):
            normalized = normalized.removeprefix("inverse_of_")
        else:
            # Fallback para Python < 3.9
            if len(normalized) >= 12:
                normalized = normalized[12:]
    
    # Generar nombre inverso genérico basado en el patrón de la relación
    # Sin asumir palabras específicas del dominio o idioma
    return f"inverse_of_{normalized}"


def get_relation_from_nested_property(
    property_name: str,
    entity_type: str,
    domain_structure: dict[str, dict[str, dict[str, str | None] | list[str] | None] | dict[str, dict[str, list[str] | None]]] | dict[str, list[str]],
) -> str:
    """
    Obtiene el tipo de relación para una propiedad anidada desde el dominio.
    Solo usa el mapeo inline definido en el dominio; no hace inferencias hardcodeadas.
    Soporta propiedades de nivel 1 y nivel 2.
    
    Args:
        property_name: Nombre de la propiedad anidada (nivel 1)
        entity_type: Tipo de entidad que contiene la propiedad
        domain_structure: Estructura del dominio parseada
    
    Returns:
        Tipo de relación como string, o nombre genérico si no se encuentra mapeo
    """
    # Verificar si domain_structure tiene el nuevo formato anidado
    if entity_type in domain_structure:
        entity_data = domain_structure[entity_type]
        
        # Si es el nuevo formato (dict con propiedades anidadas)
        if isinstance(entity_data, dict):
            if property_name in entity_data:
                prop_data = entity_data[property_name]
                if isinstance(prop_data, dict):
                    # Verificar si es estructura de nivel 2
                    is_level2 = any(
                        key not in ("relacion", "sub_propiedades", "_relacion")
                        for key in prop_data.keys()
                    )
                    
                    if is_level2:
                        # Estructura de nivel 2: buscar relación en "_relacion" o "relacion"
                        relation = prop_data.get("_relacion") or prop_data.get("relacion")
                        if relation:
                            return relation
                    elif "relacion" in prop_data:
                        # Estructura de nivel 1
                        relation = prop_data["relacion"]
                        if relation:
                            return relation
    
    # Si no hay mapeo en el dominio, retornar un nombre genérico basado en la propiedad
    # Esto es un fallback mínimo que no asume dominio ni idioma específico
    return property_name.lower()


def _is_subproperty_of_nested_level2(
    rel_type: str,
    entity_type: str,
    domain_structure: dict[str, dict[str, object]] | None,
) -> bool:
    """True si rel_type es subpropiedad anidada: en sub_propiedades (nivel 1) o en nivel 2 (lista/clave)."""
    if not domain_structure or not isinstance(rel_type, str) or not rel_type.strip():
        return False
    rt = rel_type.strip()
    if rt.lower().startswith("tiene "):
        sub_name = rt[6:].strip()
    else:
        sub_name = rt
    if not sub_name:
        return False
    entity_props = domain_structure.get(entity_type)
    if not isinstance(entity_props, dict):
        return False
    for _prop_name, prop_data in entity_props.items():
        if not isinstance(prop_data, dict):
            continue
        sub_list_direct = prop_data.get("sub_propiedades")
        if isinstance(sub_list_direct, list) and sub_name in sub_list_direct:
            return True
        is_level2 = any(
            k not in ("relacion", "sub_propiedades", "_relacion", "_sub_propiedades_nivel1")
            for k in prop_data.keys()
        )
        if not is_level2:
            continue
        for level2_key, level2_data in prop_data.items():
            if level2_key in ("relacion", "_relacion", "_sub_propiedades_nivel1"):
                continue
            if not isinstance(level2_data, dict):
                continue
            sub_list = level2_data.get("sub_propiedades")
            if isinstance(sub_list, list) and sub_name in sub_list:
                return True
            if sub_name == level2_key:
                return True
    return False


def identify_properties(
    entities: list[list],
    relations: list[list],
    domain_structure: dict[str, dict[str, dict[str, str | None] | list[str] | None]] | dict[str, list[str]],
    domain_spec: DomainSpec | None = None,
) -> tuple[
    dict[str, dict[str, dict | str | list]],
    dict[str, dict[str, dict[str, list[dict]]]],
    list[list],
]:
    """
    Identifica propiedades basadas en relaciones y estructura del dominio.
    Detecta propiedades anidadas y genera relaciones bidireccionales cuando una sub-propiedad referencia una entidad.
    
    Returns:
        Tupla con:
        - properties_map: Mapa de propiedades (soporta propiedades anidadas como dict/list)
        - properties_evidences_map: Mapa de evidencias para propiedades
        - generated_relations: Lista de relaciones generadas desde propiedades anidadas
    """
    properties: dict[str, dict[str, dict | str | list]] = {}
    properties_evidences: dict[str, dict[str, dict[str, list[dict]]]] = {}
    generated_relations: list[list] = []

    entities_by_type: dict[str, list[str]] = {}
    entities_by_name: dict[str, str] = {}  # nombre -> tipo
    for ent in entities:
        if isinstance(ent, list) and len(ent) >= 2:
            name, ent_type = ent[0], ent[1]
            entities_by_name[name] = ent_type
            if ent_type not in entities_by_type:
                entities_by_type[ent_type] = []
            entities_by_type[ent_type].append(name)


    # Normalizar domain_structure para compatibilidad hacia atrás
    def get_entity_properties(entity_type: str) -> dict[str, dict[str, str | None] | list[str] | None] | list[str]:
        """Obtiene propiedades de una entidad, normalizando el formato."""
        if entity_type not in domain_structure:
            return []
        entity_data = domain_structure[entity_type]
        # Si es formato antiguo (list), retornar como está
        if isinstance(entity_data, list):
            return entity_data
        # Si es formato nuevo (dict), retornar el dict
        return entity_data

    # Primero, procesar relaciones simples (no anidadas)
    for rel in relations:
        if not isinstance(rel, list) or len(rel) < 3:
            continue

        rel_type, source, target = rel[0], rel[1], rel[2]
        evidences = _normalize_evidence(rel[3] if len(rel) > 3 else None)

        source_type = entities_by_name.get(source)
        if not source_type:
            continue

        entity_props = get_entity_properties(source_type)
        
        # Verificar si es una propiedad simple (formato antiguo o simple en formato nuevo)
        # Detección genérica basada en coincidencia de nombres, sin mapeos hardcodeados
        property_type = None
        if isinstance(entity_props, list):
            # Formato antiguo: lista de propiedades
            if domain_spec:
                property_type = domain_spec.property_for_relation(source_type, rel_type)
            if not property_type:
                for prop in entity_props:
                    if prop.lower() in rel_type.lower() or rel_type.lower() in prop.lower():
                        property_type = prop
                        break

            if property_type and property_type in entity_props:
                if source not in properties:
                    properties[source] = {}
                properties[source][property_type] = target

                if evidences:
                    if source not in properties_evidences:
                        properties_evidences[source] = {}
                    if property_type not in properties_evidences[source]:
                        properties_evidences[source][property_type] = []
                    for ev in evidences:
                        ev_key = (ev.get("document", ""), ev.get("sentence", ""))
                        if ev_key not in [
                            (e.get("document", ""), e.get("sentence", ""))
                            for e in properties_evidences[source][property_type]
                        ]:
                            properties_evidences[source][property_type].append(ev)
        elif isinstance(entity_props, dict):
            # Formato nuevo: dict con propiedades anidadas y simples
            # Buscar propiedades simples (almacenadas como listas en el dict)
            if domain_spec:
                property_type = domain_spec.property_for_relation(source_type, rel_type)
            if not property_type:
                for prop_name, prop_data in entity_props.items():
                    # Si es una lista, es una propiedad simple
                    if isinstance(prop_data, list):
                        # Verificar si el tipo de relación coincide con el nombre de la propiedad
                        if prop_name.lower() in rel_type.lower() or rel_type.lower() in prop_name.lower():
                            property_type = prop_name
                            break

            if property_type:
                if source not in properties:
                    properties[source] = {}
                properties[source][property_type] = target

                if evidences:
                    if source not in properties_evidences:
                        properties_evidences[source] = {}
                    if property_type not in properties_evidences[source]:
                        properties_evidences[source][property_type] = []
                    for ev in evidences:
                        ev_key = (ev.get("document", ""), ev.get("sentence", ""))
                        if ev_key not in [
                            (e.get("document", ""), e.get("sentence", ""))
                            for e in properties_evidences[source][property_type]
                        ]:
                            properties_evidences[source][property_type].append(ev)

    # Segundo, procesar propiedades anidadas desde relaciones
    # Agrupar relaciones por entidad fuente para detectar patrones anidados
    relations_by_source: dict[str, list[list]] = {}
    for rel in relations:
        if isinstance(rel, list) and len(rel) >= 3:
            source = rel[1]
            if source not in relations_by_source:
                relations_by_source[source] = []
            relations_by_source[source].append(rel)

    # Detectar propiedades anidadas
    for source, source_rels in relations_by_source.items():
        source_type = entities_by_name.get(source)
        if not source_type:
            continue

        entity_props = get_entity_properties(source_type)
        if not isinstance(entity_props, dict):
            continue  # Solo procesar formato nuevo con propiedades anidadas

        # Buscar propiedades anidadas en el dominio
        for nested_prop_name, nested_prop_data in entity_props.items():
            if not isinstance(nested_prop_data, dict):
                continue
            
            # Verificar si es estructura de nivel 2 (tiene claves que no son "relacion", "sub_propiedades" ni "_relacion")
            is_level2 = any(
                key not in ("relacion", "sub_propiedades", "_relacion")
                for key in nested_prop_data.keys()
            )
            
            if is_level2:
                # Estructura de nivel 2: {prop_nivel2: {"sub_propiedades": [...]}}
                # Procesar cada propiedad de nivel 2
                for level2_prop_name, level2_prop_data in nested_prop_data.items():
                    if level2_prop_name in ("relacion", "_relacion"):
                        continue
                    if not isinstance(level2_prop_data, dict) or "sub_propiedades" not in level2_prop_data:
                        continue
                    
                    level2_sub_props = level2_prop_data.get("sub_propiedades", [])
                    if not isinstance(level2_sub_props, list):
                        continue
                    
                    # Obtener el tipo de relación esperado para la propiedad anidada nivel 1
                    expected_relation_type = get_relation_from_nested_property(
                        nested_prop_name, source_type, domain_structure
                    )
                    if domain_spec:
                        expected_relation_type = domain_spec.canonicalize_relation(
                            expected_relation_type
                        )
                    
                    # Procesar relaciones para nivel 2 (similar a nivel 1 pero con estructura anidada)
                    nested_prop_instances: list[dict[str, str | dict]] = []
                    processed_relations: set[tuple[str, str, str]] = set()
                    
                    for rel in source_rels:
                        if not isinstance(rel, list) or len(rel) < 3:
                            continue

                        rel_type, rel_source, rel_target = rel[0], rel[1], rel[2]
                        if rel_source != source:
                            continue

                        # Verificar si el tipo de relación coincide con el esperado
                        rel_type_canonical = (
                            domain_spec.canonicalize_relation(rel_type)
                            if domain_spec
                            else rel_type
                        )
                        if rel_type_canonical.lower() != expected_relation_type.lower():
                            continue

                        evidences = _normalize_evidence(rel[3] if len(rel) > 3 else None)
                        rel_key = (rel_type, rel_source, rel_target)
                        
                        if rel_key in processed_relations:
                            continue
                        processed_relations.add(rel_key)

                        # Crear instancia de propiedad anidada nivel 2
                        nested_instance: dict[str, str | dict] = {}
                        
                        # Verificar si el target es una referencia a entidad (debe ser la propiedad de nivel 2)
                        is_ref, ref_entity_type = is_entity_reference(
                            level2_prop_name, rel_target, domain_structure, entities
                        )
                        
                        if is_ref:
                            # La propiedad de nivel 2 es una referencia a entidad
                            nested_instance[level2_prop_name] = rel_target

                            # Generar relación bidireccional
                            direct_relation = [expected_relation_type, source, rel_target, evidences]
                            if direct_relation not in generated_relations:
                                generated_relations.append(direct_relation)

                            inverse_type = _generate_inverse_relation_name(expected_relation_type)
                            inverse_relation = [inverse_type, rel_target, source, evidences]
                            if inverse_relation not in generated_relations:
                                generated_relations.append(inverse_relation)

                            # Agregar evidencias por instancia (rel_target identifica la instancia)
                            if evidences:
                                if source not in properties_evidences:
                                    properties_evidences[source] = {}
                                if nested_prop_name not in properties_evidences[source]:
                                    properties_evidences[source][nested_prop_name] = {}
                                if level2_prop_name not in properties_evidences[source][nested_prop_name]:
                                    properties_evidences[source][nested_prop_name][level2_prop_name] = {}
                                instance_id = rel_target
                                if instance_id not in properties_evidences[source][nested_prop_name][level2_prop_name]:
                                    properties_evidences[source][nested_prop_name][level2_prop_name][instance_id] = {}
                                for ev in evidences:
                                    ev_key = (ev.get("document", ""), ev.get("sentence", ""))
                                    existing = properties_evidences[source][nested_prop_name][level2_prop_name][instance_id].get("_entity_ref", [])
                                    if ev_key not in [(e.get("document", ""), e.get("sentence", "")) for e in existing]:
                                        if "_entity_ref" not in properties_evidences[source][nested_prop_name][level2_prop_name][instance_id]:
                                            properties_evidences[source][nested_prop_name][level2_prop_name][instance_id]["_entity_ref"] = []
                                        properties_evidences[source][nested_prop_name][level2_prop_name][instance_id]["_entity_ref"].append(ev)
                        
                        # Si encontramos una instancia válida, agregarla
                        if nested_instance:
                            nested_instance["_evidences"] = evidences
                            nested_prop_instances.append(nested_instance)
                    
                    # Buscar relaciones adicionales que correspondan a sub-propiedades de nivel 2
                    for instance in nested_prop_instances:
                        instance_evidences = instance.get("_evidences", [])
                        if not instance_evidences:
                            continue
                        
                        instance_ev_keys = {
                            (ev.get("document", ""), ev.get("sentence", ""))
                            for ev in instance_evidences
                        }
                        
                        # Buscar relaciones adicionales de la misma fuente
                        for rel in source_rels:
                            if not isinstance(rel, list) or len(rel) < 3:
                                continue
                            
                            rel_type, rel_source, rel_target = rel[0], rel[1], rel[2]
                            if rel_source != source:
                                continue
                            
                            # Verificar si es una relación de sub-propiedad de nivel 2
                            if not rel_type.lower().startswith("tiene "):
                                continue
                            
                            sub_prop_name_from_rel = rel_type[6:].strip()
                            
                            # Verificar si esta sub-propiedad está definida en el dominio (nivel 2)
                            if sub_prop_name_from_rel not in level2_sub_props:
                                continue
                            
                            # Verificar si NO es una referencia a entidad
                            is_ref, _ = is_entity_reference(
                                sub_prop_name_from_rel, rel_target, domain_structure, entities
                            )
                            if is_ref:
                                continue
                            
                            # Verificar si las evidencias coinciden
                            rel_evidences = _normalize_evidence(rel[3] if len(rel) > 3 else None)
                            if not rel_evidences:
                                continue
                            
                            rel_ev_keys = {
                                (ev.get("document", ""), ev.get("sentence", ""))
                                for ev in rel_evidences
                            }
                            
                            # Coincidencia exacta de evidencias (mismo documento y oración).
                            # No usar coincidencia solo por documento: mezclaría subpropiedades de distintas
                            # instancias (ej. "desde cuando" de Trabajo A con "desde cuando" de Trabajo B).
                            exact_match = bool(instance_ev_keys & rel_ev_keys)
                            
                            if exact_match:
                                instance[sub_prop_name_from_rel] = rel_target
                                
                                # Agregar evidencias por instancia (evitar mezclar fuentes entre instancias)
                                instance_id = instance.get(level2_prop_name)
                                if instance_id is None:
                                    instance_id = ""
                                if source not in properties_evidences:
                                    properties_evidences[source] = {}
                                if nested_prop_name not in properties_evidences[source]:
                                    properties_evidences[source][nested_prop_name] = {}
                                if level2_prop_name not in properties_evidences[source][nested_prop_name]:
                                    properties_evidences[source][nested_prop_name][level2_prop_name] = {}
                                if instance_id not in properties_evidences[source][nested_prop_name][level2_prop_name]:
                                    properties_evidences[source][nested_prop_name][level2_prop_name][instance_id] = {}
                                if sub_prop_name_from_rel not in properties_evidences[source][nested_prop_name][level2_prop_name][instance_id]:
                                    properties_evidences[source][nested_prop_name][level2_prop_name][instance_id][sub_prop_name_from_rel] = []
                                for ev in rel_evidences:
                                    ev_key = (ev.get("document", ""), ev.get("sentence", ""))
                                    existing = properties_evidences[source][nested_prop_name][level2_prop_name][instance_id][sub_prop_name_from_rel]
                                    if ev_key not in [(e.get("document", ""), e.get("sentence", "")) for e in existing]:
                                        properties_evidences[source][nested_prop_name][level2_prop_name][instance_id][sub_prop_name_from_rel].append(ev)
                        
                        instance.pop("_evidences", None)
                    
                    # Agregar propiedades anidadas nivel 2 al mapa de propiedades
                    if nested_prop_instances:
                        if source not in properties:
                            properties[source] = {}
                        # Estructura: {prop_nivel1: [{"prop_nivel2": {...}, "sub_prop": value, ...}]}
                        if nested_prop_name not in properties[source]:
                            properties[source][nested_prop_name] = []
                        properties[source][nested_prop_name].extend(nested_prop_instances)
                
                continue  # Ya procesamos nivel 2, continuar con siguiente propiedad
            
            # Estructura de nivel 1 (compatibilidad hacia atrás)
            if "sub_propiedades" not in nested_prop_data:
                continue

            sub_props = nested_prop_data.get("sub_propiedades", [])
            if not isinstance(sub_props, list):
                continue

            # Obtener el tipo de relación esperado para esta propiedad anidada
            expected_relation_type = get_relation_from_nested_property(
                nested_prop_name, source_type, domain_structure
            )
            
            # Buscar relaciones que correspondan a esta propiedad anidada
            nested_prop_instances: list[dict[str, str | dict]] = []
            processed_relations: set[tuple[str, str, str]] = set()
            
            for rel in source_rels:
                if not isinstance(rel, list) or len(rel) < 3:
                    continue

                rel_type, rel_source, rel_target = rel[0], rel[1], rel[2]
                if rel_source != source:
                    continue

                # Verificar si el tipo de relación coincide con el esperado para esta propiedad anidada
                if rel_type.lower() != expected_relation_type.lower():
                    continue

                evidences = _normalize_evidence(rel[3] if len(rel) > 3 else None)
                rel_key = (rel_type, rel_source, rel_target)
                
                if rel_key in processed_relations:
                    continue
                processed_relations.add(rel_key)

                # Esta relación corresponde a la propiedad anidada
                # Crear instancia: el target de la relación es el valor principal de la propiedad anidada
                nested_instance: dict[str, str | dict] = {}
                nested_instance[nested_prop_name] = rel_target

                if evidences:
                    if source not in properties_evidences:
                        properties_evidences[source] = {}
                    if nested_prop_name not in properties_evidences[source]:
                        properties_evidences[source][nested_prop_name] = {}
                    instance_id = rel_target
                    if instance_id not in properties_evidences[source][nested_prop_name]:
                        properties_evidences[source][nested_prop_name][instance_id] = {}
                    if nested_prop_name not in properties_evidences[source][nested_prop_name][instance_id]:
                        properties_evidences[source][nested_prop_name][instance_id][nested_prop_name] = []
                    for ev in evidences:
                        ev_key = (ev.get("document", ""), ev.get("sentence", ""))
                        existing = properties_evidences[source][nested_prop_name][instance_id][nested_prop_name]
                        if ev_key not in [(e.get("document", ""), e.get("sentence", "")) for e in existing]:
                            properties_evidences[source][nested_prop_name][instance_id][nested_prop_name].append(ev)

                # Verificar si el target es una referencia a entidad (debe ser una sub-propiedad)
                for sub_prop in sub_props:
                    is_ref, ref_entity_type = is_entity_reference(
                        sub_prop, rel_target, domain_structure, entities
                    )
                    
                    if is_ref:
                        # Esta sub-propiedad es una referencia a entidad
                        nested_instance[sub_prop] = rel_target

                        # Generar relación bidireccional
                        # Relación directa: NO generar si ya existe como relación explícita
                        # Solo generar si no existe en las relaciones explícitas
                        relation_exists = False
                        for existing_rel in source_rels:
                            if (isinstance(existing_rel, list) and len(existing_rel) >= 3 and
                                existing_rel[0] == expected_relation_type and
                                existing_rel[1] == source and
                                existing_rel[2] == rel_target):
                                relation_exists = True
                                break
                        
                        # Solo generar si no existe como relación explícita
                        if not relation_exists:
                            direct_relation = [expected_relation_type, source, rel_target, evidences]
                            if direct_relation not in generated_relations:
                                generated_relations.append(direct_relation)

                        # Relación inversa: generar nombre genérico sin asumir dominio ni idioma
                        # La relación inversa se genera de forma completamente genérica
                        inverse_type = _generate_inverse_relation_name(expected_relation_type)
                        
                        inverse_relation = [inverse_type, rel_target, source, evidences]
                        if inverse_relation not in generated_relations:
                            generated_relations.append(inverse_relation)

                        # Agregar evidencias por instancia (nivel 1)
                        if evidences:
                            if source not in properties_evidences:
                                properties_evidences[source] = {}
                            if nested_prop_name not in properties_evidences[source]:
                                properties_evidences[source][nested_prop_name] = {}
                            if rel_target not in properties_evidences[source][nested_prop_name]:
                                properties_evidences[source][nested_prop_name][rel_target] = {}
                            if sub_prop not in properties_evidences[source][nested_prop_name][rel_target]:
                                properties_evidences[source][nested_prop_name][rel_target][sub_prop] = []
                            for ev in evidences:
                                ev_key = (ev.get("document", ""), ev.get("sentence", ""))
                                existing = properties_evidences[source][nested_prop_name][rel_target][sub_prop]
                                if ev_key not in [(e.get("document", ""), e.get("sentence", "")) for e in existing]:
                                    properties_evidences[source][nested_prop_name][rel_target][sub_prop].append(ev)
                        break  # Solo una sub-propiedad puede ser la referencia a entidad principal
                
                # Si encontramos una instancia válida, agregarla
                if nested_instance:
                    # Guardar las evidencias de esta instancia para agrupar relaciones adicionales
                    nested_instance["_evidences"] = evidences
                    nested_prop_instances.append(nested_instance)

            # Buscar relaciones adicionales que correspondan a sub-propiedades literales
            # y agruparlas con las instancias por evidencia compartida
            for instance in nested_prop_instances:
                instance_evidences = instance.get("_evidences", [])
                if not instance_evidences:
                    continue
                
                # Buscar dinámicamente qué propiedad de la instancia es una referencia a entidad
                # (genérico, no específico del dominio)
                instance_entity_ref = None
                instance_entity_ref_prop = None
                for prop_name, prop_value in instance.items():
                    if prop_name == "_evidences":
                        continue
                    # Verificar si esta propiedad es una referencia a entidad
                    is_ref, _ = is_entity_reference(
                        prop_name, prop_value, domain_structure, entities
                    )
                    if is_ref and isinstance(prop_value, str):
                        instance_entity_ref = prop_value
                        instance_entity_ref_prop = prop_name
                        break
                
                # Filtrar evidencias de la instancia: usar solo las que mencionan específicamente la entidad referenciada
                # Esto evita que evidencias genéricas se asignen a todas las instancias
                filtered_instance_evidences = instance_evidences
                if instance_entity_ref:
                    import unicodedata
                    import re
                    def normalize_text(text):
                        text = unicodedata.normalize('NFD', text.lower())
                        text = ''.join(c for c in text if unicodedata.category(c) != 'Mn')
                        text = re.sub(r'[^\w\s]', '', text)
                        text = re.sub(r'\s+', ' ', text)
                        return text.strip()
                    
                    entity_ref_normalized = normalize_text(str(instance_entity_ref))
                    entity_words = [w for w in entity_ref_normalized.split() if len(w) > 2]
                    
                    # Filtrar evidencias que mencionan esta entidad específica
                    if entity_words:
                        filtered_instance_evidences = []
                        for ev in instance_evidences:
                            ev_sentence = ev.get("sentence", "")
                            sentence_normalized = normalize_text(ev_sentence)
                            # Verificar que la evidencia menciona esta entidad
                            if all(word in sentence_normalized for word in entity_words):
                                filtered_instance_evidences.append(ev)
                
                # Crear conjunto de claves de evidencia para comparación (usando evidencias filtradas)
                instance_ev_keys = {
                    (ev.get("document", ""), ev.get("sentence", ""))
                    for ev in filtered_instance_evidences
                }
                
                # Si no hay evidencias filtradas, usar todas (fallback)
                if not instance_ev_keys:
                    instance_ev_keys = {
                        (ev.get("document", ""), ev.get("sentence", ""))
                        for ev in instance_evidences
                    }
                
                # Buscar relaciones adicionales de la misma fuente
                for rel in source_rels:
                    if not isinstance(rel, list) or len(rel) < 3:
                        continue
                    
                    rel_type, rel_source, rel_target = rel[0], rel[1], rel[2]
                    if rel_source != source:
                        continue
                    
                    # Verificar si es una relación de sub-propiedad (patrón "tiene [nombre_sub_propiedad]")
                    if not rel_type.lower().startswith("tiene "):
                        continue
                    
                    # Extraer el nombre de la sub-propiedad del tipo de relación
                    sub_prop_name_from_rel = rel_type[6:].strip()  # Remover "tiene "
                    
                    # Verificar si esta sub-propiedad está definida en el dominio
                    if sub_prop_name_from_rel not in sub_props:
                        continue
                    
                    # Verificar si NO es una referencia a entidad (ya la procesamos arriba)
                    is_ref, _ = is_entity_reference(
                        sub_prop_name_from_rel, rel_target, domain_structure, entities
                    )
                    if is_ref:
                        continue  # Ya procesada como referencia a entidad
                    
                    # Verificar si las evidencias coinciden (misma instancia)
                    rel_evidences = _normalize_evidence(rel[3] if len(rel) > 3 else None)
                    if not rel_evidences:
                        continue
                    
                    rel_ev_keys = {
                        (ev.get("document", ""), ev.get("sentence", ""))
                        for ev in rel_evidences
                    }
                    
                    # Coincidencia exacta de evidencias (mismo documento y oración); no por documento/semántica para no mezclar instancias
                    exact_match = bool(instance_ev_keys & rel_ev_keys)
                    
                    if exact_match:
                        instance[sub_prop_name_from_rel] = rel_target
                        instance_id_l1 = instance.get(nested_prop_name)
                        if instance_id_l1 is None:
                            instance_id_l1 = ""
                        if source not in properties_evidences:
                            properties_evidences[source] = {}
                        if nested_prop_name not in properties_evidences[source]:
                            properties_evidences[source][nested_prop_name] = {}
                        if instance_id_l1 not in properties_evidences[source][nested_prop_name]:
                            properties_evidences[source][nested_prop_name][instance_id_l1] = {}
                        if sub_prop_name_from_rel not in properties_evidences[source][nested_prop_name][instance_id_l1]:
                            properties_evidences[source][nested_prop_name][instance_id_l1][sub_prop_name_from_rel] = []
                        for ev in rel_evidences:
                            ev_key = (ev.get("document", ""), ev.get("sentence", ""))
                            existing = properties_evidences[source][nested_prop_name][instance_id_l1][sub_prop_name_from_rel]
                            if ev_key not in [(e.get("document", ""), e.get("sentence", "")) for e in existing]:
                                properties_evidences[source][nested_prop_name][instance_id_l1][sub_prop_name_from_rel].append(ev)
                
                # Remover la clave temporal de evidencias
                instance.pop("_evidences", None)

            # Agregar propiedades anidadas al mapa de propiedades
            if nested_prop_instances:
                if source not in properties:
                    properties[source] = {}
                # Usar lista para soportar múltiples instancias
                properties[source][nested_prop_name] = nested_prop_instances

    return properties, properties_evidences, generated_relations


def generate_inverse_relations(relations: list[list]) -> list[list]:
    """Genera relaciones inversas automáticamente desde las relaciones explícitas, preservando evidencias."""
    inverse_relations: list[list] = []
    seen: set[tuple[str, str, str]] = set()

    for rel in relations:
        if not isinstance(rel, list) or len(rel) < 3:
            continue

        rel_type, source, target = rel[0], rel[1], rel[2]
        evidences = _normalize_evidence(rel[3] if len(rel) > 3 else None)

        key = (rel_type, source, target)
        if key not in seen:
            seen.add(key)
            inverse_relations.append([rel_type, source, target, evidences])

        # Generar relación inversa de forma genérica
        inverse_type = _generate_inverse_relation_name(rel_type)
        if inverse_type == rel_type:
            continue

        inverse_key = (inverse_type, target, source)
        if inverse_key not in seen:
            seen.add(inverse_key)
            inverse_relations.append([inverse_type, target, source, evidences])

    return inverse_relations


def group_entities_by_type(entities: list[list]) -> dict[str, list[tuple[str, str, list[dict]]]]:
    """Agrupa entidades por tipo. Retorna dict con tipo -> lista de (nombre, tipo, evidencias)."""
    grouped: dict[str, list[tuple[str, str, list[dict]]]] = {}

    for ent in entities:
        if not isinstance(ent, list) or len(ent) < 2:
            continue

        name, ent_type = ent[0], ent[1]
        evidences = _normalize_evidence(ent[2] if len(ent) > 2 else None)

        normalized_type = ent_type.strip()

        if normalized_type not in grouped:
            grouped[normalized_type] = []

        if (name, normalized_type) not in [
            (n, t) for n, t, _ in grouped[normalized_type]
        ]:
            grouped[normalized_type].append((name, normalized_type, evidences))

    return grouped


def build_entity_relations_map(
    entities: list[list],
    relations: list[list],
    domain_structure: dict[str, dict[str, dict[str, str | None] | list[str] | None]] | dict[str, list[str]] | None = None,
    domain_spec: DomainSpec | None = None,
) -> tuple[
    dict[str, dict[str, list[str]]],
    dict[str, dict[str, dict | str | list]],
    dict[str, dict[str, list[dict]]],
    dict[str, dict[str, dict[str, list[dict]]]],
    dict[str, dict[str, dict[str, list[dict]]]],
    set[tuple[str, str, str]],
]:
    """
    Construye un mapa de entidad -> {tipo_relacion: [entidades_destino]} y propiedades, preservando evidencias.
    Retorna también un conjunto de relaciones que provienen de propiedades anidadas para filtrarlas del output.
    """
    entity_map: dict[str, dict[str, list[str]]] = {}
    entity_evidences_map: dict[str, list[dict]] = {}
    relation_evidences_map: dict[str, dict[str, dict[str, list[dict]]]] = {}

    for ent in entities:
        if isinstance(ent, list) and len(ent) >= 2:
            name = ent[0]
            if name not in entity_map:
                entity_map[name] = {}
            evidences = _normalize_evidence(ent[2] if len(ent) > 2 else None)
            if evidences:
                if name not in entity_evidences_map:
                    entity_evidences_map[name] = []
                for ev in evidences:
                    ev_key = (ev.get("document", ""), ev.get("sentence", ""))
                    if ev_key not in [
                        (e.get("document", ""), e.get("sentence", ""))
                        for e in entity_evidences_map[name]
                    ]:
                        entity_evidences_map[name].append(ev)

    properties_map: dict[str, dict[str, dict | str | list]] = {}
    properties_evidences_map: dict[str, dict[str, dict[str, list[dict]]]] = {}
    generated_relations_from_props: list[list] = []
    if domain_structure:
        properties_map, properties_evidences_map, generated_relations_from_props = identify_properties(
            entities, relations, domain_structure, domain_spec=domain_spec
        )

    # Combinar relaciones explícitas con relaciones generadas desde propiedades anidadas
    all_explicit_relations = generate_inverse_relations(relations)
    
    # Rastrear solo relaciones de subpropiedades nivel 2 ("tiene X"); no la relación principal (ej. "trabaja en")
    nested_property_relations: set[tuple[str, str, str]] = set()
    for rel in generated_relations_from_props:
        if isinstance(rel, list) and len(rel) >= 3:
            rel_type = rel[0]
            if isinstance(rel_type, str) and rel_type.strip().lower().startswith("tiene "):
                key = (rel[0], rel[1], rel[2])
                nested_property_relations.add(key)
    
    # También rastrear relaciones explícitas que corresponden a propiedades anidadas
    # basándose en el dominio (para evitar duplicados)
    if domain_structure:
        for rel in all_explicit_relations:
            if not isinstance(rel, list) or len(rel) < 3:
                continue
            rel_type, source, target = rel[0], rel[1], rel[2]
            # Verificar si esta relación corresponde a una propiedad anidada
            for ent in entities:
                if isinstance(ent, list) and len(ent) >= 2 and ent[0] == source:
                    source_type = ent[1]
                    entity_props = domain_structure.get(source_type, {})
                    if isinstance(entity_props, dict):
                        for prop_name, prop_data in entity_props.items():
                            if isinstance(prop_data, dict):
                                # Verificar si es estructura de nivel 2
                                is_level2 = any(
                                    key not in ("relacion", "sub_propiedades", "_relacion")
                                    for key in prop_data.keys()
                                )
                                
                                if is_level2:
                                    # Estructura de nivel 2: NO marcar relaciones explícitas como anidadas
                                    # Solo las relaciones generadas desde propiedades anidadas deben filtrarse
                                    pass
                                    
                                    # Verificar sub-propiedades de nivel 2 (en lista o como clave nivel 2)
                                    if rel_type.lower().startswith("tiene "):
                                        sub_prop_name_from_rel = rel_type[6:].strip()
                                        for level2_prop_name, level2_prop_data in prop_data.items():
                                            if level2_prop_name in ("relacion", "_relacion"):
                                                continue
                                            if sub_prop_name_from_rel == level2_prop_name:
                                                key = (rel_type, source, target)
                                                nested_property_relations.add(key)
                                                break
                                            if isinstance(level2_prop_data, dict) and "sub_propiedades" in level2_prop_data:
                                                level2_sub_props = level2_prop_data["sub_propiedades"]
                                                if isinstance(level2_sub_props, list) and sub_prop_name_from_rel in level2_sub_props:
                                                    key = (rel_type, source, target)
                                                    nested_property_relations.add(key)
                                                    break
                                else:
                                    # Estructura de nivel 1 (compatibilidad hacia atrás)
                                    # NO marcar relaciones explícitas como anidadas solo porque coinciden
                                    # Solo las relaciones generadas desde propiedades anidadas deben filtrarse
                                    # Las relaciones explícitas que coinciden con propiedades anidadas
                                    # deben mostrarse en la sección de relaciones
                                    pass
                                    
                                    # Verificar si es una relación de sub-propiedad (patrón "tiene [nombre_sub_propiedad]")
                                    if rel_type.lower().startswith("tiene "):
                                        sub_prop_name_from_rel = rel_type[6:].strip()  # Remover "tiene "
                                        if "sub_propiedades" in prop_data:
                                            sub_props = prop_data["sub_propiedades"]
                                            if isinstance(sub_props, list) and sub_prop_name_from_rel in sub_props:
                                                # Esta relación corresponde a una sub-propiedad de una propiedad anidada
                                                key = (rel_type, source, target)
                                                nested_property_relations.add(key)
                    break
    # Agregar relaciones generadas desde propiedades anidadas, evitando duplicados
    seen_relation_keys: set[tuple[str, str, str]] = set()
    all_relations: list[list] = []
    
    for rel in all_explicit_relations:
        if isinstance(rel, list) and len(rel) >= 3:
            key = (rel[0], rel[1], rel[2])
            if key not in seen_relation_keys:
                seen_relation_keys.add(key)
                all_relations.append(rel)
    
    for rel in generated_relations_from_props:
        if isinstance(rel, list) and len(rel) >= 3:
            key = (rel[0], rel[1], rel[2])
            if key not in seen_relation_keys:
                seen_relation_keys.add(key)
                all_relations.append(rel)

    for rel in all_relations:
        if not isinstance(rel, list) or len(rel) < 3:
            continue

        rel_type, source, target = rel[0], rel[1], rel[2]
        evidences = _normalize_evidence(rel[3] if len(rel) > 3 else None)

        is_property = False
        if domain_structure:
            # Detección genérica de propiedades basada en coincidencia de nombres con el dominio
            # Sin mapeos ni patrones hardcodeados específicos del dominio o idioma
            for ent in entities:
                if isinstance(ent, list) and len(ent) >= 2 and ent[0] == source:
                    source_type = ent[1]
                    if domain_spec:
                        is_property = bool(
                            domain_spec.property_for_relation(source_type, rel_type)
                        )
                    if not is_property:
                        # Obtener propiedades del dominio para este tipo de entidad
                        entity_props = domain_structure.get(source_type, [])
                        if isinstance(entity_props, list):
                            # Formato antiguo: lista de propiedades
                            for prop in entity_props:
                                if prop.lower() in rel_type.lower() or rel_type.lower() in prop.lower():
                                    is_property = True
                                    break
                        elif isinstance(entity_props, dict):
                            # Formato nuevo: dict con propiedades anidadas y simples
                            # Verificar propiedades simples (almacenadas como listas) y anidadas (almacenadas como dicts)
                            for prop_name, prop_data in entity_props.items():
                                # Propiedad simple (lista) o propiedad anidada (dict)
                                if isinstance(prop_data, list) or isinstance(prop_data, dict):
                                    # Verificar si el tipo de relación coincide con el nombre de la propiedad
                                    if prop_name.lower() in rel_type.lower() or rel_type.lower() in prop_name.lower():
                                        is_property = True
                                        break
                    break

        if is_property:
            continue

        if source not in entity_map:
            entity_map[source] = {}

        if rel_type not in entity_map[source]:
            entity_map[source][rel_type] = []

        if target not in entity_map[source][rel_type]:
            entity_map[source][rel_type].append(target)

        if evidences:
            if source not in relation_evidences_map:
                relation_evidences_map[source] = {}
            if rel_type not in relation_evidences_map[source]:
                relation_evidences_map[source][rel_type] = {}
            if target not in relation_evidences_map[source][rel_type]:
                relation_evidences_map[source][rel_type][target] = []
            for ev in evidences:
                ev_key = (ev.get("document", ""), ev.get("sentence", ""))
                if ev_key not in [
                    (e.get("document", ""), e.get("sentence", ""))
                    for e in relation_evidences_map[source][rel_type][target]
                ]:
                    relation_evidences_map[source][rel_type][target].append(ev)

    return (
        entity_map,
        properties_map,
        entity_evidences_map,
        relation_evidences_map,
        properties_evidences_map,
        nested_property_relations,
    )


def generate_ontology_markdown(
    entities: list[list],
    relations: list[list],
    domain_name: str | None = None,
    config_dir: str | None = None,
) -> str:
    """
    Genera ontología en formato Markdown con entidades agrupadas por tipo, incluyendo evidencias.
    
    Args:
        entities: Lista de entidades
        relations: Lista de relaciones
        domain_name: Nombre del dominio a usar (sin extensión .md). Si es None, usa el dominio por defecto.
        config_dir: Ruta al directorio de configuración. Si es None, usa el directorio por defecto.
    """
    domain_spec = load_domain_spec(domain_name, config_dir)
    domain_structure = domain_spec.domain_structure

    grouped = group_entities_by_type(entities)
    (
        entity_relations,
        properties_map,
        entity_evidences_map,
        relation_evidences_map,
        properties_evidences_map,
        nested_property_relations,
    ) = build_entity_relations_map(
        entities, relations, domain_structure, domain_spec=domain_spec
    )

    lines: list[str] = ["# Ontología de Entidades y Relaciones", ""]

    def format_evidence(ev: dict) -> str:
        doc = ev.get("document", "")
        sent = ev.get("sentence", "")
        return f'"{sent}" (Documento: {doc})'

    # Orden genérico: primero los tipos definidos en el dominio (si existe), luego alfabéticamente
    type_order = []
    if domain_structure:
        # Usar el orden de aparición en el dominio
        type_order = list(domain_structure.keys())
    # Agregar tipos que no están en el dominio pero aparecen en las entidades
    all_types = set(grouped.keys())
    for ent_type in sorted(all_types):
        if ent_type not in type_order:
            type_order.append(ent_type)
    # Si no hay dominio, ordenar alfabéticamente
    if not type_order:
        type_order = sorted(grouped.keys())

    seen_types = set()
    for ent_type in type_order:
        if ent_type in grouped:
            seen_types.add(ent_type)
            lines.append(f"## {ent_type}")
            lines.append("")

            for name, _, entity_evidences in sorted(grouped[ent_type], key=lambda x: x[0]):
                lines.append(f"### {name}")

                if entity_evidences:
                    lines.append("#### Evidencias de la Entidad")
                    for ev in entity_evidences:
                        lines.append(f"- {format_evidence(ev)}")
                    lines.append("")

                if name in properties_map and properties_map[name]:
                    lines.append("#### Propiedades")
                    for prop_type, prop_value in sorted(properties_map[name].items()):
                        # Verificar si es una propiedad anidada (dict o list)
                        if isinstance(prop_value, (dict, list)):
                            # Propiedad anidada
                            # Si es una lista de instancias
                            if isinstance(prop_value, list):
                                # Si hay múltiples instancias, mostrar cada una por separado
                                multiple_instances = len(prop_value) > 1
                                for idx, instance in enumerate(prop_value):
                                    # Si hay múltiples instancias, agregar un encabezado para cada una
                                    if multiple_instances:
                                        lines.append(f"- **{prop_type}** ({idx + 1}):")
                                    elif idx == 0:
                                        # Si es la única instancia, mostrar el encabezado normal
                                        lines.append(f"- **{prop_type}**:")
                                    if isinstance(instance, dict):
                                        # Verificar si es estructura de nivel 2 (tiene claves que parecen propiedades de nivel 2)
                                        # Las propiedades de nivel 2 son aquellas que están en el dominio como nivel 2
                                        source_type = None
                                        for ent in entities:
                                            if isinstance(ent, list) and len(ent) >= 2 and ent[0] == name:
                                                source_type = ent[1]
                                                break
                                        
                                        is_level2_structure = False
                                        if source_type and source_type in domain_structure:
                                            entity_props = domain_structure[source_type]
                                            if isinstance(entity_props, dict) and prop_type in entity_props:
                                                prop_data = entity_props[prop_type]
                                                if isinstance(prop_data, dict):
                                                    is_level2_structure = any(
                                                        key not in ("relacion", "sub_propiedades", "_relacion")
                                                        for key in prop_data.keys()
                                                    )
                                        
                                        if is_level2_structure:
                                            # Identificador de instancia: primera prop nivel-2 real (dict con sub_propiedades), no _relacion ni _sub_propiedades_nivel1
                                            level2_identifier = next(
                                                (
                                                    k
                                                    for k in prop_data
                                                    if k not in ("relacion", "_relacion", "_sub_propiedades_nivel1")
                                                    and isinstance(prop_data.get(k), dict)
                                                    and "sub_propiedades" in (prop_data.get(k) or {})
                                                ),
                                                None,
                                            )
                                            instance_id = instance.get(level2_identifier) if level2_identifier else None
                                            # Estructura de nivel 2: mostrar prop_nivel2 y luego sub-propiedades
                                            for level2_prop, level2_value in sorted(instance.items()):
                                                if level2_prop == "_evidences":
                                                    continue
                                                
                                                # Mostrar propiedad de nivel 2
                                                if isinstance(level2_value, dict):
                                                    # Es un dict con sub-propiedades
                                                    lines.append(f"  - **{level2_prop}**:")
                                                    for sub_prop, sub_value in sorted(level2_value.items()):
                                                        if sub_prop == "_evidences":
                                                            continue
                                                        sub_prop_line = f"    - **{sub_prop}**: {sub_value}"
                                                        
                                                        # Agregar evidencias por instancia (nueva estructura) o fallback (antigua)
                                                        if name in properties_evidences_map and prop_type in properties_evidences_map[name]:
                                                            level2_bucket = properties_evidences_map[name][prop_type].get(level2_identifier or level2_prop)
                                                            if level2_bucket is not None:
                                                                if instance_id is not None and isinstance(level2_bucket.get(instance_id), dict):
                                                                    sub_evidences = level2_bucket[instance_id].get(sub_prop)
                                                                else:
                                                                    sub_evidences = level2_bucket.get(sub_prop)
                                                                if isinstance(sub_evidences, list) and sub_evidences:
                                                                    ev_texts = [format_evidence(ev) for ev in sub_evidences]
                                                                    sub_prop_line += f" *(Evidencia: {', '.join(ev_texts)})*"
                                                        
                                                        lines.append(sub_prop_line)
                                                else:
                                                    # Es un valor directo: referencia a entidad (level2_prop == level2_identifier) o sub-propiedad (ej. "desde cuando")
                                                    level2_prop_line = f"  - **{level2_prop}**: {level2_value}"
                                                    
                                                    if name in properties_evidences_map and prop_type in properties_evidences_map[name]:
                                                        level2_bucket = properties_evidences_map[name][prop_type].get(level2_identifier or level2_prop)
                                                        if level2_bucket is not None:
                                                            if level2_prop == level2_identifier:
                                                                # Referencia a entidad: evidencias en [instance_id][_entity_ref]
                                                                if instance_id is not None and isinstance(level2_bucket.get(instance_id), dict):
                                                                    evs = level2_bucket[instance_id].get("_entity_ref")
                                                                else:
                                                                    evs = level2_bucket.get("_entity_ref")
                                                            else:
                                                                # Sub-propiedad (ej. "desde cuando"): evidencias en [instance_id][level2_prop]
                                                                if instance_id is not None and isinstance(level2_bucket.get(instance_id), dict):
                                                                    evs = level2_bucket[instance_id].get(level2_prop)
                                                                else:
                                                                    evs = level2_bucket.get(level2_prop)
                                                            if isinstance(evs, list) and evs:
                                                                ev_texts = [format_evidence(ev) for ev in evs]
                                                                level2_prop_line += f" *(Evidencia: {', '.join(ev_texts)})*"
                                                    
                                                    lines.append(level2_prop_line)
                                        else:
                                            # Estructura de nivel 1: evidencias por instancia [prop_type][instance_id][sub_prop] o fallback [prop_type][sub_prop]
                                            instance_id_l1 = instance.get(prop_type)
                                            for sub_prop, sub_value in sorted(instance.items()):
                                                if sub_prop == "_evidences":
                                                    continue
                                                sub_prop_line = f"  - **{sub_prop}**: {sub_value}"
                                                if name in properties_evidences_map and prop_type in properties_evidences_map[name]:
                                                    bucket = properties_evidences_map[name][prop_type]
                                                    if instance_id_l1 is not None and isinstance(bucket.get(instance_id_l1), dict):
                                                        sub_evidences = bucket[instance_id_l1].get(sub_prop)
                                                    else:
                                                        sub_evidences = bucket.get(sub_prop)
                                                    if isinstance(sub_evidences, list) and sub_evidences:
                                                        ev_texts = [format_evidence(ev) for ev in sub_evidences]
                                                        sub_prop_line += f" *(Evidencia: {', '.join(ev_texts)})*"
                                                lines.append(sub_prop_line)
                                    # Agregar línea en blanco entre instancias múltiples (excepto la última)
                                    if multiple_instances and idx < len(prop_value) - 1:
                                        lines.append("")
                            # Si es un dict directo (una sola instancia)
                            elif isinstance(prop_value, dict):
                                for sub_prop, sub_value in sorted(prop_value.items()):
                                    sub_prop_line = f"  - **{sub_prop}**: {sub_value}"
                                    # Verificar si generó relación y agregar evidencias
                                    if name in properties_evidences_map:
                                        if prop_type in properties_evidences_map[name]:
                                            if sub_prop in properties_evidences_map[name][prop_type]:
                                                sub_evidences = properties_evidences_map[name][prop_type][sub_prop]
                                                if sub_evidences:
                                                    ev_texts = [format_evidence(ev) for ev in sub_evidences]
                                                    sub_prop_line += f" *(Evidencia: {', '.join(ev_texts)})*"
                                    lines.append(sub_prop_line)
                        else:
                            # Propiedad simple
                            prop_line = f"- **{prop_type}**: {prop_value}"
                            if name in properties_evidences_map and prop_type in properties_evidences_map[name]:
                                # Para propiedades simples, las evidencias pueden estar en formato list
                                prop_evidences = properties_evidences_map[name][prop_type]
                                if isinstance(prop_evidences, list) and prop_evidences:
                                    ev_texts = [format_evidence(ev) for ev in prop_evidences]
                                    prop_line += f" *(Evidencia: {', '.join(ev_texts)})*"
                            lines.append(prop_line)
                    lines.append("")

                if name in entity_relations and entity_relations[name]:
                    lines.append("#### Relaciones")
                    # Filtrar relaciones que ya están en Propiedades (subpropiedades nivel 2: "tiene X")
                    filtered_relations = {}
                    for rel_type, targets in entity_relations[name].items():
                        skip_rel_type = _is_subproperty_of_nested_level2(
                            rel_type, ent_type, domain_structure
                        )
                        filtered_targets = []
                        for target in targets:
                            rel_key = (rel_type, name, target)
                            if rel_key not in nested_property_relations and not skip_rel_type:
                                filtered_targets.append(target)
                        if filtered_targets:
                            filtered_relations[rel_type] = filtered_targets
                    
                    if filtered_relations:
                        for rel_type, targets in sorted(filtered_relations.items()):
                            for target in sorted(targets):
                                rel_line = f"- **{rel_type}**: {target}"
                                if (
                                    name in relation_evidences_map
                                    and rel_type in relation_evidences_map[name]
                                    and target in relation_evidences_map[name][rel_type]
                                ):
                                    rel_evidences = relation_evidences_map[name][rel_type][target]
                                    if rel_evidences:
                                        ev_texts = [format_evidence(ev) for ev in rel_evidences]
                                        rel_line += f" *(Evidencia: {', '.join(ev_texts)})*"
                                lines.append(rel_line)
                    else:
                        lines.append("- *Sin relaciones identificadas*")
                elif name not in properties_map or not properties_map.get(name):
                    lines.append("- *Sin relaciones identificadas*")
                lines.append("")

    for ent_type in sorted(grouped.keys()):
        if ent_type not in seen_types:
            lines.append(f"## {ent_type}")
            lines.append("")
            for name, _, entity_evidences in sorted(grouped[ent_type], key=lambda x: x[0]):
                lines.append(f"### {name}")
                if entity_evidences:
                    lines.append("#### Evidencias de la Entidad")
                    for ev in entity_evidences:
                        lines.append(f"- {format_evidence(ev)}")
                    lines.append("")
                lines.append("")

    return "\n".join(lines).strip() + "\n"


def generate_ontology_json(
    entities: list[list],
    relations: list[list],
    domain_name: str | None = None,
    config_dir: str | None = None,
) -> dict:
    """
    Genera ontología en formato JSON con entidades agrupadas por tipo, incluyendo evidencias.
    
    Args:
        entities: Lista de entidades
        relations: Lista de relaciones
        domain_name: Nombre del dominio a usar (sin extensión .md). Si es None, usa el dominio por defecto.
        config_dir: Ruta al directorio de configuración. Si es None, usa el directorio por defecto.
    """
    domain_spec = load_domain_spec(domain_name, config_dir)
    domain_structure = domain_spec.domain_structure

    grouped = group_entities_by_type(entities)
    (
        entity_relations,
        properties_map,
        entity_evidences_map,
        relation_evidences_map,
        properties_evidences_map,
        nested_property_relations,
    ) = build_entity_relations_map(
        entities, relations, domain_structure, domain_spec=domain_spec
    )

    result: dict[str, dict[str, list[dict[str, object]]]] = {"tipos": {}}

    for ent_type, entity_list in grouped.items():
        result["tipos"][ent_type] = []

        for name, _, entity_evidences in sorted(entity_list, key=lambda x: x[0]):
            entity_data: dict[str, object] = {
                "nombre": name,
                "tipo": ent_type,
                "evidencias": entity_evidences if entity_evidences else [],
                "propiedades": {},
                "relaciones": [],
            }

            if name in properties_map and properties_map[name]:
                props_dict: dict[str, dict[str, object]] = {}
                for prop_type, prop_value in sorted(properties_map[name].items()):
                    # Verificar si es una propiedad anidada
                    if isinstance(prop_value, (dict, list)):
                        # Propiedad anidada
                        if isinstance(prop_value, list):
                            # Lista de instancias
                            nested_instances = []
                            for instance in prop_value:
                                if isinstance(instance, dict):
                                    # Verificar si es estructura de nivel 2
                                    source_type = None
                                    for ent in entities:
                                        if isinstance(ent, list) and len(ent) >= 2 and ent[0] == name:
                                            source_type = ent[1]
                                            break
                                    
                                    is_level2_structure = False
                                    if source_type and source_type in domain_structure:
                                        entity_props = domain_structure[source_type]
                                        if isinstance(entity_props, dict) and prop_type in entity_props:
                                            prop_data = entity_props[prop_type]
                                            if isinstance(prop_data, dict):
                                                is_level2_structure = any(
                                                    key not in ("relacion", "sub_propiedades", "_relacion")
                                                    for key in prop_data.keys()
                                                )
                                    
                                    if is_level2_structure:
                                        # Identificador de instancia: primera prop nivel-2 real (dict con sub_propiedades)
                                        level2_identifier = next(
                                            (
                                                k
                                                for k in prop_data
                                                if k not in ("relacion", "_relacion", "_sub_propiedades_nivel1")
                                                and isinstance(prop_data.get(k), dict)
                                                and "sub_propiedades" in (prop_data.get(k) or {})
                                            ),
                                            None,
                                        )
                                        instance_id = instance.get(level2_identifier) if level2_identifier else None
                                        # Estructura de nivel 2: {prop_nivel2: {...}, sub_prop: value, ...}
                                        instance_dict: dict[str, dict[str, object]] = {}
                                        for level2_prop, level2_value in instance.items():
                                            if level2_prop == "_evidences":
                                                continue
                                            
                                            if isinstance(level2_value, dict):
                                                # Es un dict con sub-propiedades de nivel 2
                                                level2_dict: dict[str, dict[str, object]] = {}
                                                for sub_prop, sub_value in level2_value.items():
                                                    if sub_prop == "_evidences":
                                                        continue
                                                    sub_prop_data: dict[str, object] = {
                                                        "valor": sub_value,
                                                        "evidencias": [],
                                                        "es_relacion": False
                                                    }
                                                    if name in properties_evidences_map and prop_type in properties_evidences_map[name]:
                                                        level2_bucket = properties_evidences_map[name][prop_type].get(level2_identifier or level2_prop)
                                                        if level2_bucket is not None:
                                                            if instance_id is not None and isinstance(level2_bucket.get(instance_id), dict):
                                                                sub_evidences = level2_bucket[instance_id].get(sub_prop)
                                                            else:
                                                                sub_evidences = level2_bucket.get(sub_prop)
                                                            if isinstance(sub_evidences, list):
                                                                sub_prop_data["evidencias"] = sub_evidences
                                                    level2_dict[sub_prop] = sub_prop_data
                                                instance_dict[level2_prop] = {
                                                    "instancias": [level2_dict],
                                                    "es_anidada": True
                                                }
                                            else:
                                                # Es un valor directo (referencia a entidad o sub-propiedad)
                                                level2_prop_data: dict[str, object] = {
                                                    "valor": level2_value,
                                                    "evidencias": [],
                                                    "es_relacion": level2_prop == level2_identifier
                                                }
                                                if name in properties_evidences_map and prop_type in properties_evidences_map[name]:
                                                    level2_bucket = properties_evidences_map[name][prop_type].get(level2_identifier or level2_prop)
                                                    if level2_bucket is not None:
                                                        if level2_prop == level2_identifier:
                                                            if instance_id is not None and isinstance(level2_bucket.get(instance_id), dict):
                                                                evs = level2_bucket[instance_id].get("_entity_ref")
                                                            else:
                                                                evs = level2_bucket.get("_entity_ref")
                                                        else:
                                                            if instance_id is not None and isinstance(level2_bucket.get(instance_id), dict):
                                                                evs = level2_bucket[instance_id].get(level2_prop)
                                                            else:
                                                                evs = level2_bucket.get(level2_prop)
                                                        if isinstance(evs, list):
                                                            level2_prop_data["evidencias"] = evs
                                                instance_dict[level2_prop] = level2_prop_data
                                        nested_instances.append(instance_dict)
                                    else:
                                        # Estructura de nivel 1: evidencias por instancia [prop_type][instance_id][sub_prop]
                                        instance_id_l1 = instance.get(prop_type)
                                        instance_dict: dict[str, dict[str, object]] = {}
                                        for sub_prop, sub_value in instance.items():
                                            if sub_prop == "_evidences":
                                                continue
                                            sub_prop_data: dict[str, object] = {
                                                "valor": sub_value,
                                                "evidencias": [],
                                                "es_relacion": False
                                            }
                                            if name in properties_evidences_map and prop_type in properties_evidences_map[name]:
                                                bucket = properties_evidences_map[name][prop_type]
                                                if instance_id_l1 is not None and isinstance(bucket.get(instance_id_l1), dict):
                                                    sub_evidences = bucket[instance_id_l1].get(sub_prop)
                                                else:
                                                    sub_evidences = bucket.get(sub_prop)
                                                if isinstance(sub_evidences, list):
                                                    sub_prop_data["evidencias"] = sub_evidences
                                                if source_type:
                                                    is_ref, _ = is_entity_reference(
                                                        sub_prop, str(sub_value), domain_structure, entities
                                                    )
                                                    if is_ref:
                                                        sub_prop_data["es_relacion"] = True
                                            instance_dict[sub_prop] = sub_prop_data
                                        nested_instances.append(instance_dict)
                            props_dict[prop_type] = {"instancias": nested_instances, "es_anidada": True}
                        elif isinstance(prop_value, dict):
                            # Una sola instancia como dict
                            instance_dict: dict[str, dict[str, object]] = {}
                            for sub_prop, sub_value in prop_value.items():
                                sub_prop_data: dict[str, object] = {
                                    "valor": sub_value,
                                    "evidencias": [],
                                    "es_relacion": False
                                }
                                if name in properties_evidences_map:
                                    if prop_type in properties_evidences_map[name]:
                                        if sub_prop in properties_evidences_map[name][prop_type]:
                                            sub_evidences = properties_evidences_map[name][prop_type][sub_prop]
                                            sub_prop_data["evidencias"] = sub_evidences
                                            # Verificar si es relación (domain_structure ya está parseado al inicio de la función)
                                            source_type = None
                                            for ent in entities:
                                                if isinstance(ent, list) and len(ent) >= 2 and ent[0] == name:
                                                    source_type = ent[1]
                                                    break
                                            if source_type:
                                                is_ref, _ = is_entity_reference(
                                                    sub_prop, str(sub_value), domain_structure, entities
                                                )
                                                if is_ref:
                                                    sub_prop_data["es_relacion"] = True
                                instance_dict[sub_prop] = sub_prop_data
                            props_dict[prop_type] = {"instancias": [instance_dict], "es_anidada": True}
                    else:
                        # Propiedad simple
                        prop_data: dict[str, object] = {"valor": prop_value, "evidencias": []}
                        if name in properties_evidences_map and prop_type in properties_evidences_map[name]:
                            prop_evidences = properties_evidences_map[name][prop_type]
                            if isinstance(prop_evidences, list):
                                prop_data["evidencias"] = prop_evidences
                        props_dict[prop_type] = prop_data
                entity_data["propiedades"] = props_dict

            if name in entity_relations and entity_relations[name]:
                # Filtrar relaciones que corresponden a propiedades anidadas (igual que en Markdown)
                for rel_type, targets in sorted(entity_relations[name].items()):
                    skip_rel_type = _is_subproperty_of_nested_level2(
                        rel_type, ent_type, domain_structure
                    )
                    for target in sorted(targets):
                        rel_key = (rel_type, name, target)
                        if rel_key in nested_property_relations or skip_rel_type:
                            continue
                        rel_data: dict[str, object] = {
                            "tipo": rel_type,
                            "destino": target,
                            "evidencias": [],
                        }
                        if (
                            name in relation_evidences_map
                            and rel_type in relation_evidences_map[name]
                            and target in relation_evidences_map[name][rel_type]
                        ):
                            rel_data["evidencias"] = relation_evidences_map[name][rel_type][target]
                        entity_data["relaciones"].append(rel_data)

            result["tipos"][ent_type].append(entity_data)

    return result
