"""GraphML exporter."""

from __future__ import annotations

import json as json_module
import xml.etree.ElementTree as ET

from ontology_explorer.domain.normalize import load_domain_spec
from ontology_explorer.exporters.ontology_export import build_entity_relations_map


def generate_graph_graphml(
    entities: list[list],
    relations: list[list],
    domain_name: str | None = None,
    config_dir: str | None = None,
) -> str:
    """
    Genera grafo en formato GraphML con nodos y aristas, incluyendo evidencias.
    
    Args:
        entities: Lista de entidades
        relations: Lista de relaciones
        domain_name: Nombre del dominio a usar (sin extensión .md). Si es None, usa el dominio por defecto.
        config_dir: Ruta al directorio de configuración. Si es None, usa el directorio por defecto.
    """
    domain_spec = load_domain_spec(domain_name, config_dir)
    domain_structure = domain_spec.domain_structure
    _, properties_map, _, relation_evidences_map, _, _ = build_entity_relations_map(
        entities, relations, domain_structure, domain_spec=domain_spec
    )

    all_properties = set()
    for props in properties_map.values():
        all_properties.update(props.keys())

    graphml = ET.Element("graphml", xmlns="http://graphml.graphdrawing.org/xmlns")
    graphml.set("xmlns:xsi", "http://www.w3.org/2001/XMLSchema-instance")
    graphml.set(
        "xsi:schemaLocation",
        "http://graphml.graphdrawing.org/xmlns "
        "http://graphml.graphdrawing.org/xmlns/1.0/graphml.xsd",
    )

    key_node_id = ET.SubElement(graphml, "key", id="d0")
    key_node_id.set("for", "node")
    key_node_id.set("attr.name", "tipo")
    key_node_id.set("attr.type", "string")

    key_node_name = ET.SubElement(graphml, "key", id="d1")
    key_node_name.set("for", "node")
    key_node_name.set("attr.name", "nombre")
    key_node_name.set("attr.type", "string")

    key_node_evidences = ET.SubElement(graphml, "key", id="d2")
    key_node_evidences.set("for", "node")
    key_node_evidences.set("attr.name", "evidencias")
    key_node_evidences.set("attr.type", "string")

    prop_key_map: dict[str, str] = {}
    key_counter = 3
    for prop in sorted(all_properties):
        key_id = f"d{key_counter}"
        prop_key_map[prop] = key_id
        key_prop = ET.SubElement(graphml, "key", id=key_id)
        key_prop.set("for", "node")
        key_prop.set("attr.name", prop)
        key_prop.set("attr.type", "string")
        key_counter += 1

    key_edge_type = ET.SubElement(graphml, "key", id=f"d{key_counter}")
    key_edge_type.set("for", "edge")
    key_edge_type.set("attr.name", "tipo")
    key_edge_type.set("attr.type", "string")
    key_counter += 1

    key_edge_evidences = ET.SubElement(graphml, "key", id=f"d{key_counter}")
    key_edge_evidences.set("for", "edge")
    key_edge_evidences.set("attr.name", "evidencias")
    key_edge_evidences.set("attr.type", "string")

    graph = ET.SubElement(graphml, "graph", id="G", edgedefault="directed")

    entity_ids: dict[str, str] = {}
    node_id_counter = 0

    for ent in entities:
        if not isinstance(ent, list) or len(ent) < 2:
            continue

        name = ent[0]
        ent_type = ent[1]
        evidences = ent[2] if len(ent) > 2 else []

        if name not in entity_ids:
            node_id = f"n{node_id_counter}"
            node_id_counter += 1
            entity_ids[name] = node_id

            node = ET.SubElement(graph, "node", id=node_id)

            data_type = ET.SubElement(node, "data", key="d0")
            data_type.text = ent_type

            data_name = ET.SubElement(node, "data", key="d1")
            data_name.text = name

            if evidences:
                data_evidences = ET.SubElement(node, "data", key="d2")
                data_evidences.text = json_module.dumps(evidences, ensure_ascii=False)

            for prop_name, prop_value in properties_map.get(name, {}).items():
                prop_key = prop_key_map.get(prop_name)
                if prop_key:
                    data_prop = ET.SubElement(node, "data", key=prop_key)
                    data_prop.text = str(prop_value)

    edge_id_counter = 0
    for rel in relations:
        if not isinstance(rel, list) or len(rel) < 3:
            continue

        rel_type, source, target = rel[0], rel[1], rel[2]

        if source not in entity_ids or target not in entity_ids:
            continue

        edge = ET.SubElement(
            graph,
            "edge",
            id=f"e{edge_id_counter}",
            source=entity_ids[source],
            target=entity_ids[target],
        )
        edge_id_counter += 1

        data_type = ET.SubElement(edge, "data", key=f"d{key_counter - 1}")
        data_type.text = rel_type

        if (
            source in relation_evidences_map
            and rel_type in relation_evidences_map[source]
            and target in relation_evidences_map[source][rel_type]
        ):
            rel_evidences = relation_evidences_map[source][rel_type][target]
            if rel_evidences:
                data_evidences = ET.SubElement(edge, "data", key=f"d{key_counter}")
                data_evidences.text = json_module.dumps(rel_evidences, ensure_ascii=False)

    ET.indent(graphml, space="  ")
    xml_str = ET.tostring(graphml, encoding="unicode", xml_declaration=True)
    return xml_str
