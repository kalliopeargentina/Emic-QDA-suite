"""Shared CLI utilities: console encoding, path normalization, sanitization."""

import os
import re
import sys
from typing import Optional

_encoding_setup_done = False


def setup_console_encoding() -> None:
    """Fix Windows console encoding to support Unicode. Idempotent."""
    global _encoding_setup_done
    if _encoding_setup_done:
        return
    if sys.platform == "win32":
        try:
            if hasattr(sys.stdout, "reconfigure"):
                sys.stdout.reconfigure(encoding="utf-8", errors="replace")
            if hasattr(sys.stderr, "reconfigure"):
                sys.stderr.reconfigure(encoding="utf-8", errors="replace")
        except (AttributeError, ValueError):
            import io
            sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
            sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding="utf-8", errors="replace")
    _encoding_setup_done = True


def safe_print(*args, **kwargs) -> None:
    """Print that handles encoding errors (e.g. Windows console)."""
    try:
        print(*args, **kwargs)
    except UnicodeEncodeError:
        safe_args = []
        for arg in args:
            if isinstance(arg, str):
                safe_args.append(arg.encode("ascii", errors="replace").decode("ascii"))
            else:
                safe_args.append(str(arg).encode("ascii", errors="replace").decode("ascii"))
        print(*safe_args, **kwargs)


def fix_path(path_str: str) -> str:
    """Normalize path: remove backticks (Obsidian), fix separators and Windows drive."""
    if not path_str or not path_str.strip():
        return path_str
    path = str(path_str).replace("`", "").replace("/", os.sep)
    if os.name == "nt":
        try:
            match = re.match(r"^[\\/]*([A-Za-z]):[\\/]", path)
            if match:
                path = f"{match.group(1)}:{os.sep}" + path[match.end():]
        except re.error:
            if len(path) >= 2 and path[1] == ":":
                path = path[1:]
    while os.sep * 2 in path:
        path = path.replace(os.sep * 2, os.sep)
    path = path.replace("/", os.sep).replace("\\", os.sep)
    while os.sep * 2 in path:
        path = path.replace(os.sep * 2, os.sep)
    return path


def sanitize_name(name: str) -> str:
    """Sanitize filename by removing invalid characters."""
    if not name:
        return name
    invalid_chars = '<>:"|?*\\'
    for char in invalid_chars:
        name = name.replace(char, "_")
    name = "".join(c for c in name if ord(c) >= 32 or c in "\n\r\t")
    return name.strip()


def sanitize_text(text: str) -> str:
    """Remove zero-width and quote-like characters from text."""
    if not text:
        return text
    text = re.sub(r"[\u200B-\u200D\uFEFF]", "", text)
    for char in ["`", "\u2018", "\u2019", "\u00B4", "\u2032", "\u201C", "\u201D", "\u201E"]:
        text = text.replace(char, "")
    s = text.strip()
    return s if s else ""


def get_optional_param(value: Optional[str]) -> Optional[str]:
    """Return stripped value or None if empty/whitespace."""
    if value is None:
        return None
    if isinstance(value, str):
        cleaned = value.strip()
        return cleaned if cleaned else None
    return str(value).strip() or None


def output_path_relative_to_vault(output_raw: str, vault: str) -> str:
    """
    Resolve output path so it always lies inside the vault.
    If output is absolute and already under vault, return as-is.
    If output is absolute and outside vault, strip drive/root and join with vault.
    If output is relative, join directly with vault.
    """
    output_fixed = fix_path(output_raw)
    vault_norm = os.path.normpath(vault)
    if os.path.isabs(output_fixed):
        try:
            if os.path.commonpath([vault_norm, output_fixed]) == vault_norm:
                return os.path.normpath(output_fixed)
        except ValueError:
            pass
        if os.name == "nt":
            output_relative = re.sub(r"^[A-Za-z]:[\\/]*", "", output_fixed)
        else:
            output_relative = output_fixed.lstrip(os.sep)
        return os.path.normpath(os.path.join(vault, output_relative))
    return os.path.normpath(os.path.join(vault, output_fixed))
