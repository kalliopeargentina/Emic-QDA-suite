"""User-facing messages for local transcription dependency issues (no heavy imports)."""

TORCHAUDIO_COMPAT_ERROR = (
    "Error: Las dependencias de transcripción local no son compatibles.\n"
    "Actualice Obsidian QDA Suite a la versión 0.1.9 o superior, por ejemplo:\n"
    '  pip install --upgrade "obsidian-qda-suite>=0.1.9"\n'
    "Si usa el complemento de Obsidian, use la opción para actualizar o reinstalar dependencias."
)


def format_transcription_error(exc: BaseException) -> str:
    msg = str(exc)
    if "AudioMetaData" in msg or "list_audio_backends" in msg:
        return TORCHAUDIO_COMPAT_ERROR
    if "k2_fsa" in msg and "Lazy import" in msg:
        return (
            "Error: Falló la carga del detector de voz (SpeechBrain en Windows).\n"
            "Actualice Obsidian QDA Suite e reinstale dependencias:\n"
            '  pip install --upgrade --force-reinstall "obsidian-qda-suite>=0.1.9"\n'
            "Si el error continúa, reporte el problema con la versión instalada."
        )
    return f"Error during transcription: {msg}"
