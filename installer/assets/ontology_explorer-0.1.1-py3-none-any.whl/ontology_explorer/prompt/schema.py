"""JSON schema helpers for structured outputs."""

from __future__ import annotations


def build_extraction_schema() -> dict:
    """Schema for entities/relations extraction output."""
    evidence_schema = {
        "type": "object",
        "properties": {
            "document": {"type": "string"},
            "sentence": {"type": "string"},
        },
        "required": ["document", "sentence"],
        "additionalProperties": True,
    }
    evidence_or_array = {
        "oneOf": [
            evidence_schema,
            {"type": "array", "items": evidence_schema},
        ]
    }

    entity_item = {
        "type": "array",
        "minItems": 3,
        "maxItems": 3,
        "items": [
            {"type": "string"},
            {"type": "string"},
            evidence_or_array,
        ],
    }
    relation_item = {
        "type": "array",
        "minItems": 4,
        "maxItems": 4,
        "items": [
            {"type": "string"},
            {"type": "string"},
            {"type": "string"},
            evidence_or_array,
        ],
    }
    property_item = {
        "type": "array",
        "minItems": 4,
        "maxItems": 4,
        "items": [
            {"type": "string"},
            {"type": "string"},
            {"type": "string"},
            evidence_or_array,
        ],
    }

    return {
        "type": "object",
        "properties": {
            "model": {"type": "string"},
            "entities": {"type": "array", "items": entity_item},
            "properties": {"type": "array", "items": property_item},
            "relations": {"type": "array", "items": relation_item},
        },
        "required": ["model", "entities", "relations"],
        "additionalProperties": False,
    }
