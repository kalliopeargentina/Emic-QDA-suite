"""RDF exporters (TTL, RDF/XML, JSON-LD) from entities and relations."""

from __future__ import annotations

import json
import re

try:
    import rdflib
    from rdflib import Literal, Namespace, URIRef
    from rdflib.namespace import RDF, RDFS, XSD

    RDFLIB_AVAILABLE = True
except ImportError:
    RDFLIB_AVAILABLE = False

from ontology_explorer.domain.normalize import load_domain_spec
from ontology_explorer.exporters.ontology_export import build_entity_relations_map


def _slug(name: str) -> str:
    """Normaliza nombres para URIs: espacios -> _, caracteres no válidos removidos."""
    s = str(name).strip()
    s = re.sub(r"\s+", "_", s)
    s = re.sub(r'[<>"{}|\\^`]', "", s)
    s = re.sub(r"[^\w\-_.]", "_", s, flags=re.ASCII)
    return s or "unknown"


def _base_uri(domain_name: str | None) -> str:
    """Base URI para el grafo."""
    d = (domain_name or "default").strip() or "default"
    return f"http://example.org/ontology/{_slug(d)}/"


def _build_rdf_graph(
    entities: list[list],
    relations: list[list],
    domain_name: str | None = None,
    config_dir: str | None = None,
) -> "rdflib.Graph":
    """Construye un grafo RDF desde entidades, relaciones y properties_map."""
    if not RDFLIB_AVAILABLE:
        raise ImportError("rdflib no está instalado. Instálalo con: pip install rdflib")

    domain_spec = load_domain_spec(domain_name, config_dir)
    domain_structure = domain_spec.domain_structure
    (
        _,
        properties_map,
        entity_evidences_map,
        relation_evidences_map,
        _,
        nested_property_relations,
    ) = build_entity_relations_map(
        entities, relations, domain_structure, domain_spec=domain_spec
    )

    base = _base_uri(domain_name)
    ex = Namespace(base)
    graph = rdflib.Graph()
    graph.bind("ex", ex)
    graph.bind("rdf", RDF)
    graph.bind("rdfs", RDFS)

    entity_names: set[str] = set()
    entity_uris: dict[str, URIRef] = {}
    entity_meta: dict[str, tuple[str, list]] = {}

    for ent in entities:
        if not isinstance(ent, list) or len(ent) < 2:
            continue
        name = ent[0]
        ent_type = ent[1]
        evidences = ent[2] if len(ent) > 2 else []
        if not isinstance(evidences, list):
            evidences = []

        if name not in entity_uris:
            entity_names.add(name)
            entity_uris[name] = ex["entity/" + _slug(name)]
            entity_meta[name] = (ent_type, evidences)

    for name, uri in entity_uris.items():
        ent_type, evidences = entity_meta[name]
        graph.add((uri, RDF.type, ex["class/" + _slug(ent_type)]))
        graph.add((uri, RDFS.label, Literal(name, lang="es")))
        if evidences:
            ev_json = json.dumps(evidences, ensure_ascii=False)
            graph.add((uri, ex["evidence"], Literal(ev_json, datatype=XSD.string)))

    def _add_property_object(
        subj: "rdflib.term.Node",
        pred: "rdflib.term.URIRef",
        val: str | dict | list,
    ) -> None:
        if isinstance(val, str) and val in entity_names:
            graph.add((subj, pred, entity_uris[val]))
        elif isinstance(val, (dict, list)):
            graph.add((
                subj, pred,
                Literal(json.dumps(val, ensure_ascii=False), datatype=XSD.string),
            ))
        else:
            graph.add((subj, pred, Literal(str(val), lang="es")))

    for name, uri in entity_uris.items():
        for prop_name, prop_value in properties_map.get(name, {}).items():
            pred = ex["property/" + _slug(prop_name)]
            if isinstance(prop_value, list) and prop_value and all(
                isinstance(x, dict) for x in prop_value
            ):
                for instance in prop_value:
                    b = rdflib.BNode()
                    graph.add((uri, pred, b))
                    for k, v in instance.items():
                        if k.startswith("_"):
                            continue
                        subpred = ex["property/" + _slug(k)]
                        _add_property_object(b, subpred, v)
            elif isinstance(prop_value, dict):
                b = rdflib.BNode()
                graph.add((uri, pred, b))
                for k, v in prop_value.items():
                    if k.startswith("_"):
                        continue
                    subpred = ex["property/" + _slug(k)]
                    _add_property_object(b, subpred, v)
            elif isinstance(prop_value, str) and prop_value in entity_names:
                graph.add((uri, pred, entity_uris[prop_value]))
            elif isinstance(prop_value, list):
                graph.add((
                    uri, pred,
                    Literal(json.dumps(prop_value, ensure_ascii=False), datatype=XSD.string),
                ))
            else:
                graph.add((uri, pred, Literal(str(prop_value), lang="es")))

    _nested = nested_property_relations if nested_property_relations is not None else set()

    for rel in relations:
        if not isinstance(rel, list) or len(rel) < 3:
            continue
        rel_type, source, target = rel[0], rel[1], rel[2]
        if (rel_type, source, target) in _nested:
            continue
        evidences = rel[3] if len(rel) > 3 else []
        if not isinstance(evidences, list):
            evidences = []

        if source not in entity_uris:
            continue

        subj = entity_uris[source]
        pred = ex["relation/" + _slug(rel_type)]

        if target in entity_uris:
            obj = entity_uris[target]
        else:
            obj = Literal(target, lang="es")

        graph.add((subj, pred, obj))
        if evidences:
            ev_json = json.dumps(evidences, ensure_ascii=False)
            bnode = rdflib.BNode()
            graph.remove((subj, pred, obj))
            graph.add((subj, pred, bnode))
            graph.add((bnode, RDF.value, obj))
            graph.add((bnode, ex["evidence"], Literal(ev_json, datatype=XSD.string)))

    return graph


def _serialize_graph(graph: "rdflib.Graph", fmt: str) -> str:
    out = graph.serialize(format=fmt, encoding="utf-8")
    return out.decode("utf-8") if isinstance(out, bytes) else out


def generate_graph_ttl(
    entities: list[list],
    relations: list[list],
    domain_name: str | None = None,
    config_dir: str | None = None,
) -> str:
    """
    Genera RDF en formato Turtle (TTL) desde entidades y relaciones.

    Args:
        entities: Lista de entidades [nombre, tipo, evidencias?]
        relations: Lista de relaciones [tipo, origen, destino, evidencias?]
        domain_name: Nombre del dominio (sin .md). None = por defecto.
        config_dir: Directorio de configuración. None = por defecto.

    Returns:
        Contenido Turtle como string UTF-8.
    """
    g = _build_rdf_graph(entities, relations, domain_name, config_dir)
    return _serialize_graph(g, "turtle")


def generate_graph_rdf(
    entities: list[list],
    relations: list[list],
    domain_name: str | None = None,
    config_dir: str | None = None,
) -> str:
    """
    Genera RDF en formato RDF/XML desde entidades y relaciones.

    Args:
        entities: Lista de entidades [nombre, tipo, evidencias?]
        relations: Lista de relaciones [tipo, origen, destino, evidencias?]
        domain_name: Nombre del dominio (sin .md). None = por defecto.
        config_dir: Directorio de configuración. None = por defecto.

    Returns:
        Contenido RDF/XML como string UTF-8.
    """
    g = _build_rdf_graph(entities, relations, domain_name, config_dir)
    return _serialize_graph(g, "xml")


def generate_graph_jsonld(
    entities: list[list],
    relations: list[list],
    domain_name: str | None = None,
    config_dir: str | None = None,
) -> str:
    """
    Genera RDF en formato JSON-LD desde entidades y relaciones.

    Args:
        entities: Lista de entidades [nombre, tipo, evidencias?]
        relations: Lista de relaciones [tipo, origen, destino, evidencias?]
        domain_name: Nombre del dominio (sin .md). None = por defecto.
        config_dir: Directorio de configuración. None = por defecto.

    Returns:
        Contenido JSON-LD como string UTF-8.
    """
    g = _build_rdf_graph(entities, relations, domain_name, config_dir)
    return _serialize_graph(g, "json-ld")
