"""
Visualization functions for sentiment and emotion analysis.
"""

from pathlib import Path
from typing import Dict, Any, Optional, List
import re
import numpy as np
from .algorithms.base import normalize_sentiment_label

# Try to import matplotlib
try:
    import matplotlib
    matplotlib.use('Agg')  # Non-interactive backend
    import matplotlib.pyplot as plt
    HAS_MATPLOTLIB = True
    
    try:
        import seaborn as sns
        HAS_SEABORN = True
        try:
            plt.style.use('seaborn-v0_8-whitegrid')
        except OSError:
            try:
                plt.style.use('seaborn-whitegrid')
            except OSError:
                plt.style.use('default')
                plt.rcParams['axes.grid'] = True
                plt.rcParams['axes.grid.alpha'] = 0.3
        if HAS_SEABORN:
            try:
                sns.set_palette("husl")
            except:
                pass
    except ImportError:
        HAS_SEABORN = False
        plt.style.use('default')
        plt.rcParams['axes.grid'] = True
        plt.rcParams['axes.grid.alpha'] = 0.3
except ImportError:
    HAS_MATPLOTLIB = False
    HAS_SEABORN = False

# Try to import wordcloud
try:
    from wordcloud import WordCloud
    HAS_WORDCLOUD = True
except ImportError:
    HAS_WORDCLOUD = False

# Try to import plotly for Sankey diagrams
try:
    import plotly.graph_objects as go
    HAS_PLOTLY = True
except ImportError:
    HAS_PLOTLY = False

# Try to import kaleido for static image export
try:
    import kaleido
    HAS_KALEIDO = True
except ImportError:
    HAS_KALEIDO = False

# Try to import nltk for text processing
try:
    import nltk
    from nltk.corpus import stopwords
    from nltk.tokenize import word_tokenize
    try:
        nltk.data.find('tokenizers/punkt')
    except LookupError:
        try:
            nltk.download('punkt', quiet=True)
        except:
            pass
    try:
        nltk.data.find('corpora/stopwords')
    except LookupError:
        try:
            nltk.download('stopwords', quiet=True)
        except:
            pass
    HAS_NLTK = True
except ImportError:
    HAS_NLTK = False


def _tokenize_and_clean(text: str, lang: str = "spanish") -> List[str]:
    """Tokenize and clean text, removing stopwords and short words."""
    if not HAS_NLTK:
        # Fallback: simple word extraction
        words = re.findall(r'\b[a-záéíóúñü]{3,}\b', text.lower())
        return words
    
    try:
        # Get stopwords for the language
        lang_map = {"spanish": "spanish", "english": "english", "es": "spanish", "en": "english"}
        stop_lang = lang_map.get(lang.lower(), "spanish")
        try:
            stop_words = set(stopwords.words(stop_lang))
        except:
            stop_words = set(stopwords.words("spanish"))
        
        # Tokenize
        tokens = word_tokenize(text.lower())
        
        # Filter: remove stopwords, punctuation, short words
        words = [w for w in tokens if w.isalpha() and len(w) >= 3 and w not in stop_words]
        return words
    except Exception:
        # Fallback
        words = re.findall(r'\b[a-záéíóúñü]{3,}\b', text.lower())
        return words


def create_sentiment_wordclouds(paragraphs_by_label: Dict[str, List[str]], output_dir: Path, lang: str = "spanish") -> Dict[str, Optional[Path]]:
    """
    Create word clouds for each sentiment category with intelligent filtering.
    
    This function filters words to show only those that are most relevant to each sentiment:
    - Words that appear in multiple sentiment categories are filtered out or downweighted
    - Words are weighted by their specificity to each sentiment (TF-IDF-like approach)
    - Only the most sentiment-specific words are included in each word cloud
    
    Args:
        paragraphs_by_label: Dictionary mapping sentiment labels (POS/NEG/NEU) to lists of paragraph texts
        output_dir: Directory where to save the word cloud images
        lang: Language for stopwords filtering
    
    Returns:
        Dictionary mapping labels to paths of saved images, or None if failed
    """
    if not HAS_WORDCLOUD:
        return {label: None for label in paragraphs_by_label.keys()}
    
    # Color mapping for sentiments
    color_funcs = {
        "POS": lambda word, font_size, position, orientation, random_state=None, **kwargs: "#388e3c",  # Green
        "NEG": lambda word, font_size, position, orientation, random_state=None, **kwargs: "#d32f2f",  # Red
        "NEU": lambda word, font_size, position, orientation, random_state=None, **kwargs: "#757575",  # Gray
        "positive": lambda word, font_size, position, orientation, random_state=None, **kwargs: "#388e3c",
        "negative": lambda word, font_size, position, orientation, random_state=None, **kwargs: "#d32f2f",
        "neutral": lambda word, font_size, position, orientation, random_state=None, **kwargs: "#757575",
    }
    
    results = {}
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # Step 1: Calculate word frequencies for each sentiment category
    from collections import Counter, defaultdict
    word_freq_by_label = {}
    all_words_set = set()
    
    for label, paragraphs in paragraphs_by_label.items():
        if not paragraphs:
            continue
        combined_text = " ".join(paragraphs)
        words = _tokenize_and_clean(combined_text, lang)
        word_freq_by_label[label] = Counter(words)
        all_words_set.update(word_freq_by_label[label].keys())
    
    if not word_freq_by_label:
        return {label: None for label in paragraphs_by_label.keys()}
    
    # Step 2: Calculate word specificity scores (similar to TF-IDF)
    # For each word in each label, calculate how specific it is to that label
    word_specificity_scores = defaultdict(dict)
    
    # Total word count per label
    total_words_per_label = {label: sum(freq.values()) for label, freq in word_freq_by_label.items()}
    
    # Number of labels containing each word
    labels_per_word = defaultdict(int)
    for label, word_freq in word_freq_by_label.items():
        for word in word_freq.keys():
            labels_per_word[word] += 1
    
    # Calculate specificity score for each word in each label
    # Score = (frequency in label / total words in label) * log(total_labels / labels_containing_word)
    # Higher score = more specific to this label
    num_labels = len(word_freq_by_label)
    
    for label, word_freq in word_freq_by_label.items():
        total_words = total_words_per_label[label]
        if total_words == 0:
            continue
        
        for word, freq in word_freq.items():
            # Term frequency (normalized)
            tf = freq / total_words
            
            # Inverse document frequency (inverse of how many labels contain this word)
            # If word appears in all labels, idf is low; if only in one, idf is high
            num_labels_with_word = labels_per_word[word]
            if num_labels_with_word > 0:
                idf = np.log(num_labels / num_labels_with_word) if num_labels_with_word > 0 else 0
            else:
                idf = 0
            
            # Specificity score
            specificity = tf * idf
            
            # Additional penalty: if word appears in multiple labels with similar frequencies, reduce score
            if num_labels_with_word > 1:
                # Check if word frequency is similar across labels
                freqs_in_other_labels = [word_freq_by_label[other_label].get(word, 0) / max(total_words_per_label[other_label], 1) 
                                         for other_label in word_freq_by_label.keys() if other_label != label]
                if freqs_in_other_labels:
                    max_other_freq = max(freqs_in_other_labels)
                    current_freq_norm = freq / total_words
                    # If frequencies are similar across labels, this word is not specific
                    if max_other_freq > 0 and abs(current_freq_norm - max_other_freq) / max(current_freq_norm, max_other_freq) < 0.3:
                        specificity *= 0.3  # Heavy penalty for non-specific words
            
            word_specificity_scores[label][word] = specificity
    
    # Step 3: Filter and create word clouds for each label
    for label, paragraphs in paragraphs_by_label.items():
        if not paragraphs or label not in word_specificity_scores:
            results[label] = None
            continue
        
        # Get specificity scores for this label
        specificity_scores = word_specificity_scores[label]
        
        # Filter words:
        # 1. Remove words that appear in all or most labels with similar frequencies
        # 2. Keep only words with positive specificity scores
        # 3. Sort by specificity and take top words
        
        filtered_word_freq = {}
        for word, specificity in specificity_scores.items():
            # Only include words with positive specificity
            if specificity > 0:
                # Get original frequency for weighting
                original_freq = word_freq_by_label[label].get(word, 0)
                # Weight by specificity
                filtered_word_freq[word] = original_freq * (1 + specificity)
        
        if not filtered_word_freq:
            results[label] = None
            continue
        
        # Normalize label for color function
        label_norm = label.upper() if label.upper() in ("POS", "NEG", "NEU") else label.lower()
        color_func = color_funcs.get(label_norm, lambda *args, **kwargs: "#2196f3")
        
        # Create word cloud
        try:
            wc = WordCloud(
                width=800,
                height=400,
                background_color='white',
                max_words=100,
                color_func=color_func,
                relative_scaling=0.5,
                colormap=None
            ).generate_from_frequencies(filtered_word_freq)
            
            # Save
            output_path = output_dir / f"wordcloud_{label.lower()}.png"
            wc.to_file(str(output_path))
            results[label] = output_path
        except Exception as e:
            results[label] = None
    
    return results


def create_emotion_wordclouds(paragraphs_by_emotion: Dict[str, List[str]], output_dir: Path, lang: str = "spanish") -> Dict[str, Optional[Path]]:
    """
    Create word clouds for each emotion category with intelligent filtering.
    
    This function filters words to show only those that are most relevant to each emotion:
    - Words that appear in multiple emotion categories are filtered out or downweighted
    - Words are weighted by their specificity to each emotion (TF-IDF-like approach)
    - Only the most emotion-specific words are included in each word cloud
    
    Args:
        paragraphs_by_emotion: Dictionary mapping emotion labels to lists of paragraph texts
        output_dir: Directory where to save the word cloud images
        lang: Language for stopwords filtering
    
    Returns:
        Dictionary mapping emotion labels to paths of saved images, or None if failed
    """
    if not HAS_WORDCLOUD:
        return {emotion: None for emotion in paragraphs_by_emotion.keys()}
    
    # Color mapping for emotions
    emotion_colors = {
        "joy": "#fbc02d",
        "sadness": "#1976d2",
        "anger": "#d32f2f",
        "fear": "#7b1fa2",
        "surprise": "#f57c00",
        "disgust": "#388e3c",
        "others": "#757575"
    }
    
    results = {}
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # Step 1: Calculate word frequencies for each emotion category
    from collections import Counter, defaultdict
    word_freq_by_emotion = {}
    
    for emotion, paragraphs in paragraphs_by_emotion.items():
        if not paragraphs:
            continue
        combined_text = " ".join(paragraphs)
        words = _tokenize_and_clean(combined_text, lang)
        word_freq_by_emotion[emotion] = Counter(words)
    
    if not word_freq_by_emotion:
        return {emotion: None for emotion in paragraphs_by_emotion.keys()}
    
    # Step 2: Calculate word specificity scores (similar to TF-IDF)
    word_specificity_scores = defaultdict(dict)
    
    # Total word count per emotion
    total_words_per_emotion = {emotion: sum(freq.values()) for emotion, freq in word_freq_by_emotion.items()}
    
    # Number of emotions containing each word
    emotions_per_word = defaultdict(int)
    for emotion, word_freq in word_freq_by_emotion.items():
        for word in word_freq.keys():
            emotions_per_word[word] += 1
    
    # Calculate specificity score for each word in each emotion
    num_emotions = len(word_freq_by_emotion)
    
    for emotion, word_freq in word_freq_by_emotion.items():
        total_words = total_words_per_emotion[emotion]
        if total_words == 0:
            continue
        
        for word, freq in word_freq.items():
            # Term frequency (normalized)
            tf = freq / total_words
            
            # Inverse document frequency
            num_emotions_with_word = emotions_per_word[word]
            if num_emotions_with_word > 0:
                idf = np.log(num_emotions / num_emotions_with_word) if num_emotions_with_word > 0 else 0
            else:
                idf = 0
            
            # Specificity score
            specificity = tf * idf
            
            # Additional penalty: if word appears in multiple emotions with similar frequencies, reduce score
            if num_emotions_with_word > 1:
                freqs_in_other_emotions = [word_freq_by_emotion[other_emotion].get(word, 0) / max(total_words_per_emotion[other_emotion], 1) 
                                          for other_emotion in word_freq_by_emotion.keys() if other_emotion != emotion]
                if freqs_in_other_emotions:
                    max_other_freq = max(freqs_in_other_emotions)
                    current_freq_norm = freq / total_words
                    # If frequencies are similar across emotions, this word is not specific
                    if max_other_freq > 0 and abs(current_freq_norm - max_other_freq) / max(current_freq_norm, max_other_freq) < 0.3:
                        specificity *= 0.3  # Heavy penalty for non-specific words
            
            word_specificity_scores[emotion][word] = specificity
    
    # Step 3: Filter and create word clouds for each emotion
    for emotion, paragraphs in paragraphs_by_emotion.items():
        if not paragraphs or emotion not in word_specificity_scores:
            results[emotion] = None
            continue
        
        # Get specificity scores for this emotion
        specificity_scores = word_specificity_scores[emotion]
        
        # Filter words: only include words with positive specificity
        filtered_word_freq = {}
        for word, specificity in specificity_scores.items():
            if specificity > 0:
                original_freq = word_freq_by_emotion[emotion].get(word, 0)
                # Weight by specificity
                filtered_word_freq[word] = original_freq * (1 + specificity)
        
        if not filtered_word_freq:
            results[emotion] = None
            continue
        
        # Get color for this emotion
        color = emotion_colors.get(emotion.lower(), "#2196f3")
        color_func = lambda word, font_size, position, orientation, random_state=None, **kwargs: color
        
        # Create word cloud
        try:
            wc = WordCloud(
                width=800,
                height=400,
                background_color='white',
                max_words=100,
                color_func=color_func,
                relative_scaling=0.5,
                colormap=None
            ).generate_from_frequencies(filtered_word_freq)
            
            # Save
            output_path = output_dir / f"wordcloud_{emotion.lower()}.png"
            wc.to_file(str(output_path))
            results[emotion] = output_path
        except Exception as e:
            results[emotion] = None
    
    return results


def create_sentiment_bar_chart(scores: Dict[str, float], output_path: Path, title: str = "Distribución de Sentimientos") -> Optional[Path]:
    """
    Create a bar chart showing sentiment distribution (POS/NEG/NEU).
    
    Args:
        scores: Dictionary with sentiment labels as keys and scores as values
        output_path: Path where to save the chart image
        title: Chart title
    
    Returns:
        Path to saved image or None if failed
    """
    if not HAS_MATPLOTLIB:
        return None
    if not scores:
        return None
    
    # Normalize labels
    normalized_scores = {}
    for k, v in scores.items():
        normalized_key = normalize_sentiment_label(k)
        normalized_scores[normalized_key] = float(v)
    
    # Order: NEG, NEU, POS
    ordered_labels = ["NEG", "NEU", "POS"]
    labels = [lab for lab in ordered_labels if lab in normalized_scores]
    values = [normalized_scores[lab] for lab in labels]
    
    if not labels:
        return None
    
    # Create figure
    fig, ax = plt.subplots(figsize=(8, 6))
    
    # Color mapping
    colors = {"NEG": "#d32f2f", "NEU": "#757575", "POS": "#388e3c"}
    bar_colors = [colors.get(lab, "#2196f3") for lab in labels]
    
    # Create bar chart
    bars = ax.bar(labels, values, color=bar_colors, alpha=0.7, edgecolor='black', linewidth=1.2)
    
    # Add value labels on bars
    for bar, val in zip(bars, values):
        height = bar.get_height()
        ax.text(bar.get_x() + bar.get_width()/2., height,
                f'{val:.3f}',
                ha='center', va='bottom', fontsize=11, fontweight='bold')
    
    # Customize chart
    ax.set_ylabel('Proporción', fontsize=12, fontweight='bold')
    ax.set_xlabel('Sentimiento', fontsize=12, fontweight='bold')
    ax.set_title(title, fontsize=14, fontweight='bold', pad=20)
    ax.set_ylim(0, max(values) * 1.15 if values else 1.0)
    ax.grid(axis='y', alpha=0.3, linestyle='--')
    
    plt.tight_layout()
    
    # Save
    output_path.parent.mkdir(parents=True, exist_ok=True)
    try:
        plt.savefig(output_path, dpi=150, bbox_inches='tight', facecolor='white')
        plt.close(fig)
        return output_path
    except Exception as e:
        plt.close(fig)
        return None


def create_emotion_bar_chart(scores: Dict[str, float], output_path: Path, title: str = "Distribución de Emociones") -> Optional[Path]:
    """
    Create a bar chart showing emotion distribution.
    
    Args:
        scores: Dictionary with emotion labels as keys and scores as values
        output_path: Path where to save the chart image
        title: Chart title
    
    Returns:
        Path to saved image or None if failed
    """
    if not HAS_MATPLOTLIB:
        return None
    if not scores:
        return None
    
    # Sort by value descending
    sorted_items = sorted(scores.items(), key=lambda x: x[1], reverse=True)
    labels = [k for k, v in sorted_items]
    values = [float(v) for k, v in sorted_items]
    
    if not labels:
        return None
    
    # Create figure
    fig, ax = plt.subplots(figsize=(10, 6))
    
    # Color palette for emotions
    emotion_colors = {
        "joy": "#fbc02d",
        "sadness": "#1976d2",
        "anger": "#d32f2f",
        "fear": "#7b1fa2",
        "surprise": "#f57c00",
        "disgust": "#388e3c",
        "others": "#757575"
    }
    bar_colors = [emotion_colors.get(lab.lower(), "#2196f3") for lab in labels]
    
    # Create bar chart
    bars = ax.barh(labels, values, color=bar_colors, alpha=0.7, edgecolor='black', linewidth=1.2)
    
    # Add value labels on bars
    for bar, val in zip(bars, values):
        width = bar.get_width()
        ax.text(width, bar.get_y() + bar.get_height()/2.,
                f' {val:.3f}',
                ha='left', va='center', fontsize=10, fontweight='bold')
    
    # Customize chart
    ax.set_xlabel('Proporción', fontsize=12, fontweight='bold')
    ax.set_ylabel('Emoción', fontsize=12, fontweight='bold')
    ax.set_title(title, fontsize=14, fontweight='bold', pad=20)
    ax.set_xlim(0, max(values) * 1.15 if values else 1.0)
    ax.grid(axis='x', alpha=0.3, linestyle='--')
    
    plt.tight_layout()
    
    # Save
    output_path.parent.mkdir(parents=True, exist_ok=True)
    try:
        plt.savefig(output_path, dpi=150, bbox_inches='tight', facecolor='white')
        plt.close(fig)
        return output_path
    except Exception as e:
        plt.close(fig)
        return None


def create_emotion_radar_chart(scores: Dict[str, float], output_path: Path, title: str = "Radar de Emociones") -> Optional[Path]:
    """
    Create a radar/spider chart showing emotion distribution.
    
    Args:
        scores: Dictionary with emotion labels as keys and scores as values
        output_path: Path where to save the chart image
        title: Chart title
    
    Returns:
        Path to saved image or None if failed
    """
    if not HAS_MATPLOTLIB:
        return None
    if not scores:
        return None
    
    # Always use the same order for comparability between documents
    # Order: joy, sadness, anger, fear, surprise, disgust, others
    ordered_emotions = ["joy", "sadness", "anger", "fear", "surprise", "disgust", "others"]
    
    # Get all unique emotions from scores and add any missing ones from ordered list
    all_emotions = set(scores.keys())
    all_emotions.update(ordered_emotions)
    
    # Use ordered emotions, but include any additional emotions found in scores
    labels = ordered_emotions.copy()
    # Add any emotions from scores that aren't in the ordered list (at the end)
    for emotion in sorted(all_emotions):
        if emotion not in labels:
            labels.append(emotion)
    
    # Get values for each label (0.0 if not present)
    values = [float(scores.get(lab, 0.0)) for lab in labels]
    
    # Number of variables
    N = len(labels)
    
    if N == 0:
        return None
    
    # Compute angle for each axis
    angles = [n / float(N) * 2 * np.pi for n in range(N)]
    angles += angles[:1]  # Complete the circle
    
    # Add the first value at the end to close the polygon
    values += values[:1]
    
    # Create figure with polar projection
    fig, ax = plt.subplots(figsize=(10, 10), subplot_kw=dict(projection='polar'))
    
    # Plot the data
    ax.plot(angles, values, 'o-', linewidth=2, color='#2196f3', label='Emociones')
    ax.fill(angles, values, alpha=0.25, color='#2196f3')
    
    # Add labels for each axis
    ax.set_xticks(angles[:-1])
    ax.set_xticklabels(labels, fontsize=11, fontweight='bold')
    
    # Color mapping for emotions
    emotion_colors = {
        "joy": "#fbc02d",
        "sadness": "#1976d2",
        "anger": "#d32f2f",
        "fear": "#7b1fa2",
        "surprise": "#f57c00",
        "disgust": "#388e3c",
        "others": "#757575"
    }
    
    # Add value labels on each axis with emotion-specific colors
    for label, angle, value in zip(labels, angles[:-1], values[:-1]):
        color = emotion_colors.get(label.lower(), "#2196f3")
        # Position label slightly outside the max value
        label_radius = value + 0.05 if value > 0 else 0.1
        ax.text(angle, label_radius, f'{value:.3f}', 
                ha='center', va='center', fontsize=9, fontweight='bold',
                color=color)
    
    # Set y-axis limits (0 to 1 for proportions)
    ax.set_ylim(0, 1.0)
    
    # Add grid
    ax.grid(True, linestyle='--', alpha=0.5)
    
    # Add title
    plt.title(title, size=14, fontweight='bold', pad=20)
    
    plt.tight_layout()
    
    # Save
    output_path.parent.mkdir(parents=True, exist_ok=True)
    try:
        plt.savefig(output_path, dpi=150, bbox_inches='tight', facecolor='white')
        plt.close(fig)
        return output_path
    except Exception as e:
        plt.close(fig)
        return None


def create_sentiment_sankey_diagram(paragraph_labels: List[str], output_path: Path, title: str = "Flujo de Sentimientos a lo Largo del Documento") -> Optional[Path]:
    """
    Create a Sankey diagram showing sentiment flow throughout the document.
    
    Args:
        paragraph_labels: List of sentiment labels for each paragraph in order (e.g., ["POS", "NEU", "NEG", ...])
        output_path: Path where to save the diagram image
        title: Diagram title
    
    Returns:
        Path to saved image or None if failed
    """
    if not HAS_PLOTLY:
        return None
    if not paragraph_labels or len(paragraph_labels) < 2:
        return None
    
    # Normalize labels
    normalized_labels = []
    for lab in paragraph_labels:
        if isinstance(lab, str):
            normalized = normalize_sentiment_label(lab)
            normalized_labels.append(normalized)
        else:
            normalized_labels.append(normalize_sentiment_label(str(lab)))
    
    # Create nodes: each paragraph position + sentiment categories
    # Nodes format: [P1, P2, ..., Pn, POS, NEG, NEU]
    num_paragraphs = len(normalized_labels)
    paragraph_nodes = [f"P{i+1}" for i in range(num_paragraphs)]
    sentiment_nodes = ["POS", "NEG", "NEU"]
    all_nodes = paragraph_nodes + sentiment_nodes
    
    # Create links: from each paragraph to its sentiment
    source = []
    target = []
    value = []
    
    # Map each paragraph to its sentiment
    for i, label in enumerate(normalized_labels):
        if label in sentiment_nodes:
            source.append(i)  # Paragraph index
            target.append(num_paragraphs + sentiment_nodes.index(label))  # Sentiment index
            value.append(1)
    
    # Color mapping
    color_map = {"POS": "#388e3c", "NEG": "#d32f2f", "NEU": "#757575"}
    node_colors = []
    for i in range(num_paragraphs):
        label = normalized_labels[i]
        node_colors.append(color_map.get(label, "#2196f3"))
    for sent in sentiment_nodes:
        node_colors.append(color_map.get(sent, "#2196f3"))
    
    # Create Sankey diagram
    fig = go.Figure(data=[go.Sankey(
        node=dict(
            pad=15,
            thickness=20,
            line=dict(color="black", width=0.5),
            label=all_nodes,
            color=node_colors
        ),
        link=dict(
            source=source,
            target=target,
            value=value,
            color="rgba(33, 150, 243, 0.4)"
        )
    )])
    
    fig.update_layout(
        title_text=title,
        font_size=10,
        height=600
    )
    
    # Save
    output_path.parent.mkdir(parents=True, exist_ok=True)
    try:
        # Try to save as PNG first (static image) - preferred format
        if HAS_KALEIDO:
            try:
                fig.write_image(str(output_path), width=1200, height=600, scale=2)
                return output_path
            except Exception as img_error:
                # If image generation fails, fall back to HTML
                pass
        
        # Fallback to HTML if PNG generation fails or kaleido not available
        html_path = output_path.with_suffix('.html')
        fig.write_html(str(html_path), include_plotlyjs='cdn')
        return html_path
    except Exception as e:
        return None


def create_emotion_sankey_diagram(paragraph_labels: List[str], output_path: Path, title: str = "Flujo de Emociones a lo Largo del Documento") -> Optional[Path]:
    """
    Create a Sankey diagram showing emotion flow throughout the document.
    
    Args:
        paragraph_labels: List of emotion labels for each paragraph in order
        output_path: Path where to save the diagram image
        title: Diagram title
    
    Returns:
        Path to saved image or None if failed
    """
    if not HAS_PLOTLY:
        return None
    if not paragraph_labels or len(paragraph_labels) < 2:
        return None
    
    # Get unique emotions and create nodes
    unique_emotions = sorted(set(paragraph_labels))
    num_paragraphs = len(paragraph_labels)
    paragraph_nodes = [f"P{i+1}" for i in range(num_paragraphs)]
    all_nodes = paragraph_nodes + unique_emotions
    
    # Create links: from each paragraph to its emotion
    source = []
    target = []
    value = []
    
    emotion_colors = {
        "joy": "#fbc02d",
        "sadness": "#1976d2",
        "anger": "#d32f2f",
        "fear": "#7b1fa2",
        "surprise": "#f57c00",
        "disgust": "#388e3c",
        "others": "#757575"
    }
    
    # Map each paragraph to its emotion
    for i, label in enumerate(paragraph_labels):
        if label in unique_emotions:
            source.append(i)  # Paragraph index
            target.append(num_paragraphs + unique_emotions.index(label))  # Emotion index
            value.append(1)
    
    # Color mapping
    node_colors = []
    for i in range(num_paragraphs):
        label = paragraph_labels[i]
        node_colors.append(emotion_colors.get(str(label).lower(), "#2196f3"))
    for emotion in unique_emotions:
        node_colors.append(emotion_colors.get(str(emotion).lower(), "#2196f3"))
    
    # Create Sankey diagram
    fig = go.Figure(data=[go.Sankey(
        node=dict(
            pad=15,
            thickness=20,
            line=dict(color="black", width=0.5),
            label=all_nodes,
            color=node_colors
        ),
        link=dict(
            source=source,
            target=target,
            value=value,
            color="rgba(33, 150, 243, 0.4)"
        )
    )])
    
    fig.update_layout(
        title_text=title,
        font_size=10,
        height=600
    )
    
    # Save
    output_path.parent.mkdir(parents=True, exist_ok=True)
    try:
        # Try to save as PNG first (static image) - preferred format
        if HAS_KALEIDO:
            try:
                fig.write_image(str(output_path), width=1200, height=600, scale=2)
                return output_path
            except Exception as img_error:
                # If image generation fails, fall back to HTML
                pass
        
        # Fallback to HTML if PNG generation fails or kaleido not available
        html_path = output_path.with_suffix('.html')
        fig.write_html(str(html_path), include_plotlyjs='cdn')
        return html_path
    except Exception as e:
        return None


def create_sentiment_heatmap(paragraph_data: List[Dict[str, Any]], output_path: Path, title: str = "Distribución de Sentimientos a lo Largo del Documento") -> Optional[Path]:
    """
    Create a heatmap showing sentiment distribution throughout the document.
    
    Args:
        paragraph_data: List of dicts with keys: 'index' (paragraph number), 'label' (sentiment), 'scores' (dict of scores)
        output_path: Path where to save the heatmap image
        title: Heatmap title
    
    Returns:
        Path to saved image or None if failed
    """
    if not HAS_MATPLOTLIB or not HAS_SEABORN:
        return None
    if not paragraph_data:
        return None
    
    # Normalize labels and extract data
    ordered_labels = ["POS", "NEG", "NEU"]
    
    # Create matrix: rows = paragraphs, columns = sentiments
    num_paragraphs = len(paragraph_data)
    heatmap_data = []
    paragraph_indices = []
    
    for para in paragraph_data:
        idx = para.get('index', 0)
        label = para.get('label', 'NEU')
        scores = para.get('scores', {})
        
        # Normalize label
        if isinstance(label, str):
            normalized_label = normalize_sentiment_label(label)
        else:
            normalized_label = normalize_sentiment_label(str(label))
        
        # Get scores for each sentiment
        row = []
        for sent in ordered_labels:
            if isinstance(scores, dict):
                # Try to find score for this sentiment
                score = scores.get(sent, 0.0)
                if score == 0.0:
                    # Try alternative names
                    for k, v in scores.items():
                        if normalize_sentiment_label(k) == sent:
                            score = float(v)
                            break
                row.append(float(score))
            else:
                row.append(1.0 if sent == normalized_label else 0.0)
        
        heatmap_data.append(row)
        paragraph_indices.append(f"P{idx}")
    
    if not heatmap_data:
        return None
    
    # Create heatmap
    fig, ax = plt.subplots(figsize=(8, max(6, num_paragraphs * 0.3)))
    
    heatmap_array = np.array(heatmap_data)
    sns.heatmap(heatmap_array, 
                xticklabels=ordered_labels,
                yticklabels=paragraph_indices,
                annot=True,
                fmt='.2f',
                cmap='RdYlGn',
                center=0.5,
                vmin=0,
                vmax=1,
                cbar_kws={'label': 'Score'},
                ax=ax)
    
    ax.set_title(title, fontsize=14, fontweight='bold', pad=20)
    ax.set_xlabel('Sentimiento', fontsize=12, fontweight='bold')
    ax.set_ylabel('Párrafo', fontsize=12, fontweight='bold')
    
    plt.tight_layout()
    
    # Save
    output_path.parent.mkdir(parents=True, exist_ok=True)
    try:
        plt.savefig(output_path, dpi=150, bbox_inches='tight', facecolor='white')
        plt.close(fig)
        return output_path
    except Exception as e:
        plt.close(fig)
        return None


def create_emotion_heatmap(paragraph_data: List[Dict[str, Any]], output_path: Path, title: str = "Distribución de Emociones a lo Largo del Documento") -> Optional[Path]:
    """
    Create a heatmap showing emotion distribution throughout the document.
    
    Args:
        paragraph_data: List of dicts with keys: 'index' (paragraph number), 'label' (emotion), 'scores' (dict of scores)
        output_path: Path where to save the heatmap image
        title: Heatmap title
    
    Returns:
        Path to saved image or None if failed
    """
    if not HAS_MATPLOTLIB or not HAS_SEABORN:
        return None
    if not paragraph_data:
        return None
    
    # Get all unique emotions and order them
    ordered_emotions = ["joy", "sadness", "anger", "fear", "surprise", "disgust", "others"]
    all_emotions = set()
    for para in paragraph_data:
        scores = para.get('scores', {})
        if isinstance(scores, dict):
            all_emotions.update(scores.keys())
        label = para.get('label', 'others')
        if isinstance(label, str):
            all_emotions.add(label.lower())
    
    # Use ordered emotions, add any missing ones
    emotion_labels = ordered_emotions.copy()
    for emo in sorted(all_emotions):
        if emo.lower() not in [e.lower() for e in emotion_labels]:
            emotion_labels.append(emo)
    
    # Create matrix: rows = paragraphs, columns = emotions
    num_paragraphs = len(paragraph_data)
    heatmap_data = []
    paragraph_indices = []
    
    for para in paragraph_data:
        idx = para.get('index', 0)
        label = para.get('label', 'others')
        scores = para.get('scores', {})
        
        # Get scores for each emotion
        row = []
        for emotion in emotion_labels:
            if isinstance(scores, dict):
                score = scores.get(emotion, 0.0)
                if score == 0.0:
                    # Try case-insensitive match
                    for k, v in scores.items():
                        if k.lower() == emotion.lower():
                            score = float(v)
                            break
                row.append(float(score))
            else:
                row.append(1.0 if emotion.lower() == str(label).lower() else 0.0)
        
        heatmap_data.append(row)
        paragraph_indices.append(f"P{idx}")
    
    if not heatmap_data:
        return None
    
    # Create heatmap
    fig, ax = plt.subplots(figsize=(max(8, len(emotion_labels) * 0.8), max(6, num_paragraphs * 0.3)))
    
    heatmap_array = np.array(heatmap_data)
    sns.heatmap(heatmap_array, 
                xticklabels=emotion_labels,
                yticklabels=paragraph_indices,
                annot=True,
                fmt='.2f',
                cmap='viridis',
                vmin=0,
                vmax=1,
                cbar_kws={'label': 'Score'},
                ax=ax)
    
    ax.set_title(title, fontsize=14, fontweight='bold', pad=20)
    ax.set_xlabel('Emoción', fontsize=12, fontweight='bold')
    ax.set_ylabel('Párrafo', fontsize=12, fontweight='bold')
    
    plt.tight_layout()
    
    # Save
    output_path.parent.mkdir(parents=True, exist_ok=True)
    try:
        plt.savefig(output_path, dpi=150, bbox_inches='tight', facecolor='white')
        plt.close(fig)
        return output_path
    except Exception as e:
        plt.close(fig)
        return None


def create_corpus_sentiment_heatmap(document_data: List[Dict[str, Any]], output_path: Path, title: str = "Distribución de Sentimientos por Documento") -> Optional[Path]:
    """
    Create a heatmap showing sentiment distribution across documents in a corpus.
    
    Args:
        document_data: List of dicts with keys: 'name' (document name), 'scores' (dict of sentiment scores)
        output_path: Path where to save the heatmap image
        title: Heatmap title
    
    Returns:
        Path to saved image or None if failed
    """
    if not HAS_MATPLOTLIB or not HAS_SEABORN:
        return None
    if not document_data:
        return None
    
    # Sort documents alphabetically
    sorted_docs = sorted(document_data, key=lambda x: x.get('name', '').lower())
    
    # Normalize labels
    ordered_labels = ["POS", "NEG", "NEU"]
    
    # Create matrix: rows = documents, columns = sentiments
    heatmap_data = []
    document_names = []
    
    for doc in sorted_docs:
        name = doc.get('name', 'Unknown')
        scores = doc.get('scores', {})
        
        row = []
        for sent in ordered_labels:
            if isinstance(scores, dict):
                score = scores.get(sent, 0.0)
                if score == 0.0:
                    # Try alternative names
                    for k, v in scores.items():
                        if normalize_sentiment_label(k) == sent:
                            score = float(v)
                            break
                row.append(float(score))
            else:
                row.append(0.0)
        
        heatmap_data.append(row)
        document_names.append(name)
    
    if not heatmap_data:
        return None
    
    # Create heatmap
    fig, ax = plt.subplots(figsize=(6, max(6, len(document_names) * 0.5)))
    
    heatmap_array = np.array(heatmap_data)
    sns.heatmap(heatmap_array, 
                xticklabels=ordered_labels,
                yticklabels=document_names,
                annot=True,
                fmt='.2f',
                cmap='RdYlGn',
                center=0.5,
                vmin=0,
                vmax=1,
                cbar_kws={'label': 'Score'},
                ax=ax)
    
    ax.set_title(title, fontsize=14, fontweight='bold', pad=20)
    ax.set_xlabel('Sentimiento', fontsize=12, fontweight='bold')
    ax.set_ylabel('Documento', fontsize=12, fontweight='bold')
    
    plt.tight_layout()
    
    # Save
    output_path.parent.mkdir(parents=True, exist_ok=True)
    try:
        plt.savefig(output_path, dpi=150, bbox_inches='tight', facecolor='white')
        plt.close(fig)
        return output_path
    except Exception as e:
        plt.close(fig)
        return None


def create_corpus_emotion_heatmap(document_data: List[Dict[str, Any]], output_path: Path, title: str = "Distribución de Emociones por Documento") -> Optional[Path]:
    """
    Create a heatmap showing emotion distribution across documents in a corpus.
    
    Args:
        document_data: List of dicts with keys: 'name' (document name), 'scores' (dict of emotion scores)
        output_path: Path where to save the heatmap image
        title: Heatmap title
    
    Returns:
        Path to saved image or None if failed
    """
    if not HAS_MATPLOTLIB or not HAS_SEABORN:
        return None
    if not document_data:
        return None
    
    # Sort documents alphabetically
    sorted_docs = sorted(document_data, key=lambda x: x.get('name', '').lower())
    
    # Get all unique emotions and order them
    ordered_emotions = ["joy", "sadness", "anger", "fear", "surprise", "disgust", "others"]
    all_emotions = set()
    for doc in sorted_docs:
        scores = doc.get('scores', {})
        if isinstance(scores, dict):
            all_emotions.update(scores.keys())
    
    # Use ordered emotions, add any missing ones
    emotion_labels = ordered_emotions.copy()
    for emo in sorted(all_emotions):
        if emo.lower() not in [e.lower() for e in emotion_labels]:
            emotion_labels.append(emo)
    
    # Create matrix: rows = documents, columns = emotions
    heatmap_data = []
    document_names = []
    
    for doc in sorted_docs:
        name = doc.get('name', 'Unknown')
        scores = doc.get('scores', {})
        
        row = []
        for emotion in emotion_labels:
            if isinstance(scores, dict):
                score = scores.get(emotion, 0.0)
                if score == 0.0:
                    # Try case-insensitive match
                    for k, v in scores.items():
                        if k.lower() == emotion.lower():
                            score = float(v)
                            break
                row.append(float(score))
            else:
                row.append(0.0)
        
        heatmap_data.append(row)
        document_names.append(name)
    
    if not heatmap_data:
        return None
    
    # Create heatmap
    fig, ax = plt.subplots(figsize=(max(8, len(emotion_labels) * 0.8), max(6, len(document_names) * 0.5)))
    
    heatmap_array = np.array(heatmap_data)
    sns.heatmap(heatmap_array, 
                xticklabels=emotion_labels,
                yticklabels=document_names,
                annot=True,
                fmt='.2f',
                cmap='viridis',
                vmin=0,
                vmax=1,
                cbar_kws={'label': 'Score'},
                ax=ax)
    
    ax.set_title(title, fontsize=14, fontweight='bold', pad=20)
    ax.set_xlabel('Emoción', fontsize=12, fontweight='bold')
    ax.set_ylabel('Documento', fontsize=12, fontweight='bold')
    
    plt.tight_layout()
    
    # Save
    output_path.parent.mkdir(parents=True, exist_ok=True)
    try:
        plt.savefig(output_path, dpi=150, bbox_inches='tight', facecolor='white')
        plt.close(fig)
        return output_path
    except Exception as e:
        plt.close(fig)
        return None

