"""CLI module."""
