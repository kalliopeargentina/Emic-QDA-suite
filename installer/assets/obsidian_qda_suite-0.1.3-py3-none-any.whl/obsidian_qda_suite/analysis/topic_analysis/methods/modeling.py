"""
Topic modeling function wrapper.

This module provides the perform_topic_modeling function that wraps
various topic modeling methods.
"""

import numpy as np
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer
from sklearn.decomposition import LatentDirichletAllocation, NMF
import gensim
from gensim.models import HdpModel, LsiModel
from gensim.corpora import Dictionary

from ..config import DEFAULT_CONFIG
try:
    from ..config import VERBOSE
except ImportError:
    VERBOSE = False

from ..nlp_utils import get_stopwords_set


def filter_stopwords_from_words(words_with_weights, language='english', top_n=10):
    """Filter stopwords from a list of (word, weight) tuples."""
    stopwords_set = get_stopwords_set(language)
    
    filtered = []
    for word, weight in words_with_weights:
        word_normalized = word.lower().strip()
        if word_normalized in stopwords_set:
            continue
        word_parts = word.split()
        if any(part.lower().strip() in stopwords_set for part in word_parts):
            continue
        filtered.append((word, weight))
        if len(filtered) >= top_n:
            break
    
    return filtered


def perform_topic_modeling(texts, n_topics=5, method='lda', seed_topics=None, hdp_gamma=1.0, hdp_alpha=1.0, 
                           hdp_min_topics=2, top2vec_embedding_model='all-MiniLM-L6-v2',
                           bertopic_min_topic_size=10, bertopic_top_n_words=10, bertopic_diversity=0.0,
                           bertopic_calculate_probabilities=True, bertopic_embedding_model=None, language='english',
                           custom_stopwords=None):
    """Perform topic modeling using LDA, NMF, Guided LDA, HDP, CorEx, LSI/LSA, Top2Vec, or BERTopic."""
    # Get stopwords using centralized function with cache (including custom stopwords)
    stopwords_set = get_stopwords_set(language, custom_stopwords=custom_stopwords)
    stop_words_list = list(stopwords_set)
    
    # Create vectorizer with explicit stopword filtering
    vectorizer_config = DEFAULT_CONFIG['vectorizer'].copy()
    vectorizer_config['stop_words'] = stop_words_list
    vectorizer = TfidfVectorizer(**vectorizer_config)
    
    try:
        X = vectorizer.fit_transform(texts)
    except ValueError as e:
        if VERBOSE:
            print(f"Warning: Vectorization failed: {e}")
            print("Using simpler vectorization...")
        fallback_config = DEFAULT_CONFIG['vectorizer_fallback'].copy()
        fallback_config['stop_words'] = stop_words_list
        vectorizer = CountVectorizer(**fallback_config)
        X = vectorizer.fit_transform(texts)
    
    feature_names = vectorizer.get_feature_names_out()
    original_feature_count = len(feature_names)
    
    # Filter out features that contain stopwords in n-grams
    valid_feature_indices = []
    filtered_feature_names = []
    
    for idx, feature in enumerate(feature_names):
        feature_parts = feature.split()
        if len(feature_parts) == 1:
            valid_feature_indices.append(idx)
            filtered_feature_names.append(feature)
            continue
        
        contains_stopword = any(part.lower().strip() in stopwords_set for part in feature_parts)
        if not contains_stopword:
            valid_feature_indices.append(idx)
            filtered_feature_names.append(feature)
    
    if valid_feature_indices and len(valid_feature_indices) < original_feature_count:
        from scipy import sparse
        if sparse.issparse(X):
            X = X[:, valid_feature_indices]
        else:
            X = X[:, valid_feature_indices]
        feature_names = np.array(filtered_feature_names)
        removed_count = original_feature_count - len(feature_names)
        if VERBOSE or removed_count > 0:
            print(f"Filtered {len(feature_names)} features (removed {removed_count} n-grams containing stopwords)")
    elif not valid_feature_indices:
        if VERBOSE:
            print("Warning: All features were filtered! Keeping original features.")
    
    # Perform topic modeling based on method
    if method.lower() == 'nmf':
        model = NMF(n_components=n_topics, random_state=42, max_iter=1000)
        W = model.fit_transform(X)
        H = model.components_
        
        # Extract topics
        topics = []
        candidate_count = DEFAULT_CONFIG['topic_extraction']['candidate_words']
        top_n = DEFAULT_CONFIG['topic_extraction']['top_n_words']
        
        for topic_idx, topic in enumerate(H):
            top_words_idx = topic.argsort()[-candidate_count:][::-1]
            candidate_words = [(feature_names[i], topic[i]) for i in top_words_idx]
            filtered_words = filter_stopwords_from_words(candidate_words, language=language, top_n=top_n)
            
            if not filtered_words:
                filtered_words = [(feature_names[i], topic[i]) for i in top_words_idx[:top_n]]
            
            top_words = [word for word, _ in filtered_words]
            top_weights = [weight for _, weight in filtered_words]
            
            topics.append({
                'topic_id': topic_idx,
                'words': top_words,
                'weights': top_weights
            })
        
        return topics, model, vectorizer, W
    
    elif method.lower() == 'hdp':
        # HDP (Hierarchical Dirichlet Process)
        texts_tokenized = []
        for text in texts:
            tokens = text.split()
            texts_tokenized.append(tokens)
        
        dictionary = Dictionary(texts_tokenized)
        dictionary.filter_extremes(no_below=2, no_above=0.95)
        corpus = [dictionary.doc2bow(text) for text in texts_tokenized]
        
        model = HdpModel(
            corpus=corpus,
            id2word=dictionary,
            random_state=42,
            gamma=hdp_gamma,
            alpha=hdp_alpha,
        )
        
        topics_array = model.get_topics()
        n_topics_actual = topics_array.shape[0] if len(topics_array.shape) > 0 else 0
        print(f"HDP discovered {n_topics_actual} topics automatically (gamma={hdp_gamma}, alpha={hdp_alpha})")
        
        if n_topics_actual == 0:
            raise ValueError("HDP model did not discover any topics. The corpus may be too small or too sparse.")
        
        W = np.zeros((len(corpus), n_topics_actual))
        for i, doc in enumerate(corpus):
            doc_topics = model[doc]
            if isinstance(doc_topics, list):
                for topic_id, prob in doc_topics:
                    if topic_id < n_topics_actual:
                        W[i, topic_id] = prob
        
        topic_prevalence = np.mean(W, axis=0)
        topic_indices = []
        
        for idx in range(n_topics_actual):
            if topic_prevalence[idx] > 0.01:
                topic_indices.append(idx)
        
        if len(topic_indices) < hdp_min_topics:
            topic_prev_list = [(idx, topic_prevalence[idx]) for idx in range(n_topics_actual)]
            topic_prev_list.sort(key=lambda x: x[1], reverse=True)
            topic_indices = [idx for idx, _ in topic_prev_list[:hdp_min_topics]]
            topic_indices.sort()
        
        if n_topics is not None and len(topic_indices) > n_topics:
            topic_prev_dict = {idx: topic_prevalence[idx] for idx in topic_indices}
            sorted_topics = sorted(topic_prev_dict.items(), key=lambda x: x[1], reverse=True)
            topic_indices = [idx for idx, _ in sorted_topics[:n_topics]]
            topic_indices.sort()
        
        topics = []
        W_filtered = W[:, topic_indices]
        
        for new_idx, old_idx in enumerate(topic_indices):
            try:
                topic_terms = model.show_topic(old_idx, topn=10)
                top_words = [word for word, prob in topic_terms]
                top_weights = [prob for word, prob in topic_terms]
            except:
                topic_vector = topics_array[old_idx]
                top_word_indices = topic_vector.argsort()[-10:][::-1]
                top_words = [dictionary.id2token[i] for i in top_word_indices if i < len(dictionary.id2token)]
                top_weights = [topic_vector[i] for i in top_word_indices if i < len(topic_vector)]
            
            topics.append({
                'topic_id': new_idx,
                'words': top_words,
                'weights': top_weights
            })
        
        n_topics_actual = len(topics)
        original_count = topics_array.shape[0]
        if n_topics_actual < original_count:
            print(f"Filtered topics: {n_topics_actual} topics kept from {original_count} discovered")
        
        W = W_filtered
        
        class DummyModel:
            def __init__(self, gensim_model):
                self.gensim_model = gensim_model
        
        model = DummyModel(model)
        return topics, model, vectorizer, W
    
    elif method.lower() == 'guided-lda' and seed_topics:
        # Guided LDA using gensim
        texts_tokenized = []
        for text in texts:
            tokens = text.split()
            texts_tokenized.append(tokens)
        
        dictionary = Dictionary(texts_tokenized)
        dictionary.filter_extremes(no_below=2, no_above=0.95)
        corpus = [dictionary.doc2bow(text) for text in texts_tokenized]
        
        seed_list = []
        for topic_name, words in seed_topics.items():
            topic_seeds = []
            for word in words:
                word_id = dictionary.token2id.get(word)
                if word_id is not None:
                    topic_seeds.append(word_id)
            if topic_seeds:
                seed_list.append(topic_seeds)
        
        if seed_list:
            eta = np.ones((n_topics, len(dictionary))) * 0.01
            for topic_idx, seed_ids in enumerate(seed_list):
                if topic_idx < n_topics:
                    for seed_id in seed_ids:
                        eta[topic_idx, seed_id] = 1.0
            
            model = gensim.models.LdaModel(
                corpus=corpus,
                id2word=dictionary,
                num_topics=n_topics,
                random_state=42,
                passes=10,
                alpha='auto',
                eta=eta,
                per_word_topics=True
            )
            
            W = np.zeros((len(corpus), n_topics))
            for i, doc in enumerate(corpus):
                topic_dist = model.get_document_topics(doc, minimum_probability=0.0)
                for topic_id, prob in topic_dist:
                    W[i, topic_id] = prob
            
            topics = []
            for topic_idx in range(n_topics):
                topic_terms = model.show_topic(topic_idx, topn=10)
                top_words = [word for word, prob in topic_terms]
                top_weights = [prob for word, prob in topic_terms]
                
                seed_words = []
                if topic_idx < len(seed_topics):
                    topic_name = list(seed_topics.keys())[topic_idx]
                    seed_words = seed_topics[topic_name]
                
                topics.append({
                    'topic_id': topic_idx,
                    'words': top_words,
                    'weights': top_weights,
                    'seed_words': seed_words
                })
            
            class DummyModel:
                def __init__(self, gensim_model):
                    self.gensim_model = gensim_model
            
            model = DummyModel(model)
            return topics, model, vectorizer, W
        else:
            print("Warning: No valid seed words found, falling back to regular LDA")
            method = 'lda'
    
    elif method.lower() == 'corex':
        try:
            from corextopic import corextopic as ct
        except ImportError:
            raise ImportError("corextopic library not found. Install it with: pip install corextopic")
        
        corex_config = DEFAULT_CONFIG['vectorizer'].copy()
        if hasattr(vectorizer, 'get_feature_names_out'):
            corex_config['vocabulary'] = vectorizer.get_feature_names_out()
        count_vectorizer = CountVectorizer(**corex_config)
        X_counts = count_vectorizer.fit_transform(texts)
        feature_names = count_vectorizer.get_feature_names_out()
        
        if hasattr(X_counts, 'toarray'):
            X_dense = X_counts.toarray().astype(int)
        else:
            X_dense = X_counts.astype(int)
        
        anchors = None
        anchor_strength = 2
        if seed_topics:
            anchors = []
            for topic_name, words_list in seed_topics.items():
                topic_anchors = []
                for word in words_list:
                    try:
                        word_idx = list(feature_names).index(word)
                        topic_anchors.append(word_idx)
                    except ValueError:
                        continue
                if topic_anchors:
                    anchors.append(topic_anchors)
            
            if anchors:
                print(f"Using {len(anchors)} topics with seed words (anchors) for CorEx")
                if n_topics is None:
                    n_topics = len(anchors)
                elif n_topics < len(anchors):
                    n_topics = len(anchors)
        
        model = ct.Corex(n_hidden=n_topics, seed=42, verbose=False)
        
        if anchors and len(anchors) > 0:
            model.fit(X_dense, words=feature_names, anchors=anchors, anchor_strength=anchor_strength)
        else:
            model.fit(X_dense, words=feature_names)
        
        W = model.transform(X_dense)
        H = np.zeros((n_topics, len(feature_names)))
        topics = []
        
        for topic_idx in range(n_topics):
            topic_words_mi = model.get_topics(topic=topic_idx, n_words=10)
            top_words = []
            top_mi_scores = []
            for item in topic_words_mi:
                if len(item) == 3:
                    word, mi_score, sign = item
                elif len(item) == 2:
                    word, mi_score = item
                else:
                    word = item[0]
                    mi_score = item[1] if len(item) > 1 else 0.0
                top_words.append(word)
                top_mi_scores.append(abs(mi_score))
            
            if top_mi_scores:
                min_mi = min(top_mi_scores)
                max_mi = max(top_mi_scores)
                if max_mi > min_mi:
                    top_probs = [(mi - min_mi) / (max_mi - min_mi) for mi in top_mi_scores]
                else:
                    top_probs = [1.0 / len(top_mi_scores)] * len(top_mi_scores)
                total = sum(top_probs)
                if total > 0:
                    top_probs = [p / total for p in top_probs]
                else:
                    top_probs = [1.0 / len(top_probs)] * len(top_probs)
            else:
                top_probs = []
            
            for word, prob in zip(top_words, top_probs):
                try:
                    word_idx = list(feature_names).index(word)
                    H[topic_idx, word_idx] = prob
                except ValueError:
                    pass
            
            seed_words = []
            if anchors and topic_idx < len(anchors):
                anchor_indices = anchors[topic_idx]
                seed_words = [feature_names[idx] for idx in anchor_indices if idx < len(feature_names)]
            
            topics.append({
                'topic_id': topic_idx,
                'words': top_words,
                'weights': top_probs,
                'seed_words': seed_words if seed_words else None
            })
        
        W = np.abs(W)
        W = W / (W.sum(axis=1, keepdims=True) + 1e-10)
        
        class DummyModel:
            def __init__(self, corex_model):
                self.corex_model = corex_model
        
        model = DummyModel(model)
        return topics, model, count_vectorizer, W
    
    elif method.lower() == 'lsi' or method.lower() == 'lsa':
        texts_tokenized = []
        for text in texts:
            tokens = text.split()
            texts_tokenized.append(tokens)
        
        dictionary = Dictionary(texts_tokenized)
        dictionary.filter_extremes(no_below=2, no_above=0.95)
        corpus = [dictionary.doc2bow(text) for text in texts_tokenized]
        
        model = LsiModel(
            corpus=corpus,
            id2word=dictionary,
            num_topics=n_topics,
            random_seed=42
        )
        
        W = np.zeros((len(corpus), n_topics))
        for i, doc in enumerate(corpus):
            doc_topics = model[doc]
            if isinstance(doc_topics, list):
                for topic_id, weight in doc_topics:
                    if topic_id < n_topics:
                        W[i, topic_id] = abs(weight)
        
        W = np.abs(W)
        W = W / (W.sum(axis=1, keepdims=True) + 1e-10)
        
        topics = []
        for topic_idx in range(n_topics):
            try:
                topic_terms = model.show_topic(topic_idx, topn=10)
                top_words = [word for word, weight in topic_terms]
                top_weights = [abs(weight) for word, weight in topic_terms]
            except:
                top_words = []
                top_weights = []
            
            if top_weights:
                total = sum(top_weights)
                if total > 0:
                    top_weights = [w / total for w in top_weights]
            
            topics.append({
                'topic_id': topic_idx,
                'words': top_words,
                'weights': top_weights
            })
        
        class DummyModel:
            def __init__(self, gensim_model):
                self.gensim_model = gensim_model
        
        model = DummyModel(model)
        return topics, model, vectorizer, W
    
    elif method.lower() == 'top2vec':
        try:
            from top2vec import Top2Vec
        except (ImportError, OSError) as e:
            error_msg = str(e)
            if "DLL" in error_msg or "dll" in error_msg.lower():
                raise ImportError(
                    "top2vec library found but failed to load dependencies. "
                    "Try: pip install 'numpy<2' or reinstall torch/tensorflow."
                ) from e
            raise ImportError(f"top2vec library not found. Install it with: pip install top2vec. Error: {e}") from e
        
        documents = texts
        
        if n_topics is None:
            print("Top2Vec will discover topics automatically")
            model = Top2Vec(documents, embedding_model=top2vec_embedding_model, speed='learn', workers=4, min_count=2)
            num_topics_discovered = model.get_num_topics()
            print(f"Top2Vec discovered {num_topics_discovered} topics")
            n_topics = num_topics_discovered
        else:
            print(f"Using Top2Vec with target of {n_topics} topics")
            model = Top2Vec(documents, embedding_model=top2vec_embedding_model, speed='learn', workers=4, min_count=2, topic_merge_delta=0.1)
            num_topics_discovered = model.get_num_topics()
            print(f"Top2Vec discovered {num_topics_discovered} topics")
            if num_topics_discovered != n_topics:
                print(f"Note: Top2Vec discovered {num_topics_discovered} topics (requested {n_topics})")
                n_topics = min(n_topics, num_topics_discovered)
        
        topic_words_list, word_scores_list, topic_nums = model.get_topics(n_topics)
        
        W = np.zeros((len(documents), n_topics))
        topic_idx_map = {topic_num: idx for idx, topic_num in enumerate(topic_nums[:n_topics])}
        
        for i in range(len(documents)):
            try:
                result = model.get_documents_topics(doc_ids=[i], num_topics=n_topics)
                if len(result) == 2:
                    doc_topics_nums, doc_distances = result
                elif len(result) == 3:
                    doc_topics_nums, doc_distances, _ = result
                else:
                    doc_topics_nums = result[0] if len(result) > 0 else []
                    doc_distances = result[1] if len(result) > 1 else []
                
                if hasattr(doc_topics_nums, 'tolist'):
                    doc_topics_nums = doc_topics_nums.tolist()
                if hasattr(doc_distances, 'tolist'):
                    doc_distances = doc_distances.tolist()
                
                if len(doc_topics_nums) > 0 and len(doc_distances) > 0:
                    doc_distances = [float(d) for d in doc_distances]
                    max_dist = max(doc_distances) if doc_distances else 1.0
                    similarities = [np.exp(-d / max_dist) if max_dist > 0 else 1.0 for d in doc_distances]
                    total = sum(similarities)
                    if total > 0:
                        probs = [s / total for s in similarities]
                    else:
                        probs = [1.0 / len(similarities)] * len(similarities)
                    
                    for topic_num, prob in zip(doc_topics_nums, probs):
                        topic_num = int(topic_num)
                        if topic_num in topic_idx_map:
                            topic_idx = topic_idx_map[topic_num]
                            if topic_idx < n_topics:
                                W[i, topic_idx] = prob
            except Exception as e:
                W[i, :] = 1.0 / n_topics
        
        W = W / (W.sum(axis=1, keepdims=True) + 1e-10)
        
        topics = []
        for idx in range(len(topic_words_list[:n_topics])):
            topic_words = topic_words_list[idx][:10]
            word_scores = word_scores_list[idx][:10]
            
            if len(word_scores) > 0:
                max_score = max(word_scores)
                min_score = min(word_scores)
                if max_score > min_score:
                    normalized_scores = [(s - min_score) / (max_score - min_score) for s in word_scores]
                else:
                    normalized_scores = [1.0 / len(word_scores)] * len(word_scores)
                total = sum(normalized_scores)
                if total > 0:
                    top_weights = [s / total for s in normalized_scores]
                else:
                    top_weights = [1.0 / len(normalized_scores)] * len(normalized_scores)
            else:
                top_weights = []
            
            topics.append({
                'topic_id': idx,
                'words': topic_words,
                'weights': top_weights
            })
        
        class DummyModel:
            def __init__(self, top2vec_model):
                self.top2vec_model = top2vec_model
        
        model = DummyModel(model)
        return topics, model, vectorizer, W
    
    elif method.lower() == 'bertopic':
        try:
            import torch
        except Exception as e:
            raise ImportError(f"PyTorch could not be loaded: {e}. This is required for BERTopic.")
        
        try:
            from hdbscan import HDBSCAN
            try:
                from umap import UMAP
            except ImportError:
                from umap.umap_ import UMAP
            from bertopic import BERTopic
        except ImportError as e:
            raise ImportError(f"BERTopic dependencies not found: {e}. Install with: pip install bertopic umap-learn hdbscan")
        
        documents = texts
        
        if n_topics is not None and n_topics > 0:
            n_docs = len(documents)
            estimated_min_size = max(2, int(n_docs / (n_topics * 2)))
            estimated_min_size = min(estimated_min_size, bertopic_min_topic_size)
            print(f"Using BERTopic with target of {n_topics} topics (min_cluster_size={estimated_min_size})")
        else:
            estimated_min_size = bertopic_min_topic_size
            print(f"BERTopic will discover topics automatically (min_cluster_size={estimated_min_size})")
        
        hdbscan_model = HDBSCAN(min_cluster_size=estimated_min_size, metric='euclidean', cluster_selection_method='eom', prediction_data=True)
        umap_model = UMAP(n_neighbors=15, n_components=5, metric='cosine', random_state=42)
        
        if n_topics is not None and n_topics > 0:
            bertopic_nr_topics = n_topics
        else:
            bertopic_nr_topics = 'auto'
        
        model_kwargs = {
            'umap_model': umap_model,
            'hdbscan_model': hdbscan_model,
            'nr_topics': bertopic_nr_topics,
            'top_n_words': bertopic_top_n_words,
            'calculate_probabilities': bertopic_calculate_probabilities,
            'verbose': False
        }
        
        if bertopic_embedding_model is not None:
            try:
                from sentence_transformers import SentenceTransformer
                embedding_model = SentenceTransformer(bertopic_embedding_model)
                model_kwargs['embedding_model'] = embedding_model
                print(f"BERTopic using custom embedding model: {bertopic_embedding_model}")
            except Exception as e:
                print(f"Warning: Could not load custom embedding model: {e}")
        
        if bertopic_diversity is not None and bertopic_diversity > 0.0:
            try:
                from bertopic.representation import MaximalMarginalRelevance
                representation_model = MaximalMarginalRelevance(diversity=bertopic_diversity)
                model_kwargs['representation_model'] = representation_model
                print(f"BERTopic using MMR representation with diversity={bertopic_diversity}")
            except ImportError:
                model_kwargs['diversity'] = bertopic_diversity
        
        model = BERTopic(**model_kwargs)
        topic_assignments, topic_probs = model.fit_transform(documents)
        
        valid_topics = [t for t in topic_assignments if t != -1]
        if valid_topics:
            n_topics_actual = len(set(valid_topics))
        else:
            n_topics_actual = 1
        
        print(f"BERTopic discovered {n_topics_actual} topics (excluding outliers)")
        
        if n_topics is None:
            n_topics = n_topics_actual
        elif n_topics_actual != n_topics:
            print(f"Note: BERTopic discovered {n_topics_actual} topics (requested {n_topics})")
            n_topics = n_topics_actual
        
        valid_topic_ids = sorted(set([t for t in topic_assignments if t != -1]))[:n_topics]
        n_topics_actual = len(valid_topic_ids)
        if n_topics_actual == 0:
            n_topics_actual = 1
        
        W = np.zeros((len(documents), n_topics_actual))
        topic_id_to_idx = {orig_id: idx for idx, orig_id in enumerate(valid_topic_ids)}
        
        if topic_probs is not None:
            topic_probs = np.array(topic_probs)
            if len(topic_probs.shape) == 2:
                for i, topic_id in enumerate(topic_assignments):
                    if topic_id != -1 and topic_id in topic_id_to_idx:
                        idx = topic_id_to_idx[topic_id]
                        if topic_id < topic_probs.shape[1]:
                            prob = topic_probs[i, topic_id]
                            if not np.isnan(prob):
                                W[i, idx] = prob
                            else:
                                W[i, idx] = 1.0
                        else:
                            W[i, idx] = 1.0
            else:
                for i, (topic_id, prob) in enumerate(zip(topic_assignments, topic_probs)):
                    if topic_id != -1 and topic_id in topic_id_to_idx:
                        idx = topic_id_to_idx[topic_id]
                        prob_val = prob
                        if isinstance(prob, np.ndarray):
                            if len(prob) > 0:
                                prob_val = prob[0] if len(prob) == 1 else float(prob)
                            else:
                                prob_val = 1.0
                        if prob_val is not None and not np.isnan(prob_val):
                            W[i, idx] = float(prob_val)
                        else:
                            W[i, idx] = 1.0
        else:
            for i, topic_id in enumerate(topic_assignments):
                if topic_id != -1 and topic_id in topic_id_to_idx:
                    idx = topic_id_to_idx[topic_id]
                    W[i, idx] = 1.0
        
        W = W / (W.sum(axis=1, keepdims=True) + 1e-10)
        
        topics = []
        topic_ids = sorted(set(topic_assignments))
        topic_ids = [t for t in topic_ids if t != -1][:n_topics]
        topic_id_to_idx = {orig_id: idx for idx, orig_id in enumerate(topic_ids)}
        
        for idx, topic_id in enumerate(topic_ids):
            try:
                topic_words_weights = model.get_topic(topic_id)
                if topic_words_weights:
                    top_words = [word for word, weight in topic_words_weights[:bertopic_top_n_words]]
                    top_weights = [weight for word, weight in topic_words_weights[:bertopic_top_n_words]]
                else:
                    top_words = []
                    top_weights = []
            except:
                top_words = []
                top_weights = []
            
            if top_weights:
                max_weight = max(top_weights)
                min_weight = min(top_weights)
                if max_weight > min_weight:
                    normalized_weights = [(w - min_weight) / (max_weight - min_weight) for w in top_weights]
                else:
                    normalized_weights = [1.0 / len(top_weights)] * len(top_weights)
                total = sum(normalized_weights)
                if total > 0:
                    top_weights = [w / total for w in normalized_weights]
                else:
                    top_weights = [1.0 / len(normalized_weights)] * len(normalized_weights)
            
            topics.append({
                'topic_id': idx,
                'words': top_words,
                'weights': top_weights
            })
        
        if len(topics) == 0:
            topics.append({
                'topic_id': 0,
                'words': [],
                'weights': []
            })
        
        class DummyModel:
            def __init__(self, bertopic_model):
                self.bertopic_model = bertopic_model
        
        model = DummyModel(model)
        return topics, model, vectorizer, W
    
    # Regular LDA (fallback or default)
    if method.lower() == 'lda':
        model = LatentDirichletAllocation(
            n_components=n_topics,
            random_state=42,
            max_iter=20,
            learning_method='online'
        )
        W = model.fit_transform(X)
        H = model.components_
    
    # Extract topics - with final stopword filtering
    topics = []
    candidate_count = DEFAULT_CONFIG['topic_extraction']['candidate_words']
    top_n = DEFAULT_CONFIG['topic_extraction']['top_n_words']
    
    for topic_idx, topic in enumerate(H):
        top_words_idx = topic.argsort()[-candidate_count:][::-1]
        candidate_words = [(feature_names[i], topic[i]) for i in top_words_idx]
        filtered_words = filter_stopwords_from_words(candidate_words, language=language, top_n=top_n)
        
        if not filtered_words:
            filtered_words = [(feature_names[i], topic[i]) for i in top_words_idx[:top_n]]
        
        top_words = [word for word, _ in filtered_words]
        top_weights = [weight for _, weight in filtered_words]
        
        topics.append({
            'topic_id': topic_idx,
            'words': top_words,
            'weights': top_weights
        })
    
    return topics, model, vectorizer, W

