"""Exportadores para archivos de dominio."""

from __future__ import annotations

import json
import re
from typing import Any

try:
    import rdflib
    from rdflib import Literal, Namespace, URIRef
    from rdflib.namespace import RDF, RDFS
    RDFLIB_AVAILABLE = True
except ImportError:
    RDFLIB_AVAILABLE = False

from ontology_explorer.domain.normalize import normalize_domain_content
from ontology_explorer.domain.spec import DomainSpec


def _slug(s: str) -> str:
    """Normaliza nombres para URIs: espacios -> _, caracteres no válidos removidos."""
    t = re.sub(r"\s+", "_", (s or "").strip())
    t = t.replace('"', "").replace("/", "_")
    return t or "unknown"


def export_domain_to_rdf(
    domain_content: str,
    metadata: dict[str, Any] | None = None,
    domain_name: str = "domain",
) -> str:
    """
    Exporta un dominio a formato RDF/TTL (Turtle).
    
    Args:
        domain_content: Contenido del dominio (sin frontmatter)
        metadata: Metadatos del frontmatter (opcional)
        domain_name: Nombre del dominio para crear URIs
    
    Returns:
        Contenido RDF en formato Turtle
    """
    if not RDFLIB_AVAILABLE:
        raise ImportError(
            "rdflib no está instalado. Instálalo con: pip install rdflib"
        )
    
    # Crear grafo RDF
    graph = rdflib.Graph()
    
    # Definir namespaces
    base_uri = f"http://example.org/ontology/{domain_name}#"
    ex = Namespace(base_uri)
    graph.bind("ex", ex)
    graph.bind("rdf", RDF)
    graph.bind("rdfs", RDFS)
    
    # Parsear estructura del dominio y relaciones normalizadas
    domain_spec = normalize_domain_content(domain_content, metadata=metadata)
    domain_structure = domain_spec.domain_structure
    relations = _relations_from_spec(domain_spec)
    
    # Crear clases para cada entidad
    for entity_name in domain_structure.keys():
        entity_uri = ex[entity_name.replace(" ", "_")]
        graph.add((entity_uri, RDF.type, RDFS.Class))
        graph.add((entity_uri, RDFS.label, Literal(entity_name, lang="es")))
        
        # Agregar propiedades de la entidad
        entity_props = domain_structure[entity_name]
        if isinstance(entity_props, dict):
            for prop_name, prop_data in entity_props.items():
                if isinstance(prop_data, dict):
                    # Verificar si es estructura de nivel 2 (tiene claves que no son "relacion" ni "sub_propiedades" ni "_relacion")
                    is_level2 = any(
                        key not in ("relacion", "sub_propiedades", "_relacion")
                        for key in prop_data.keys()
                    )
                    
                    if is_level2:
                        # Estructura de nivel 2: {prop_nivel2: {"sub_propiedades": [...]}}
                        prop_id = _slug(prop_name)
                        prop_uri = ex[prop_id]
                        graph.add((prop_uri, RDF.type, RDF.Property))
                        graph.add((prop_uri, RDFS.label, Literal(prop_name, lang="es")))
                        graph.add((prop_uri, RDFS.domain, entity_uri))
                        
                        # Procesar cada propiedad de nivel 2
                        for level2_prop_name, level2_prop_data in prop_data.items():
                            if level2_prop_name in ("relacion", "_relacion"):
                                continue
                            if isinstance(level2_prop_data, dict):
                                level2_prop_id = _slug(level2_prop_name)
                                level2_prop_uri = ex[f"{prop_id}_{level2_prop_id}"]
                                graph.add((level2_prop_uri, RDF.type, RDF.Property))
                                graph.add((level2_prop_uri, RDFS.label, Literal(level2_prop_name, lang="es")))
                                graph.add((level2_prop_uri, RDFS.subPropertyOf, prop_uri))
                                
                                # Subpropiedades de nivel 2
                                for sub in level2_prop_data.get("sub_propiedades") or []:
                                    sub_id = _slug(sub)
                                    sub_uri = ex[f"{prop_id}_{level2_prop_id}_{sub_id}"]
                                    graph.add((sub_uri, RDF.type, RDF.Property))
                                    graph.add((sub_uri, RDFS.label, Literal(sub, lang="es")))
                                    graph.add((sub_uri, RDFS.subPropertyOf, level2_prop_uri))
                    else:
                        # Propiedad anidada nivel 1 (estructura antigua)
                        prop_id = _slug(prop_name)
                        prop_uri = ex[prop_id]
                        graph.add((prop_uri, RDF.type, RDF.Property))
                        graph.add((prop_uri, RDFS.label, Literal(prop_name, lang="es")))
                        graph.add((prop_uri, RDFS.domain, entity_uri))
                        # Subpropiedades como rdfs:subPropertyOf de la anidada
                        for sub in prop_data.get("sub_propiedades") or []:
                            sub_id = _slug(sub)
                            sub_uri = ex[f"{prop_id}_{sub_id}"]
                            graph.add((sub_uri, RDF.type, RDF.Property))
                            graph.add((sub_uri, RDFS.label, Literal(sub, lang="es")))
                            graph.add((sub_uri, RDFS.subPropertyOf, prop_uri))
                elif isinstance(prop_data, list):
                    # Propiedades simples
                    for simple_prop in prop_data:
                        prop_uri = ex[simple_prop.replace(" ", "_")]
                        graph.add((prop_uri, RDF.type, RDF.Property))
                        graph.add((prop_uri, RDFS.label, Literal(simple_prop, lang="es")))
                        graph.add((prop_uri, RDFS.domain, entity_uri))
    
    # Agregar relaciones como propiedades
    for rel_type, source, target in relations:
        rel_uri = ex[rel_type.replace(" ", "_").replace('"', "").replace("/", "_")]
        graph.add((rel_uri, RDF.type, RDF.Property))
        graph.add((rel_uri, RDFS.label, Literal(rel_type, lang="es")))
    
    # Agregar metadatos si están disponibles
    if metadata:
        domain_uri = ex["Domain"]
        graph.add((domain_uri, RDF.type, RDFS.Resource))
        if "title" in metadata:
            graph.add((domain_uri, RDFS.label, Literal(metadata["title"], lang="es")))
        if "description" in metadata:
            graph.add((domain_uri, RDFS.comment, Literal(metadata["description"], lang="es")))
        if "version" in metadata:
            graph.add((domain_uri, ex["version"], Literal(metadata["version"])))
    
    # Serializar a Turtle
    return graph.serialize(format="turtle", encoding="utf-8").decode("utf-8")


def export_domain_to_json(
    domain_content: str,
    metadata: dict[str, Any] | None = None,
) -> str:
    """
    Exporta un dominio a formato JSON estructurado.
    
    Args:
        domain_content: Contenido del dominio (sin frontmatter)
        metadata: Metadatos del frontmatter (opcional)
    
    Returns:
        JSON como string
    """
    # Parsear estructura del dominio y relaciones normalizadas
    domain_spec = normalize_domain_content(domain_content, metadata=metadata)
    domain_structure = domain_spec.domain_structure
    relations = _relations_from_spec(domain_spec)
    context = domain_spec.context
    
    # Construir estructura JSON
    result: dict[str, Any] = {
        "metadata": metadata or {},
        "context": context,
        "entities": {},
        "relations": [],
    }
    
    # Agregar entidades con sus propiedades
    for entity_name, entity_props in domain_structure.items():
        entity_data: dict[str, Any] = {
            "name": entity_name,
            "properties": [],
        }
        
        if isinstance(entity_props, dict):
            for prop_name, prop_data in entity_props.items():
                if isinstance(prop_data, dict):
                    # Verificar si es estructura de nivel 2
                    is_level2 = any(
                        key not in ("relacion", "sub_propiedades", "_relacion")
                        for key in prop_data.keys()
                    )
                    
                    if is_level2:
                        # Estructura de nivel 2: {prop_nivel2: {"sub_propiedades": [...]}}
                        # Puede tener también _sub_propiedades_nivel1 para sub-propiedades de nivel 1
                        level1_sub_props = prop_data.get("_sub_propiedades_nivel1", [])
                        level2_props_count = sum(
                            1 for k in prop_data.keys()
                            if k not in ("relacion", "_relacion", "_sub_propiedades_nivel1")
                        )
                        
                        # Si hay sub-propiedades de nivel 1 Y propiedades de nivel 2, usar estructura mixta
                        # Si solo hay propiedades de nivel 2, usar nested_level1
                        # Si solo hay sub-propiedades de nivel 1, usar nested (nivel 1)
                        if level1_sub_props and level2_props_count > 0:
                            # Estructura mixta: tiene tanto sub-propiedades de nivel 1 como propiedades de nivel 2
                            prop_info: dict[str, Any] = {
                                "name": prop_name,
                                "type": "nested",
                                "relation": prop_data.get("_relacion") or prop_data.get("relacion"),
                                "sub_properties": level1_sub_props if isinstance(level1_sub_props, list) else [],
                                "nested_properties": [],
                            }
                            # Procesar propiedades de nivel 2
                            for level2_prop_name, level2_prop_data in prop_data.items():
                                if level2_prop_name in ("relacion", "_relacion", "_sub_propiedades_nivel1"):
                                    continue
                                if isinstance(level2_prop_data, dict):
                                    level2_prop_info: dict[str, Any] = {
                                        "name": level2_prop_name,
                                        "type": "nested_level2",
                                        "sub_properties": level2_prop_data.get("sub_propiedades", []),
                                    }
                                    prop_info["nested_properties"].append(level2_prop_info)
                            entity_data["properties"].append(prop_info)
                        elif level2_props_count > 0:
                            # Solo propiedades de nivel 2
                            prop_info: dict[str, Any] = {
                                "name": prop_name,
                                "type": "nested_level1",
                                "relation": prop_data.get("_relacion") or prop_data.get("relacion"),
                                "nested_properties": [],
                            }
                            # Procesar propiedades de nivel 2
                            for level2_prop_name, level2_prop_data in prop_data.items():
                                if level2_prop_name in ("relacion", "_relacion", "_sub_propiedades_nivel1"):
                                    continue
                                if isinstance(level2_prop_data, dict):
                                    level2_prop_info: dict[str, Any] = {
                                        "name": level2_prop_name,
                                        "type": "nested_level2",
                                        "sub_properties": level2_prop_data.get("sub_propiedades", []),
                                    }
                                    prop_info["nested_properties"].append(level2_prop_info)
                            entity_data["properties"].append(prop_info)
                        else:
                            # Solo sub-propiedades de nivel 1 (no debería pasar si is_level2 es True, pero por seguridad)
                            prop_info: dict[str, Any] = {
                                "name": prop_name,
                                "type": "nested",
                                "relation": prop_data.get("_relacion") or prop_data.get("relacion"),
                                "sub_properties": level1_sub_props if isinstance(level1_sub_props, list) else [],
                            }
                            entity_data["properties"].append(prop_info)
                    else:
                        # Propiedad anidada nivel 1 (estructura antigua)
                        prop_info: dict[str, Any] = {
                            "name": prop_name,
                            "type": "nested",
                            "relation": prop_data.get("relacion"),
                            "sub_properties": prop_data.get("sub_propiedades", []),
                        }
                        entity_data["properties"].append(prop_info)
                elif isinstance(prop_data, list):
                    # Propiedades simples
                    for simple_prop in prop_data:
                        entity_data["properties"].append({
                            "name": simple_prop,
                            "type": "simple",
                        })
        
        result["entities"][entity_name] = entity_data
    
    # Agregar relaciones
    for rel_type, source, target in relations:
        result["relations"].append({
            "type": rel_type,
            "source": source,
            "target": target,
        })
    
    return json.dumps(result, ensure_ascii=False, indent=2)


def export_domain_to_jsonld(
    domain_content: str,
    metadata: dict[str, Any] | None = None,
    domain_name: str = "domain",
) -> str:
    """
    Exporta un dominio a formato JSON-LD.
    
    Args:
        domain_content: Contenido del dominio (sin frontmatter)
        metadata: Metadatos del frontmatter (opcional)
        domain_name: Nombre del dominio para crear URIs
    
    Returns:
        JSON-LD como string
    """
    # Parsear estructura del dominio y relaciones normalizadas
    domain_spec = normalize_domain_content(domain_content, metadata=metadata)
    domain_structure = domain_spec.domain_structure
    relations = _relations_from_spec(domain_spec)
    
    # Construir contexto JSON-LD
    base_uri = f"http://example.org/ontology/{domain_name}#"
    context: dict[str, Any] = {
        "@context": {
            "@vocab": base_uri,
            "rdf": "http://www.w3.org/1999/02/22-rdf-syntax-ns#",
            "rdfs": "http://www.w3.org/2000/01/rdf-schema#",
            "label": "rdfs:label",
            "comment": "rdfs:comment",
            "type": "rdf:type",
        }
    }
    
    # Construir grafo JSON-LD
    graph: list[dict[str, Any]] = []
    
    # Agregar entidades como clases
    for entity_name in domain_structure.keys():
        entity_id = entity_name.replace(" ", "_")
        entity_node: dict[str, Any] = {
            "@id": f"{base_uri}{entity_id}",
            "@type": "rdfs:Class",
            "label": entity_name,
        }
        graph.append(entity_node)
        
        # Agregar propiedades (incl. anidadas y subpropiedades)
        entity_props = domain_structure[entity_name]
        if isinstance(entity_props, dict):
            for prop_name, prop_data in entity_props.items():
                prop_id = _slug(prop_name)
                prop_node: dict[str, Any] = {
                    "@id": f"{base_uri}{prop_id}",
                    "@type": "rdf:Property",
                    "label": prop_name,
                    "rdfs:domain": {"@id": f"{base_uri}{entity_id}"},
                }
                graph.append(prop_node)
                if isinstance(prop_data, dict):
                    # Verificar si es estructura de nivel 2
                    is_level2 = any(
                        key not in ("relacion", "sub_propiedades", "_relacion")
                        for key in prop_data.keys()
                    )
                    
                    if is_level2:
                        # Estructura de nivel 2: {prop_nivel2: {"sub_propiedades": [...]}}
                        for level2_prop_name, level2_prop_data in prop_data.items():
                            if level2_prop_name in ("relacion", "_relacion"):
                                continue
                            if isinstance(level2_prop_data, dict):
                                level2_prop_id = _slug(level2_prop_name)
                                level2_prop_uri = f"{base_uri}{prop_id}_{level2_prop_id}"
                                level2_prop_node: dict[str, Any] = {
                                    "@id": level2_prop_uri,
                                    "@type": "rdf:Property",
                                    "label": level2_prop_name,
                                    "rdfs:subPropertyOf": {"@id": f"{base_uri}{prop_id}"},
                                }
                                graph.append(level2_prop_node)
                                
                                # Subpropiedades de nivel 2
                                for sub in level2_prop_data.get("sub_propiedades") or []:
                                    sub_id = _slug(sub)
                                    sub_uri = f"{base_uri}{prop_id}_{level2_prop_id}_{sub_id}"
                                    sub_node: dict[str, Any] = {
                                        "@id": sub_uri,
                                        "@type": "rdf:Property",
                                        "label": sub,
                                        "rdfs:subPropertyOf": {"@id": level2_prop_uri},
                                    }
                                    graph.append(sub_node)
                    else:
                        # Propiedad anidada nivel 1 (estructura antigua)
                        for sub in prop_data.get("sub_propiedades") or []:
                            sub_id = _slug(sub)
                            sub_uri = f"{base_uri}{prop_id}_{sub_id}"
                            sub_node: dict[str, Any] = {
                                "@id": sub_uri,
                                "@type": "rdf:Property",
                                "label": sub,
                                "rdfs:subPropertyOf": {"@id": f"{base_uri}{prop_id}"},
                            }
                            graph.append(sub_node)
    
    # Agregar relaciones
    for rel_type, source, target in relations:
        rel_id = rel_type.replace(" ", "_").replace('"', "").replace("/", "_")
        rel_node: dict[str, Any] = {
            "@id": f"{base_uri}{rel_id}",
            "@type": "rdf:Property",
            "label": rel_type,
        }
        graph.append(rel_node)
    
    # Agregar metadatos
    if metadata:
        domain_node: dict[str, Any] = {
            "@id": f"{base_uri}Domain",
            "@type": "rdfs:Resource",
        }
        if "title" in metadata:
            domain_node["label"] = metadata["title"]
        if "description" in metadata:
            domain_node["comment"] = metadata["description"]
        graph.append(domain_node)
    
    # Construir documento JSON-LD
    result = {
        **context,
        "@graph": graph,
    }
    
    return json.dumps(result, ensure_ascii=False, indent=2)


def _extract_context(domain_content: str) -> str:
    """Extrae el contexto del dominio."""
    lines = domain_content.split("\n")
    for line in lines:
        if "CONTEXTO DEL DOMINIO" in line.upper():
            # Extraer el contexto después de los dos puntos
            if ":" in line:
                return line.split(":", 1)[1].strip()
    return ""


def _extract_relations(domain_content: str) -> list[tuple[str, str, str]]:
    """
    Extrae relaciones del contenido del dominio.
    
    Returns:
        Lista de tuplas (tipo_relacion, entidad_origen, entidad_destino)
    """
    relations: list[tuple[str, str, str]] = []
    lines = domain_content.split("\n")
    
    in_relations_section = False
    in_entity_relations = False
    in_property_relations = False
    
    for line in lines:
        stripped = line.strip()
        
        if "RELACIONES DISPONIBLES" in stripped.upper():
            in_relations_section = True
            continue
        
        if in_relations_section and "RELACIONES ENTRE ENTIDADES" in stripped.upper():
            in_entity_relations = True
            in_property_relations = False
            continue
        
        if in_relations_section and "RELACIONES PARA PROPIEDADES" in stripped.upper():
            in_entity_relations = False
            in_property_relations = True
            continue
        
        if in_entity_relations and stripped.startswith("- "):
            # Formato: "relación": Entidad1 -> Entidad2
            # o: "relación" / "variante": Entidad1 -> Entidad2
            rel_line = stripped[2:].strip()
            
            # Buscar patrón de relación
            # Puede ser: "relación": Entidad -> Entidad
            # o: "relación" / "variante": Entidad -> Entidad
            match = re.search(r'"([^"]+)"\s*:?\s*([^->]+)\s*->\s*(.+)', rel_line)
            if match:
                rel_type = match.group(1).strip()
                source = match.group(2).strip()
                target = match.group(3).strip()
                
                # Limpiar source y target (pueden tener "/" para variantes)
                source = source.split("/")[0].strip()
                target = target.split("/")[0].strip()
                
                relations.append((rel_type, source, target))
        
        if in_property_relations and stripped.startswith("- "):
            # Similar formato para relaciones de propiedades
            rel_line = stripped[2:].strip()
            match = re.search(r'"([^"]+)"\s*:?\s*([^->]+)\s*->\s*(.+)', rel_line)
            if match:
                rel_type = match.group(1).strip()
                source = match.group(2).strip()
                target = match.group(3).strip()
                
                source = source.split("/")[0].strip()
                target = target.split("/")[0].strip()
                
                relations.append((rel_type, source, target))
    
    return relations


def _relations_from_spec(domain_spec: DomainSpec) -> list[tuple[str, str, str]]:
    """Convierte relaciones normalizadas en tuplas simples."""
    relations: list[tuple[str, str, str]] = []
    for rel in domain_spec.entity_relations + domain_spec.property_relations:
        source = rel.source_types[0] if rel.source_types else ""
        target = rel.target_types[0] if rel.target_types else ""
        if source and target:
            relations.append((rel.name, source, target))
    return relations
