"""Loader for domain and role definitions from Markdown files."""

from __future__ import annotations

import re
import sys
from pathlib import Path
from typing import Any

try:
    import yaml
except ImportError:
    yaml = None


def _get_config_dir(config_dir: Path | str | None = None) -> Path:
    """
    Obtiene la ruta al directorio config/.
    
    Args:
        config_dir: Ruta al directorio de configuración. Si es None, usa el directorio
                    por defecto relativo a la raíz del proyecto.
    
    Returns:
        Path al directorio de configuración
    """
    if config_dir is not None:
        return Path(config_dir)
    
    # Find project root by looking for pyproject.toml or README.md
    current_file = Path(__file__).resolve()
    current_dir = current_file.parent
    
    # Walk up the directory tree to find project root
    for parent in [current_dir] + list(current_dir.parents):
        # Check for project root markers
        if (parent / "pyproject.toml").exists() or (parent / "README.md").exists():
            config_path = parent / "config"
            if config_path.exists():
                return config_path
    
    # Fallback: use relative path from current file location
    # Desde src/ontology_explorer/prompt/loader.py
    # Subir: prompt -> ontology_explorer -> src -> OntologyExplorer -> config
    return current_file.parent.parent.parent.parent / "config"


def parse_frontmatter(content: str) -> tuple[dict[str, Any], str]:
    """
    Parsea el frontmatter YAML y extrae el contenido restante.
    
    Retorna:
        (metadata, content): Tupla con el diccionario de metadatos y el contenido sin frontmatter
    """
    content = content.strip()
    
    # Si no empieza con ---, no hay frontmatter
    if not content.startswith("---"):
        return {}, content
    
    # Buscar el segundo ---
    lines = content.split("\n")
    if len(lines) < 2:
        return {}, content
    
    first_line = lines[0].strip()
    if first_line != "---":
        return {}, content
    
    # Buscar el cierre del frontmatter (segundo ---)
    yaml_lines = []
    content_start_idx = None
    
    for i in range(1, len(lines)):
        line = lines[i]
        if line.strip() == "---":
            content_start_idx = i + 1
            break
        yaml_lines.append(line)
    
    if content_start_idx is None:
        # No se encontró el cierre, tratar todo como contenido
        return {}, content
    
    yaml_content = "\n".join(yaml_lines).strip()
    markdown_content = "\n".join(lines[content_start_idx:]).strip()
    
    # Parsear YAML
    metadata = {}
    if yaml_content:
        if yaml:
            try:
                metadata = yaml.safe_load(yaml_content) or {}
            except Exception:
                # Si falla el parsing, ignorar el frontmatter
                pass
        else:
            # Si no hay yaml instalado, intentar parseo básico
            for line in yaml_content.split("\n"):
                line = line.strip()
                if ":" in line and not line.startswith("#"):
                    key, value = line.split(":", 1)
                    key = key.strip()
                    value = value.strip().strip('"').strip("'")
                    if key and value:
                        metadata[key] = value
    
    return metadata, markdown_content


def load_domain_with_metadata(
    name: str, config_dir: Path | str | None = None
) -> tuple[dict[str, Any], str]:
    """
    Carga un dominio desde config/domains/{name}.md y devuelve metadatos + contenido.
    """
    config_dir_path = _get_config_dir(config_dir)
    domain_file = config_dir_path / "domains" / f"{name}.md"

    if not domain_file.exists():
        available = list_available_domains(config_dir)
        available_str = ", ".join(available) if available else "ninguno"
        raise FileNotFoundError(
            f"Dominio '{name}' no encontrado. "
            f"Dominios disponibles: {available_str}"
        )

    content = domain_file.read_text(encoding="utf-8")
    metadata, domain_content = parse_frontmatter(content)

    if not domain_content.strip():
        raise ValueError(f"El dominio '{name}' está vacío o no tiene contenido válido.")

    return metadata, domain_content


def load_domain(name: str, config_dir: Path | str | None = None) -> str:
    """
    Carga un dominio desde config/domains/{name}.md.
    
    Args:
        name: Nombre del dominio (sin extensión .md)
        config_dir: Ruta al directorio de configuración. Si es None, usa el directorio por defecto.
    
    Returns:
        Contenido del dominio (sin frontmatter)
    
    Raises:
        FileNotFoundError: Si el archivo no existe
        ValueError: Si el archivo está vacío o no tiene contenido válido
    """
    config_dir_path = _get_config_dir(config_dir)
    domain_file = config_dir_path / "domains" / f"{name}.md"
    
    if not domain_file.exists():
        available = list_available_domains(config_dir)
        available_str = ", ".join(available) if available else "ninguno"
        raise FileNotFoundError(
            f"Dominio '{name}' no encontrado. "
            f"Dominios disponibles: {available_str}"
        )
    
    content = domain_file.read_text(encoding="utf-8")
    metadata, domain_content = parse_frontmatter(content)
    
    if not domain_content.strip():
        raise ValueError(f"El dominio '{name}' está vacío o no tiene contenido válido.")
    
    return domain_content


def load_role(name: str, config_dir: Path | str | None = None) -> str:
    """
    Carga un rol desde config/roles/{name}.md.
    
    Args:
        name: Nombre del rol (sin extensión .md)
        config_dir: Ruta al directorio de configuración. Si es None, usa el directorio por defecto.
    
    Returns:
        Contenido del rol (sin frontmatter)
    
    Raises:
        FileNotFoundError: Si el archivo no existe
        ValueError: Si el archivo está vacío o no tiene contenido válido
    """
    config_dir_path = _get_config_dir(config_dir)
    role_file = config_dir_path / "roles" / f"{name}.md"
    
    if not role_file.exists():
        available = list_available_roles(config_dir)
        available_str = ", ".join(available) if available else "ninguno"
        raise FileNotFoundError(
            f"Rol '{name}' no encontrado. "
            f"Roles disponibles: {available_str}"
        )
    
    content = role_file.read_text(encoding="utf-8")
    metadata, role_content = parse_frontmatter(content)
    
    if not role_content.strip():
        raise ValueError(f"El rol '{name}' está vacío o no tiene contenido válido.")
    
    return role_content


def get_domain_metadata(name: str, config_dir: Path | str | None = None) -> dict[str, Any]:
    """
    Obtiene los metadatos (frontmatter) de un dominio.
    
    Args:
        name: Nombre del dominio (sin extensión .md)
        config_dir: Ruta al directorio de configuración. Si es None, usa el directorio por defecto.
    
    Returns:
        Diccionario con los metadatos del dominio
    
    Raises:
        FileNotFoundError: Si el archivo no existe
    """
    config_dir_path = _get_config_dir(config_dir)
    domain_file = config_dir_path / "domains" / f"{name}.md"
    
    if not domain_file.exists():
        available = list_available_domains(config_dir)
        available_str = ", ".join(available) if available else "ninguno"
        raise FileNotFoundError(
            f"Dominio '{name}' no encontrado. "
            f"Dominios disponibles: {available_str}"
        )
    
    content = domain_file.read_text(encoding="utf-8")
    metadata, _ = parse_frontmatter(content)
    return metadata


def get_role_metadata(name: str, config_dir: Path | str | None = None) -> dict[str, Any]:
    """
    Obtiene los metadatos (frontmatter) de un rol.
    
    Args:
        name: Nombre del rol (sin extensión .md)
        config_dir: Ruta al directorio de configuración. Si es None, usa el directorio por defecto.
    
    Returns:
        Diccionario con los metadatos del rol
    
    Raises:
        FileNotFoundError: Si el archivo no existe
    """
    config_dir_path = _get_config_dir(config_dir)
    role_file = config_dir_path / "roles" / f"{name}.md"
    
    if not role_file.exists():
        available = list_available_roles(config_dir)
        available_str = ", ".join(available) if available else "ninguno"
        raise FileNotFoundError(
            f"Rol '{name}' no encontrado. "
            f"Roles disponibles: {available_str}"
        )
    
    content = role_file.read_text(encoding="utf-8")
    metadata, _ = parse_frontmatter(content)
    return metadata


def list_available_domains(config_dir: Path | str | None = None) -> list[str]:
    """
    Lista todos los dominios disponibles.
    
    Args:
        config_dir: Ruta al directorio de configuración. Si es None, usa el directorio por defecto.
    
    Returns:
        Lista de nombres de dominios (sin extensión .md)
    """
    config_dir_path = _get_config_dir(config_dir)
    domains_dir = config_dir_path / "domains"
    
    if not domains_dir.exists():
        return []
    
    domains = []
    for file in domains_dir.glob("*.md"):
        domains.append(file.stem)
    
    return sorted(domains)


def list_available_roles(config_dir: Path | str | None = None) -> list[str]:
    """
    Lista todos los roles disponibles.
    
    Args:
        config_dir: Ruta al directorio de configuración. Si es None, usa el directorio por defecto.
    
    Returns:
        Lista de nombres de roles (sin extensión .md)
    """
    config_dir_path = _get_config_dir(config_dir)
    roles_dir = config_dir_path / "roles"
    
    if not roles_dir.exists():
        return []
    
    roles = []
    for file in roles_dir.glob("*.md"):
        roles.append(file.stem)
    
    return sorted(roles)
