"""Prompt templates used for extraction."""

PROMPT_ROL = """
Actúa como analista experto en Venture Capital. Extrae entidades y relaciones
del siguiente artículo sobre startups, inversiones y ecosistema emprendedor.
"""

PROMPT_DOMINIO = """
CONTEXTO DEL DOMINIO: Ecosistema de Startups y Venture Capital en Latinoamérica

TIPOS DE ENTIDADES DISPONIBLES:
- Persona: Personas humanas mencionadas (fundadores, inversores, mentores, ejecutivos, gerentes, etc.)
- Organización: Son organizaciones en general, empresas, instituciones, corporaciones, universidades, instituciones educativas,ONGs, fondos de inversión, aceleradoras, incubadoras,  etc.
    - Ubicación: Ubicaciones geográficas (ciudades, países, regiones)
    - Tipo: Tipo de organización (startup, empresa, institución, ONG, etc.)
    - Sector: Sectores o verticales de negocio (B2B Software, Healthcare, Smart City, Climate, etc.)
- Evento: Eventos, conferencias, programas de aceleración, lanzamientos, encuentros, etc.
    - Ubicación: Ubicaciones geográficas (ciudades, países, regiones)
    - Tipo: Tipo de evento (conferencia, programa de aceleración, lanzamiento, encuentro, etc.)
- Ronda de Inversión:  eventos de levantamiento de capital, acuerdos de inversión, Etapas de inversión (Seed, Series A, B, etc.)
    - Monto: Cantidades monetarias mencionadas
    - Fecha: Fechas o períodos temporales mencionados
    - Ubicación: Ubicaciones geográficas (ciudades, países, regiones)
- Programa: Programas de aceleración, incubación o apoyo a emprendedores
    - Monto: Cantidades monetarias mencionadas
    - Fecha: Fechas o períodos temporales mencionados
    - Ubicación: Ubicaciones geográficas (ciudades, países, regiones)

RELACIONES DISPONIBLES:

RELACIONES ENTRE ENTIDADES:
- "invierte en": Organización -> Organización 
- "fundó": Persona -> Organización
- "trabaja en" / "pertenece a": Persona -> Organización
- "participa en": Organización/Persona -> Evento/Programa/Ronda de Inversión
- "organiza": Organización -> Evento/Programa/Ronda de Inversión
- "lidera": Persona -> Organización/Evento/Programa
- "colabora con": Organización -> Organización
- "apoya": Organización -> Organización/Evento/Programa
- "incluye": Evento/Programa -> Organización/Persona/Ronda de Inversión
- "inversor del evento": Organización -> Ronda de Inversión
- "startup del evento": Organización -> Ronda de Inversión

RELACIONES PARA PROPIEDADES (estas se tratarán como atributos de las entidades):
- "tiene ubicación" / "ubicado en": Organización/Evento/Ronda de Inversión/Programa -> Ubicación
- "tiene tipo" / "tipo de": Organización/Evento -> Tipo
- "tiene sector" / "sector de": Organización -> Sector
- "tiene monto" / "monto de" / "monto del evento": Ronda de Inversión/Programa -> Monto
- "tiene fecha" / "fecha de" / "fecha del evento": Ronda de Inversión/Programa -> Fecha
- "tiene moneda" / "moneda de" / "moneda del evento": Ronda de Inversión -> Moneda (opcional, si se menciona la moneda)

NOTA: Las relaciones de propiedades pueden expresarse con cualquiera de las variantes mostradas.
Por ejemplo, "tiene ubicación" y "ubicado en" son equivalentes y ambas indican la propiedad Ubicación.

PROPIEDADES ANIDADAS:
Algunas entidades pueden tener propiedades complejas con sub-propiedades.
Las propiedades anidadas se identifican por múltiples niveles de indentación en el dominio.
Una propiedad anidada puede tener sub-propiedades que pueden ser referencias a otras entidades o valores literales.
"""

PROMPT_PATRONES = """
PATRONES ESPECIALES A CONSIDERAR:
- Conjunciones "y", "e", "o" o incluso una "," o ";": Pueden unir dos entidades diferentes aunque no 
  siempre indican entidades separadas. 
  Ejemplo: "Juan Juez e hijos" es UNA entidad (Organización), no dos. 
  Pero "Crofam y Energia Sur" son dos
- Paréntesis con organización: "Nombre (Organización)" indica que la persona 
  pertenece a esa organización. Ejemplo: "Juan Fernandez (Emprelatam)" → 
  extrae "Juan Fernandez" como Persona, "Emprelatam" como Organización, 
  y la relación correspondiente según el dominio: Juan Fernandez -> Emprelatam.
- IMPORTANTE: Si aparece "Persona (Organización)", SEPÁRALOS en 2 entidades distintas (no lo dejes como un solo string).
- Nombres compuestos: Mantén el nombre completo como aparece en el texto.
- Abreviaciones: Si hay una forma completa y abreviada, usa la más completa.
"""

PROMPT_TAREA = """
Tarea:
1. Identifica todas las entidades mencionadas en el artículo (personas, organizaciones,
   eventos, lugares, sectores, etc.). Usa EXCLUSIVAMENTE los tipos definidos arriba.
   Extrae los NOMBRES REALES del artículo, NO los nombres de los tipos.

2. Identifica las relaciones entre estas entidades usando EXCLUSIVAMENTE las relaciones
   definidas arriba.

3. Para las entidades, usa los tipos del contexto del dominio arriba. Extrae SOLO
   nombres que aparezcan REALMENTE en el artículo (no uses nombres genéricos de tipos).

4. Para las relaciones, usa EXCLUSIVAMENTE los nombres de relaciones definidos arriba.
   IMPORTANTE: Usa SIEMPRE el nombre CANÓNICO de cada relación (no uses aliases).
   REGLA CRÍTICA: Cada relación DEBE tener exactamente 3 elementos:
   `[relación, nombre_entidad_origen, nombre_entidad_destino]`
   - `nombre_entidad_origen` DEBE ser un nombre exacto de una entidad listada en `entities`
   - `nombre_entidad_destino` DEBE ser un nombre exacto de una entidad listada en `entities`
   - NUNCA uses nombres de tipos genéricos como "Evento", "Organización", "Persona", etc.
   - NUNCA uses nombres que no estén en la lista de `entities`
   - Ejemplo CORRECTO: ["nombre_relacion", "Nombre Entidad 1", "Nombre Entidad 2"]
   - Ejemplo INCORRECTO: ["organiza", "Endeavor Biobío", "Evento"] (Evento no es una entidad, debe ser el nombre específico de un evento)

5. PROPIEDADES: Algunas entidades tienen propiedades (marcadas por indentación en el dominio).
   - Si puedes, devuelve las propiedades en el campo `properties` además de `relations`.
   - En `relations`, usa SOLO las relaciones canónicas definidas en el dominio para propiedades
     (generalmente "tiene [propiedad]" o la relación definida para la propiedad).
   - El valor de la propiedad puede ser una entidad (si existe en `entities`) o un literal (string).
   - Ejemplo genérico (en relations): ["tiene Y", "X", "Z", evidencia]

5.5. PROPIEDADES ANIDADAS: Si una entidad tiene propiedades anidadas (múltiples niveles de indentación):
   - Extrae la relación principal correspondiente a la propiedad anidada (definida en el dominio con el formato: relación: "nombre_relación")
   - Para cada sub-propiedad que NO sea referencia a entidad, crea una relación usando el patrón "tiene [nombre_sub_propiedad]"
   - El destino de estas relaciones es el valor literal extraído del texto
   - Todas las relaciones que pertenecen a la misma instancia de propiedad anidada deben compartir la misma evidencia o evidencias relacionadas del mismo contexto
   - Ejemplo genérico: Si una entidad tiene una propiedad anidada "X" con sub-propiedades "desde cuando" y "hasta cuando", y el texto menciona "desde Y hasta Z", extrae:
     * La relación principal (según lo definido en el dominio)
     * ["tiene desde cuando", "nombre_entidad", "Y", evidencia]
     * ["tiene hasta cuando", "nombre_entidad", "Z", evidencia]

6. EVIDENCIAS (OBLIGATORIO): Para cada entidad, propiedad y relación que extraigas, DEBES
   proporcionar evidencia que fundamente tu decisión. La evidencia consiste en:
   - El nombre del documento (se te proporcionará en el prompt)
   - La oración o frase exacta del texto que fundamenta la extracción
   - La evidencia debe ser la oración completa o frase relevante del artículo que menciona
     explícitamente la entidad, propiedad o relación
   - Si una entidad, propiedad o relación aparece múltiples veces, puedes incluir múltiples
     evidencias (una por cada mención relevante)

7. Sé exhaustivo pero preciso. Solo incluye entidades y relaciones que estén
   explícitamente mencionadas o claramente inferibles del texto.
"""

PROMPT_OUTPUT_JSON = """
FORMATO DE SALIDA - JSON:
Responde ÚNICAMENTE con JSON válido usando UTF-8 y la estructura exacta:
{{
  "model": "{model_name}",
  "entities": [
    ["name exacto", "TipoEntidad", {{"document": "nombre_documento", "sentence": "oración que fundamenta la entidad"}}]
  ],
  "properties": [
    ["name_entidad", "nombre_propiedad", "valor", {{"document": "nombre_documento", "sentence": "oración que fundamenta la propiedad"}}]
  ],
  "relations": [
    ["NombreRelacion", "name origen", "name destino", {{"document": "nombre_documento", "sentence": "oración que fundamenta la relación"}}]
  ]
}}

IMPORTANTE SOBRE EVIDENCIAS:
- Cada entidad DEBE incluir un objeto de evidencia con "document" (nombre del documento proporcionado) y "sentence" (oración exacta del texto).
- El campo "properties" es opcional; si no hay propiedades, puedes omitirlo o dejarlo como lista vacía.
- Cada relación DEBE incluir un objeto de evidencia con "document" y "sentence".
- La "sentence" debe ser la oración o frase completa del artículo que menciona explícitamente la entidad o relación.
- Si una entidad o relación aparece múltiples veces, puedes incluir múltiples evidencias como array: [{{"document": "...", "sentence": "..."}}, {{"document": "...", "sentence": "..."}}]

VALIDACIÓN FINAL (antes de responder):
- La respuesta debe ser SOLO un JSON válido (sin texto extra).
- Todas las entidades deben tener exactamente 3 elementos: [nombre, tipo, evidencia].
- Todas las propiedades deben tener exactamente 4 elementos: [entidad, propiedad, valor, evidencia].
- Todas las relaciones deben tener exactamente 4 elementos: [relación, origen, destino, evidencia].
- Origen y destino deben existir en "entities". Si querés usar una entidad en una relación y no está, AGREGALA a "entities".
- No uses como nombres de entidad palabras genéricas/tipos: "Evento", "Organización", "Persona", "Programa", etc. (si necesitás un evento, poné un nombre específico del artículo).
- Para literales (fecha/monto): el literal va como tercer elemento (string) y el segundo elemento es una entidad real.
- NO dejes "relations" vacío si hay al menos 1 relación clara en el texto. Prioriza las relaciones definidas en el dominio que sean más relevantes según el contenido.
- Las evidencias son OBLIGATORIAS. No omitas el campo de evidencia en ninguna entidad o relación.
- No agregues texto fuera del JSON (sin comentarios, explicaciones ni marcadores).
"""
