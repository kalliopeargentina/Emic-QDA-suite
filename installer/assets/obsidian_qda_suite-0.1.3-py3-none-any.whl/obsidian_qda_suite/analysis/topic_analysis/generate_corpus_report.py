"""
Corpus-level topic analysis report generator.

This module generates topic analysis reports for folders of markdown files,
performing consolidated corpus-level analysis.
"""

import sys
import numpy as np
from pathlib import Path
from collections import Counter

# Import from our new modules - handle both relative and absolute imports
try:
    # Try relative imports first (when running as package)
    from .corpus_processing import (
        extract_documents_from_folder,
        prepare_corpus_for_analysis,
        get_corpus_statistics
    )
    from .text_processing import extract_text_from_markdown_content
    from .nlp_utils import (
        get_stopwords_set,
        detect_language,
        load_spacy_model,
        load_custom_stopwords,
        load_seed_words_from_markdown,
        log_language_info
    )
    from .text_processing import preprocess_text, analyze_text_statistics
    from .config import DEFAULT_CONFIG, VERBOSE, DEBUG_MODE
except ImportError:
    # Fallback to absolute imports (when running directly)
    import sys
    from pathlib import Path
    current_file = Path(__file__).resolve()
    parent_dir = current_file.parent
    
    # Add parent directory to path if not already there
    if str(parent_dir) not in sys.path:
        sys.path.insert(0, str(parent_dir))
    
    from corpus_processing import (
        extract_documents_from_folder,
        prepare_corpus_for_analysis,
        get_corpus_statistics
    )
    from text_processing import extract_text_from_markdown_content
    from nlp_utils import (
        get_stopwords_set,
        detect_language,
        load_spacy_model,
        load_custom_stopwords,
        load_seed_words_from_markdown,
        log_language_info
    )
    from text_processing import preprocess_text, analyze_text_statistics
    from config import DEFAULT_CONFIG, VERBOSE, DEBUG_MODE




def generate_corpus_report(folder_path, output_path, n_topics=None, method='lda', 
                           language='auto', images_dir=None, custom_stopwords_file=None,
                           seed_words_file=None, hdp_gamma=1.0, hdp_alpha=1.0,
                           top2vec_embedding_model='all-MiniLM-L6-v2',
                           bertopic_min_topic_size=10, bertopic_top_n_words=10,
                           bertopic_diversity=0.0, bertopic_calculate_probabilities=True,
                           bertopic_embedding_model=None, recursive=True, file_pattern='*.md'):
    """
    Generate topic analysis report for a corpus (folder of markdown files).
    
    Parameters match generate_report but folder_path is a directory instead of a file.
    """
    # Import functions from modular structure
    try:
        from .methods.modeling import perform_topic_modeling
    except ImportError:
        try:
            from methods.modeling import perform_topic_modeling
        except ImportError:
            raise ImportError("Could not import perform_topic_modeling from methods.modeling")
    
    try:
        from .visualizations import (
            create_topic_distribution_chart,
            create_topic_word_chart,
            create_topic_heatmap,
            create_word_frequency_chart,
            create_word_cloud,
            create_topic_map,
            create_word_topic_network,
            create_topic_cooccurrence_network,
            create_word_cooccurrence_network
        )
    except ImportError:
        try:
            from visualizations import (
                create_topic_distribution_chart,
                create_topic_word_chart,
                create_topic_heatmap,
                create_word_frequency_chart,
                create_word_cloud,
                create_topic_map,
                create_word_topic_network,
                create_topic_cooccurrence_network,
                create_word_cooccurrence_network
            )
        except ImportError:
            raise ImportError("Could not import visualization functions from visualizations")
    
    try:
        from .report.templates import generate_markdown_report
    except ImportError:
        try:
            from report.templates import generate_markdown_report
        except ImportError:
            raise ImportError("Could not import generate_markdown_report from report.templates")
    
    try:
        from .nlp_utils import determine_optimal_topics
    except ImportError:
        try:
            from nlp_utils import determine_optimal_topics
        except ImportError:
            raise ImportError("Could not import determine_optimal_topics from nlp_utils")
    
    from nltk.stem import WordNetLemmatizer
    
    print(f"Reading corpus from folder: {folder_path}")
    
    # Extract documents from folder
    folder_path_obj = Path(folder_path)
    documents = extract_documents_from_folder(
        folder_path_obj,
        recursive=recursive,
        file_pattern=file_pattern
    )
    
    print(f"Found {len(documents)} documents in corpus")
    
    # Get corpus statistics
    corpus_stats = get_corpus_statistics(documents)
    print(f"Corpus statistics:")
    print(f"  - Total documents: {corpus_stats['num_documents']}")
    print(f"  - Total characters: {corpus_stats['total_characters']:,}")
    print(f"  - Average document length: {corpus_stats['avg_document_length']:.0f} chars")
    
    # Prepare corpus for analysis (split into sentences)
    all_sentences, document_labels = prepare_corpus_for_analysis(documents)
    print(f"Extracted {len(all_sentences)} sentences from corpus")
    
    # Combine all documents for full text
    raw_text = ' '.join(doc['clean_text'] for doc in documents)
    
    # Validate text length
    min_text_len = DEFAULT_CONFIG['text_processing']['min_text_length']
    if len(raw_text.strip()) < min_text_len:
        print(f"Error: Corpus text content is too short for meaningful topic analysis (minimum {min_text_len} characters)")
        sys.exit(1)
    
    # Load custom stopwords if provided
    custom_stopwords = None
    if custom_stopwords_file:
        print(f"Loading custom stopwords from: {custom_stopwords_file}")
        custom_stopwords = load_custom_stopwords(custom_stopwords_file)
        print(f"Loaded {len(custom_stopwords)} custom stopwords")
    
    # Auto-detect language if not specified
    if language == 'auto' or language is None:
        print("Auto-detecting language...")
        detected_lang = detect_language(raw_text)
        language = detected_lang
        log_language_info(language, detected=True, verbose=VERBOSE)
    else:
        log_language_info(language, detected=False, verbose=VERBOSE)
    
    # Load spaCy model for lemmatization if available
    lemmatizer = None
    try:
        import spacy
        HAS_SPACY = True
    except (ImportError, OSError):
        HAS_SPACY = False
    
    if HAS_SPACY:
        if VERBOSE:
            print(f"Loading spaCy model for {language}...")
        lemmatizer = load_spacy_model(language)
        if lemmatizer:
            if VERBOSE:
                print(f"Using spaCy model for lemmatization")
        else:
            if VERBOSE:
                print(f"spaCy model not available, using NLTK WordNetLemmatizer")
            lemmatizer = WordNetLemmatizer()
    else:
        if VERBOSE:
            print("spaCy not available, using NLTK WordNetLemmatizer")
        lemmatizer = WordNetLemmatizer()
    
    # Preprocess each sentence
    print("Preprocessing text...")
    processed_sentences = []
    filtered_labels = []
    
    min_processed_len = DEFAULT_CONFIG['text_processing']['min_processed_length']
    
    if DEBUG_MODE:
        verification_stopwords = get_stopwords_set(language, custom_stopwords)
        for i, s in enumerate(all_sentences):
            processed = preprocess_text(s, language, custom_stopwords, lemmatizer)
            
            processed_words = processed.split()
            stopwords_found = [w for w in processed_words if w.lower().strip() in verification_stopwords]
            
            if stopwords_found:
                print(f"DEBUG: Found stopwords in processed text: {stopwords_found[:5]}")
                processed_words_clean = [w for w in processed_words if w.lower().strip() not in verification_stopwords]
                processed = ' '.join(processed_words_clean)
            
            if len(processed.strip()) > min_processed_len:
                processed_sentences.append(processed)
                filtered_labels.append(document_labels[i] if i < len(document_labels) else "Document")
    else:
        for i, s in enumerate(all_sentences):
            processed = preprocess_text(s, language, custom_stopwords, lemmatizer)
            if len(processed.strip()) > min_processed_len:
                processed_sentences.append(processed)
                filtered_labels.append(document_labels[i] if i < len(document_labels) else "Document")
    
    if len(processed_sentences) < 2:
        print("Error: Not enough processed text segments for topic analysis")
        sys.exit(1)
    
    # Process full text if needed for topic detection
    processed_text = None
    min_processed_text_len = DEFAULT_CONFIG['text_processing']['min_processed_text_length']
    
    needs_full_text = (n_topics is None and 
                      method.lower() not in ['hdp', 'top2vec', 'bertopic'])
    
    if needs_full_text:
        processed_text = preprocess_text(raw_text, language, custom_stopwords, lemmatizer)
        if len(processed_text.strip()) < min_processed_text_len:
            print("Error: After preprocessing, corpus text is too short for analysis")
            sys.exit(1)
    
    # Load seed words if using guided-lda or corex
    seed_topics = None
    if method.lower() in ['guided-lda', 'corex']:
        if seed_words_file:
            seed_topics = load_seed_words_from_markdown(seed_words_file)
            print(f"Loaded seed words for {len(seed_topics)} topics")
            for topic_name, words in seed_topics.items():
                print(f"  - {topic_name}: {', '.join(words[:5])}{'...' if len(words) > 5 else ''}")
        elif method.lower() == 'guided-lda':
            print("Error: Guided LDA requires --seed-words-file parameter")
            sys.exit(1)
        elif method.lower() == 'corex':
            print("Note: CorEx can work without seed words, but seed words (anchors) improve topic quality")
    
    # Determine optimal number of topics (same logic as generate_report)
    if n_topics is None:
        if method.lower() == 'hdp':
            print("Using HDP - number of topics will be discovered automatically")
        elif method.lower() == 'corex':
            if seed_topics:
                num_seed_topics = len(seed_topics)
                print(f"Found {num_seed_topics} topics with seed words (anchors)")
                n_topics = num_seed_topics
                print(f"Using {n_topics} topics based on seed words")
            else:
                n_topics = determine_optimal_topics(processed_text)
                print(f"Auto-detected optimal number of topics for CorEx: {n_topics}")
        elif method.lower() == 'lsi' or method.lower() == 'lsa':
            if n_topics is None:
                n_topics = determine_optimal_topics(processed_text)
                print(f"Auto-detected optimal number of topics for LSI/LSA: {n_topics}")
            else:
                print(f"Using {n_topics} topics for LSI/LSA")
        elif method.lower() == 'top2vec':
            print(f"Top2Vec using embedding model: {top2vec_embedding_model}")
            if n_topics is None:
                print("Top2Vec will discover topics automatically")
                n_topics = None
            else:
                print(f"Using Top2Vec with target of {n_topics} topics")
        elif method.lower() == 'bertopic':
            if n_topics is None:
                bertopic_nr_topics = 'auto'
                print("BERTopic will discover topics automatically")
            else:
                bertopic_nr_topics = n_topics
                print(f"BERTopic will target {n_topics} topics")
            print(f"BERTopic parameters: nr_topics={bertopic_nr_topics}, min_topic_size={bertopic_min_topic_size}, top_n_words={bertopic_top_n_words}, diversity={bertopic_diversity}")
        elif method.lower() == 'guided-lda' and seed_topics:
            num_seed_topics = len(seed_topics)
            print(f"Found {num_seed_topics} topics with seed words")
            optimal_total = determine_optimal_topics(processed_text, min_topics=num_seed_topics, max_topics=15)
            print(f"Optimal total topics (by coherence): {optimal_total}")
            n_topics = optimal_total
            if optimal_total > num_seed_topics:
                print(f"Auto-detecting {optimal_total - num_seed_topics} additional topics beyond seed words")
            else:
                print(f"Using {num_seed_topics} topics total")
        else:
            n_topics = determine_optimal_topics(processed_text)
            print(f"Auto-detected optimal number of topics: {n_topics}")
    else:
        if method.lower() == 'hdp':
            print(f"Using HDP with --topics={n_topics} as maximum topics limit")
        else:
            print(f"Using {n_topics} topics")
    
    # Perform topic modeling
    print(f"Performing {method.upper()} topic modeling on corpus...")
    
    topics, model, vectorizer, W = perform_topic_modeling(
        processed_sentences,
        n_topics=n_topics,
        method=method,
        seed_topics=seed_topics,
        hdp_gamma=hdp_gamma,
        hdp_alpha=hdp_alpha,
        hdp_min_topics=2,
        top2vec_embedding_model=top2vec_embedding_model,
        bertopic_min_topic_size=bertopic_min_topic_size,
        bertopic_top_n_words=bertopic_top_n_words,
        bertopic_diversity=bertopic_diversity,
        bertopic_calculate_probabilities=bertopic_calculate_probabilities,
        bertopic_embedding_model=bertopic_embedding_model,
        language=language
    )
    
    # Analyze text statistics
    stats = analyze_text_statistics(raw_text)
    
    # Enhance corpus_stats with word and sentence statistics from stats
    corpus_stats['total_documents'] = corpus_stats['num_documents']
    corpus_stats['total_words'] = stats['total_words']
    corpus_stats['total_sentences'] = stats['total_sentences']
    if corpus_stats['num_documents'] > 0:
        corpus_stats['avg_words_per_document'] = stats['total_words'] / corpus_stats['num_documents']
        corpus_stats['avg_sentences_per_document'] = stats['total_sentences'] / corpus_stats['num_documents']
    else:
        corpus_stats['avg_words_per_document'] = 0
        corpus_stats['avg_sentences_per_document'] = 0.0
    
    # Calculate word frequencies
    if processed_text is None:
        processed_text = preprocess_text(raw_text, language, custom_stopwords, lemmatizer)
    words = processed_text.split()
    word_freq = Counter(words)
    top_words = word_freq.most_common(50)
    
    # Create output directory for graphs
    if images_dir:
        graphs_dir = Path(images_dir)
        graphs_dir.mkdir(parents=True, exist_ok=True)
    else:
        output_dir = Path(output_path).parent
        graphs_dir = output_dir / f"{Path(output_path).stem}_graphs"
        graphs_dir.mkdir(exist_ok=True)
    
    # Generate visualizations
    print("Generating visualizations...")
    chart_paths = {}
    
    # Topic distribution chart
    chart_paths['distribution'] = create_topic_distribution_chart(
        W, graphs_dir / 'topic_distribution.png'
    )
    
    # Topic words chart
    chart_paths['words'] = create_topic_word_chart(
        topics, graphs_dir / 'topic_words.png'
    )
    
    # Heatmap - aggregate by document for corpus analysis
    # W has shape (n_sentences, n_topics), we need to aggregate by document
    unique_docs = []
    doc_indices = []
    doc_to_idx = {}
    
    # Create mapping from document labels to indices
    for i, label in enumerate(filtered_labels):
        if label not in doc_to_idx:
            doc_to_idx[label] = len(unique_docs)
            unique_docs.append(label)
        doc_indices.append(doc_to_idx[label])
    
    # Aggregate topic distributions by document (average)
    n_docs = len(unique_docs)
    n_topics = W.shape[1] if len(W.shape) > 1 else len(topics)
    W_doc = np.zeros((n_docs, n_topics))
    doc_counts = np.zeros(n_docs)
    
    for i, doc_idx in enumerate(doc_indices):
        if i < len(W):
            W_doc[doc_idx] += W[i]
            doc_counts[doc_idx] += 1
    
    # Normalize by document count
    for doc_idx in range(n_docs):
        if doc_counts[doc_idx] > 0:
            W_doc[doc_idx] /= doc_counts[doc_idx]
    
    # Use document names for labels (truncate if needed)
    doc_labels = [doc[:30] + '...' if len(doc) > 30 else doc for doc in unique_docs]
    
    # Heatmap showing documents instead of sections
    chart_paths['heatmap'] = create_topic_heatmap(
        W_doc, graphs_dir / 'topic_heatmap.png', section_labels=doc_labels
    )
    
    # Word frequency chart
    chart_paths['word_freq'] = create_word_frequency_chart(
        top_words, graphs_dir / 'word_frequency.png'
    )
    
    # Word cloud
    chart_paths['wordcloud'] = create_word_cloud(
        top_words, graphs_dir / 'word_cloud.png', title="Word Cloud - Most Frequent Words"
    )
    
    # Topic map
    chart_paths['topic_map'] = create_topic_map(
        topics, W, graphs_dir / 'topic_map.png'
    )
    
    # Word-Topic Network
    chart_paths['word_topic_network'] = create_word_topic_network(
        topics, graphs_dir / 'word_topic_network.png'
    )
    
    # Topic Co-occurrence Network
    chart_paths['topic_cooccurrence_network'] = create_topic_cooccurrence_network(
        topics, W, graphs_dir / 'topic_cooccurrence_network.png'
    )
    
    # Word Co-occurrence Network
    chart_paths['word_cooccurrence_network'] = create_word_cooccurrence_network(
        topics, graphs_dir / 'word_cooccurrence_network.png'
    )
    
    # Generate markdown report
    print("Generating markdown report...")
    try:
        generate_markdown_report(
            output_path,
            topics,
            stats,
            top_words[:20],
            chart_paths,
            str(folder_path),  # Source is now a folder path
            images_dir,
            method=method,
            n_topics=n_topics,
            custom_stopwords_file=custom_stopwords_file,
            seed_words_file=seed_words_file,
            hdp_gamma=hdp_gamma,
            hdp_alpha=hdp_alpha,
            top2vec_embedding_model=top2vec_embedding_model,
            bertopic_min_topic_size=bertopic_min_topic_size,
            bertopic_top_n_words=bertopic_top_n_words,
            bertopic_diversity=bertopic_diversity,
            bertopic_calculate_probabilities=bertopic_calculate_probabilities,
            bertopic_embedding_model=bertopic_embedding_model,
            corpus_stats=corpus_stats,
            document_labels=filtered_labels if filtered_labels else None
        )
    except Exception as e:
        print(f"Error generating markdown report: {e}")
        import traceback
        traceback.print_exc()
        raise
    
    print(f"\nCorpus topic analysis complete!")
    print(f"Report saved to: {output_path}")
    print(f"Graphs saved to: {graphs_dir}")

