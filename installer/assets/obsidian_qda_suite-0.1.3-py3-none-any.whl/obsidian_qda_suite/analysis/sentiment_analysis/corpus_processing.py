from pathlib import Path
from typing import List, Dict, Optional
from .text_processing import extract_text_from_markdown_content
from .config import DEFAULTS


def find_markdown_files(folder: Path, recursive: bool, pattern: str) -> List[Path]:
    files = list(folder.rglob(pattern)) if recursive else list(folder.glob(pattern))
    return [f for f in files if f.is_file()]


def extract_documents_from_folder(folder: Path,
                                  recursive: bool = True,
                                  file_pattern: str = "*.md",
                                  min_document_length: Optional[int] = None) -> List[Dict]:
    if min_document_length is None:
        min_document_length = DEFAULTS["min_document_length"]
    if not folder.exists() or not folder.is_dir():
        raise ValueError(f"No existe carpeta: {folder}")
    md_files = find_markdown_files(folder, recursive, file_pattern)
    docs = []
    for md in md_files:
        raw = md.read_text(encoding="utf-8")
        clean = extract_text_from_markdown_content(raw)
        if len(clean.strip()) < min_document_length:
            continue
        try:
            rel = md.relative_to(folder)
        except Exception:
            rel = md.name
        docs.append({
            "file_path": md,
            "file_name": md.stem,
            "raw_text": raw,
            "clean_text": clean,
            "relative_path": rel,
        })
    if not docs:
        raise ValueError(f"No se encontraron documentos válidos en {folder} (patrón: {file_pattern})")
    return docs


