"""OpenAI Whisper transcription: SRT and markdown output."""

import os
import shutil
import subprocess
import tempfile
from datetime import datetime, timedelta
from pathlib import Path
from typing import List, Optional, Tuple

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

from openai import OpenAI

MAX_FILE_SIZE = 25 * 1024 * 1024  # 25 MB


def format_timestamp_srt(seconds: float) -> str:
    """Convert seconds to SRT timestamp (HH:MM:SS,mmm)."""
    td = timedelta(seconds=seconds)
    total_seconds = int(td.total_seconds())
    hours, remainder = divmod(total_seconds, 3600)
    minutes, secs = divmod(remainder, 60)
    milliseconds = int((td.total_seconds() - total_seconds) * 1000)
    return f"{hours:02d}:{minutes:02d}:{secs:02d},{milliseconds:03d}"


def get_api_key(api_key_arg: Optional[str] = None) -> Optional[str]:
    """API key from argument, OPENAI_API_KEY env, or .openai_api_key file."""
    if api_key_arg and api_key_arg.strip():
        return api_key_arg.strip()
    key = os.getenv("OPENAI_API_KEY")
    if key and key.strip():
        return key.strip()
    for p in [Path(".openai_api_key"), Path.home() / ".openai_api_key", Path("config.txt")]:
        if p.exists():
            try:
                with open(p, "r", encoding="utf-8") as f:
                    k = f.read().strip()
                    if k:
                        return k
            except Exception:
                pass
    return None


def transcribe_audio(
    file_path: str,
    api_key: str,
    language: Optional[str] = None,
    model: str = "whisper-1",
) -> object:
    """Transcribe one audio file with OpenAI Whisper. Returns response with .segments and .text."""
    client = OpenAI(api_key=api_key)
    with open(file_path, "rb") as audio_file:
        params: dict = {
            "model": model,
            "file": audio_file,
            "response_format": "verbose_json",
        }
        if language:
            params["language"] = language
        transcript = client.audio.transcriptions.create(**params)
    return transcript


def _get_audio_duration_ffprobe(file_path: str, ffprobe_bin: str = "ffprobe") -> Optional[float]:
    try:
        r = subprocess.run(
            [
                ffprobe_bin,
                "-v", "error",
                "-show_entries", "format=duration",
                "-of", "default=noprint_wrappers=1:nokey=1",
                str(file_path),
            ],
            capture_output=True,
            text=True,
            check=True,
            timeout=10,
        )
        if r.stdout.strip():
            return float(r.stdout.strip())
    except (subprocess.CalledProcessError, FileNotFoundError, ValueError):
        pass
    return None


def _split_audio_chunks(
    input_file: Path,
    output_dir: Path,
    max_size_mb: int,
    ffmpeg_bin: str,
    ffprobe_bin: str,
) -> List[Path]:
    """Split audio into chunks under max_size_mb. Returns list of chunk paths."""
    file_size = input_file.stat().st_size
    max_bytes = max_size_mb * 1024 * 1024
    if file_size <= max_bytes:
        return [input_file]
    duration = _get_audio_duration_ffprobe(str(input_file), ffprobe_bin)
    if duration is None or duration <= 0:
        duration = 3600.0
    bytes_per_sec = file_size / duration
    chunk_duration_sec = (max_bytes * 0.9) / bytes_per_sec
    chunks: List[Path] = []
    start = 0.0
    idx = 0
    while start < duration:
        end = min(start + chunk_duration_sec, duration)
        chunk_path = output_dir / f"chunk_{idx:03d}.mp3"
        cmd = [
            ffmpeg_bin, "-y", "-i", str(input_file),
            "-ss", str(start), "-t", str(end - start),
            "-acodec", "libmp3lame", "-b:a", "64k",
            str(chunk_path),
        ]
        subprocess.run(cmd, capture_output=True, check=True, timeout=300)
        chunks.append(chunk_path)
        idx += 1
        start = end
    return chunks


def generate_srt(segments: List[dict], output_path: str) -> None:
    """Write SRT file from segments (each with 'start', 'end', 'text')."""
    with open(output_path, "w", encoding="utf-8") as f:
        for i, seg in enumerate(segments, start=1):
            f.write(f"{i}\n")
            f.write(f"{format_timestamp_srt(seg['start'])} --> {format_timestamp_srt(seg['end'])}\n")
            f.write(f"{seg.get('text', '').strip()}\n\n")


def generate_markdown(
    segments: List[dict],
    output_path: str,
    title: Optional[str] = None,
    link_target: Optional[str] = None,
) -> None:
    """Write markdown with YAML frontmatter and timestamped list."""
    with open(output_path, "w", encoding="utf-8") as f:
        f.write("---\n")
        f.write(f"date: {datetime.now().strftime('%Y-%m-%d')}\n")
        f.write(f'audio: "[[{link_target or ""}]]"\n')
        f.write("speaker: \n")
        f.write("tags:\n  - transcripción\n")
        f.write("data-type: transcripcion\nread: false\n---\n\n")
        if title:
            f.write(f"# {title}\n\n")
        f.write("## Transcription\n\n")
        for seg in segments:
            start = seg.get("start", 0)
            total_seconds = int(start)
            hours, remainder = divmod(total_seconds, 3600)
            minutes, secs = divmod(remainder, 60)
            display = f"{hours:02d}:{minutes:02d}:{secs:02d}" if hours > 0 else f"{minutes:02d}:{secs:02d}"
            text = seg.get("text", "").strip()
            target = link_target or ""
            f.write(f"- [[{target}#t={total_seconds}|{display}]] {text}\n")
        f.write("\n")


def run_whisper_transcribe(
    audio_path: str,
    output_dir: str,
    output_name: str,
    api_key: str,
    language: Optional[str] = None,
    model: str = "whisper-1",
    chunk_size_mb: int = 24,
    title: Optional[str] = None,
    link_target: Optional[str] = None,
    ffmpeg_bin: str = "ffmpeg",
    ffprobe_bin: str = "ffprobe",
) -> Tuple[str, str]:
    """
    Transcribe audio to SRT and markdown in output_dir with base name output_name.
    Returns (srt_path, md_path). Splits into chunks if file exceeds 25 MB.
    """
    path = Path(audio_path)
    if not path.exists():
        raise FileNotFoundError(f"Audio file not found: {audio_path}")
    out_dir = Path(output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    srt_path = out_dir / f"{output_name}.srt"
    md_path = out_dir / f"{output_name}.md"
    file_size = path.stat().st_size
    if file_size > MAX_FILE_SIZE:
        temp_dir = Path(tempfile.mkdtemp())
        try:
            chunks = _split_audio_chunks(path, temp_dir, chunk_size_mb, ffmpeg_bin, ffprobe_bin)
        except Exception:
            shutil.rmtree(temp_dir, ignore_errors=True)
            raise
        all_segments: List[dict] = []
        t0 = 0.0
        for ch in chunks:
            dur = _get_audio_duration_ffprobe(str(ch), ffprobe_bin) or 0.0
            try:
                resp = transcribe_audio(str(ch), api_key, language=language, model=model)
            finally:
                pass
            if hasattr(resp, "segments") and resp.segments:
                for s in resp.segments:
                    all_segments.append({
                        "start": getattr(s, "start", 0) + t0,
                        "end": getattr(s, "end", 0) + t0,
                        "text": getattr(s, "text", ""),
                    })
            elif hasattr(resp, "text") and resp.text:
                all_segments.append({"start": t0, "end": t0 + dur, "text": resp.text})
            t0 += dur
        shutil.rmtree(temp_dir, ignore_errors=True)
        segments = all_segments
    else:
        resp = transcribe_audio(str(path), api_key, language=language, model=model)
        segments = []
        if hasattr(resp, "segments") and resp.segments:
            for s in resp.segments:
                segments.append({
                    "start": getattr(s, "start", 0),
                    "end": getattr(s, "end", 0),
                    "text": getattr(s, "text", ""),
                })
        elif hasattr(resp, "text") and resp.text:
            segments = [{"start": 0, "end": 0, "text": resp.text}]
        else:
            segments = [{"start": 0, "end": 0, "text": str(resp)}]

    if len(segments) > 1 or (len(segments) == 1 and segments[0].get("start", 0) > 0):
        generate_srt(segments, str(srt_path))
    tit = title or output_name
    if link_target is None:
        try:
            link_target = os.path.relpath(str(path), str(out_dir))
        except (TypeError, ValueError):
            link_target = path.name
    generate_markdown(segments, str(md_path), title=tit, link_target=link_target)
    return str(srt_path), str(md_path)
