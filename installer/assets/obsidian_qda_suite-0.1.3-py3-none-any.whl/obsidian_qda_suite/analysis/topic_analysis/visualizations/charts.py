"""
Chart visualization functions for topic analysis.

This module provides functions for creating various charts and visualizations
for topic modeling results.
"""

import numpy as np
import matplotlib
matplotlib.use('Agg')  # Non-interactive backend
import matplotlib.pyplot as plt

try:
    import seaborn as sns
    HAS_SEABORN = True
    try:
        plt.style.use('seaborn-v0_8-whitegrid')
    except OSError:
        try:
            plt.style.use('seaborn-whitegrid')
        except OSError:
            plt.style.use('default')
            plt.rcParams['axes.grid'] = True
            plt.rcParams['axes.grid.alpha'] = 0.3
    if HAS_SEABORN:
        try:
            sns.set_palette("husl")
        except:
            pass
except ImportError:
    HAS_SEABORN = False
    plt.style.use('default')
    plt.rcParams['axes.grid'] = True
    plt.rcParams['axes.grid.alpha'] = 0.3

try:
    import networkx as nx
    HAS_NETWORKX = True
except ImportError:
    HAS_NETWORKX = False

from sklearn.manifold import TSNE
from sklearn.metrics.pairwise import cosine_similarity


def create_topic_distribution_chart(topic_distributions, output_path):
    """Create a bar chart showing topic distributions."""
    if len(topic_distributions) == 0:
        return None
    
    avg_dist = np.mean(topic_distributions, axis=0)
    
    fig, ax = plt.subplots(figsize=(10, 6))
    bars = ax.bar(range(len(avg_dist)), avg_dist, color='steelblue', alpha=0.8)
    
    for i, (bar, val) in enumerate(zip(bars, avg_dist)):
        height = bar.get_height()
        ax.text(bar.get_x() + bar.get_width()/2., height,
                f'{val:.1%}', ha='center', va='bottom', fontsize=10)
    
    ax.set_xlabel('Topic', fontsize=12)
    ax.set_ylabel('Proportion', fontsize=12)
    ax.set_title('Average Topic Distribution', fontsize=14, fontweight='bold')
    ax.set_xticks(range(len(avg_dist)))
    ax.set_xticklabels([f'Topic {i+1}' for i in range(len(avg_dist))])
    ax.set_ylim(0, max(avg_dist) * 1.15)
    ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda y, _: '{:.0%}'.format(y)))
    ax.grid(axis='y', alpha=0.3, linestyle='--')
    
    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches='tight')
    plt.close()
    return output_path


def create_topic_word_chart(topics, output_path):
    """Create a horizontal bar chart showing top words for each topic."""
    n_topics = len(topics)
    fig, axes = plt.subplots(n_topics, 1, figsize=(10, 4 * n_topics))
    
    if n_topics == 1:
        axes = [axes]
    
    colors = plt.cm.Set3(np.linspace(0, 1, n_topics))
    
    for idx, (topic, ax, color) in enumerate(zip(topics, axes, colors)):
        words = topic['words'][:10]
        weights = topic['weights'][:10]
        
        y_pos = np.arange(len(words))
        bars = ax.barh(y_pos, weights, color=color, alpha=0.8)
        
        ax.set_yticks(y_pos)
        ax.set_yticklabels(words)
        ax.invert_yaxis()
        ax.set_xlabel('Weight', fontsize=11)
        ax.set_title(f'Topic {topic["topic_id"]+1}', fontsize=12, fontweight='bold')
        ax.grid(axis='x', alpha=0.3, linestyle='--')
    
    fig.suptitle('Top Words per Topic', fontsize=14, fontweight='bold', y=0.995)
    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches='tight')
    plt.close()
    return output_path


def create_topic_heatmap(topic_distributions, output_path, section_labels=None):
    """Create a heatmap showing topic distribution across documents or sections."""
    if len(topic_distributions) == 0:
        return None
    
    max_docs = min(50, len(topic_distributions))  # Increased from 20 to 50 for corpus analysis
    data = topic_distributions[:max_docs].T
    
    fig, ax = plt.subplots(figsize=(max(14, max_docs * 0.5), 6))
    
    im = ax.imshow(data, aspect='auto', cmap='viridis', interpolation='nearest')
    
    ax.set_xticks(np.arange(max_docs))
    
    if section_labels and len(section_labels) >= max_docs:
        labels = [label[:40] + '...' if len(label) > 40 else label for label in section_labels[:max_docs]]
        ax.set_xticklabels(labels, rotation=45, ha='right', fontsize=9)
        xlabel = 'Document'
        if len(topic_distributions) > max_docs:
            title = f'Topic Distribution Across Documents (First {max_docs} of {len(topic_distributions)})'
        else:
            title = f'Topic Distribution Across Documents ({len(topic_distributions)} documents)'
    else:
        ax.set_xticklabels([f'Doc {i+1}' for i in range(max_docs)], rotation=45, ha='right', fontsize=9)
        xlabel = 'Document'
        if len(topic_distributions) > max_docs:
            title = f'Topic Distribution Across Documents (First {max_docs} of {len(topic_distributions)})'
        else:
            title = f'Topic Distribution Across Documents ({len(topic_distributions)} documents)'
    
    ax.set_yticks(np.arange(data.shape[0]))
    ax.set_yticklabels([f'Topic {i+1}' for i in range(data.shape[0])])
    
    cbar = plt.colorbar(im, ax=ax)
    cbar.set_label('Proportion', rotation=270, labelpad=20)
    
    ax.set_xlabel(xlabel, fontsize=12)
    ax.set_ylabel('Topic', fontsize=12)
    ax.set_title(title, fontsize=14, fontweight='bold')
    
    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches='tight')
    plt.close()
    return output_path


def create_word_frequency_chart(top_words, output_path):
    """Create a chart of most frequent words."""
    words, frequencies = zip(*top_words[:20])
    
    fig, ax = plt.subplots(figsize=(12, 7))
    bars = ax.bar(range(len(words)), frequencies, color='crimson', alpha=0.8)
    
    for bar, freq in zip(bars, frequencies):
        height = bar.get_height()
        ax.text(bar.get_x() + bar.get_width()/2., height,
                str(int(freq)), ha='center', va='bottom', fontsize=9)
    
    ax.set_xlabel('Word', fontsize=12)
    ax.set_ylabel('Frequency', fontsize=12)
    ax.set_title('Top 20 Most Frequent Words', fontsize=14, fontweight='bold')
    ax.set_xticks(range(len(words)))
    ax.set_xticklabels(words, rotation=45, ha='right')
    ax.grid(axis='y', alpha=0.3, linestyle='--')
    
    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches='tight')
    plt.close()
    return output_path


def create_word_cloud(top_words, output_path, title="Word Cloud"):
    """Create a word cloud visualization from word frequencies."""
    try:
        from wordcloud import WordCloud
    except ImportError:
        print("Warning: wordcloud library not available. Skipping word cloud generation.")
        print("Install it with: pip install wordcloud")
        return None
    
    if not top_words:
        return None
    
    word_freq_dict = {word: freq for word, freq in top_words}
    
    wordcloud = WordCloud(
        width=1200,
        height=800,
        background_color='white',
        max_words=200,
        relative_scaling=0.5,
        colormap='viridis',
        prefer_horizontal=0.7,
        min_font_size=10,
        max_font_size=100
    ).generate_from_frequencies(word_freq_dict)
    
    fig, ax = plt.subplots(figsize=(14, 10))
    ax.imshow(wordcloud, interpolation='bilinear')
    ax.axis('off')
    ax.set_title(title, fontsize=16, fontweight='bold', pad=20)
    
    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches='tight', facecolor='white')
    plt.close()
    return output_path


def create_topic_map(topics, topic_distributions, output_path):
    """Create a 2D semantic map of topics."""
    if len(topics) < 2:
        print("Warning: Need at least 2 topics for topic map. Skipping...")
        return None
    
    try:
        n_topics = len(topics)
        
        topic_distributions = np.array(topic_distributions)
        if topic_distributions.ndim == 1:
            topic_distributions = topic_distributions.reshape(1, -1)
        
        if topic_distributions.shape[1] != n_topics:
            if topic_distributions.shape[0] == n_topics:
                topic_distributions = topic_distributions.T
        
        topic_prevalence = np.mean(topic_distributions, axis=0)
        
        all_words = set()
        for topic in topics:
            all_words.update(topic['words'])
        all_words = sorted(list(all_words))
        
        topic_vectors = []
        for topic in topics:
            vector = np.zeros(len(all_words))
            word_to_weight = dict(zip(topic['words'], topic['weights']))
            for idx, word in enumerate(all_words):
                if word in word_to_weight:
                    vector[idx] = word_to_weight[word]
            if vector.sum() > 0:
                vector = vector / vector.sum()
            topic_vectors.append(vector)
        
        topic_vectors = np.array(topic_vectors)
        
        if len(topic_vectors) < 2:
            return None
        
        tsne = TSNE(n_components=2, random_state=42, perplexity=min(30, len(topic_vectors)-1))
        topic_positions = tsne.fit_transform(topic_vectors)
        
        fig, ax = plt.subplots(figsize=(12, 10))
        
        sizes = topic_prevalence * 5000 + 500
        colors = plt.cm.tab20(np.linspace(0, 1, n_topics))
        
        scatter = ax.scatter(topic_positions[:, 0], topic_positions[:, 1], 
                            s=sizes, c=colors, alpha=0.7, edgecolors='black', linewidths=2)
        
        for idx, topic in enumerate(topics):
            top_words_str = ', '.join(topic['words'][:3])
            ax.annotate(f"Topic {topic['topic_id']+1}\n({top_words_str})",
                       (topic_positions[idx, 0], topic_positions[idx, 1]),
                       fontsize=9, ha='center', va='center',
                       bbox=dict(boxstyle='round,pad=0.3', facecolor='white', alpha=0.8))
        
        ax.set_title('Mapa Semántico de Temas\n(Tamaño = prevalencia, Distancia = similitud)', 
                    fontsize=14, fontweight='bold', pad=20)
        ax.set_xlabel('Dimensión 1 (t-SNE)', fontsize=12)
        ax.set_ylabel('Dimensión 2 (t-SNE)', fontsize=12)
        ax.grid(True, alpha=0.3)
        
        plt.tight_layout()
        plt.savefig(output_path, dpi=150, bbox_inches='tight')
        plt.close()
        return output_path
        
    except Exception as e:
        print(f"Warning: Failed to create topic map: {e}")
        import traceback
        traceback.print_exc()
        return None


def create_word_topic_network(topics, output_path):
    """Create a bipartite network showing words connected to topics."""
    if not HAS_NETWORKX:
        print("Warning: networkx library not available. Skipping word-topic network generation.")
        print("Install it with: pip install networkx")
        return None
    
    try:
        G = nx.Graph()
        
        for topic in topics:
            topic_node = f"Topic {topic['topic_id']+1}"
            G.add_node(topic_node, node_type='topic', topic_id=topic['topic_id'])
            
            for word, weight in zip(topic['words'][:15], topic['weights'][:15]):
                if word not in G:
                    G.add_node(word, node_type='word')
                G.add_edge(topic_node, word, weight=weight)
        
        if len(G.nodes()) == 0:
            return None
        
        pos = nx.spring_layout(G, k=2, iterations=50, seed=42)
        
        topic_nodes = [n for n, d in G.nodes(data=True) if d.get('node_type') == 'topic']
        word_nodes = [n for n, d in G.nodes(data=True) if d.get('node_type') == 'word']
        
        fig, ax = plt.subplots(figsize=(16, 12))
        
        edges = G.edges()
        edge_weights = [G[u][v].get('weight', 0.1) for u, v in edges]
        if edge_weights:
            max_weight = max(edge_weights)
            min_weight = min(edge_weights)
            if max_weight > min_weight:
                normalized_weights = [(w - min_weight) / (max_weight - min_weight) * 2 + 0.5 for w in edge_weights]
            else:
                normalized_weights = [1.0] * len(edge_weights)
        else:
            normalized_weights = [1.0] * len(edges)
        
        nx.draw_networkx_edges(G, pos, ax=ax, alpha=0.3, width=normalized_weights, 
                              edge_color='gray', style='dashed')
        
        topic_colors = plt.cm.Set3(np.linspace(0, 1, len(topic_nodes)))
        topic_sizes = [1500] * len(topic_nodes)
        nx.draw_networkx_nodes(G, pos, nodelist=topic_nodes, node_color=topic_colors,
                              node_size=topic_sizes, alpha=0.8, ax=ax, node_shape='o')
        
        word_sizes = [300] * len(word_nodes)
        nx.draw_networkx_nodes(G, pos, nodelist=word_nodes, node_color='lightblue',
                              node_size=word_sizes, alpha=0.6, ax=ax, node_shape='s')
        
        nx.draw_networkx_labels(G, pos, {n: n for n in topic_nodes}, 
                               font_size=10, font_weight='bold', ax=ax)
        word_degrees = dict(G.degree(word_nodes))
        top_words = sorted(word_degrees.items(), key=lambda x: x[1], reverse=True)[:30]
        top_word_labels = {w: w for w, _ in top_words}
        nx.draw_networkx_labels(G, pos, top_word_labels, 
                               font_size=7, font_color='darkblue', ax=ax)
        
        ax.set_title('Word-Topic Network\n(Words connected to their main topics)', 
                    fontsize=14, fontweight='bold', pad=20)
        ax.axis('off')
        
        from matplotlib.patches import Patch
        legend_elements = [
            Patch(facecolor='lightgray', edgecolor='gray', label='Topic'),
            Patch(facecolor='lightblue', edgecolor='blue', label='Word'),
        ]
        ax.legend(handles=legend_elements, loc='upper right', framealpha=0.9)
        
        plt.tight_layout()
        plt.savefig(output_path, dpi=150, bbox_inches='tight')
        plt.close()
        return output_path
        
    except Exception as e:
        print(f"Warning: Failed to create word-topic network: {e}")
        import traceback
        traceback.print_exc()
        return None


def create_topic_cooccurrence_network(topics, topic_distributions, output_path):
    """Create a network showing topic co-occurrence and similarity."""
    if not HAS_NETWORKX:
        print("Warning: networkx library not available. Skipping topic co-occurrence network generation.")
        print("Install it with: pip install networkx")
        return None
    
    if len(topics) < 2:
        return None
    
    try:
        topic_distributions = np.array(topic_distributions)
        if topic_distributions.ndim == 1:
            topic_distributions = topic_distributions.reshape(1, -1)
        topic_prevalence = np.mean(topic_distributions, axis=0)
        
        all_words = set()
        for topic in topics:
            all_words.update(topic['words'])
        all_words = sorted(list(all_words))
        
        topic_vectors = []
        for topic in topics:
            vector = np.zeros(len(all_words))
            word_to_weight = dict(zip(topic['words'], topic['weights']))
            for idx, word in enumerate(all_words):
                if word in word_to_weight:
                    vector[idx] = word_to_weight[word]
            if vector.sum() > 0:
                vector = vector / vector.sum()
            topic_vectors.append(vector)
        
        topic_vectors = np.array(topic_vectors)
        
        similarity_matrix = cosine_similarity(topic_vectors)
        
        G = nx.Graph()
        
        for idx, topic in enumerate(topics):
            topic_node = f"Topic {topic['topic_id']+1}"
            G.add_node(topic_node, 
                      topic_id=topic['topic_id'],
                      prevalence=topic_prevalence[idx] if idx < len(topic_prevalence) else 0.5,
                      top_words=', '.join(topic['words'][:3]))
        
        threshold = 0.1
        for i in range(len(topics)):
            for j in range(i+1, len(topics)):
                similarity = similarity_matrix[i, j]
                if similarity > threshold:
                    topic_i = f"Topic {topics[i]['topic_id']+1}"
                    topic_j = f"Topic {topics[j]['topic_id']+1}"
                    G.add_edge(topic_i, topic_j, weight=similarity)
        
        if len(G.nodes()) == 0:
            return None
        
        pos = nx.spring_layout(G, k=3, iterations=100, seed=42)
        
        node_prevalences = [G.nodes[n].get('prevalence', 0.5) for n in G.nodes()]
        min_prev = min(node_prevalences) if node_prevalences else 0
        max_prev = max(node_prevalences) if node_prevalences else 1
        if max_prev > min_prev:
            normalized_prev = [(p - min_prev) / (max_prev - min_prev) for p in node_prevalences]
            node_sizes = [500 + p * 2500 for p in normalized_prev]
        else:
            node_sizes = [1500] * len(G.nodes())
        
        edge_weights = [G[u][v].get('weight', 0.5) for u, v in G.edges()]
        if edge_weights:
            max_weight = max(edge_weights)
            min_weight = min(edge_weights)
            if max_weight > min_weight:
                edge_widths = [(w - min_weight) / (max_weight - min_weight) * 4 + 0.5 for w in edge_weights]
            else:
                edge_widths = [2.0] * len(edge_weights)
        else:
            edge_widths = [1.0]
        
        fig, ax = plt.subplots(figsize=(14, 10))
        
        nx.draw_networkx_edges(G, pos, ax=ax, width=edge_widths, 
                              alpha=0.5, edge_color='gray')
        
        colors = plt.cm.tab20(np.linspace(0, 1, len(G.nodes())))
        nx.draw_networkx_nodes(G, pos, node_size=node_sizes, 
                              node_color=colors, alpha=0.8, ax=ax)
        
        labels = {n: f"{n}\n({G.nodes[n].get('top_words', '')})" for n in G.nodes()}
        nx.draw_networkx_labels(G, pos, labels, font_size=9, 
                               font_weight='bold', ax=ax)
        
        ax.set_title('Topic Co-occurrence Network\n(Size = prevalence, Line width = similarity)', 
                    fontsize=14, fontweight='bold', pad=20)
        ax.axis('off')
        
        plt.tight_layout()
        plt.savefig(output_path, dpi=150, bbox_inches='tight')
        plt.close()
        return output_path
        
    except Exception as e:
        print(f"Warning: Failed to create topic co-occurrence network: {e}")
        import traceback
        traceback.print_exc()
        return None


def create_word_cooccurrence_network(topics, output_path):
    """Create a network showing words that co-occur across topics."""
    if not HAS_NETWORKX:
        print("Warning: networkx library not available. Skipping word co-occurrence network generation.")
        print("Install it with: pip install networkx")
        return None
    
    try:
        word_topics = {}
        word_weights = {}
        
        for topic in topics:
            topic_id = topic['topic_id']
            for word, weight in zip(topic['words'][:10], topic['weights'][:10]):
                if word not in word_topics:
                    word_topics[word] = []
                    word_weights[word] = []
                word_topics[word].append(topic_id)
                word_weights[word].append(weight)
        
        significant_words = []
        for word, topic_list in word_topics.items():
            avg_weight = np.mean(word_weights[word])
            if len(topic_list) > 1 or avg_weight > 0.1:
                significant_words.append(word)
        
        if len(significant_words) < 2:
            return None
        
        significant_words = significant_words[:40]
        
        G = nx.Graph()
        
        for word in significant_words:
            topic_count = len(word_topics[word])
            avg_weight = np.mean(word_weights[word])
            G.add_node(word, topic_count=topic_count, avg_weight=avg_weight)
        
        for i, word1 in enumerate(significant_words):
            topics1 = set(word_topics[word1])
            for word2 in significant_words[i+1:]:
                topics2 = set(word_topics[word2])
                shared_topics = topics1.intersection(topics2)
                if shared_topics:
                    weight1 = np.mean(word_weights[word1])
                    weight2 = np.mean(word_weights[word2])
                    edge_weight = len(shared_topics) * (weight1 + weight2) / 2
                    G.add_edge(word1, word2, weight=edge_weight)
        
        if len(G.nodes()) == 0:
            return None
        
        pos = nx.spring_layout(G, k=2, iterations=100, seed=42)
        
        node_weights = [G.nodes[n].get('avg_weight', 0) for n in G.nodes()]
        node_counts = [G.nodes[n].get('topic_count', 1) for n in G.nodes()]
        if node_weights:
            max_weight = max(node_weights)
            min_weight = min(node_weights)
            if max_weight > min_weight:
                normalized_weights = [(w - min_weight) / (max_weight - min_weight) for w in node_weights]
            else:
                normalized_weights = [0.5] * len(node_weights)
        else:
            normalized_weights = [0.5] * len(G.nodes())
        
        node_sizes = [300 + (w * 500) + (c * 100) for w, c in zip(normalized_weights, node_counts)]
        
        edge_weights_list = [G[u][v].get('weight', 0.5) for u, v in G.edges()]
        if edge_weights_list:
            max_edge = max(edge_weights_list)
            min_edge = min(edge_weights_list)
            if max_edge > min_edge:
                edge_widths = [(w - min_edge) / (max_edge - min_edge) * 3 + 0.5 for w in edge_weights_list]
            else:
                edge_widths = [1.0] * len(edge_weights_list)
        else:
            edge_widths = [1.0]
        
        fig, ax = plt.subplots(figsize=(16, 12))
        
        nx.draw_networkx_edges(G, pos, ax=ax, width=edge_widths, 
                              alpha=0.4, edge_color='gray')
        
        node_colors = [G.nodes[n].get('topic_count', 1) for n in G.nodes()]
        nx.draw_networkx_nodes(G, pos, node_size=node_sizes, 
                              node_color=node_colors, 
                              cmap=plt.cm.viridis_r, alpha=0.7, ax=ax)
        
        nx.draw_networkx_labels(G, pos, font_size=8, 
                               font_weight='bold', ax=ax)
        
        ax.set_title('Word Co-occurrence Network\n(Words that appear together in the same topics)', 
                    fontsize=14, fontweight='bold', pad=20)
        ax.axis('off')
        
        sm = plt.cm.ScalarMappable(cmap=plt.cm.viridis_r, 
                                   norm=plt.Normalize(vmin=min(node_colors), vmax=max(node_colors)))
        sm.set_array([])
        cbar = plt.colorbar(sm, ax=ax)
        cbar.set_label('Number of Topics', rotation=270, labelpad=20)
        
        plt.tight_layout()
        plt.savefig(output_path, dpi=150, bbox_inches='tight')
        plt.close()
        return output_path
        
    except Exception as e:
        print(f"Warning: Failed to create word co-occurrence network: {e}")
        import traceback
        traceback.print_exc()
        return None

