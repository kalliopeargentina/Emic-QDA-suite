"""Canonical domain spec types."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class PropertySpec:
    """Property definition for an entity."""

    name: str
    description: str | None = None
    relation: str | None = None
    sub_properties: list[str] = field(default_factory=list)
    nested_properties: list["PropertySpec"] = field(default_factory=list)
    kind: str = "simple"  # simple | nested_level1 | nested_level2


@dataclass
class EntitySpec:
    """Entity definition."""

    name: str
    description: str | None = None
    properties: list[PropertySpec] = field(default_factory=list)


@dataclass
class RelationSpec:
    """Relation definition."""

    name: str
    source_types: list[str]
    target_types: list[str]
    aliases: list[str] = field(default_factory=list)
    kind: str = "entity"  # entity | property


@dataclass
class DomainSpec:
    """Canonical, normalized domain representation."""

    name: str | None
    metadata: dict[str, Any]
    context: str
    entities: dict[str, EntitySpec]
    entity_relations: list[RelationSpec]
    property_relations: list[RelationSpec]
    relation_aliases: dict[str, str]
    property_relation_map: dict[tuple[str, str], str]
    nested_relation_map: dict[tuple[str, str], str]
    nested_property_relation_map: dict[tuple[str, str], str]
    domain_structure: dict[str, dict[str, object]]

    def canonicalize_relation(self, relation_name: str) -> str:
        """Return canonical relation name for a given relation/alias."""
        key = _normalize_relation_name(relation_name)
        return self.relation_aliases.get(key, relation_name)

    def property_for_relation(self, source_type: str, relation_name: str) -> str | None:
        """Return property name for a property relation and source type."""
        canonical = self.canonicalize_relation(relation_name)
        return self.property_relation_map.get((source_type, canonical))

    def nested_property_for_relation(self, source_type: str, relation_name: str) -> str | None:
        """Return nested property name for a relation and source type."""
        canonical = self.canonicalize_relation(relation_name)
        return self.nested_relation_map.get((source_type, canonical))

    def relation_for_nested_property(self, source_type: str, property_name: str) -> str | None:
        """Return relation name for a nested property and source type."""
        return self.nested_property_relation_map.get((source_type, property_name))


def _normalize_relation_name(text: str) -> str:
    return " ".join(text.strip().lower().split())
