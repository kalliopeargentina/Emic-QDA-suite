"""Vault-style Markdown exporter: one folder per entity type, one .md file per entity with YAML frontmatter and wikilinks."""

from __future__ import annotations

import re
from datetime import datetime
import yaml

from ontology_explorer.domain.normalize import load_domain_spec
from ontology_explorer.exporters.ontology_export import (
    _is_subproperty_of_nested_level2,
    build_entity_relations_map,
    group_entities_by_type,
)
from ontology_explorer.extraction.parse import _normalize_evidence


def _sanitize_filename(s: str) -> str:
    """Replace filesystem-invalid characters so the name is safe for Windows/Unix."""
    if not s or not isinstance(s, str):
        return "unknown"
    t = (s or "").strip()
    for c in r'\/:*?"<>|':
        t = t.replace(c, "_")
    t = re.sub(r"\s+", " ", t)
    return t.strip() or "unknown"


def _ordinal_en(n: int) -> str:
    """English ordinal suffix: 1st, 2nd, 3rd, 4th, ..."""
    if 10 <= n % 100 <= 20:
        return "th"
    return {1: "st", 2: "nd", 3: "rd"}.get(n % 10, "th")


def _format_date_english(dt: datetime) -> str:
    """Format datetime as 'Tuesday, November 4th 2025, 12:22:33 pm'."""
    day = dt.day
    ordinal = _ordinal_en(day)
    date_part = dt.strftime(f"%A, %B {day}{ordinal} %Y")
    time_part = dt.strftime("%I:%M:%S %p").lstrip("0")
    return f"{date_part}, {time_part}"


def _build_frontmatter(
    entity_relations: dict[str, list[str]],
    entity_name: str,
    ent_type: str,
    domain_structure: dict | None,
    nested_property_relations: set,
    now: datetime,
) -> dict:
    """Build frontmatter dict: aliases, tags, dates, and relations as block lists of wikilinks."""
    fm: dict = {
        "aliases": [],
        "tags": [],
        "date created": _format_date_english(now),
        "date modified": _format_date_english(now),
    }
    # Only entity-level relations (exclude nested subproperties like "tiene X")
    for rel_type, targets in sorted(entity_relations.items()):
        skip = _is_subproperty_of_nested_level2(rel_type, ent_type, domain_structure)
        if skip:
            continue
        filtered_targets = [
            t for t in targets
            if (rel_type, entity_name, t) not in nested_property_relations
        ]
        if not filtered_targets:
            continue
        # Each target as wikilink "[[Name]]"
        fm[rel_type] = [f"[[{t}]]" for t in sorted(filtered_targets)]
    return fm


def _frontmatter_to_yaml(fm: dict) -> str:
    """Serialize frontmatter to YAML with block-style lists (one item per line with dash)."""
    return yaml.dump(
        fm,
        default_flow_style=False,
        allow_unicode=True,
        sort_keys=False,
        width=2**31,
    ).strip()


def _format_evidence_wikilink(ev: dict) -> str:
    """Format evidence with document as wikilink: '(Documento: [[doc]])'."""
    doc = ev.get("document", "")
    sent = ev.get("sentence", "")
    doc_part = f"[[{doc}]]" if doc else ""
    if doc_part:
        return f'"{sent}" (Documento: {doc_part})'
    return f'"{sent}" (Documento: )'


def export_ontology_vault_markdown(
    entities: list[list],
    relations: list[list],
    domain_name: str | None = None,
    config_dir: str | None = None,
) -> dict[str, str]:
    """
    Export ontology to vault-style Markdown: one folder per entity type, one .md file per entity.

    Each file has YAML frontmatter (aliases, tags, dates, relations as block lists of wikilinks)
    and a body with the same content as generate_ontology_markdown for that entity, but with
    wikilinks for entity references and evidence documents.

    Returns:
        Dict mapping relative path (e.g. "Persona/Juan Pérez.md") to full file content (frontmatter + body).
    """
    domain_spec = load_domain_spec(domain_name, config_dir)
    domain_structure = domain_spec.domain_structure

    grouped = group_entities_by_type(entities)
    (
        entity_relations,
        properties_map,
        entity_evidences_map,
        relation_evidences_map,
        properties_evidences_map,
        nested_property_relations,
    ) = build_entity_relations_map(
        entities, relations, domain_structure, domain_spec=domain_spec
    )

    entity_names: set[str] = set()
    for ent in entities:
        if isinstance(ent, list) and len(ent) >= 2:
            entity_names.add(ent[0])

    now = datetime.now()
    type_order: list[str] = []
    if domain_structure:
        type_order = list(domain_structure.keys())
    for ent_type in sorted(grouped.keys()):
        if ent_type not in type_order:
            type_order.append(ent_type)
    if not type_order:
        type_order = sorted(grouped.keys())

    # Sanitize folder names for entity types
    def safe_type(t: str) -> str:
        return _sanitize_filename(t) or "Entity"

    result: dict[str, str] = {}

    for ent_type in type_order:
        if ent_type not in grouped:
            continue
        type_folder = safe_type(ent_type)
        for name, _, entity_evidences in sorted(grouped[ent_type], key=lambda x: x[0]):
            safe_name = _sanitize_filename(name)
            rel_path = f"{type_folder}/{safe_name}.md"

            # Frontmatter: relations for this entity (filtered)
            rels_for_entity = entity_relations.get(name, {})
            fm = _build_frontmatter(
                rels_for_entity,
                name,
                ent_type,
                domain_structure,
                nested_property_relations,
                now,
            )
            yaml_str = _frontmatter_to_yaml(fm)
            lines_body: list[str] = []

            # Title (optional): entity name as H1
            lines_body.append(f"# {name}")
            lines_body.append("")

            # Evidencias de la Entidad (with document wikilinks)
            if entity_evidences:
                lines_body.append("## Evidencias de la Entidad")
                for ev in entity_evidences:
                    lines_body.append(f"- {_format_evidence_wikilink(ev)}")
                lines_body.append("")

            # Propiedades (entity refs as wikilinks)
            if name in properties_map and properties_map[name]:
                lines_body.append("## Propiedades")
                for prop_type, prop_value in sorted(properties_map[name].items()):
                    if isinstance(prop_value, (dict, list)):
                        if isinstance(prop_value, list):
                            multiple_instances = len(prop_value) > 1
                            for idx, instance in enumerate(prop_value):
                                if multiple_instances:
                                    lines_body.append(f"- **{prop_type}** ({idx + 1}):")
                                elif idx == 0:
                                    lines_body.append(f"- **{prop_type}**:")
                                if isinstance(instance, dict):
                                    _append_property_instance_lines(
                                        lines_body,
                                        instance,
                                        prop_type,
                                        name,
                                        entities,
                                        domain_structure,
                                        properties_evidences_map,
                                        entity_names,
                                    )
                                if multiple_instances and idx < len(prop_value) - 1:
                                    lines_body.append("")
                        elif isinstance(prop_value, dict):
                            for sub_prop, sub_value in sorted(prop_value.items()):
                                val_str = f"[[{sub_value}]]" if sub_value in entity_names else str(sub_value)
                                sub_prop_line = f"  - **{sub_prop}**: {val_str}"
                                bucket = properties_evidences_map.get(name, {}).get(prop_type, {})
                                if isinstance(bucket, dict):
                                    sub_evidences = bucket.get(sub_prop)
                                    if isinstance(sub_evidences, list) and sub_evidences:
                                        ev_texts = [_format_evidence_wikilink(ev) for ev in sub_evidences]
                                        sub_prop_line += f" *(Evidencia: {', '.join(ev_texts)})*"
                                lines_body.append(sub_prop_line)
                    else:
                        val_str = f"[[{prop_value}]]" if prop_value in entity_names else str(prop_value)
                        prop_line = f"- **{prop_type}**: {val_str}"
                        prop_evidences = properties_evidences_map.get(name, {}).get(prop_type)
                        if isinstance(prop_evidences, list) and prop_evidences:
                            ev_texts = [_format_evidence_wikilink(ev) for ev in prop_evidences]
                            prop_line += f" *(Evidencia: {', '.join(ev_texts)})*"
                        lines_body.append(prop_line)
                lines_body.append("")

            # Relaciones (targets as wikilinks)
            if name in entity_relations and entity_relations[name]:
                filtered_relations = {}
                for rel_type, targets in entity_relations[name].items():
                    skip = _is_subproperty_of_nested_level2(rel_type, ent_type, domain_structure)
                    filtered_targets = [
                        t
                        for t in targets
                        if (rel_type, name, t) not in nested_property_relations and not skip
                    ]
                    if filtered_targets:
                        filtered_relations[rel_type] = filtered_targets
                if filtered_relations:
                    lines_body.append("## Relaciones")
                    for rel_type, targets in sorted(filtered_relations.items()):
                        for target in sorted(targets):
                            target_str = f"[[{target}]]"
                            rel_line = f"- **{rel_type}**: {target_str}"
                            if (
                                name in relation_evidences_map
                                and rel_type in relation_evidences_map[name]
                                and target in relation_evidences_map[name][rel_type]
                            ):
                                rel_evidences = relation_evidences_map[name][rel_type][target]
                                if rel_evidences:
                                    ev_texts = [_format_evidence_wikilink(ev) for ev in rel_evidences]
                                    rel_line += f" *(Evidencia: {', '.join(ev_texts)})*"
                            lines_body.append(rel_line)
                    lines_body.append("")
                else:
                    lines_body.append("## Relaciones")
                    lines_body.append("- *Sin relaciones identificadas*")
                    lines_body.append("")
            else:
                lines_body.append("## Relaciones")
                lines_body.append("- *Sin relaciones identificadas*")
                lines_body.append("")

            body = "\n".join(lines_body).strip()
            full_content = f"---\n{yaml_str}\n---\n\n{body}\n"
            result[rel_path] = full_content

    # Types that had no entities in type_order (e.g. only in grouped)
    for ent_type in sorted(grouped.keys()):
        if ent_type in type_order:
            continue
        type_folder = safe_type(ent_type)
        for name, _, entity_evidences in sorted(grouped[ent_type], key=lambda x: x[0]):
            safe_name = _sanitize_filename(name)
            rel_path = f"{type_folder}/{safe_name}.md"
            rels_for_entity = entity_relations.get(name, {})
            fm = _build_frontmatter(
                rels_for_entity,
                name,
                ent_type,
                domain_structure,
                nested_property_relations,
                now,
            )
            yaml_str = _frontmatter_to_yaml(fm)
            lines_body = [f"# {name}", ""]
            if entity_evidences:
                lines_body.append("## Evidencias de la Entidad")
                for ev in entity_evidences:
                    lines_body.append(f"- {_format_evidence_wikilink(ev)}")
                lines_body.append("")
            lines_body.append("## Relaciones")
            lines_body.append("- *Sin relaciones identificadas*")
            lines_body.append("")
            body = "\n".join(lines_body).strip()
            result[rel_path] = f"---\n{yaml_str}\n---\n\n{body}\n"

    return result


def _append_property_instance_lines(
    lines_body: list[str],
    instance: dict,
    prop_type: str,
    entity_name: str,
    entities: list[list],
    domain_structure: dict | None,
    properties_evidences_map: dict,
    entity_names: set[str],
) -> None:
    """Append lines for one nested property instance (level 1 or level 2), with entity refs as wikilinks."""
    source_type = None
    for ent in entities:
        if isinstance(ent, list) and len(ent) >= 2 and ent[0] == entity_name:
            source_type = ent[1]
            break
    prop_data = None
    if source_type and domain_structure:
        entity_props = domain_structure.get(source_type)
        if isinstance(entity_props, dict):
            prop_data = entity_props.get(prop_type)
    is_level2 = (
        prop_data
        and isinstance(prop_data, dict)
        and any(
            k not in ("relacion", "sub_propiedades", "_relacion")
            for k in prop_data.keys()
        )
    )
    if is_level2 and prop_data:
        level2_identifier = next(
            (
                k
                for k in prop_data
                if k not in ("relacion", "_relacion", "_sub_propiedades_nivel1")
                and isinstance(prop_data.get(k), dict)
                and "sub_propiedades" in (prop_data.get(k) or {})
            ),
            None,
        )
        instance_id = instance.get(level2_identifier) if level2_identifier else None
        for level2_prop, level2_value in sorted(instance.items()):
            if level2_prop == "_evidences":
                continue
            if isinstance(level2_value, dict):
                lines_body.append(f"  - **{level2_prop}**:")
                for sub_prop, sub_value in sorted(level2_value.items()):
                    if sub_prop == "_evidences":
                        continue
                    val_str = f"[[{sub_value}]]" if sub_value in entity_names else str(sub_value)
                    sub_prop_line = f"    - **{sub_prop}**: {val_str}"
                    level2_bucket = properties_evidences_map.get(entity_name, {}).get(prop_type, {}).get(level2_identifier or level2_prop)
                    if isinstance(level2_bucket, dict):
                        if instance_id is not None and isinstance(level2_bucket.get(instance_id), dict):
                            sub_evidences = level2_bucket[instance_id].get(sub_prop)
                        else:
                            sub_evidences = level2_bucket.get(sub_prop)
                        if isinstance(sub_evidences, list) and sub_evidences:
                            ev_texts = [_format_evidence_wikilink(ev) for ev in sub_evidences]
                            sub_prop_line += f" *(Evidencia: {', '.join(ev_texts)})*"
                    lines_body.append(sub_prop_line)
            else:
                val_str = f"[[{level2_value}]]" if level2_value in entity_names else str(level2_value)
                level2_prop_line = f"  - **{level2_prop}**: {val_str}"
                level2_bucket = properties_evidences_map.get(entity_name, {}).get(prop_type, {}).get(level2_identifier or level2_prop)
                if isinstance(level2_bucket, dict):
                    if level2_prop == level2_identifier:
                        if instance_id is not None and isinstance(level2_bucket.get(instance_id), dict):
                            evs = level2_bucket[instance_id].get("_entity_ref")
                        else:
                            evs = level2_bucket.get("_entity_ref")
                    else:
                        if instance_id is not None and isinstance(level2_bucket.get(instance_id), dict):
                            evs = level2_bucket[instance_id].get(level2_prop)
                        else:
                            evs = level2_bucket.get(level2_prop)
                    if isinstance(evs, list) and evs:
                        ev_texts = [_format_evidence_wikilink(ev) for ev in evs]
                        level2_prop_line += f" *(Evidencia: {', '.join(ev_texts)})*"
                lines_body.append(level2_prop_line)
    else:
        instance_id_l1 = instance.get(prop_type)
        for sub_prop, sub_value in sorted(instance.items()):
            if sub_prop == "_evidences":
                continue
            val_str = f"[[{sub_value}]]" if sub_value in entity_names else str(sub_value)
            sub_prop_line = f"  - **{sub_prop}**: {val_str}"
            bucket = properties_evidences_map.get(entity_name, {}).get(prop_type)
            if isinstance(bucket, dict):
                if instance_id_l1 is not None and isinstance(bucket.get(instance_id_l1), dict):
                    sub_evidences = bucket[instance_id_l1].get(sub_prop)
                else:
                    sub_evidences = bucket.get(sub_prop)
                if isinstance(sub_evidences, list) and sub_evidences:
                    ev_texts = [_format_evidence_wikilink(ev) for ev in sub_evidences]
                    sub_prop_line += f" *(Evidencia: {', '.join(ev_texts)})*"
            lines_body.append(sub_prop_line)
