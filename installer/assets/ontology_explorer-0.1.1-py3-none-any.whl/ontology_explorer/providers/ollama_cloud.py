"""Ollama Cloud provider (API)."""

from __future__ import annotations

import json
import os
import sys

from .base import Provider, ProviderConfig


class OllamaCloudProvider(Provider):
    def run(self, prompt: str, model: str, config: ProviderConfig) -> str:
        api_key = config.api_key or os.getenv("OLLAMA_API_KEY")
        if not api_key:
            raise SystemExit(
                "Proporcioná la clave de Ollama Cloud con --api-key o definí OLLAMA_API_KEY."
            )

        try:
            import requests
        except ImportError as exc:
            raise SystemExit(
                "No se encuentra el paquete 'requests'. Instalalo con 'pip install requests'."
            ) from exc

        url = "https://ollama.com/api/chat"
        headers = {"Authorization": f"Bearer {api_key}"}

        options = {}
        if config.temperature is not None:
            options["temperature"] = config.temperature

        # Validar tamaño del prompt antes de enviarlo
        # Ollama Cloud tiene un límite de ~131072 tokens
        # Usamos una estimación muy conservadora: 1 carácter ≈ 1.3 tokens (conservador)
        # Esto da un límite de ~60,000 caracteres para estar seguros (60k * 1.3 ≈ 78k tokens)
        OLLAMA_CLOUD_MAX_CHARS = 60000  # Límite muy conservador basado en 131072 tokens
        
        prompt_chars = len(prompt)
        if prompt_chars > OLLAMA_CLOUD_MAX_CHARS:
            # Estimación conservadora: 1 carácter ≈ 1.3 tokens
            estimated_tokens = int(prompt_chars * 1.3)
            raise SystemExit(
                f"El prompt es demasiado grande para Ollama Cloud.\n"
                f"  Tamaño del prompt: {prompt_chars:,} caracteres (~{estimated_tokens:,} tokens estimados)\n"
                f"  Límite de Ollama Cloud: ~131,072 tokens\n"
                f"  Límite seguro usado: ~60,000 caracteres\n"
                f"  Solución: Usá --max-tokens para dividir el texto en chunks más pequeños.\n"
                f"  Ejemplo: --max-tokens 60000"
            )

        payload = {
            "model": model,
            "messages": [{"role": "user", "content": prompt}],
            "stream": False,
            "options": options,
        }

        try:
            print(f"Consultando Ollama Cloud con modelo: {model}", file=sys.stderr, flush=True)

            timeout_sec = 300 if config.timeout is None else config.timeout
            response = requests.post(url, json=payload, headers=headers, timeout=timeout_sec)

            if not response.ok:
                error_msg = self._extract_error(response)
                
                if response.status_code == 401:
                    raise SystemExit(
                        "Error de autenticación con Ollama Cloud. Verificá que tu API key sea válida."
                    )
                if "model" in error_msg.lower() or "not found" in error_msg.lower():
                    raise SystemExit(
                        f"Modelo Ollama Cloud no encontrado: {model}. "
                        f"Verificá que el modelo esté disponible en Ollama Cloud."
                    )
                if "prompt too long" in error_msg.lower() or "limit is" in error_msg.lower():
                    # Estimación conservadora: 1 carácter ≈ 1.3 tokens
                    estimated_tokens = int(len(prompt) * 1.3)
                    raise SystemExit(
                        f"El prompt excede el límite de tokens de Ollama Cloud.\n"
                        f"  Tamaño del prompt: {len(prompt):,} caracteres (~{estimated_tokens:,} tokens estimados)\n"
                        f"  Error de Ollama Cloud: {error_msg}\n"
                        f"  Solución: Usá --max-tokens para dividir el texto en chunks más pequeños.\n"
                        f"  Ejemplo: --max-tokens 60000"
                    )
                raise SystemExit(f"Ollama Cloud devolvió un error: {error_msg}")

            data = response.json()
            message = data.get("message", {})
            content = message.get("content")
            if not content:
                raise SystemExit("Ollama Cloud no devolvió contenido de texto.")

            print(f"Output recibido ({len(content)} caracteres)", file=sys.stderr, flush=True)
            return content.strip()

        except requests.exceptions.ConnectionError as exc:
            raise SystemExit(
                "No se pudo conectar con Ollama Cloud. Verificá tu conexión a internet."
            ) from exc
        except requests.exceptions.Timeout as exc:
            timeout_sec = 300 if config.timeout is None else config.timeout
            raise TimeoutError(
                f"El modelo tardó más de {timeout_sec} segundos en responder. "
                "El modelo puede estar generando una respuesta muy larga."
            ) from exc
        except SystemExit:
            raise
        except Exception as exc:
            raise SystemExit(f"Ollama Cloud devolvió un error: {exc}") from exc

    def _extract_error(self, response) -> str:
        """Extrae el mensaje de error de la respuesta."""
        try:
            data = response.json()
            error_msg = data.get("error")
            if error_msg:
                return str(error_msg)
        except Exception:
            pass
        return f"HTTP {response.status_code}"
