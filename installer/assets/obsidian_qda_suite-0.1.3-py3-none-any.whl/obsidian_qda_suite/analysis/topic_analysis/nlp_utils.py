"""
NLP utilities for topic analysis.

This module provides language detection, lemmatization, stopword management,
and spaCy model loading functionality.
"""

import sys
import nltk
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer

# Try to download required NLTK data
try:
    nltk.data.find('tokenizers/punkt')
except LookupError:
    nltk.download('punkt', quiet=True)

try:
    nltk.data.find('tokenizers/punkt_tab')
except LookupError:
    nltk.download('punkt_tab', quiet=True)

try:
    nltk.data.find('corpora/stopwords')
except LookupError:
    nltk.download('stopwords', quiet=True)

try:
    nltk.data.find('corpora/wordnet')
except LookupError:
    nltk.download('wordnet', quiet=True)

try:
    nltk.data.find('corpora/omw-1.4')
except LookupError:
    nltk.download('omw-1.4', quiet=True)

# Import spaCy for multi-language lemmatization
try:
    import spacy
    HAS_SPACY = True
except (ImportError, OSError):
    HAS_SPACY = False

# Handle both relative and absolute imports
try:
    from .config import _stopwords_cache, _spacy_model_cache, VERBOSE
except ImportError:
    # Fallback to absolute imports (when running directly)
    import sys
    from pathlib import Path
    current_file = Path(__file__).resolve()
    parent_dir = current_file.parent
    
    # Add parent directory to path if not already there
    if str(parent_dir) not in sys.path:
        sys.path.insert(0, str(parent_dir))
    
    from config import _stopwords_cache, _spacy_model_cache, VERBOSE


def get_stopwords_set(language='english', custom_stopwords=None):
    """Get stopwords set for a language, with caching.
    
    Parameters:
    -----------
    language : str
        Language code ('english', 'spanish', etc.)
    custom_stopwords : set or None
        Custom stopwords to add
    
    Returns:
    --------
    set
        Set of stopwords (normalized to lowercase)
    """
    # Create cache key
    cache_key = (language, tuple(sorted(custom_stopwords)) if custom_stopwords else None)
    
    if cache_key not in _stopwords_cache:
        try:
            stop_words = set(stopwords.words(language))
        except:
            stop_words = set(stopwords.words('english'))
        
        # Normalize to lowercase
        stop_words = {word.lower().strip() for word in stop_words}
        
        # Add custom stopwords if provided
        if custom_stopwords:
            custom_stopwords_lower = {word.lower().strip() for word in custom_stopwords if word}
            stop_words = stop_words.union(custom_stopwords_lower)
        
        _stopwords_cache[cache_key] = stop_words
    
    return _stopwords_cache[cache_key]


def log_language_info(language, detected=False, verbose=False):
    """Centralized language logging.
    
    Parameters:
    -----------
    language : str
        Language code
    detected : bool
        Whether language was auto-detected
    verbose : bool
        Whether to show detailed information
    """
    if detected:
        print(f"Auto-detected language: {language}")
    else:
        print(f"Using specified language: {language}")
    
    if verbose or VERBOSE:
        try:
            sw_count = len(stopwords.words(language))
            sample_sw = list(stopwords.words(language))[:5]
            print(f"  Loaded {sw_count} stopwords for '{language}'")
            print(f"  Sample stopwords: {sample_sw}")
            
            # Check if common Spanish stopwords are present (if Spanish)
            if language == 'spanish':
                spanish_check = ['que', 'la', 'del', 'los', 'una']
                found = [sw for sw in spanish_check if sw in stopwords.words(language)]
                print(f"  Verified Spanish stopwords present: {found}")
        except Exception as e:
            print(f"  Warning: Could not load stopwords for '{language}': {e}")
            print("  Falling back to English stopwords")


def detect_language(text):
    """Detect language of the text."""
    try:
        from langdetect import detect, LangDetectException
        # Sample first 1000 characters for faster detection
        sample = text[:1000] if len(text) > 1000 else text
        if not sample.strip():
            return 'english'  # Fallback if sample is empty
        detected = detect(sample)
        # Map detected codes to NLTK language names
        lang_map = {
            'es': 'spanish',
            'en': 'english',
            'fr': 'french',
            'de': 'german',
            'it': 'italian',
            'pt': 'portuguese',
            'ru': 'russian',
            'zh': 'chinese',
            'ja': 'japanese',
            'ko': 'korean',
            'nl': 'dutch',
            'pl': 'polish',
            'ar': 'arabic',
        }
        return lang_map.get(detected, detected)
    except (ImportError, LangDetectException, Exception) as e:
        # Fallback to English if detection fails
        return 'english'


def load_spacy_model(language):
    """Load spaCy model for a given language, downloading if necessary, with caching.
    
    Parameters:
    -----------
    language : str
        Language name ('spanish', 'english', etc.)
    
    Returns:
    --------
    spacy.Language or None
        Loaded spaCy model, or None if not available
    """
    if not HAS_SPACY:
        return None
    
    # Check cache first
    if language.lower() in _spacy_model_cache:
        return _spacy_model_cache[language.lower()]
    
    # Map language names to spaCy model names
    model_map = {
        'spanish': 'es_core_news_sm',
        'english': 'en_core_web_sm',
        'french': 'fr_core_news_sm',
        'german': 'de_core_news_sm',
        'italian': 'it_core_news_sm',
        'portuguese': 'pt_core_news_sm',
    }
    
    model_name = model_map.get(language.lower())
    if not model_name:
        return None
    
    try:
        # Try to load the model
        nlp = spacy.load(model_name)
        _spacy_model_cache[language.lower()] = nlp  # Cache it
        return nlp
    except OSError:
        # Model not found, try to download it
        try:
            print(f"Downloading spaCy model '{model_name}' for {language}...")
            from spacy.cli import download
            download(model_name)
            nlp = spacy.load(model_name)
            _spacy_model_cache[language.lower()] = nlp  # Cache it
            return nlp
        except Exception as e:
            print(f"Warning: Could not load spaCy model for {language}: {e}")
            print("Falling back to NLTK WordNetLemmatizer (may work less well for non-English languages)")
            return None


def lemmatize_word(word, lemmatizer, language='english'):
    """Lemmatize a single word using spaCy if available, otherwise NLTK.
    
    Parameters:
    -----------
    word : str
        Word to lemmatize
    lemmatizer : object
        spaCy model or WordNetLemmatizer instance
    language : str
        Language code (for fallback)
    
    Returns:
    --------
    str
        Lemmatized word
    """
    if not lemmatizer:
        return word.lower()
    
    # Check if it's a spaCy model (has pipe method and can be called)
    if HAS_SPACY and hasattr(lemmatizer, 'pipe') and hasattr(lemmatizer, '__call__'):
        try:
            doc = lemmatizer(word)
            if doc and len(doc) > 0:
                return doc[0].lemma_.lower()
        except Exception:
            # If spaCy fails, fall through to NLTK
            pass
    
    # Fall back to NLTK WordNetLemmatizer
    try:
        if isinstance(lemmatizer, WordNetLemmatizer):
            return lemmatizer.lemmatize(word.lower())
        else:
            # If lemmatizer is not WordNetLemmatizer, try to create one
            lemmatizer_nltk = WordNetLemmatizer()
            return lemmatizer_nltk.lemmatize(word.lower())
    except:
        return word.lower()


def load_custom_stopwords(file_path):
    """Load custom stopwords from a file (one word per line)."""
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            stopwords_list = [line.strip().lower() for line in f if line.strip()]
        return set(stopwords_list)
    except FileNotFoundError:
        print(f"Error: Stopwords file not found: {file_path}")
        sys.exit(1)
    except Exception as e:
        print(f"Error reading stopwords file: {e}")
        sys.exit(1)


def load_seed_words_from_markdown(file_path):
    """Load seed words for Guided LDA from a markdown file.
    
    Expected format:
    ## Topic 1
    word1, word2, word3
    
    ## Topic 2
    word4, word5, word6
    """
    import re
    seed_topics = {}
    
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # Find all sections with ## headers
        pattern = r'^##\s+(.+)$\n((?:[^#]|\n)+?)(?=^##|\Z)'
        matches = re.finditer(pattern, content, re.MULTILINE)
        
        for match in matches:
            topic_name = match.group(1).strip()
            words_text = match.group(2).strip()
            
            # Extract words (split by comma, newline, or whitespace)
            words = re.split(r'[,\n\s]+', words_text)
            words = [w.strip().lower() for w in words if w.strip()]
            
            if words:
                seed_topics[topic_name] = words
        
        return seed_topics
    except FileNotFoundError:
        print(f"Error: Seed words file not found: {file_path}")
        sys.exit(1)
    except Exception as e:
        print(f"Error reading seed words file: {e}")
        sys.exit(1)


def determine_optimal_topics(text, max_topics=10, min_topics=2):
    """Determine optimal number of topics using coherence scores."""
    import re
    import numpy as np
    import gensim
    from gensim.models import CoherenceModel
    from gensim.corpora import Dictionary
    from .config import DEFAULT_CONFIG
    
    # Get config values
    min_sent_len = DEFAULT_CONFIG['text_processing']['min_sentence_length']
    min_word_len = DEFAULT_CONFIG['text_processing']['min_word_length']
    min_sent_words = DEFAULT_CONFIG['coherence']['min_sentence_words']
    no_below = DEFAULT_CONFIG['coherence']['no_below']
    no_above = DEFAULT_CONFIG['coherence']['no_above']
    min_vocab = DEFAULT_CONFIG['coherence']['min_vocab_size']
    passes = DEFAULT_CONFIG['coherence']['passes']
    
    # Split text into sentences
    sentences = re.split(r'[.!?]+', text)
    sentences = [s.strip() for s in sentences if len(s.strip()) > min_sent_len]
    
    if len(sentences) < 3:
        return min_topics
    
    # Preprocess sentences for gensim
    from collections import Counter
    processed_sentences = []
    for s in sentences:
        # Simple tokenization (words only)
        tokens = re.findall(r'\b\w+\b', s.lower())
        # Filter short words
        tokens = [t for t in tokens if len(t) > min_word_len]
        if len(tokens) > min_sent_words:  # Keep sentences with at least min_sent_words words
            processed_sentences.append(tokens)
    
    if len(processed_sentences) < 3:
        return min_topics
    
    # Create dictionary and corpus
    try:
        dictionary = Dictionary(processed_sentences)
        # Filter extremes using config values
        dictionary.filter_extremes(no_below=no_below, no_above=no_above)
        
        if len(dictionary) < min_vocab:  # Not enough vocabulary
            return min_topics
        
        corpus = [dictionary.doc2bow(text) for text in processed_sentences]
        
        # Test different numbers of topics
        coherence_scores = []
        # Limit topic range based on available data
        max_possible = min(max_topics, len(processed_sentences) // 2, len(dictionary) // 5)
        if max_possible < min_topics:
            return min_topics
        
        topic_range = range(min_topics, max_possible + 1)
        
        if len(topic_range) == 0:
            return min_topics
        
        for num_topics in topic_range:
            try:
                # Train LDA model
                lda_model = gensim.models.LdaModel(
                    corpus=corpus,
                    id2word=dictionary,
                    num_topics=num_topics,
                    random_state=42,
                    passes=passes,
                    alpha='auto',
                    per_word_topics=True
                )
                
                # Calculate coherence score
                coherence_model = CoherenceModel(
                    model=lda_model,
                    texts=processed_sentences,
                    dictionary=dictionary,
                    coherence='c_v'
                )
                coherence_score = coherence_model.get_coherence()
                coherence_scores.append((num_topics, coherence_score))
            except Exception as e:
                # If model training fails, skip this number
                continue
        
        if not coherence_scores:
            # Fallback to simple heuristic if coherence calculation fails
            n_samples = len(processed_sentences)
            optimal = min(max(min_topics, int(np.sqrt(n_samples / 2))), max_topics)
            return optimal
        
        # Find topic count with highest coherence
        best_topics, best_score = max(coherence_scores, key=lambda x: x[1])
        
        try:
            from .config import VERBOSE
            if VERBOSE:
                print(f"Coherence scores tested: {dict(coherence_scores)}")
                print(f"Best coherence: {best_score:.4f} with {best_topics} topics")
        except ImportError:
            pass
        
        return best_topics
        
    except Exception as e:
        # Fallback to simple heuristic
        try:
            from .config import VERBOSE
            if VERBOSE:
                print(f"Warning: Coherence-based detection failed: {e}")
                print("Falling back to heuristic method...")
        except ImportError:
            pass
        n_samples = len(sentences)
        optimal = min(max(min_topics, int(np.sqrt(n_samples / 2))), max_topics)
        return optimal

