"""Prompt construction utilities."""

from __future__ import annotations

import sys
import textwrap

from ontology_explorer.domain.normalize import load_domain_spec, render_domain_for_prompt
from ontology_explorer.domain.spec import DomainSpec
from .loader import load_role
from .templates import (
    PROMPT_OUTPUT_JSON,
    PROMPT_PATRONES,
    PROMPT_ROL,
    PROMPT_TAREA,
)


def build_prompt(
    text: str,
    model_name: str,
    document_name: str = "",
    domain_name: str | None = None,
    role_name: str | None = None,
    config_dir: str | None = None,
    domain_spec: DomainSpec | None = None,
) -> str:
    """
    Construye el prompt para la LLM. Siempre solicita formato JSON.
    
    Args:
        text: Texto del artículo a analizar
        model_name: Nombre del modelo a usar
        document_name: Nombre del documento (opcional)
        domain_name: Nombre del dominio a usar (sin extensión .md). Si es None, usa "default"
        role_name: Nombre del rol a usar (sin extensión .md). Si es None, usa "default"
        config_dir: Ruta al directorio de configuración. Si es None, usa el directorio por defecto.
    
    Returns:
        Prompt completo para la LLM
    """
    # Usar "default" si no se especifica
    domain_name = domain_name or "default"
    role_name = role_name or "default"
    
    # Cargar dominio y rol desde archivos
    if domain_spec is None:
        try:
            domain_spec = load_domain_spec(domain_name, config_dir)
        except (FileNotFoundError, ValueError) as e:
            print(
                f"ADVERTENCIA: No se pudo cargar el dominio '{domain_name}': {e}",
                file=sys.stderr,
                flush=True,
            )
            domain_spec = load_domain_spec("default", config_dir)
    domain_content = render_domain_for_prompt(domain_spec)
    
    try:
        role_content = load_role(role_name, config_dir)
    except (FileNotFoundError, ValueError) as e:
        print(
            f"ADVERTENCIA: No se pudo cargar el rol '{role_name}': {e}",
            file=sys.stderr,
            flush=True,
        )
        print("Usando rol por defecto desde templates.", file=sys.stderr, flush=True)
        role_content = PROMPT_ROL
    
    output_prompt = PROMPT_OUTPUT_JSON.format(model_name=model_name).strip()

    document_info = ""
    if document_name:
        document_info = (
            f"\n\nNOMBRE DEL DOCUMENTO: {document_name}\n"
            "Usa este nombre exacto en el campo 'document' de todas las evidencias."
        )

    prompt = textwrap.dedent(
        f"""
        {role_content.strip()}

        CONTEXTO DEL DOMINIO (usa estos tipos y relaciones para clasificar):
        {domain_content.strip()}

        {PROMPT_PATRONES.strip()}

        {PROMPT_TAREA.strip()}
        
        {output_prompt}
        {document_info}

        Artículo:
        ```
        {text}
        ```
        """
    ).strip()
    return prompt
