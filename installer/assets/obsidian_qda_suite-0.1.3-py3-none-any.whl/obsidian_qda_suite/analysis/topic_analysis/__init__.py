"""
Topic Analysis Package

A modular package for topic modeling and analysis of markdown documents.
"""

try:
    from .report.generator import generate_report
except ImportError:
    generate_report = None

__all__ = ['generate_report']

