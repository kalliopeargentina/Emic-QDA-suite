"""I/O helpers."""

from ontology_explorer.io.cache import (
    get_cache_path,
    load_cached_result,
    save_cached_result,
)
from ontology_explorer.io.discovery import discover_files
from ontology_explorer.io.files import (
    ensure_outputs_dir,
    read_article_text,
    read_article_text_safe,
    write_text_output,
    write_vault_output,
)
