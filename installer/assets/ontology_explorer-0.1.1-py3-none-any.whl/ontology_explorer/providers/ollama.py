"""Ollama provider (CLI)."""

from __future__ import annotations

import json
import subprocess
import sys

from .base import Provider, ProviderConfig


class OllamaProvider(Provider):
    def run(self, prompt: str, model: str, config: ProviderConfig) -> str:
        # If temperature is specified, use API instead of CLI (CLI doesn't support temperature)
        if config.temperature is not None:
            return self._run_via_api(prompt, model, config)
        
        timeout_sec = 300 if config.timeout is None else config.timeout
        try:
            command = ["ollama", "run", model]
            print(f"Ejecutando: {' '.join(command)}", file=sys.stderr, flush=True)
            result = subprocess.run(
                command,
                input=prompt,
                text=True,
                encoding="utf-8",
                errors="replace",
                capture_output=True,
                check=True,
                timeout=timeout_sec,
            )
        except FileNotFoundError as exc:
            raise SystemExit(
                "Ollama no está instalado o no está en el PATH del sistema."
            ) from exc
        except subprocess.TimeoutExpired as exc:
            raise TimeoutError(
                f"El modelo tardó más de {timeout_sec} segundos en responder."
            ) from exc
        except subprocess.CalledProcessError as exc:
            stderr = exc.stderr if isinstance(exc.stderr, str) else ""
            message = f"Ollama devolvió un error (código {exc.returncode})."
            if stderr:
                message += f" Detalle: {stderr.strip()}"
            raise SystemExit(message) from exc

        output = result.stdout.strip()
        if not output:
            print("ADVERTENCIA: El modelo no devolvió output", file=sys.stderr, flush=True)
            if result.stderr:
                print(f"Stderr: {result.stderr[:500]}", file=sys.stderr, flush=True)
        else:
            print(f"Output recibido ({len(output)} caracteres)", file=sys.stderr, flush=True)
        return output
    
    def _run_via_api(self, prompt: str, model: str, config: ProviderConfig) -> str:
        """Run Ollama via local API to support temperature parameter."""
        try:
            import requests
        except ImportError as exc:
            raise SystemExit(
                "No se encuentra el paquete 'requests'. Instalalo con 'pip install requests'."
            ) from exc
        
        url = "http://localhost:11434/api/generate"
        options = {}
        if config.temperature is not None:
            options["temperature"] = config.temperature
        
        payload = {
            "model": model,
            "prompt": prompt,
            "stream": False,
            "options": options,
        }
        
        timeout_sec = 300 if config.timeout is None else config.timeout
        try:
            print(f"Consultando Ollama local API con modelo: {model}, temperature: {config.temperature}", file=sys.stderr, flush=True)
            response = requests.post(url, json=payload, timeout=timeout_sec)
            
            if not response.ok:
                error_msg = response.text[:500] if response.text else f"HTTP {response.status_code}"
                raise SystemExit(f"Ollama API devolvió un error: {error_msg}")
            
            data = response.json()
            content = data.get("response", "")
            if not content:
                raise SystemExit("Ollama API no devolvió contenido de texto.")
            
            print(f"Output recibido ({len(content)} caracteres)", file=sys.stderr, flush=True)
            return content.strip()
            
        except requests.exceptions.ConnectionError as exc:
            raise SystemExit(
                "No se pudo conectar con Ollama local. Asegurate de que Ollama esté corriendo (ollama serve)."
            ) from exc
        except requests.exceptions.Timeout as exc:
            raise TimeoutError(
                f"El modelo tardó más de {timeout_sec} segundos en responder."
            ) from exc
        except SystemExit:
            raise
        except Exception as exc:
            raise SystemExit(f"Ollama API devolvió un error: {exc}") from exc
