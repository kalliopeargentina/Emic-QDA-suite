"""CLI entry points for Obsidian QDA Suite."""
