#!/usr/bin/env python3
"""
Command-line interface for topic analysis package.

This is the main entry point for the topic_analysis package.
Can be invoked as:
  python -m topic_analysis <markdown_file> [options]
  python topic_analysis/main.py <markdown_file> [options]
"""

import argparse
import sys
import importlib.util
import os
from pathlib import Path

# Detect if we're running as a module or directly
_is_package = __package__ is not None

# Import generate_report from the modular structure
generate_report = None

if _is_package:
    try:
        from .report.generator import generate_report
    except ImportError:
        try:
            from .report import generate_report
        except ImportError:
            generate_report = None
else:
    try:
        from .report.generator import generate_report
    except ImportError:
        try:
            from .report import generate_report
        except ImportError:
            generate_report = None


def main():
    """Main CLI entry point."""
    parser = argparse.ArgumentParser(
        description="Generate topic analysis report from markdown file or folder of markdown files",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Single file analysis:
  python -m topic_analysis document.md
  python -m topic_analysis document.md --output report.md
  python -m topic_analysis document.md --md-dir ./reports --images-dir ./attachments
  python -m topic_analysis document.md --topics 5 --method nmf
  
  # Folder/corpus analysis:
  python -m topic_analysis ./my_corpus
  python -m topic_analysis ./my_corpus --output corpus_report.md
  python -m topic_analysis ./my_corpus --no-recursive  # Don't search subdirectories
  python -m topic_analysis ./my_corpus --file-pattern "*.markdown"  # Different file pattern
  python -m topic_analysis ./my_corpus --topics 10 --method lda
  
  # Other examples:
  python -m topic_analysis document.md --language spanish
  python -m topic_analysis document.md --method guided-lda --seed-words-file seed_words.md
  python -m topic_analysis document.md --method hdp
  python -m topic_analysis document.md --method corex --topics 5
  python -m topic_analysis document.md --method bertopic --topics 10
        """
    )
    
    parser.add_argument(
        "input_path",
        type=str,
        help="Path to a markdown file or folder containing markdown files to analyze"
    )
    
    parser.add_argument(
        "--recursive",
        action='store_true',
        default=True,
        help="When analyzing a folder, search subdirectories recursively (default: True)"
    )
    
    parser.add_argument(
        "--no-recursive",
        dest='recursive',
        action='store_false',
        help="Disable recursive folder search"
    )
    
    parser.add_argument(
        "--file-pattern",
        type=str,
        default='*.md',
        help="File pattern to match when analyzing a folder (default: '*.md')"
    )
    
    parser.add_argument(
        "--output",
        type=str,
        default=None,
        help="Output path for the report (default: <input_file>_analysis.md)"
    )
    
    parser.add_argument(
        "--md-dir",
        type=str,
        default=None,
        help="Directory where markdown file should be saved (creates if non-existent)"
    )
    
    parser.add_argument(
        "--images-dir",
        type=str,
        default=None,
        help="Root directory where images should be saved (creates if non-existent). Default: subdirectory next to markdown file"
    )
    
    parser.add_argument(
        "--topics",
        type=int,
        default=None,
        help="Number of topics to extract (default: auto-detect). For HDP method, this acts as maximum topics limit (filters by prevalence after automatic discovery)"
    )
    
    parser.add_argument(
        "--method",
        type=str,
        choices=['lda', 'nmf', 'guided-lda', 'hdp', 'corex', 'lsi', 'lsa', 'top2vec', 'bertopic'],
        default='lda',
        help="Topic modeling method: 'lda', 'nmf', 'guided-lda', 'hdp', 'corex', 'lsi', 'lsa', 'top2vec', or 'bertopic' (default: lda). HDP, Top2Vec, and BERTopic discover topics automatically. CorEx supports seed words (anchors). LSI/LSA are SVD-based methods."
    )
    
    parser.add_argument(
        "--language",
        type=str,
        default='auto',
        help="Language for stopwords. Use 'auto' for auto-detection (default: auto), or specify: english, spanish, french, german, etc."
    )
    
    parser.add_argument(
        "--stopwords-file",
        type=str,
        default=None,
        help="Path to a text file containing custom stopwords (one word per line). These stopwords will be added to the language-specific stopwords."
    )
    
    parser.add_argument(
        "--seed-words-file",
        type=str,
        default=None,
        help="Path to a markdown file containing seed words for Guided LDA. Format: ## Topic Name\\nword1, word2, word3"
    )
    
    parser.add_argument(
        "--hdp-gamma",
        type=float,
        default=1.0,
        help="HDP gamma parameter (top-level concentration). Lower values = fewer topics (default: 1.0). Try 0.1-0.5 for fewer topics."
    )
    
    parser.add_argument(
        "--hdp-alpha",
        type=float,
        default=1.0,
        help="HDP alpha parameter (per-document concentration). Lower values = fewer topics per document (default: 1.0). Try 0.1-0.5 for fewer topics."
    )
    
    parser.add_argument(
        "--top2vec-embedding-model",
        type=str,
        default='all-MiniLM-L6-v2',
        help="Embedding model for Top2Vec. Options: all-MiniLM-L6-v2, universal-sentence-encoder*, distiluse-base-multilingual-cased, doc2vec. Use 'obsidianqda topic --check-embeddings' to verify availability. Default: all-MiniLM-L6-v2"
    )
    
    parser.add_argument(
        "--bertopic-min-topic-size",
        type=int,
        default=10,
        help="Minimum cluster size for BERTopic HDBSCAN clustering. Larger values = fewer topics. Default: 10"
    )
    
    parser.add_argument(
        "--bertopic-top-n-words",
        type=int,
        default=10,
        help="Number of top words to extract per topic in BERTopic. Default: 10"
    )
    
    parser.add_argument(
        "--bertopic-diversity",
        type=float,
        default=0.0,
        help="MMR diversity parameter for BERTopic (0.0 to 1.0). 0.0 = relevance only, 1.0 = maximum diversity. Default: 0.0"
    )
    
    parser.add_argument(
        "--bertopic-calculate-probabilities",
        type=str,
        choices=['true', 'false', 'True', 'False'],
        default='true',
        help="Calculate topic probabilities for documents in BERTopic. Default: true"
    )
    
    parser.add_argument(
        "--bertopic-embedding-model",
        type=str,
        default=None,
        help="Custom embedding model for BERTopic (e.g. all-MiniLM-L6-v2, paraphrase-multilingual-MiniLM-L12-v2). If None, uses default. Use 'obsidianqda topic --check-embeddings' to verify. Default: None"
    )
    
    args = parser.parse_args()
    
    # Check if input exists
    input_path = Path(args.input_path)
    if not input_path.exists():
        print(f"Error: Path not found: {args.input_path}")
        sys.exit(1)
    
    # Determine if input is a file or folder
    is_folder = input_path.is_dir()
    is_file = input_path.is_file()
    
    if not (is_file or is_folder):
        print(f"Error: Path must be either a file or directory: {args.input_path}")
        sys.exit(1)
    
    # Determine output path
    if args.output:
        output_path = Path(args.output)
    elif is_folder:
        # For folders, use folder name
        if args.md_dir:
            md_dir = Path(args.md_dir)
            md_dir.mkdir(parents=True, exist_ok=True)
            output_path = md_dir / f"{input_path.name}_analysis.md"
        else:
            # Place in parent directory of the folder
            output_path = input_path.parent / f"{input_path.name}_analysis.md"
    else:
        # For files, use existing logic
        if args.md_dir:
            md_dir = Path(args.md_dir)
            md_dir.mkdir(parents=True, exist_ok=True)
            output_path = md_dir / f"{input_path.stem}_analysis.md"
        else:
            output_path = input_path.parent / f"{input_path.stem}_analysis.md"
    
    # Create output directory if needed
    output_path.parent.mkdir(parents=True, exist_ok=True)
    
    # Handle images directory
    images_dir = args.images_dir
    if images_dir:
        images_dir = Path(images_dir)
        images_dir.mkdir(parents=True, exist_ok=True)
        images_dir = str(images_dir)
    
    # Generate report
    try:
        # Validate bertopic_diversity range
        bertopic_diversity = args.bertopic_diversity
        if bertopic_diversity < 0.0 or bertopic_diversity > 1.0:
            print(f"Warning: --bertopic-diversity must be between 0.0 and 1.0, clamping to valid range")
            bertopic_diversity = max(0.0, min(1.0, bertopic_diversity))
        
        # Convert bertopic_calculate_probabilities string to boolean
        bertopic_calculate_probabilities = str(args.bertopic_calculate_probabilities).lower() == 'true'
        
        # Import corpus processing if needed
        if is_folder:
            # Handle both relative and absolute imports
            if _is_package:
                from . import generate_corpus_report
            else:
                # When running directly, use absolute import
                import importlib.util
                current_file = Path(__file__).resolve()
                corpus_report_path = current_file.parent / 'generate_corpus_report.py'
                if corpus_report_path.exists():
                    spec = importlib.util.spec_from_file_location("generate_corpus_report", corpus_report_path)
                    corpus_report_module = importlib.util.module_from_spec(spec)
                    spec.loader.exec_module(corpus_report_module)
                    generate_corpus_report = corpus_report_module
                else:
                    raise ImportError(f"Could not find generate_corpus_report.py at {corpus_report_path}")
        
        # Generate report based on input type
        if is_folder:
            # Corpus-level analysis
            generate_corpus_report.generate_corpus_report(
                str(input_path),
                str(output_path),
                n_topics=args.topics,
                method=args.method,
                language=args.language,
                images_dir=images_dir,
                custom_stopwords_file=args.stopwords_file,
                seed_words_file=args.seed_words_file,
                hdp_gamma=args.hdp_gamma,
                hdp_alpha=args.hdp_alpha,
                top2vec_embedding_model=args.top2vec_embedding_model,
                bertopic_min_topic_size=args.bertopic_min_topic_size,
                bertopic_top_n_words=args.bertopic_top_n_words,
                bertopic_diversity=bertopic_diversity,
                bertopic_calculate_probabilities=bertopic_calculate_probabilities,
                bertopic_embedding_model=args.bertopic_embedding_model if hasattr(args, 'bertopic_embedding_model') else None,
                recursive=args.recursive,
                file_pattern=args.file_pattern
            )
        else:
            # Single file analysis using new modular structure
            if generate_report is None:
                print("Error: Single-file analysis requires the report.generator module", file=sys.stderr)
                print("Please ensure topic_analysis/report/generator.py exists and is properly configured.", file=sys.stderr)
                print("The generate_report function should be available from .report.generator", file=sys.stderr)
                sys.stderr.flush()
                sys.exit(1)
            
            generate_report(
                str(input_path),
                str(output_path),
                n_topics=args.topics,
                method=args.method,
                language=args.language,
                images_dir=images_dir,
                custom_stopwords_file=args.stopwords_file,
                seed_words_file=args.seed_words_file,
                hdp_gamma=args.hdp_gamma,
                hdp_alpha=args.hdp_alpha,
                top2vec_embedding_model=args.top2vec_embedding_model,
                bertopic_min_topic_size=args.bertopic_min_topic_size,
                bertopic_top_n_words=args.bertopic_top_n_words,
                bertopic_diversity=bertopic_diversity,
                bertopic_calculate_probabilities=bertopic_calculate_probabilities,
                bertopic_embedding_model=args.bertopic_embedding_model if hasattr(args, 'bertopic_embedding_model') else None
            )
    except Exception as e:
        print(f"Error during analysis: {str(e)}", file=sys.stderr)
        import traceback
        traceback.print_exc(file=sys.stderr)
        sys.stderr.flush()
        sys.exit(1)


if __name__ == "__main__":
    main()

