"""
Vectorization utilities for topic analysis.

This module provides text vectorization with stopword filtering
and n-gram validation.
"""

import numpy as np
from scipy import sparse
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer

# Handle both relative and absolute imports
try:
    from .config import DEFAULT_CONFIG, VERBOSE
    from .nlp_utils import get_stopwords_set
except ImportError:
    # Fallback to absolute imports (when running directly)
    import sys
    from pathlib import Path
    current_file = Path(__file__).resolve()
    parent_dir = current_file.parent
    
    # Add parent directory to path if not already there
    if str(parent_dir) not in sys.path:
        sys.path.insert(0, str(parent_dir))
    
    from config import DEFAULT_CONFIG, VERBOSE
    from nlp_utils import get_stopwords_set


def create_vectorizer(language='english', custom_stopwords=None):
    """Create a vectorizer with appropriate configuration.
    
    Parameters:
    -----------
    language : str
        Language code for stopwords
    custom_stopwords : set or None
        Custom stopwords to add
    
    Returns:
    --------
    TfidfVectorizer
        Configured vectorizer
    """
    # Get stopwords using centralized function with cache
    stopwords_set = get_stopwords_set(language, custom_stopwords)
    stop_words_list = list(stopwords_set)  # For vectorizer (needs list)
    
    # Create vectorizer with explicit stopword filtering as additional safety measure
    vectorizer_config = DEFAULT_CONFIG['vectorizer'].copy()
    vectorizer_config['stop_words'] = stop_words_list
    vectorizer = TfidfVectorizer(**vectorizer_config)
    
    return vectorizer, stopwords_set


def vectorize_texts(texts, language='english', custom_stopwords=None):
    """Vectorize texts with stopword filtering and n-gram validation.
    
    Parameters:
    -----------
    texts : list of str
        Preprocessed texts to vectorize
    language : str
        Language code for stopwords
    custom_stopwords : set or None
        Custom stopwords to add
    
    Returns:
    --------
    tuple
        (X, vectorizer, feature_names) where:
        - X: sparse matrix of features
        - vectorizer: fitted vectorizer
        - feature_names: array of feature names (after filtering)
    """
    vectorizer, stopwords_set = create_vectorizer(language, custom_stopwords)
    
    try:
        X = vectorizer.fit_transform(texts)
    except ValueError as e:
        print(f"Warning: Vectorization failed: {e}")
        print("Using simpler vectorization...")
        stop_words_list = list(stopwords_set)
        fallback_config = DEFAULT_CONFIG['vectorizer_fallback'].copy()
        fallback_config['stop_words'] = stop_words_list
        vectorizer = CountVectorizer(**fallback_config)
        X = vectorizer.fit_transform(texts)
    
    feature_names = vectorizer.get_feature_names_out()
    original_feature_count = len(feature_names)
    
    # Filter out features that contain stopwords in n-grams
    # Note: Unigrams are already filtered by stop_words parameter, so only check n-grams
    valid_feature_indices = []
    filtered_feature_names = []
    
    for idx, feature in enumerate(feature_names):
        feature_parts = feature.split()
        
        # If it's a unigram, skip check (already filtered by stop_words parameter)
        if len(feature_parts) == 1:
            valid_feature_indices.append(idx)
            filtered_feature_names.append(feature)
            continue
        
        # For n-grams, check if any part is a stopword
        contains_stopword = any(part.lower().strip() in stopwords_set for part in feature_parts)
        
        if not contains_stopword:
            valid_feature_indices.append(idx)
            filtered_feature_names.append(feature)
    
    # Filter the feature matrix to only include valid features
    if valid_feature_indices and len(valid_feature_indices) < original_feature_count:
        if sparse.issparse(X):
            X = X[:, valid_feature_indices]
        else:
            X = X[:, valid_feature_indices]
        feature_names = np.array(filtered_feature_names)
        removed_count = original_feature_count - len(feature_names)
        if VERBOSE or removed_count > 0:
            print(f"Filtered {len(feature_names)} features (removed {removed_count} n-grams containing stopwords)")
    elif not valid_feature_indices:
        print("Warning: All features were filtered! Keeping original features.")
        # Don't filter if all features would be removed
    
    return X, vectorizer, feature_names

