"""Domain normalization for Markdown-based domains."""

from __future__ import annotations

import re
from typing import Any

from .spec import DomainSpec, EntitySpec, PropertySpec, RelationSpec, _normalize_relation_name
from ontology_explorer.prompt import loader


_RELATION_INLINE_RE = re.compile(r'\(relación\s*:\s*"([^"]+)"\)', re.IGNORECASE)


def load_domain_spec(
    domain_name: str | None = None,
    config_dir: str | None = None,
    domain_text: str | None = None,
    metadata: dict[str, Any] | None = None,
) -> DomainSpec:
    """Load and normalize a domain from markdown text or by name."""
    if domain_text is None:
        name = (domain_name or "default").strip() or "default"
        try:
            metadata, domain_text = loader.load_domain_with_metadata(
                name, config_dir
            )
        except (FileNotFoundError, ValueError):
            # Fallback to default domain if provided name is invalid
            if name != "default":
                metadata, domain_text = loader.load_domain_with_metadata(
                    "default", config_dir
                )
                name = "default"
            else:
                raise
        return normalize_domain_content(
            domain_text=domain_text,
            domain_name=name,
            metadata=metadata or {},
        )

    if metadata is None:
        metadata, domain_text = loader.parse_frontmatter(domain_text)
    return normalize_domain_content(
        domain_text=domain_text,
        domain_name=domain_name,
        metadata=metadata or {},
    )


def normalize_domain_content(
    domain_text: str,
    domain_name: str | None = None,
    metadata: dict[str, Any] | None = None,
) -> DomainSpec:
    """Normalize markdown domain text into a canonical DomainSpec."""
    metadata = metadata or {}
    lines = domain_text.split("\n")

    context = ""
    entities: dict[str, EntitySpec] = {}

    current_entity: EntitySpec | None = None
    current_prop_level1: PropertySpec | None = None
    pending_level2: list[PropertySpec] = []

    in_entities_section = False

    def _finalize_pending_level2() -> None:
        nonlocal pending_level2, current_prop_level1
        if not current_prop_level1 or not pending_level2:
            pending_level2 = []
            return
        # Level2 candidates with subprops become nested properties
        for prop in pending_level2:
            if prop.sub_properties:
                prop.kind = "nested_level2"
                current_prop_level1.nested_properties.append(prop)
            else:
                current_prop_level1.sub_properties.append(prop.name)
        pending_level2 = []

    for line in lines:
        stripped = line.strip()
        if not stripped:
            continue

        if "CONTEXTO DEL DOMINIO" in stripped.upper() and ":" in stripped:
            context = stripped.split(":", 1)[1].strip()

        if "TIPOS DE ENTIDADES" in stripped.upper() or "ENTIDADES DISPONIBLES" in stripped.upper():
            in_entities_section = True
            continue

        if in_entities_section and stripped.upper().startswith("RELACIONES"):
            # finish pending before switching sections
            _finalize_pending_level2()
            current_entity = None
            current_prop_level1 = None
            break

        if not in_entities_section or not stripped.startswith("- "):
            continue

        leading_spaces = len(line) - len(line.lstrip())
        content = stripped[2:].strip()

        # Extract relation mapping from property line if present
        relation_mapping = None
        match = _RELATION_INLINE_RE.search(content)
        if match:
            relation_mapping = match.group(1).strip()
            content = _RELATION_INLINE_RE.sub("", content).strip()

        name, description = _split_name_description(content)

        # Entity (level 0-2)
        if leading_spaces <= 2:
            _finalize_pending_level2()
            current_prop_level1 = None
            current_entity = EntitySpec(name=name, description=description)
            entities[name] = current_entity
            continue

        if not current_entity:
            continue

        # Property level1 (4-6 spaces)
        if 4 <= leading_spaces <= 6:
            _finalize_pending_level2()
            current_prop_level1 = PropertySpec(
                name=name,
                description=description,
                relation=relation_mapping,
                kind="nested_level1" if relation_mapping else "simple",
            )
            current_entity.properties.append(current_prop_level1)
            continue

        if not current_prop_level1:
            continue

        # Property level2 candidate (8-10 spaces)
        if 8 <= leading_spaces <= 10:
            pending_level2.append(PropertySpec(name=name, description=description))
            continue

        # Sub-properties (12+ spaces) or inconsistent indent
        if leading_spaces >= 12:
            if pending_level2:
                pending_level2[-1].sub_properties.append(name)
            else:
                current_prop_level1.sub_properties.append(name)
            continue

        # Compatibility: level 3 spaces treated as simple property under entity
        if leading_spaces == 3 and name and name not in (p.name for p in current_entity.properties):
            current_entity.properties.append(PropertySpec(name=name))

    _finalize_pending_level2()

    entity_relations, property_relations, relation_aliases = _parse_relations(lines)

    # Inferir relación en propiedades anidadas sin "(relación: ...)" desde RELACIONES ENTRE ENTIDADES
    for ent in entities.values():
        for prop in ent.properties:
            if prop.relation:
                continue
            for rel in entity_relations:
                if ent.name in rel.source_types and prop.name in rel.target_types:
                    prop.relation = rel.name
                    break

    property_relation_map: dict[tuple[str, str], str] = {}
    for rel in property_relations:
        for source in rel.source_types:
            if rel.target_types:
                property_relation_map[(source, rel.name)] = rel.target_types[0]

    nested_relation_map: dict[tuple[str, str], str] = {}
    nested_property_relation_map: dict[tuple[str, str], str] = {}
    for ent in entities.values():
        for prop in ent.properties:
            if prop.relation:
                canonical = relation_aliases.get(
                    _normalize_relation_name(prop.relation),
                    prop.relation,
                )
                nested_relation_map[(ent.name, canonical)] = prop.name
                nested_property_relation_map[(ent.name, prop.name)] = canonical
                # ensure inline relations are also canonicalized
                relation_aliases.setdefault(
                    _normalize_relation_name(canonical), canonical
                )

    domain_structure = _domain_structure_from_entities(entities)

    return DomainSpec(
        name=domain_name,
        metadata=metadata,
        context=context,
        entities=entities,
        entity_relations=entity_relations,
        property_relations=property_relations,
        relation_aliases=relation_aliases,
        property_relation_map=property_relation_map,
        nested_relation_map=nested_relation_map,
        nested_property_relation_map=nested_property_relation_map,
        domain_structure=domain_structure,
    )


def render_domain_for_prompt(domain_spec: DomainSpec) -> str:
    """Render normalized domain content for prompt inclusion."""
    lines: list[str] = []
    if domain_spec.context:
        lines.append(f"CONTEXTO DEL DOMINIO: {domain_spec.context}")
        lines.append("")

    lines.append("TIPOS DE ENTIDADES DISPONIBLES:")
    for entity in domain_spec.entities.values():
        desc = f": {entity.description}" if entity.description else ""
        lines.append(f"- {entity.name}{desc}")
        for prop in entity.properties:
            prop_desc = f": {prop.description}" if prop.description else ""
            rel = f' (relación: "{prop.relation}")' if prop.relation else ""
            lines.append(f"    - {prop.name}{rel}{prop_desc}")
            if prop.nested_properties:
                for nested in prop.nested_properties:
                    nested_desc = f": {nested.description}" if nested.description else ""
                    lines.append(f"        - {nested.name}{nested_desc}")
                    for sub in nested.sub_properties:
                        lines.append(f"            - {sub}")
            else:
                for sub in prop.sub_properties:
                    lines.append(f"        - {sub}")
    lines.append("")
    lines.append("RELACIONES DISPONIBLES:")
    lines.append("")
    lines.append("RELACIONES ENTRE ENTIDADES:")
    for rel in domain_spec.entity_relations:
        names = _format_relation_names(rel)
        sources = "/".join(rel.source_types)
        targets = "/".join(rel.target_types)
        lines.append(f"- {names}: {sources} -> {targets}")
    lines.append("")
    lines.append("RELACIONES PARA PROPIEDADES (estas se tratarán como atributos de las entidades):")
    for rel in domain_spec.property_relations:
        names = _format_relation_names(rel)
        sources = "/".join(rel.source_types)
        targets = "/".join(rel.target_types)
        lines.append(f"- {names}: {sources} -> {targets}")
    return "\n".join(lines).strip()


def _format_relation_names(rel: RelationSpec) -> str:
    names = [f'"{rel.name}"']
    for alias in rel.aliases:
        names.append(f'"{alias}"')
    return " / ".join(names)


def _split_name_description(content: str) -> tuple[str, str | None]:
    if ":" in content:
        name, desc = content.split(":", 1)
        return name.strip(), desc.strip() or None
    return content.strip(), None


def _parse_relations(lines: list[str]) -> tuple[list[RelationSpec], list[RelationSpec], dict[str, str]]:
    relations: list[RelationSpec] = []
    prop_relations: list[RelationSpec] = []
    aliases: dict[str, str] = {}

    in_relations_section = False
    in_entity_relations = False
    in_property_relations = False

    for line in lines:
        stripped = line.strip()
        if not stripped:
            continue

        if "RELACIONES DISPONIBLES" in stripped.upper():
            in_relations_section = True
            continue

        if in_relations_section and "RELACIONES ENTRE ENTIDADES" in stripped.upper():
            in_entity_relations = True
            in_property_relations = False
            continue

        if in_relations_section and "RELACIONES PARA PROPIEDADES" in stripped.upper():
            in_entity_relations = False
            in_property_relations = True
            continue

        if not stripped.startswith("- "):
            continue

        parsed = _parse_relation_line(stripped[2:].strip())
        if not parsed:
            continue

        names, source_types, target_types = parsed
        canonical = names[0]
        rel = RelationSpec(
            name=canonical,
            source_types=source_types,
            target_types=target_types,
            aliases=names[1:],
            kind="property" if in_property_relations else "entity",
        )
        if in_property_relations:
            prop_relations.append(rel)
        elif in_entity_relations:
            relations.append(rel)

        for rel_name in names:
            aliases[_normalize_relation_name(rel_name)] = canonical

    return relations, prop_relations, aliases


def _parse_relation_line(line: str) -> tuple[list[str], list[str], list[str]] | None:
    if '"' not in line:
        return None
    names = re.findall(r'"([^"]+)"', line)
    if not names:
        return None

    rest = line
    if ":" in line:
        rest = line.split(":", 1)[1].strip()
    elif "->" in line:
        # Best-effort fallback
        rest = line.split('"')[-1].strip()
    if "->" not in rest:
        return None

    source_part, target_part = rest.split("->", 1)
    source_types = [s.strip() for s in source_part.split("/") if s.strip()]
    target_types = [t.strip() for t in target_part.split("/") if t.strip()]
    return names, source_types, target_types


def _domain_structure_from_entities(
    entities: dict[str, EntitySpec],
) -> dict[str, dict[str, object]]:
    """Convert normalized entities to legacy domain_structure dict."""
    domain_structure: dict[str, dict[str, object]] = {}
    for ent_name, entity in entities.items():
        props: dict[str, object] = {}
        for prop in entity.properties:
            if prop.nested_properties:
                nested: dict[str, object] = {}
                if prop.relation:
                    nested["_relacion"] = prop.relation
                if prop.sub_properties:
                    nested["_sub_propiedades_nivel1"] = list(prop.sub_properties)
                for level2 in prop.nested_properties:
                    nested[level2.name] = {
                        "sub_propiedades": list(level2.sub_properties)
                    }
                props[prop.name] = nested
            elif prop.sub_properties:
                props[prop.name] = {
                    "relacion": prop.relation,
                    "sub_propiedades": list(prop.sub_properties),
                }
            else:
                props[prop.name] = []
        domain_structure[ent_name] = props
    return domain_structure
