"""CLI for Whisper (OpenAI) transcription. Obsidian or direct args."""

import argparse
import os
import re
import sys
from pathlib import Path

from . import common
from ..audio.ffmpeg_utils import get_ffmpeg_path, get_ffprobe_path
from ..audio.split import convert_audio, needs_conversion, probe_audio_file
from ..audio.whisper_transcribe import get_api_key, run_whisper_transcribe

MAX_MP3_BYTES = 25 * 1024 * 1024


def _update_markdown_links(md_file: str, original_file_name: str, mp3_stem: str) -> None:
    """Replace MP3 links in markdown with original file name for timestamps."""
    if not os.path.isfile(md_file):
        return
    try:
        with open(md_file, "r", encoding="utf-8") as f:
            content = f.read()
        original_link = original_file_name
        mp3_name_with_ext = f"{mp3_stem}.mp3"
        content = content.replace(f'audio: "[[{mp3_name_with_ext}]]"', f'audio: "[[{original_link}]]"')
        content = content.replace(f'audio: "[[{mp3_stem}]]"', f'audio: "[[{original_link}]]"')
        frontmatter_pattern = re.compile(r'(audio:\s*"\[\[)([^\]]+)(\]\]")')

        def replace_frontmatter(match):
            link_path = match.group(2)
            if (link_path == mp3_stem or link_path == mp3_name_with_ext or
                link_path.endswith("/" + mp3_stem) or link_path.endswith("/" + mp3_name_with_ext) or
                link_path.endswith("\\" + mp3_stem) or link_path.endswith("\\" + mp3_name_with_ext)):
                return f"{match.group(1)}{original_link}{match.group(3)}"
            return match.group(0)

        content = frontmatter_pattern.sub(replace_frontmatter, content)
        pattern = re.compile(r"\[\[([^\]#|]+)(#t=\d+\|[^\]]+)\]\]")

        def replace_link(match):
            file_part = match.group(1)
            fn = file_part.replace("\\", "/")
            ms = mp3_stem.replace("\\", "/")
            mn = mp3_name_with_ext.replace("\\", "/")
            if (file_part == mp3_stem or file_part == mp3_name_with_ext or
                fn.endswith("/" + ms) or fn.endswith("/" + mn) or
                fn.endswith("\\" + ms) or fn.endswith("\\" + mn)):
                return f"[[{original_link}{match.group(2)}]]"
            return match.group(0)

        content = pattern.sub(replace_link, content)
        with open(md_file, "w", encoding="utf-8") as f:
            f.write(content)
    except Exception as e:
        common.safe_print(f"Warning: Could not update markdown links: {e}", file=sys.stderr)


def main() -> None:
    common.setup_console_encoding()
    parser = argparse.ArgumentParser(description="Transcribe audio with OpenAI Whisper.")
    parser.add_argument("--vault-path", type=str, help="Obsidian vault path (Obsidian mode)")
    parser.add_argument("--file-path", type=str, help="Path to audio/video file (Obsidian mode)")
    parser.add_argument("--file-name", type=str, help="Name of the file (Obsidian mode)")
    parser.add_argument("--api-key", type=str, help="OpenAI API key (or set OPENAI_API_KEY)")
    parser.add_argument("file", type=str, nargs="?", help="Audio file (direct mode)")
    parser.add_argument("--output-dir", type=str, help="Output directory (direct mode)")
    parser.add_argument("--language", type=str, help="Language code (e.g. es, en)")
    parser.add_argument("--model", type=str, default="whisper-1", help="Whisper model")
    args = parser.parse_args()

    vault_path = common.get_optional_param(args.vault_path)
    file_path_arg = common.get_optional_param(args.file_path)
    file_name_arg = common.get_optional_param(args.file_name)
    api_key_arg = common.get_optional_param(args.api_key)
    direct_file = common.get_optional_param(args.file)
    output_dir_arg = common.get_optional_param(args.output_dir)

    api_key = get_api_key(api_key_arg)
    if not api_key or not api_key.strip():
        common.safe_print("Error: OpenAI API key required. Use --api-key or set OPENAI_API_KEY.", file=sys.stderr)
        sys.exit(1)

    if vault_path and file_path_arg and file_name_arg:
        vault = common.fix_path(vault_path)
        file_abs = common.fix_path(file_path_arg)
        file_name = common.sanitize_name(file_name_arg)
        if not os.path.isdir(vault):
            common.safe_print(f"Error: Vault path not found: {vault}", file=sys.stderr)
            sys.exit(1)
        if not os.path.isfile(file_abs):
            common.safe_print(f"Error: File not found: {file_abs}", file=sys.stderr)
            sys.exit(1)
        stem = Path(file_name).stem
        src_dir = os.path.dirname(file_abs)
        medios_dir = os.path.join(vault, "Attachments", "Medios")
        os.makedirs(medios_dir, exist_ok=True)
        out_mp3 = os.path.join(medios_dir, f"{stem}.mp3")
        try:
            ffmpeg_bin = get_ffmpeg_path()
            ffprobe_bin = get_ffprobe_path()
        except RuntimeError as e:
            common.safe_print(f"Error: {e}", file=sys.stderr)
            sys.exit(1)
        probe_data = probe_audio_file(file_abs, ffprobe_bin)
        transcribe_path = file_abs
        remove_derived_mp3 = False
        if needs_conversion(probe_data):
            if not convert_audio(file_abs, out_mp3, ffmpeg_bin):
                common.safe_print("Error: Failed to convert audio to MP3.", file=sys.stderr)
                sys.exit(1)
            transcribe_path = out_mp3
            remove_derived_mp3 = True
        if os.path.getsize(transcribe_path) > MAX_MP3_BYTES:
            common.safe_print("Error: Audio exceeds 25 MB. Split audio first.", file=sys.stderr)
            if remove_derived_mp3 and os.path.isfile(out_mp3):
                try:
                    os.remove(out_mp3)
                except OSError:
                    pass
            sys.exit(1)
        try:
            srt_path, md_path = run_whisper_transcribe(
                transcribe_path,
                src_dir,
                stem,
                api_key,
                language=common.get_optional_param(args.language),
                model=args.model or "whisper-1",
                ffmpeg_bin=ffmpeg_bin,
                ffprobe_bin=ffprobe_bin,
            )
        except Exception as e:
            if remove_derived_mp3 and os.path.isfile(out_mp3):
                try:
                    os.remove(out_mp3)
                except OSError:
                    pass
            common.safe_print(f"Error: Transcription failed: {e}", file=sys.stderr)
            sys.exit(1)
        _update_markdown_links(md_path, file_name, stem)
        if remove_derived_mp3 and os.path.isfile(out_mp3):
            try:
                os.remove(out_mp3)
            except OSError as e:
                common.safe_print(f"Warning: Could not remove derived MP3: {e}", file=sys.stderr)
        common.safe_print(f"SRT: {srt_path}")
        common.safe_print(f"MD:  {md_path}")
        return

    if direct_file:
        file_abs = common.fix_path(direct_file)
        if not os.path.isfile(file_abs):
            common.safe_print(f"Error: File not found: {file_abs}", file=sys.stderr)
            sys.exit(1)
        stem = Path(file_abs).stem
        output_dir = common.fix_path(output_dir_arg) if output_dir_arg else os.path.dirname(file_abs)
        os.makedirs(output_dir, exist_ok=True)
        try:
            ffmpeg_bin = get_ffmpeg_path()
            ffprobe_bin = get_ffprobe_path()
        except RuntimeError as e:
            common.safe_print(f"Error: {e}", file=sys.stderr)
            sys.exit(1)
        try:
            srt_path, md_path = run_whisper_transcribe(
                file_abs,
                output_dir,
                stem,
                api_key,
                language=common.get_optional_param(args.language),
                model=args.model or "whisper-1",
                ffmpeg_bin=ffmpeg_bin,
                ffprobe_bin=ffprobe_bin,
            )
        except Exception as e:
            common.safe_print(f"Error: Transcription failed: {e}", file=sys.stderr)
            sys.exit(1)
        common.safe_print(f"SRT: {srt_path}")
        common.safe_print(f"MD:  {md_path}")
        return

    common.safe_print(
        "Error: Use --vault-path, --file-path, --file-name (Obsidian) or pass <file> (direct).",
        file=sys.stderr,
    )
    parser.print_help(sys.stderr)
    sys.exit(1)
