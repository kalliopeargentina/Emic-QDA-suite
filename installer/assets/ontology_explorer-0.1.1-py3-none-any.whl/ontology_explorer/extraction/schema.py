"""Data structures for extraction results."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class Evidence:
    document: str
    sentence: str

    @staticmethod
    def from_dict(data: dict[str, Any]) -> "Evidence":
        return Evidence(
            document=str(data.get("document", "")),
            sentence=str(data.get("sentence", "")),
        )

    def to_dict(self) -> dict[str, str]:
        return {"document": self.document, "sentence": self.sentence}


@dataclass
class Entity:
    name: str
    entity_type: str
    evidences: list[Evidence] = field(default_factory=list)

    def to_list(self) -> list:
        return [self.name, self.entity_type, [e.to_dict() for e in self.evidences]]


@dataclass
class Relation:
    relation_type: str
    source: str
    target: str
    evidences: list[Evidence] = field(default_factory=list)

    def to_list(self) -> list:
        return [self.relation_type, self.source, self.target, [e.to_dict() for e in self.evidences]]


@dataclass
class ExtractionResult:
    model: str
    entities: list[Entity] = field(default_factory=list)
    relations: list[Relation] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "model": self.model,
            "entities": [entity.to_list() for entity in self.entities],
            "relations": [relation.to_list() for relation in self.relations],
        }
