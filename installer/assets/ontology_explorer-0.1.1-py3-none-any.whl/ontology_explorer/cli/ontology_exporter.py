"""Programa CLI para exportar JSON de ontología a diferentes formatos.

Este programa permite convertir un archivo JSON con entidades y relaciones
a diferentes formatos de salida (JSON, Markdown, Ontología Markdown/JSON,
GraphML, TTL, RDF, JSON-LD).

Es extensible: para agregar nuevos exportadores, simplemente regístralos
en el diccionario EXPORTERS.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Callable

from ontology_explorer.exporters.graphml_export import generate_graph_graphml
from ontology_explorer.exporters.json_export import export_json
from ontology_explorer.exporters.markdown_export import generate_markdown_from_json
from ontology_explorer.exporters.ontology_export import (
    generate_ontology_json,
    generate_ontology_markdown,
)
from ontology_explorer.exporters.vault_markdown_export import (
    export_ontology_vault_markdown,
)
from ontology_explorer.exporters.rdf_export import (
    generate_graph_jsonld,
    generate_graph_rdf,
    generate_graph_ttl,
)


# Registro de exportadores
# Para agregar un nuevo exportador, simplemente agrega una entrada aquí
EXPORTERS: dict[str, dict[str, Callable]] = {
    "json": {
        "name": "JSON",
        "description": "JSON formateado (mismo formato de entrada)",
        "function": lambda entities, relations, **kwargs: export_json(
            {"entities": entities, "relations": relations}
        ),
        "extension": "json",
    },
    "markdown": {
        "name": "Markdown Simple",
        "description": "Markdown simple con entidades y relaciones agrupadas",
        "function": lambda entities, relations, **kwargs: generate_markdown_from_json(
            entities, relations
        ),
        "extension": "md",
    },
    "ontologia-markdown": {
        "name": "Ontología Markdown",
        "description": "Ontología en formato Markdown con estructura jerárquica",
        "function": lambda entities, relations, domain_name=None, config_dir=None, **kwargs: generate_ontology_markdown(
            entities, relations, domain_name=domain_name, config_dir=config_dir
        ),
        "extension": "md",
    },
    "ontologia-json": {
        "name": "Ontología JSON",
        "description": "Ontología en formato JSON estructurado",
        "function": lambda entities, relations, domain_name=None, config_dir=None, **kwargs: generate_ontology_json(
            entities, relations, domain_name=domain_name, config_dir=config_dir
        ),
        "extension": "json",
    },
    "vault-markdown": {
        "name": "Vault Markdown",
        "description": "Un archivo .md por entidad en carpetas por tipo, con frontmatter YAML y wikilinks (salida: directorio)",
        "function": lambda entities, relations, domain_name=None, config_dir=None, **kwargs: export_ontology_vault_markdown(
            entities, relations, domain_name=domain_name, config_dir=config_dir
        ),
        "extension": "md",
        "writes_directory": True,
    },
    "graphml": {
        "name": "GraphML",
        "description": "Grafo en formato GraphML (XML)",
        "function": lambda entities, relations, domain_name=None, config_dir=None, **kwargs: generate_graph_graphml(
            entities, relations, domain_name=domain_name, config_dir=config_dir
        ),
        "extension": "graphml",
    },
    "ttl": {
        "name": "Turtle (TTL)",
        "description": "RDF en formato Turtle",
        "function": lambda entities, relations, domain_name=None, config_dir=None, **kwargs: generate_graph_ttl(
            entities, relations, domain_name=domain_name, config_dir=config_dir
        ),
        "extension": "ttl",
    },
    "rdf": {
        "name": "RDF/XML",
        "description": "RDF en formato XML",
        "function": lambda entities, relations, domain_name=None, config_dir=None, **kwargs: generate_graph_rdf(
            entities, relations, domain_name=domain_name, config_dir=config_dir
        ),
        "extension": "rdf",
    },
    "jsonld": {
        "name": "JSON-LD",
        "description": "RDF en formato JSON-LD",
        "function": lambda entities, relations, domain_name=None, config_dir=None, **kwargs: generate_graph_jsonld(
            entities, relations, domain_name=domain_name, config_dir=config_dir
        ),
        "extension": "jsonld",
    },
}


def load_json_file(json_path: Path) -> dict:
    """Carga un archivo JSON y valida su estructura.
    
    Soporta dos formatos:
    1. Formato de entrada: {"entities": [...], "relations": [...]}
    2. Formato de ontología exportada: {"tipos": {"Tipo": [{"nombre": ..., "relaciones": [...]}]}}
    
    Si detecta el formato de ontología, lo convierte automáticamente al formato de entrada.
    """
    if not json_path.exists():
        raise FileNotFoundError(f"El archivo '{json_path}' no existe.")
    
    if not json_path.is_file():
        raise ValueError(f"'{json_path}' no es un archivo válido.")
    
    try:
        with open(json_path, encoding="utf-8") as f:
            data = json.load(f)
    except json.JSONDecodeError as e:
        raise ValueError(f"Error al parsear JSON: {e}")
    
    # Validar estructura básica
    if not isinstance(data, dict):
        raise ValueError("El JSON debe ser un objeto (dict).")
    
    # Detectar formato de ontología exportada y convertir
    if "tipos" in data and "entities" not in data:
        # Convertir formato de ontología a formato de entrada
        entities = []
        relations = []
        
        tipos = data.get("tipos", {})
        if not isinstance(tipos, dict):
            raise ValueError("'tipos' debe ser un objeto (dict).")
        
        for ent_type, entity_list in tipos.items():
            if not isinstance(entity_list, list):
                continue
            
            for entity_data in entity_list:
                if not isinstance(entity_data, dict):
                    continue
                
                nombre = entity_data.get("nombre")
                tipo = entity_data.get("tipo", ent_type)
                evidencias = entity_data.get("evidencias", [])
                
                if nombre:
                    # Agregar entidad
                    entities.append([nombre, tipo, evidencias])
                
                # NOTA: En el formato de ontología exportada, las propiedades ya están
                # procesadas y convertidas a relaciones en la sección "relaciones".
                # No necesitamos convertir las propiedades nuevamente, solo usar las relaciones existentes.
                
                # Procesar relaciones (ya incluyen las propiedades convertidas)
                relaciones = entity_data.get("relaciones", [])
                if isinstance(relaciones, list):
                    for rel in relaciones:
                        if isinstance(rel, dict):
                            rel_tipo = rel.get("tipo")
                            destino = rel.get("destino")
                            rel_evidencias = rel.get("evidencias", [])
                            
                            if rel_tipo and destino and nombre:
                                # Limpiar nombres de relaciones que tienen "inverse_of_" duplicado
                                # El JSON de ontología exportada puede tener relaciones inversas
                                # que luego se vuelven a invertir, causando "inverse_of_inverse_of_..."
                                cleaned_rel_tipo = str(rel_tipo).strip()  # Asegurar que es string y limpiar espacios
                                
                                # Remover todos los niveles de "inverse_of_" de forma segura
                                # Usar removeprefix que es más seguro que slicing manual
                                prefix = "inverse_of_"
                                while cleaned_rel_tipo.startswith(prefix):
                                    if hasattr(str, "removeprefix"):
                                        # Python 3.9+ - método más seguro
                                        cleaned_rel_tipo = cleaned_rel_tipo.removeprefix(prefix)
                                    else:
                                        # Fallback para Python < 3.9
                                        if len(cleaned_rel_tipo) >= len(prefix):
                                            cleaned_rel_tipo = cleaned_rel_tipo[len(prefix):]
                                        else:
                                            break
                                    # Si después de remover queda vacío, mantener el original
                                    if not cleaned_rel_tipo or not cleaned_rel_tipo.strip():
                                        cleaned_rel_tipo = rel_tipo
                                        break
                                
                                # Convertir guiones bajos a espacios para relaciones comunes
                                # (esto corrige casos donde "colabora_con" debería ser "colabora con")
                                # También corregir errores comunes como "olabora_con" -> "colabora con"
                                if "_" in cleaned_rel_tipo and " " not in cleaned_rel_tipo:
                                    # Intentar convertir guiones bajos a espacios para relaciones comunes
                                    common_relations = {
                                        "colabora_con": "colabora con",
                                        "olabora_con": "colabora con",  # Corregir error común
                                        "trabaja_en": "trabaja en",
                                        "participa_en": "participa en",
                                        "tiene_ubicación": "tiene ubicación",
                                        "tiene_tipo": "tiene tipo",
                                        "tiene_sector": "tiene sector",
                                        "tiene_monto": "tiene monto",
                                        "tiene_fecha": "tiene fecha",
                                        "tiene_moneda": "tiene moneda",
                                    }
                                    if cleaned_rel_tipo in common_relations:
                                        cleaned_rel_tipo = common_relations[cleaned_rel_tipo]
                                
                                # Formato esperado: [tipo_relacion, origen, destino, evidencias]
                                relations.append([cleaned_rel_tipo, nombre, destino, rel_evidencias])
        
        # Retornar en formato de entrada
        return {"entities": entities, "relations": relations}
    
    # Validar formato de entrada estándar
    if "entities" not in data:
        raise ValueError(
            "El JSON debe contener una clave 'entities' o 'tipos' (formato de ontología exportada)."
        )
    
    if "relations" not in data:
        raise ValueError("El JSON debe contener una clave 'relations'.")
    
    if not isinstance(data["entities"], list):
        raise ValueError("'entities' debe ser una lista.")
    
    if not isinstance(data["relations"], list):
        raise ValueError("'relations' debe ser una lista.")
    
    return data


def export_to_format(
    entities: list,
    relations: list,
    format_name: str,
    domain_name: str | None = None,
    config_dir: str | None = None,
) -> str | dict[str, str]:
    """Exporta entidades y relaciones al formato especificado."""
    if format_name not in EXPORTERS:
        available = ", ".join(EXPORTERS.keys())
        raise ValueError(
            f"Formato '{format_name}' no reconocido. Formatos disponibles: {available}"
        )
    
    exporter = EXPORTERS[format_name]
    function = exporter["function"]
    
    # Llamar a la función con los parámetros apropiados
    try:
        if format_name in (
            "ontologia-markdown",
            "ontologia-json",
            "vault-markdown",
            "graphml",
            "ttl",
            "rdf",
            "jsonld",
        ):
            result = function(
                entities, relations, domain_name=domain_name, config_dir=config_dir
            )
        else:
            result = function(entities, relations)

        # vault-markdown returns dict of path -> content; leave as dict for main() to write directory
        if format_name == "vault-markdown" and isinstance(result, dict):
            return result

        # Si el resultado es un dict (como ontologia-json), convertirlo a JSON string
        if isinstance(result, dict):
            return json.dumps(result, ensure_ascii=False, indent=2)

        return result
    except Exception as e:
        raise RuntimeError(f"Error al exportar a {format_name}: {e}") from e


def parse_args() -> argparse.Namespace:
    """Parsea los argumentos de línea de comandos."""
    parser = argparse.ArgumentParser(
        description=(
            "Exporta un archivo JSON con entidades y relaciones a diferentes formatos. "
            "Formatos disponibles: JSON, Markdown, Ontología (Markdown/JSON), GraphML, "
            "TTL, RDF, JSON-LD."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Ejemplos:\n"
            "  %(prog)s input.json --format markdown\n"
            "  %(prog)s input.json --format ontologia-markdown --domain venture-capital\n"
            "  %(prog)s input.json --format graphml --output resultado.graphml\n"
            "  %(prog)s input.json --format ttl [--domain venture-capital] -o out.ttl\n"
            "  %(prog)s input.json --format rdf -o out.rdf\n"
            "  %(prog)s input.json --format jsonld -o out.jsonld\n"
            "\n"
            "Para agregar nuevos exportadores, edita el diccionario EXPORTERS en el código."
        ),
    )
    
    parser.add_argument(
        "input",
        type=Path,
        nargs="?",
        default=None,
        help="Archivo JSON de entrada con entidades y relaciones (no requerido con --list-formats)",
    )
    
    parser.add_argument(
        "--format",
        "-f",
        choices=list(EXPORTERS.keys()),
        default="json",
        help="Formato de salida (por defecto: json)",
    )
    
    parser.add_argument(
        "--output",
        "-o",
        type=Path,
        default=None,
        help=(
            "Archivo de salida. Si no se especifica, se usa el nombre del archivo de entrada "
            "con la extensión apropiada para el formato seleccionado."
        ),
    )
    parser.add_argument(
        "--output-name",
        type=str,
        default=None,
        help=(
            "Nombre base de salida (sin extensión). Se usa si no se especifica --output. "
            "Para vault-markdown crea un directorio con ese nombre."
        ),
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=None,
        help=(
            "Directorio base donde escribir la salida. Si se especifica, el archivo o directorio "
            "de salida se crea dentro de este directorio (junto con --output-name o nombre por defecto)."
        ),
    )
    parser.add_argument(
        "--domain",
        type=str,
        default=None,
        help=(
            "Nombre del dominio a usar para exportadores que lo requieren "
            "(ontologia-markdown, ontologia-json, graphml, ttl, rdf, jsonld). "
            "Por defecto: 'default'. Los dominios se cargan desde config/domains/."
        ),
    )
    
    parser.add_argument(
        "--config-dir",
        type=Path,
        default=None,
        help=(
            "Directorio desde donde se cargan las definiciones de dominios. "
            "Por defecto: 'config' (relativo a la raíz del proyecto)."
        ),
    )
    
    parser.add_argument(
        "--list-formats",
        action="store_true",
        help="Lista todos los formatos disponibles y sale",
    )
    
    return parser.parse_args()


def list_formats() -> None:
    """Lista todos los formatos disponibles."""
    print("Formatos disponibles:\n")
    for format_key, format_info in EXPORTERS.items():
        print(f"  {format_key:20} - {format_info['name']}")
        print(f"  {'':20}   {format_info['description']}")
        print(f"  {'':20}   Extensión: .{format_info['extension']}\n")


def main() -> None:
    """Función principal del programa."""
    args = parse_args()
    
    if args.list_formats:
        list_formats()
        return

    if args.input is None:
        print("Error: se requiere archivo JSON de entrada.", file=sys.stderr)
        sys.exit(1)

    # Cargar JSON de entrada
    try:
        data = load_json_file(args.input)
    except (FileNotFoundError, ValueError) as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
    
    entities = data.get("entities", [])
    relations = data.get("relations", [])
    
    # Determinar archivo o directorio de salida
    exporter = EXPORTERS[args.format]
    writes_directory = exporter.get("writes_directory", False)
    base_dir = args.output_dir.resolve() if args.output_dir else args.input.parent
    if args.output:
        output_path = args.output
    else:
        extension = exporter["extension"]
        if args.output_name:
            output_name_path = Path(args.output_name)
            if writes_directory:
                output_path = base_dir / output_name_path.with_suffix("")
            else:
                if output_name_path.suffix:
                    output_path = base_dir / output_name_path
                else:
                    output_path = base_dir / f"{output_name_path}.{extension}"
        else:
            if writes_directory:
                output_path = base_dir / f"{args.input.stem}_vault"
            else:
                output_path = base_dir / f"{args.input.stem}.{extension}"

    # Convertir config_dir a string si es Path
    config_dir_str = str(args.config_dir) if args.config_dir else None

    # Exportar
    try:
        result = export_to_format(
            entities=entities,
            relations=relations,
            format_name=args.format,
            domain_name=args.domain,
            config_dir=config_dir_str,
        )
    except (ValueError, RuntimeError) as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)

    # Escribir resultado
    if writes_directory and isinstance(result, dict):
        try:
            # Si el usuario pasó un archivo (ej. -o out.md), usar el padre como directorio
            base_dir = output_path.parent if output_path.suffix else output_path
            base_dir.mkdir(parents=True, exist_ok=True)
            for rel_path, content in result.items():
                file_path = base_dir / rel_path
                file_path.parent.mkdir(parents=True, exist_ok=True)
                file_path.write_text(content, encoding="utf-8")
            print(f"Exportado a directorio: {base_dir} ({len(result)} archivos)", file=sys.stderr)
            for rel_path in sorted(result.keys()):
                print(rel_path, flush=True)
        except OSError as e:
            print(f"Error al escribir archivos: {e}", file=sys.stderr)
            sys.exit(1)
    else:
        try:
            output_path.parent.mkdir(parents=True, exist_ok=True)
            with open(output_path, "w", encoding="utf-8") as f:
                f.write(result)
            print(f"Exportado a: {output_path}", file=sys.stderr)
        except OSError as e:
            print(f"Error al escribir archivo: {e}", file=sys.stderr)
            sys.exit(1)
        print(result, flush=True)


if __name__ == "__main__":
    main()
