"""
Corpus processing utilities for topic analysis.

This module provides functions for processing folders of markdown files,
extracting documents, and preparing them for corpus-level topic analysis.
"""

import re
from pathlib import Path
from typing import List, Dict, Optional

# Handle both relative and absolute imports
try:
    from .text_processing import extract_text_from_markdown_content
    from .config import DEFAULT_CONFIG
except ImportError:
    # Fallback to absolute imports (when running directly)
    import sys
    current_file = Path(__file__).resolve()
    parent_dir = current_file.parent
    
    # Add parent directory to path if not already there
    if str(parent_dir) not in sys.path:
        sys.path.insert(0, str(parent_dir))
    
    from text_processing import extract_text_from_markdown_content
    from config import DEFAULT_CONFIG


def find_markdown_files(folder_path: Path, recursive: bool = True, 
                        file_pattern: str = '*.md') -> List[Path]:
    """
    Find all markdown files in a folder.
    
    Parameters:
    -----------
    folder_path : Path
        Path to the folder to search
    recursive : bool
        Whether to search subdirectories (default: True)
    file_pattern : str
        Glob pattern for files to match (default: '*.md')
    
    Returns:
    --------
    List[Path]
        List of paths to markdown files found
    """
    if not folder_path.exists() or not folder_path.is_dir():
        raise ValueError(f"Path does not exist or is not a directory: {folder_path}")
    
    if recursive:
        files = list(folder_path.rglob(file_pattern))
    else:
        files = list(folder_path.glob(file_pattern))
    
    # Filter out directories (in case of weird filesystem behavior)
    files = [f for f in files if f.is_file()]
    
    return sorted(files)


def extract_documents_from_folder(folder_path: Path, recursive: bool = True,
                                   file_pattern: str = '*.md',
                                   min_document_length: Optional[int] = None) -> List[Dict]:
    """
    Extract text from all markdown files in a folder.
    
    Each file becomes one document in the corpus.
    
    Parameters:
    -----------
    folder_path : Path
        Path to the folder containing markdown files
    recursive : bool
        Whether to search subdirectories (default: True)
    file_pattern : str
        Glob pattern for files to match (default: '*.md')
    min_document_length : int or None
        Minimum character length for a document to be included (default: from config)
    
    Returns:
    --------
    List[Dict]
        List of document dictionaries, each containing:
        - 'file_path': Path to the source file
        - 'file_name': Name of the file (for display)
        - 'raw_text': Raw text content (with markdown formatting)
        - 'clean_text': Clean text content (markdown stripped)
        - 'relative_path': Relative path from folder_path to file (for display)
    """
    if min_document_length is None:
        min_document_length = DEFAULT_CONFIG['corpus_processing'].get('min_document_length', 100)
    
    # Find all markdown files
    md_files = find_markdown_files(folder_path, recursive, file_pattern)
    
    if len(md_files) == 0:
        raise ValueError(f"No markdown files found in {folder_path} (pattern: {file_pattern})")
    
    documents = []
    for md_file in md_files:
        try:
            # Read raw content
            with open(md_file, 'r', encoding='utf-8') as f:
                raw_content = f.read()
            
            # Extract clean text
            clean_text = extract_text_from_markdown_content(raw_content)
            
            # Check minimum length
            if len(clean_text.strip()) < min_document_length:
                continue
            
            # Calculate relative path for display
            try:
                relative_path = md_file.relative_to(folder_path)
            except ValueError:
                # If relative path calculation fails, use absolute path
                relative_path = md_file
            
            documents.append({
                'file_path': md_file,
                'file_name': md_file.stem,  # Filename without extension
                'raw_text': raw_content,
                'clean_text': clean_text,
                'relative_path': relative_path
            })
        except Exception as e:
            print(f"Warning: Could not process {md_file}: {e}")
            continue
    
    if len(documents) == 0:
        raise ValueError(
            f"No valid documents found in {folder_path}. "
            f"All files were either too short (min {min_document_length} chars) or had errors."
        )
    
    return documents


def split_document_into_sentences(document: Dict, min_sentence_length: Optional[int] = None) -> List[str]:
    """
    Split a document into sentences for topic modeling.
    
    Parameters:
    -----------
    document : Dict
        Document dictionary (from extract_documents_from_folder)
    min_sentence_length : int or None
        Minimum sentence length in characters (default: from config)
    
    Returns:
    --------
    List[str]
        List of sentences from the document
    """
    if min_sentence_length is None:
        min_sentence_length = DEFAULT_CONFIG['text_processing']['min_sentence_length']
    
    clean_text = document['clean_text']
    sentences = re.split(r'[.!?]+', clean_text)
    sentences = [s.strip() for s in sentences if len(s.strip()) > min_sentence_length]
    
    return sentences


def prepare_corpus_for_analysis(documents: List[Dict], 
                                min_sentence_length: Optional[int] = None) -> tuple:
    """
    Prepare corpus documents for topic modeling by splitting into sentences.
    
    Parameters:
    -----------
    documents : List[Dict]
        List of document dictionaries from extract_documents_from_folder
    min_sentence_length : int or None
        Minimum sentence length (default: from config)
    
    Returns:
    --------
    tuple
        (all_sentences, document_labels)
        - all_sentences: List of sentence strings
        - document_labels: List of document identifiers (one per sentence)
    """
    if min_sentence_length is None:
        min_sentence_length = DEFAULT_CONFIG['text_processing']['min_sentence_length']
    
    all_sentences = []
    document_labels = []
    
    for doc in documents:
        sentences = split_document_into_sentences(doc, min_sentence_length)
        
        # Use file_name as label (can be customized)
        doc_label = doc['file_name']
        
        for sentence in sentences:
            all_sentences.append(sentence)
            document_labels.append(doc_label)
    
    return all_sentences, document_labels


def get_corpus_statistics(documents: List[Dict]) -> Dict:
    """
    Calculate statistics about the corpus.
    
    Parameters:
    -----------
    documents : List[Dict]
        List of document dictionaries
    
    Returns:
    --------
    Dict
        Dictionary with corpus statistics:
        - 'num_documents': Number of documents
        - 'total_characters': Total characters across all documents
        - 'avg_document_length': Average document length
        - 'min_document_length': Minimum document length
        - 'max_document_length': Maximum document length
        - 'document_names': List of document names
    """
    if len(documents) == 0:
        return {
            'num_documents': 0,
            'total_characters': 0,
            'avg_document_length': 0,
            'min_document_length': 0,
            'max_document_length': 0,
            'document_names': []
        }
    
    doc_lengths = [len(doc['clean_text']) for doc in documents]
    total_chars = sum(doc_lengths)
    
    return {
        'num_documents': len(documents),
        'total_characters': total_chars,
        'avg_document_length': total_chars / len(documents) if documents else 0,
        'min_document_length': min(doc_lengths),
        'max_document_length': max(doc_lengths),
        'document_names': [doc['file_name'] for doc in documents]
    }

