"""Gemini provider."""

from __future__ import annotations

import os
import sys

from .base import Provider, ProviderConfig


class GeminiProvider(Provider):
    def run(self, prompt: str, model: str, config: ProviderConfig) -> str:
        api_key = config.api_key or os.getenv("GEMINI_API_KEY")
        if not api_key:
            raise SystemExit(
                "Proporcioná la clave de Gemini con --api-key o definí GEMINI_API_KEY."
            )

        try:
            import google.generativeai as genai
        except ImportError as exc:
            raise SystemExit(
                "No se encuentra el paquete 'google-generativeai'. Instalalo con "
                "'pip install google-generativeai'."
            ) from exc

        genai.configure(api_key=api_key)

        try:
            print(f"Consultando Gemini con modelo: {model}", file=sys.stderr, flush=True)

            model_obj = genai.GenerativeModel(model_name=model)
            generation_config: dict[str, object] = {
                "response_mime_type": "application/json"
            }

            if config.temperature is not None:
                generation_config["temperature"] = config.temperature
            # Note: response_schema not supported in generation_config for this library version
            # Rely on prompt instructions for JSON format instead
            # Timeout: google-generativeai may not expose request timeout; exceptions propagate
            try:
                response = model_obj.generate_content(
                    prompt,
                    generation_config=generation_config,
                )
            except Exception as exc:
                # Re-raise the exception (no fallback needed since we don't use response_schema)
                raise
        except Exception as exc:
            raise SystemExit(f"Gemini devolvió un error: {exc}") from exc

        text = getattr(response, "text", None)
        if not text:
            raise SystemExit("Gemini no devolvió contenido de texto.")

        print(f"Output recibido ({len(text)} caracteres)", file=sys.stderr, flush=True)
        return text.strip()
