"""Lazy-load backends to avoid importing pysentimiento (Trainer/datasets) when using transformers."""
import importlib

# Map name -> (module_path, class_name) for lazy import; avoids pysentimiento's Trainer import
_BACKEND_LOADERS = {
    "pysentimiento": (".pysentimiento_backend", "PySentimientoBackend"),
    "transformers": (".transformers_backend", "TransformersBackend"),
    "pysentimiento-emotion": (".pysentimiento_emotion_backend", "PySentimientoEmotionBackend"),
    "transformers-emotion": (".transformers_emotion_backend", "TransformersEmotionBackend"),
}


def _get_backend_class(name: str):
    if name not in _BACKEND_LOADERS:
        raise ValueError(f"Algoritmo no soportado: {name}. Opciones: {list(_BACKEND_LOADERS)}")
    mod_path, cls_name = _BACKEND_LOADERS[name]
    mod = importlib.import_module(mod_path, package=__name__)
    return getattr(mod, cls_name)


# For backward compat and listing options
BACKENDS = _BACKEND_LOADERS


