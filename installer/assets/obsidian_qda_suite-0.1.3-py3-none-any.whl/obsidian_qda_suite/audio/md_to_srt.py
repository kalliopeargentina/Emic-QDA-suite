"""Convert corrected Markdown transcript into SRT."""

import re
from pathlib import Path
from datetime import timedelta
from typing import List, Optional, Tuple

WIKILINK_BULLET_RE = re.compile(
    r"^\s*-\s*\[\[(?P<target>[^\]#|]+?)#t=(?P<sec>\d+)\|(?P<display>[^\]]+)\]\]\s*(?P<text>.*)$"
)
HASHLINK_BULLET_RE = re.compile(
    r"^\s*-\s*\[(?P<display>[0-9]{1,2}:[0-9]{2}(?::[0-9]{2})?)\]\(#t=(?P<sec>\d+)\)\s*(?P<text>.*)$"
)
MEDIA_WIKILINK_RE = re.compile(r"\[\[(?P<media>[^\]#|]+)\]\]")

MD_WIKILINK_WITH_ALIAS = re.compile(r"\[\[([^\]|]+)\|([^\]]+)\]\]")
MD_WIKILINK_NO_ALIAS = re.compile(r"\[\[([^\]]+)\]\]")
MD_LINK = re.compile(r"!??\[([^\]]*)\]\([^\)]*\)")
MD_CODE = re.compile(r"`([^`]*)`")
MD_BOLD_ITALIC = re.compile(r"(\*\*|__|\*|_|~~)")
MD_FOOTNOTE_REF = re.compile(r"\[\^[^\]]+\]")
MD_HTML_TAG = re.compile(r"<[^>]+>")
MD_ESCAPES = re.compile(r"\\([*_`\[\](){}#+\-.!|>])")
MD_INLINE_MATH = re.compile(r"\$([^$]+)\$")
MD_HIGHLIGHT = re.compile(r"==([^=]+)==")
MD_REF_LINK = re.compile(r"\[([^\]]+)\]\[[^\]]*\]")


def format_srt_timestamp(seconds_float: float) -> str:
    td = timedelta(seconds=seconds_float)
    total_ms = int(td.total_seconds() * 1000)
    hours, remainder_ms = divmod(total_ms, 3600 * 1000)
    minutes, remainder_ms = divmod(remainder_ms, 60 * 1000)
    seconds, milliseconds = divmod(remainder_ms, 1000)
    return f"{hours:02d}:{minutes:02d}:{seconds:02d},{milliseconds:03d}"


def parse_markdown(md_path: Path) -> Tuple[Optional[Path], List[Tuple[int, str]]]:
    """Return (media_path_relative, segments[(start_sec, text)])."""
    media_rel: Optional[Path] = None
    segments: List[Tuple[int, str]] = []
    with open(md_path, "r", encoding="utf-8") as f:
        for line in f:
            m = WIKILINK_BULLET_RE.match(line)
            if m:
                target = m.group("target").strip()
                sec = int(m.group("sec"))
                text = m.group("text").strip()
                if not media_rel:
                    media_rel = Path(target)
                segments.append((sec, text))
                continue
            m2 = HASHLINK_BULLET_RE.match(line)
            if m2:
                sec = int(m2.group("sec"))
                text = m2.group("text").strip()
                segments.append((sec, text))
                continue
            if media_rel is None:
                m3 = MEDIA_WIKILINK_RE.search(line)
                if m3:
                    media_rel = Path(m3.group("media").strip())
    segments.sort(key=lambda x: x[0])
    return media_rel, segments


def strip_markdown(text: str) -> str:
    text = MD_WIKILINK_WITH_ALIAS.sub(lambda m: m.group(2), text)
    text = MD_WIKILINK_NO_ALIAS.sub(lambda m: Path(m.group(1)).name, text)
    text = MD_LINK.sub(lambda m: m.group(1), text)
    text = MD_CODE.sub(lambda m: m.group(1), text)
    text = MD_BOLD_ITALIC.sub("", text)
    text = MD_HIGHLIGHT.sub(lambda m: m.group(1), text)
    text = MD_REF_LINK.sub(lambda m: m.group(1), text)
    text = MD_FOOTNOTE_REF.sub("", text)
    text = MD_INLINE_MATH.sub(lambda m: m.group(1), text)
    text = MD_HTML_TAG.sub("", text)
    text = MD_ESCAPES.sub(lambda m: m.group(1), text)
    text = text.replace("|", " ")
    text = re.sub(r"\s+", " ", text).strip()
    return text


def write_srt(segments: List[Tuple[int, str]], srt_path: Path) -> None:
    if not segments:
        raise ValueError("No timestamped bullets found in markdown.")
    with open(srt_path, "w", encoding="utf-8") as f:
        for idx, (start_sec, text) in enumerate(segments, start=1):
            cleaned = strip_markdown(text)
            if idx < len(segments):
                next_start = segments[idx][0]
                end_sec = max(start_sec + 1.5, next_start - 0.5)
            else:
                end_sec = start_sec + 3.0
            start_ts = format_srt_timestamp(start_sec)
            end_ts = format_srt_timestamp(end_sec)
            f.write(f"{idx}\n")
            f.write(f"{start_ts} --> {end_ts}\n")
            f.write(f"{cleaned}\n\n")


def run(
    md_path: Path,
    srt_output: Optional[Path] = None,
    output_basename: Optional[str] = None,
) -> Path:
    """
    Convert markdown transcript to SRT.
    md_path: path to .md file.
    srt_output: optional dir or file path for SRT; if dir, writes <media_stem>.srt there
        unless output_basename is set.
    output_basename: if set and srt_output is a dir, use srt_output / (output_basename + ".srt").
    Returns path to written SRT file.
    """
    if not md_path.exists():
        raise FileNotFoundError(f"Markdown file not found: {md_path}")
    media_rel, segments = parse_markdown(md_path)
    if media_rel is None:
        raise ValueError("Could not determine media file path from markdown (no wikilink found).")
    media_abs = (md_path.parent / media_rel).resolve()

    if srt_output is not None:
        out = Path(srt_output)
        if out.exists() and out.is_dir() or out.suffix.lower() != ".srt":
            out.mkdir(parents=True, exist_ok=True)
            if output_basename:
                srt_path = out / f"{output_basename}.srt"
            else:
                srt_path = out / media_abs.with_suffix(".srt").name
        else:
            srt_path = out
            srt_path.parent.mkdir(parents=True, exist_ok=True)
    else:
        srt_path = media_abs.with_suffix(".srt")

    write_srt(segments, srt_path)
    return srt_path
