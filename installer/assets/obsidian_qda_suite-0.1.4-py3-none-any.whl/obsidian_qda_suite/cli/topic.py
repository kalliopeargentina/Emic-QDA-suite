"""CLI for topic analysis. File or folder. Obsidian or direct args."""

import argparse
import os
import re
import sys
from pathlib import Path

from . import common
from ..config import get_paths_config

# Method aliases (aligned with run_topic_analysis.py)
METHOD_ALIASES = {
    "guided": "guided-lda",
    "guided_lda": "guided-lda",
    "guided lda": "guided-lda",
    "cor-ex": "corex",
    "co-rex": "corex",
    "latent semantic": "lsa",
    "top2-vec": "top2vec",
    "top2 vec": "top2vec",
    "ber-topic": "bertopic",
    "ber topic": "bertopic",
}
VALID_METHODS = ["lda", "nmf", "guided-lda", "hdp", "corex", "lsi", "lsa", "top2vec", "bertopic"]


def _parse_topics(value: str | None) -> int | None:
    """Parse --topics: None/'Auto'/empty → None (auto-detect); digit string → int."""
    raw = common.get_optional_param(value)
    if not raw:
        return None
    clean = common.sanitize_text(raw)
    if not clean or clean.strip().lower() == "auto":
        return None
    if clean.isdigit():
        return int(clean)
    common.safe_print(
        f"Warning: Invalid --topics value '{value}' (ignored; use a number or 'Auto')",
        file=sys.stderr,
    )
    return None


def _parse_float(value: str | None, name: str) -> float | None:
    """Parse optional float; return None if missing/invalid."""
    raw = common.get_optional_param(value)
    if not raw:
        return None
    clean = common.sanitize_text(raw)
    if clean and re.match(r"^\d+(\.\d+)?$", clean):
        return float(clean)
    if clean:
        common.safe_print(f"Warning: Invalid {name} value '{value}' (ignored)", file=sys.stderr)
    return None


def main() -> None:
    common.setup_console_encoding()
    parser = argparse.ArgumentParser(description="Topic analysis on file or folder.")
    parser.add_argument("--vault-path", type=str, help="Obsidian vault path (Obsidian mode)")
    parser.add_argument("--file-path", type=str, help="Path to file/folder (Obsidian mode)")
    parser.add_argument("--file-name", type=str, help="Name (Obsidian mode)")
    parser.add_argument(
        "--method",
        type=str,
        default="lda",
        help="Method: lda | nmf | guided-lda | hdp | corex | lsi | lsa | top2vec | bertopic",
    )
    parser.add_argument(
        "--topics",
        type=str,
        default=None,
        help="Number of topics, or 'Auto' for auto-detect (default: Auto)",
    )
    parser.add_argument("--seed-words", type=str, help="Path to seed words file (e.g. for guided-lda)")
    parser.add_argument("--top2vec-embedding", type=str, help="Top2Vec embedding model name")
    parser.add_argument("--hdp-gamma", type=str, help="HDP gamma (float)")
    parser.add_argument("--hdp-alpha", type=str, help="HDP alpha (float)")
    parser.add_argument("--bertopic-min-topic-size", type=str, help="BERTopic min topic size")
    parser.add_argument("--bertopic-top-n-words", type=str, help="BERTopic top N words")
    parser.add_argument("--bertopic-diversity", type=str, help="BERTopic diversity (0–1)")
    parser.add_argument("--bertopic-calc-probs", type=str, help="BERTopic calculate probs (true/false)")
    parser.add_argument("--bertopic-embedding-model", type=str, help="BERTopic embedding model name")
    parser.add_argument("--output", type=str, help="Output path")
    parser.add_argument("--md-dir", type=str, help="Output dir for markdown")
    parser.add_argument("--images-dir", type=str, help="Output dir for images")
    parser.add_argument("--stopwords-file", type=str, help="Path to stopwords file (overrides config default)")
    parser.add_argument("--seedwords-file", type=str, help="Path to seed words file for guided-lda (overrides config default)")
    parser.add_argument(
        "--check-embeddings",
        action="store_true",
        help="Check availability of Top2Vec/BERTopic embedding models and exit",
    )
    parser.add_argument("input_path", type=str, nargs="?", help="File or folder (direct mode)")
    args = parser.parse_args()

    if args.check_embeddings:
        from ..analysis.topic_analysis.embeddings_check import check_embeddings
        check_embeddings(verbose=True)
        sys.exit(0)

    vault_path = common.get_optional_param(args.vault_path)
    file_path_arg = common.get_optional_param(args.file_path)
    file_name_arg = common.get_optional_param(args.file_name)
    input_path = common.get_optional_param(args.input_path)

    file_abs = None
    obsidian_mode = bool(vault_path and file_path_arg and file_name_arg)
    md_dir = common.get_optional_param(args.md_dir)
    images_dir = common.get_optional_param(args.images_dir)
    stopwords_file = None

    if vault_path and file_path_arg:
        vault = common.fix_path(vault_path)
        file_abs = common.fix_path(file_path_arg)
        if not os.path.isdir(vault):
            common.safe_print(f"Error: Vault path not found: {vault}", file=sys.stderr)
            sys.exit(1)
        if not os.path.exists(file_abs):
            common.safe_print(f"Error: Path not found: {file_abs}", file=sys.stderr)
            sys.exit(1)
        if obsidian_mode:
            paths_config = get_paths_config(vault)
            safe_stem = common.sanitize_name(Path(file_name_arg).stem)
            base_dir = os.path.join(vault, paths_config["topic_analysis_dir"], safe_stem)
            images_dir = images_dir or os.path.join(base_dir, "images")
            md_dir = md_dir or base_dir
            os.makedirs(base_dir, exist_ok=True)
            os.makedirs(images_dir, exist_ok=True)
            stopwords_path = common.get_optional_param(args.stopwords_file)
            if stopwords_path:
                stopwords_path = common.fix_path(stopwords_path)
            else:
                stopwords_path = os.path.join(vault, paths_config["topic_stopwords_file"])
            os.makedirs(os.path.dirname(stopwords_path), exist_ok=True)
            if not os.path.isfile(stopwords_path):
                Path(stopwords_path).touch()
            stopwords_file = stopwords_path
    elif input_path:
        file_abs = common.fix_path(input_path)
        if not os.path.exists(file_abs):
            common.safe_print(f"Error: Path not found: {file_abs}", file=sys.stderr)
            sys.exit(1)
    else:
        common.safe_print(
            "Error: Use --vault-path and --file-path (Obsidian) or pass input_path (direct).",
            file=sys.stderr,
        )
        parser.print_help(sys.stderr)
        sys.exit(1)

    method_raw = (args.method or "lda").strip().lower()
    method = METHOD_ALIASES.get(method_raw, method_raw)
    if method not in VALID_METHODS:
        common.safe_print(
            f"Error: Invalid --method '{method}'. Use: {' | '.join(VALID_METHODS)}",
            file=sys.stderr,
        )
        sys.exit(1)

    topics_int = _parse_topics(args.topics)
    seed_words = common.get_optional_param(args.seedwords_file) or common.get_optional_param(args.seed_words)
    if method == "guided-lda" and not seed_words and obsidian_mode and vault_path:
        paths_config = get_paths_config(common.fix_path(vault_path))
        seed_path = os.path.join(common.fix_path(vault_path), paths_config["topic_seedwords_file"])
        os.makedirs(os.path.dirname(seed_path), exist_ok=True)
        if not os.path.isfile(seed_path):
            Path(seed_path).touch()
        seed_words = seed_path

    argv = ["topic_main", str(file_abs), "--method", method]
    if topics_int is not None:
        argv.extend(["--topics", str(topics_int)])
    if seed_words:
        argv.extend(["--seed-words-file", common.fix_path(seed_words)])
    top2vec = common.get_optional_param(args.top2vec_embedding)
    if top2vec:
        argv.extend(["--top2vec-embedding-model", re.sub(r"\s{2,}", " ", common.sanitize_text(top2vec) or top2vec)])
    hdp_g = _parse_float(args.hdp_gamma, "hdp-gamma")
    if hdp_g is not None:
        argv.extend(["--hdp-gamma", str(hdp_g)])
    hdp_a = _parse_float(args.hdp_alpha, "hdp-alpha")
    if hdp_a is not None:
        argv.extend(["--hdp-alpha", str(hdp_a)])
    bt_min_raw = common.get_optional_param(args.bertopic_min_topic_size)
    if bt_min_raw:
        clean = common.sanitize_text(bt_min_raw)
        if clean and clean.isdigit():
            argv.extend(["--bertopic-min-topic-size", clean])
        elif clean:
            common.safe_print(
                "Warning: Invalid --bertopic-min-topic-size (ignored)",
                file=sys.stderr,
            )
    bt_n_raw = common.get_optional_param(args.bertopic_top_n_words)
    if bt_n_raw:
        clean = common.sanitize_text(bt_n_raw)
        if clean and clean.isdigit():
            argv.extend(["--bertopic-top-n-words", clean])
        elif clean:
            common.safe_print(
                "Warning: Invalid --bertopic-top-n-words (ignored)",
                file=sys.stderr,
            )
    bt_div_raw = common.get_optional_param(args.bertopic_diversity)
    if bt_div_raw:
        d = _parse_float(bt_div_raw, "bertopic-diversity")
        if d is not None:
            d = max(0.0, min(1.0, d))
            argv.extend(["--bertopic-diversity", str(d)])
    bt_probs = common.get_optional_param(args.bertopic_calc_probs)
    if bt_probs:
        p = common.sanitize_text(bt_probs).lower()
        if p in ("true", "false"):
            argv.extend(["--bertopic-calculate-probabilities", p])
        elif p:
            common.safe_print(
                "Warning: Invalid --bertopic-calc-probs (use true/false; ignored)",
                file=sys.stderr,
            )
    bt_emb = common.get_optional_param(args.bertopic_embedding_model)
    if bt_emb:
        argv.extend(["--bertopic-embedding-model", re.sub(r"\s{2,}", " ", common.sanitize_text(bt_emb) or bt_emb)])
    if args.output:
        argv.extend(["--output", args.output])
    if md_dir:
        argv.extend(["--md-dir", md_dir])
    if images_dir:
        argv.extend(["--images-dir", images_dir])
    if stopwords_file:
        argv.extend(["--stopwords-file", stopwords_file])

    orig_argv = sys.argv
    try:
        sys.argv = argv
        from ..analysis.topic_analysis import main as topic_main
        topic_main.main()
    except SystemExit as e:
        if e.code != 0:
            sys.exit(e.code if e.code is not None else 1)
    except Exception as e:
        common.safe_print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
    finally:
        sys.argv = orig_argv
