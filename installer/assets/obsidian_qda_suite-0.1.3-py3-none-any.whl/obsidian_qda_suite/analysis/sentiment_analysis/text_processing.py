import re


def extract_text_from_markdown_content(content: str) -> str:
    content = re.sub(r'```[\s\S]*?```', '', content)
    content = re.sub(r'~~~[\s\S]*?~~~', '', content)
    content = re.sub(r'`([^`]+)`', r'\1', content)
    content = re.sub(r'!\[([^\]]*)\]\([^\)]+\)', r'\1', content)
    content = re.sub(r'\[([^\]]+)\]\([^\)]+\)', r'\1', content)
    content = re.sub(r'\[\[([^\]]+)\]\]', lambda m: m.group(1).split('|')[-1], content)
    content = re.sub(r'\*\*([^\*]+)\*\*', r'\1', content)
    content = re.sub(r'__([^_]+)__', r'\1', content)
    content = re.sub(r'\*([^\*]+)\*', r'\1', content)
    content = re.sub(r'_([^_]+)_', r'\1', content)
    content = re.sub(r'~~([^~]+)~~', r'\1', content)
    content = re.sub(r'#{1,6}\s+', '', content)
    content = re.sub(r'^[\s]*[-*_]{3,}[\s]*$', '', content, flags=re.MULTILINE)
    content = re.sub(r'^>\s*', '', content, flags=re.MULTILINE)
    content = re.sub(r'^\s*[-*+]\s+', '', content, flags=re.MULTILINE)
    content = re.sub(r'^\s*\d+\.\s+', '', content, flags=re.MULTILINE)
    content = re.sub(r'^\s*[-*+]\s*\[[ xX]\]\s*', '', content, flags=re.MULTILINE)
    content = re.sub(r'\|', ' ', content)
    content = re.sub(r'^[\s:-\|]*$', '', content, flags=re.MULTILINE)
    content = re.sub(r'https?://[^\s]+', '', content)
    content = re.sub(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b', '', content)
    content = re.sub(r'\d{1,2}:\d{2}(?::\d{2})?', '', content)
    content = re.sub(r'\d{4}-\d{2}-\d{2}[\sT]\d{2}:\d{2}:\d{2}', '', content)
    content = re.sub(r'<[^>]+>', '', content)
    content = re.sub(r'\\(.)', r'\1', content)
    content = re.sub(r'\n\s*\n\s*\n+', '\n\n', content)
    content = re.sub(r' +', ' ', content)
    return '\n'.join(line.strip() for line in content.split('\n')).strip()


def split_sentences(text: str, min_len: int = 10):
    parts = [s.strip() for s in re.split(r'[.!?]+', text) if len(s.strip()) > min_len]
    return parts


def split_paragraphs(text: str, min_len: int = 10):
    parts = [p.strip() for p in text.split('\n\n') if len(p.strip()) > min_len]
    return parts


