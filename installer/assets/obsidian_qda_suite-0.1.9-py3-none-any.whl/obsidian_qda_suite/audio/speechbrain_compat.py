"""Windows compatibility patch for SpeechBrain lazy imports (k2_fsa crash)."""

from __future__ import annotations

import importlib
import inspect
import os
import sys
import warnings
from types import ModuleType

_PATCHED_ATTR = "_obsidian_qda_lazy_import_patched"


def apply_windows_lazy_import_patch() -> None:
    """Avoid loading k2_fsa on Windows when inspect probes lazy modules.

    SpeechBrain < fixed builds use filename.endswith('/inspect.py'), which never
    matches on Windows and triggers ImportError for optional k2_fsa during VAD.
    See: https://github.com/speechbrain/speechbrain/pull/3052
    """
    if os.name != "nt":
        return
    try:
        from speechbrain.utils import importutils
    except ImportError:
        return
    if getattr(importutils, _PATCHED_ATTR, False):
        return

    def ensure_module_patched(self: importutils.LazyModule, stacklevel: int) -> ModuleType:
        importer_frame = None
        try:
            importer_frame = inspect.getframeinfo(sys._getframe(stacklevel + 1))
        except AttributeError:
            warnings.warn(
                "Failed to inspect frame to check if we should ignore "
                "importing a module lazily. This relies on a CPython "
                "implementation detail, report an issue if you see this with "
                "standard Python and include your version number."
            )

        if importer_frame is not None and os.path.basename(importer_frame.filename) == "inspect.py":
            raise AttributeError()

        if self.lazy_module is None:
            try:
                if self.package is None:
                    self.lazy_module = importlib.import_module(self.target)
                else:
                    self.lazy_module = importlib.import_module(
                        f".{self.target}", self.package
                    )
            except Exception as e:
                raise ImportError(f"Lazy import of {repr(self)} failed") from e

        return self.lazy_module

    importutils.LazyModule.ensure_module = ensure_module_patched  # type: ignore[method-assign]
    setattr(importutils, _PATCHED_ATTR, True)
