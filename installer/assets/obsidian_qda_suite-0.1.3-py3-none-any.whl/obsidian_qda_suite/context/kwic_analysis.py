#!/usr/bin/env python3
"""
Keyword-in-Context (KWIC) Analysis Script for Markdown Files

Generates tables with keyword occurrences and context, with Obsidian file links.
Analyzes all markdown files in a folder recursively.
"""

import argparse
import re
from pathlib import Path
from datetime import datetime

import nltk
from nltk.tokenize import word_tokenize
from nltk.corpus import wordnet
from nltk.stem import WordNetLemmatizer

# Ensure NLTK data is available
try:
    nltk.data.find('tokenizers/punkt')
    nltk.data.find('tokenizers/punkt_tab')
except LookupError:
    nltk.download('punkt', quiet=True)
    nltk.download('punkt_tab', quiet=True)

# Download wordnet for lemmatization
try:
    nltk.data.find('corpora/wordnet')
except LookupError:
    nltk.download('wordnet', quiet=True)

# Download averaged_perceptron_tagger for POS tagging
try:
    nltk.data.find('taggers/averaged_perceptron_tagger')
except LookupError:
    nltk.download('averaged_perceptron_tagger', quiet=True)

# Import spaCy for multi-language lemmatization
try:
    import spacy
    HAS_SPACY = True
except ImportError:
    HAS_SPACY = False


def clean_markdown_content(content):
    """
    Clean markdown content by removing all formatting, links, and anchors.
    Similar to extract_text_from_markdown but works on content string.
    
    Parameters:
    -----------
    content : str
        Markdown content to clean
    
    Returns:
    --------
    str
        Clean text without markdown formatting
    """
    # Remove code blocks (```...```) - must be done before other processing
    content = re.sub(r'```[\s\S]*?```', '', content)
    content = re.sub(r'~~~[\s\S]*?~~~', '', content)
    
    # Remove inline code but keep text: `code` -> code
    content = re.sub(r'`([^`]+)`', r'\1', content)
    
    # Remove ALL links, images, and wikilinks completely (no keeping text)
    content = re.sub(r'!\[[^\]]*\]\([^\)]+\)', '', content)  # Markdown images
    content = re.sub(r'!\[\[[^\]]+\]\]', '', content)  # Obsidian image wikilinks
    content = re.sub(r'\[[^\]]+\]\([^\)]+\)', '', content)  # Markdown links
    content = re.sub(r'\[\[[^\]]+\]\]', '', content)  # Obsidian wikilinks
    content = re.sub(r'\[[^\]]+\]\[[^\]]*\]', '', content)  # Reference-style links
    content = re.sub(r'\[[^\]]+\]', '', content)  # Standalone brackets
    content = re.sub(r'\^[a-zA-Z0-9\-]+', '', content)  # Obsidian block references
    
    # Remove markdown formatting - bold (**text** or __text__)
    content = re.sub(r'\*\*([^\*]+)\*\*', r'\1', content)
    content = re.sub(r'__([^_]+)__', r'\1', content)
    
    # Remove markdown formatting - italic (*text* or _text_)
    content = re.sub(r'\*([^\*]+)\*', r'\1', content)
    content = re.sub(r'_([^_]+)_', r'\1', content)
    
    # Remove strikethrough: ~~text~~
    content = re.sub(r'~~([^~]+)~~', r'\1', content)
    
    # Remove highlights: ==text==
    content = re.sub(r'==([^=]+)==', r'\1', content)
    
    # Remove headers (# Header)
    content = re.sub(r'#{1,6}\s+', '', content)
    
    # Remove horizontal rules (---, ***, ___)
    content = re.sub(r'^[\s]*[-*_]{3,}[\s]*$', '', content, flags=re.MULTILINE)
    
    # Remove blockquotes (> text)
    content = re.sub(r'^>\s*', '', content, flags=re.MULTILINE)
    
    # Remove list markers (bullets and numbers)
    content = re.sub(r'^\s*[-*+]\s+', '', content, flags=re.MULTILINE)
    content = re.sub(r'^\s*\d+\.\s+', '', content, flags=re.MULTILINE)
    
    # Remove task list markers (- [ ] or - [x])
    content = re.sub(r'^\s*[-*+]\s*\[[ xX]\]\s*', '', content, flags=re.MULTILINE)
    
    # Remove table formatting (| col1 | col2 |)
    content = re.sub(r'\|', ' ', content)  # Replace pipe separators with space
    content = re.sub(r'^[\s:-\|]*$', '', content, flags=re.MULTILINE)  # Remove table separator rows
    
    # Remove URLs (http/https/ftp)
    content = re.sub(r'https?://[^\s]+', '', content)
    content = re.sub(r'ftp://[^\s]+', '', content)
    content = re.sub(r'www\.[^\s]+', '', content)
    
    # Remove email addresses
    content = re.sub(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b', '', content)
    
    # Remove timestamps in various formats
    content = re.sub(r'\d{1,2}:\d{2}(?::\d{2})?', '', content)
    content = re.sub(r'\d{4}-\d{2}-\d{2}[\sT]\d{2}:\d{2}:\d{2}', '', content)  # ISO format
    
    # Remove HTML tags if any
    content = re.sub(r'<[^>]+>', '', content)
    
    # Remove markdown escape characters (\)
    content = re.sub(r'\\(.)', r'\1', content)
    
    # Remove excessive whitespace
    content = re.sub(r'\n\s*\n\s*\n+', '\n\n', content)
    content = re.sub(r' +', ' ', content)
    
    # Remove leading/trailing whitespace from lines
    content = '\n'.join(line.strip() for line in content.split('\n'))
    
    return content.strip()


def calculate_relative_path(from_path, to_path, vault_root=None):
    """
    Calculate relative path for Obsidian wikilink between two files.
    
    Parameters:
    -----------
    from_path : Path
        Path to the file where the link will be placed
    to_path : Path
        Path to the file being linked to
    vault_root : Path or None
        Root of the Obsidian vault (if None, uses common parent)
    
    Returns:
    --------
    str
        Relative path as string for wikilink
    """
    from_path = Path(from_path).resolve()
    to_path = Path(to_path).resolve()
    
    # If both are in same directory, just use filename
    if from_path.parent == to_path.parent:
        return to_path.stem
    
    # If vault_root is specified, calculate relative to that
    if vault_root:
        vault_root = Path(vault_root).resolve()
        try:
            relative_to = to_path.relative_to(vault_root)
            relative_from = from_path.relative_to(vault_root)
        except ValueError:
            # Paths not under vault_root, fall back to common parent
            pass
        else:
            # Return path with forward slashes for Obsidian
            return str(relative_to.parent / to_path.stem).replace('\\', '/')
    
    # Calculate relative path from from_path to to_path
    try:
        relative = to_path.relative_to(from_path.parent)
        # For Obsidian, we want to use forward slashes and drop the .md extension
        return str(relative.parent / to_path.stem).replace('\\', '/')
    except ValueError:
        # Paths don't have common parent, use just filename
        return str(to_path.stem)


def detect_language(text, specified_lang=None):
    """
    Detect language of text or use specified language.
    
    Parameters:
    -----------
    text : str
        Text to detect language from
    specified_lang : str or None
        Explicitly specified language (skips detection if provided)
    
    Returns:
    --------
    str
        Language code ('spanish', 'english', etc.)
    """
    if specified_lang:
        # Map common language codes to NLTK names
        lang_map = {
            'es': 'spanish',
            'en': 'english',
            'fr': 'french',
            'de': 'german',
            'it': 'italian',
            'pt': 'portuguese',
        }
        return lang_map.get(specified_lang.lower(), specified_lang.lower())
    
    # Try to detect language automatically
    try:
        from langdetect import detect, LangDetectException
        sample = text[:1000] if len(text) > 1000 else text
        if not sample.strip():
            return 'english'
        detected = detect(sample)
        lang_map = {
            'es': 'spanish',
            'en': 'english',
            'fr': 'french',
            'de': 'german',
            'it': 'italian',
            'pt': 'portuguese',
        }
        return lang_map.get(detected, 'english')
    except (ImportError, Exception):
        return 'english'


def load_spacy_model(language):
    """
    Load spaCy model for a given language, downloading if necessary.
    
    Parameters:
    -----------
    language : str
        Language name ('spanish', 'english', etc.)
    
    Returns:
    --------
    spacy.Language or None
        Loaded spaCy model, or None if not available
    """
    if not HAS_SPACY:
        return None
    
    # Map language names to spaCy model names
    model_map = {
        'spanish': 'es_core_news_sm',
        'english': 'en_core_web_sm',
        'french': 'fr_core_news_sm',
        'german': 'de_core_news_sm',
        'italian': 'it_core_news_sm',
        'portuguese': 'pt_core_news_sm',
    }
    
    model_name = model_map.get(language.lower())
    if not model_name:
        return None
    
    try:
        # Try to load the model
        nlp = spacy.load(model_name)
        return nlp
    except OSError:
        # Model not found, try to download it
        try:
            print(f"Downloading spaCy model '{model_name}'...")
            from spacy.cli import download
            download(model_name)
            nlp = spacy.load(model_name)
            return nlp
        except Exception as e:
            print(f"Warning: Could not load spaCy model for {language}: {e}")
            return None


def get_wordnet_pos(treebank_tag):
    """
    Convert NLTK POS tag to WordNet POS tag.
    
    Parameters:
    -----------
    treebank_tag : str
        NLTK treebank POS tag
    
    Returns:
    --------
    str
        WordNet POS tag
    """
    if treebank_tag.startswith('J'):
        return wordnet.ADJ
    elif treebank_tag.startswith('V'):
        return wordnet.VERB
    elif treebank_tag.startswith('N'):
        return wordnet.NOUN
    elif treebank_tag.startswith('R'):
        return wordnet.ADV
    else:
        return wordnet.NOUN  # Default to NOUN


def lemmatize_keyword(keyword, language='english', lemmatizer=None):
    """
    Lemmatize a single keyword using appropriate lemmatizer.
    
    Supports both spaCy models (recommended for multi-language) and NLTK WordNetLemmatizer.
    
    Parameters:
    -----------
    keyword : str
        Keyword to lemmatize
    language : str
        Language of the keyword
    lemmatizer : object
        Pre-initialized lemmatizer (spaCy model or WordNetLemmatizer)
    
    Returns:
    --------
    str
        Lemmatized version of the keyword
    """
    if not lemmatizer:
        return keyword
    
    # Check if it's a spaCy model
    if HAS_SPACY and hasattr(lemmatizer, '__call__') and hasattr(lemmatizer, 'pipe'):
        try:
            doc = lemmatizer(keyword)
            if doc and len(doc) > 0:
                return doc[0].lemma_.lower()
        except:
            pass
    
    # Fall back to NLTK WordNetLemmatizer
    try:
        return lemmatizer.lemmatize(keyword.lower())
    except:
        return keyword.lower()


def find_keyword_contexts_in_file(markdown_file, keywords, context_size=10, 
                                   case_sensitive=False, lemmatize=False, 
                                   language=None, lemmatizer=None):
    """
    Find keyword-in-context instances in a single markdown file.
    
    Parameters:
    -----------
    markdown_file : Path or str
        Path to the markdown file
    keywords : list
        List of keywords to search for
    context_size : int
        Number of words before/after keyword
    case_sensitive : bool
        Whether matching should be case-sensitive
    
    Returns:
    --------
    list of dicts with keys:
        - 'file': Path to the file
        - 'keyword': the matched keyword
        - 'before': text before keyword
        - 'after': text after keyword
        - 'position': character position in file
        - 'heading': nearest heading text (for Obsidian anchor links)
    """
    markdown_file = Path(markdown_file)
    
    if not markdown_file.exists():
        return []
    
    # Read the original file to preserve headings
    with open(markdown_file, 'r', encoding='utf-8') as f:
        original_content = f.read()
    
    # Parse headings with their positions
    heading_positions = []
    lines = original_content.split('\n')
    char_pos = 0
    for line_num, line in enumerate(lines):
        # Check if line is a heading (any level of #)
        heading_match = re.match(r'^(#{1,6})\s+(.+)$', line)
        if heading_match:
            heading_text = heading_match.group(2).strip()
            # Remove markdown formatting from heading
            heading_text = re.sub(r'\*\*([^\*]+)\*\*', r'\1', heading_text)
            heading_text = re.sub(r'\*([^\*]+)\*', r'\1', heading_text)
            heading_text = re.sub(r'`([^`]+)`', r'\1', heading_text)
            heading_text = re.sub(r'==([^=]+)==', r'\1', heading_text)  # Remove highlights
            heading_text = re.sub(r'\[\[([^\]]+)\]\]', r'', heading_text)  # Remove all wikilinks
            heading_text = re.sub(r'\^[a-zA-Z0-9-]+', '', heading_text)  # Remove block IDs
            heading_text = re.sub(r'\[([^\]]+)\]\([^\)]+\)', r'\1', heading_text)
            heading_text = heading_text.strip()
            if heading_text:  # Only add non-empty headings
                heading_positions.append({
                    'text': heading_text,
                    'char_pos': char_pos,
                    'line': line_num
                })
        char_pos += len(line) + 1  # +1 for newline
    
    # Remove YAML frontmatter from content for analysis
    content = re.sub(r'^---\n.*?\n---\n', '', original_content, flags=re.DOTALL)
    
    # Clean markdown content to remove all formatting, links, and anchors
    clean_content = clean_markdown_content(content)
    
    # Normalize whitespace for tokenization (already done by clean_markdown_content, but ensure it)
    clean_content = re.sub(r'\s+', ' ', clean_content)
    
    results = []
    
    # Tokenize content into words with positions
    words = word_tokenize(clean_content)
    
    # Build a mapping of word positions back to character positions
    char_pos = 0
    word_positions = []
    for i, word in enumerate(words):
        word_start = clean_content.find(word, char_pos)
        if word_start == -1:
            word_start = char_pos
        word_positions.append({
            'index': i,
            'word': word,
            'char_start': word_start,
            'char_end': word_start + len(word)
        })
        char_pos = word_start + len(word)
    
    # If lemmatization is enabled, detect language from content
    detected_lang = None
    if lemmatize and language:
        detected_lang = language
    elif lemmatize:
        detected_lang = detect_language(clean_content)
    
    # Lemmatize keywords if needed
    lemmatized_keywords = {}
    if lemmatize and lemmatizer:
        for keyword in keywords:
            lemmatized_keywords[keyword] = lemmatize_keyword(
                keyword, detected_lang, lemmatizer
            )
    
    # Search for each keyword
    for keyword in keywords:
        # Normalize for searching
        if case_sensitive:
            search_keyword = keyword
        else:
            search_keyword = keyword.lower()
        
        # Find word indices where keyword appears
        keyword_word_indices = []
        matched_original_words = {}  # Store actual matched words for display
        
        for i, word_pos in enumerate(word_positions):
            if case_sensitive:
                match_word = word_pos['word']
            else:
                match_word = word_pos['word'].lower()
            
            # Check for direct match
            matches = False
            matched_word = match_word
            
            if search_keyword in match_word:
                matches = True
            # If lemmatization enabled, check against lemmatized version
            elif lemmatize and lemmatizer and keyword in lemmatized_keywords:
                lemmatized_form = lemmatized_keywords[keyword]
                try:
                    # Try to lemmatize the current word
                    word_lemma = lemmatize_keyword(match_word, detected_lang, lemmatizer)
                    # Exact match for lemmatization (not substring)
                    if lemmatized_form == word_lemma or lemmatized_form == match_word:
                        matches = True
                except:
                    pass
            
            if matches:
                keyword_word_indices.append(i)
                # Store the actual matched word (for display with lemma)
                matched_original_words[i] = word_pos['word']
        
        # For each occurrence, extract context
        for word_idx in keyword_word_indices:
            word_pos = word_positions[word_idx]
            
            # Find the nearest heading before this position
            # We need to find the heading in the original content
            # by mapping the clean_content position back to original
            nearest_heading = None
            if heading_positions:
                # Get approximate position in original content
                # Simple mapping: find character position in original
                # This is approximate but should work for most cases
                for heading in reversed(heading_positions):
                    if heading['char_pos'] <= word_pos['char_start']:
                        nearest_heading = heading
                        break
            
            # Calculate context boundaries
            context_start_idx = max(0, word_idx - context_size)
            context_end_idx = min(len(words), word_idx + context_size + 1)
            
            # Extract context words
            context_words = words[context_start_idx:context_end_idx]
            
            # Find where keyword starts in the context
            keyword_in_context_idx = context_start_idx
            for i in range(context_start_idx, word_idx + 1):
                if i == word_idx:
                    keyword_in_context_idx = i - context_start_idx
                    break
            
            # Split into before, keyword, and after
            before_words = context_words[:keyword_in_context_idx]
            keyword_word = context_words[keyword_in_context_idx] if keyword_in_context_idx < len(context_words) else ''
            after_words = context_words[keyword_in_context_idx + 1:]
            
            # Add ellipsis if not at start/end
            before_text = ' '.join(before_words)
            if context_start_idx > 0:
                before_text = '... ' + before_text
            else:
                # Try to preserve some leading context from original
                if word_pos['char_start'] > 0:
                    # Get a bit more context from original text
                    additional_start = max(0, word_pos['char_start'] - 50)
                    additional_context = clean_content[additional_start:word_pos['char_start']].strip()
                    if additional_context:
                        before_text = additional_context + ' ' + before_text
            
            after_text = ' '.join(after_words)
            if context_end_idx < len(words):
                after_text = after_text + ' ...'
            else:
                # Try to preserve some trailing context
                if word_pos['char_end'] < len(clean_content):
                    additional_end = min(len(clean_content), word_pos['char_end'] + 50)
                    additional_context = clean_content[word_pos['char_end']:additional_end].strip()
                    if additional_context:
                        after_text = after_text + ' ' + additional_context
            
            # Truncate if too long
            if len(before_text) > 150:
                before_text = '...' + before_text[-147:]
            if len(after_text) > 150:
                after_text = after_text[:147] + '...'
            
            # Determine keyword to display
            display_keyword = keyword
            if lemmatize and lemmatizer and word_idx in matched_original_words:
                matched_word = matched_original_words[word_idx]
                # If the matched word is different from the keyword, show both
                if matched_word.lower() != keyword.lower() and lemmatized_keywords.get(keyword):
                    display_keyword = f"{matched_word} ({lemmatized_keywords[keyword]})"
            
            results.append({
                'file': markdown_file,
                'keyword': display_keyword,
                'before': before_text,
                'after': after_text,
                'position': word_pos['char_start'],
                'heading': nearest_heading['text'] if nearest_heading else None
            })
    
    return results


def find_all_markdown_files(folder_path):
    """
    Find all markdown files in a folder, recursively including subfolders.
    
    Parameters:
    -----------
    folder_path : Path or str
        Root folder to search
    
    Returns:
    --------
    list of Path objects
    """
    folder_path = Path(folder_path)
    
    if not folder_path.exists():
        return []
    
    if folder_path.is_file():
        return [folder_path] if folder_path.suffix == '.md' else []
    
    # Recursively find all .md files
    md_files = list(folder_path.rglob('*.md'))
    return md_files


def generate_kwic_table(folder_path, keywords, output_file=None, 
                       context_size=10, case_sensitive=False, 
                       max_results_per_file=50, vault_root=None,
                       lemmatize=False, language=None, spacy_lemmatizer=None):
    """
    Generate a comprehensive KWIC table analyzing all markdown files in a folder.
    
    Parameters:
    -----------
    folder_path : Path or str
        Folder containing markdown files to analyze
    keywords : list or str
        Keywords to search for
    output_file : Path or str
        Output file path (default: kwic_analysis.md)
    context_size : int
        Number of words before/after keyword
    case_sensitive : bool
        Case-sensitive matching
    max_results_per_file : int
        Maximum results per file (0 = unlimited)
    vault_root : Path or str
        Root of Obsidian vault for link generation
    
    Returns:
    --------
    Path to output file
    """
    folder_path = Path(folder_path)
    
    if not folder_path.exists():
        raise FileNotFoundError(f"Folder not found: {folder_path}")
    
    # Initialize lemmatizer if needed
    lemmatizer = None
    if lemmatize:
        # Use spaCy if provided, otherwise use NLTK
        if spacy_lemmatizer:
            lemmatizer = spacy_lemmatizer
        else:
            lemmatizer = WordNetLemmatizer()
    
    # Parse keywords
    if isinstance(keywords, str):
        # Check if it's a file path
        keywords_path = Path(keywords)
        if keywords_path.exists():
            with open(keywords_path, 'r', encoding='utf-8') as f:
                keywords = [line.strip() for line in f if line.strip()]
        else:
            # Comma-separated string
            keywords = [k.strip() for k in keywords.split(',')]
    
    if not keywords:
        raise ValueError("No keywords provided")
    
    # Find all markdown files
    md_files = find_all_markdown_files(folder_path)
    
    if not md_files:
        print(f"No markdown files found in {folder_path}")
        return None
    
    print(f"Found {len(md_files)} markdown files to analyze")
    
    # Analyze each file
    all_results = []
    for md_file in md_files:
        file_results = find_keyword_contexts_in_file(
            md_file,
            keywords,
            context_size=context_size,
            case_sensitive=case_sensitive,
            lemmatize=lemmatize,
            language=language,
            lemmatizer=lemmatizer
        )
        
        # Apply per-file limit
        if max_results_per_file > 0 and len(file_results) > max_results_per_file:
            file_results = file_results[:max_results_per_file]
        
        all_results.extend(file_results)
    
    # Determine output file
    if output_file is None:
        output_file = folder_path / "kwic_analysis.md"
    else:
        output_file = Path(output_file)
    
    # Ensure output directory exists
    output_file.parent.mkdir(parents=True, exist_ok=True)
    
    # Generate markdown table
    with open(output_file, 'w', encoding='utf-8') as f:
        # Write YAML frontmatter
        f.write("---\n")
        f.write(f"date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write("analysis_type: Keyword-in-Context (KWIC)\n")
        keywords_str = ', '.join(keywords)
        f.write(f'keywords: "{keywords_str}"\n')
        f.write(f"context_size: {context_size} words\n")
        f.write(f"case_sensitive: {case_sensitive}\n")
        if lemmatize:
            f.write(f"lemmatization: enabled\n")
            if language:
                f.write(f"language: {language}\n")
            else:
                f.write("language: auto-detected\n")
        f.write("tags:\n  - analysis\n  - kwic\n")
        f.write("---\n\n")
        
        # Write title
        f.write("# Keyword-in-Context Analysis\n\n")
        
        # Write metadata
        f.write("## Analysis Summary\n\n")
        f.write("| Parameter | Value |\n")
        f.write("|-----------|-------|\n")
        f.write(f"| Source Folder | `{folder_path}` |\n")
        f.write(f"| Files Analyzed | {len(md_files)} |\n")
        f.write(f"| Keywords | {keywords_str} |\n")
        f.write(f"| Context Size | {context_size} words |\n")
        f.write(f"| Case Sensitive | {case_sensitive} |\n")
        if lemmatize:
            f.write(f"| Lemmatization | Enabled |\n")
            if language:
                f.write(f"| Language | {language} |\n")
            else:
                f.write(f"| Language | Auto-detected |\n")
        f.write(f"| Total Occurrences | {len(all_results)} |\n")
        f.write("\n")
        
        # Write results table
        if all_results:
            f.write("## Results\n\n")
            f.write("| Before | Keyword | After | File |\n")
            f.write("|--------|---------|-------|------|\n")
            
            for result in all_results:
                # Escape pipe characters in text
                before = result['before'].replace('|', '\\|').replace('\n', ' ')
                after = result['after'].replace('|', '\\|').replace('\n', ' ')
                
                # Truncate if still too long
                if len(before) > 150:
                    before = '...' + before[-147:]
                if len(after) > 150:
                    after = after[:147] + '...'
                
                # Generate file link with optional heading anchor
                file_link = calculate_relative_path(output_file, result['file'], vault_root=vault_root)
                
                # Add heading anchor if available
                if result.get('heading'):
                    # Escape # in heading for proper Obsidian link
                    heading_text = result['heading'].replace('#', '')
                    file_link_wikilink = f"[[{file_link}#{heading_text}]]"
                else:
                    file_link_wikilink = f"[[{file_link}]]"
                
                # Write row
                f.write(f"| {before} | **{result['keyword']}** | {after} | {file_link_wikilink} |\n")
        else:
            f.write("## Results\n\n")
            f.write("*No occurrences found.*\n")
    
    print(f"\nKWIC analysis complete!")
    print(f"Files analyzed: {len(md_files)}")
    print(f"Total occurrences: {len(all_results)}")
    print(f"Output: {output_file}")
    
    return output_file


def main():
    """Command-line interface for KWIC analysis."""
    parser = argparse.ArgumentParser(
        description='Generate keyword-in-context tables for Obsidian markdown files',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Analyze a folder with one keyword
  python kwic_analysis.py --folder Documents --keywords "investment"
  
  # Analyze with multiple keywords
  python kwic_analysis.py --folder Data --keywords "investment,value,risk"
  
  # Analyze with more context and case sensitivity
  python kwic_analysis.py --folder Research --keywords "Investment" --context-size 20 --case-sensitive
  
  # Keywords from a file
  python kwic_analysis.py --folder Vault --keywords keywords.txt --context-size 15
  
  # Specify vault root for proper wikilinks
  python kwic_analysis.py --folder Notes --keywords "analysis" --vault-root /path/to/vault
  
  # Custom output location
  python kwic_analysis.py --folder . --keywords "thesis" --output Results/thesis_kwic.md
  
  # Limit results per file
  python kwic_analysis.py --folder . --keywords "keyword" --max-per-file 10
  
  # Enable lemmatization (auto-detect language)
  python kwic_analysis.py --folder . --keywords "proyecto" --lemmatize
  
  # Lemmatization with specified language
  python kwic_analysis.py --folder . --keywords "investment" --lemmatize --language en
        """
    )
    
    parser.add_argument(
        '--folder',
        type=str,
        required=True,
        help='Folder containing markdown files to analyze (recursively searches subfolders)'
    )
    
    parser.add_argument(
        '--keywords',
        type=str,
        required=True,
        help='Keywords to search for (comma-separated list or path to file with one keyword per line)'
    )
    
    parser.add_argument(
        '--output',
        type=str,
        default=None,
        help='Output file path (default: kwic_analysis.md in the analyzed folder)'
    )
    
    parser.add_argument(
        '--context-size',
        type=int,
        default=10,
        help='Number of words before/after keyword for context (default: 10)'
    )
    
    parser.add_argument(
        '--case-sensitive',
        action='store_true',
        help='Perform case-sensitive keyword matching'
    )
    
    parser.add_argument(
        '--max-per-file',
        type=int,
        default=50,
        help='Maximum results per file (default: 50, 0 = unlimited)'
    )
    
    parser.add_argument(
        '--vault-root',
        type=str,
        default=None,
        help='Root directory of Obsidian vault (for proper wikilink generation)'
    )
    
    parser.add_argument(
        '--lemmatize',
        action='store_true',
        help='Enable lemmatization to find variant forms of keywords (e.g., "proyectos" -> "proyecto")'
    )
    
    parser.add_argument(
        '--language',
        type=str,
        default=None,
        help='Language for lemmatization (auto-detected if not specified). Options: es, en, fr, de, it, pt'
    )
    
    args = parser.parse_args()
    
    # Load spaCy model if lemmatization is enabled
    spacy_nlp = None
    if args.lemmatize and HAS_SPACY:
        # Map language code to language name if provided
        if args.language:
            lang_map = {
                'es': 'spanish', 'en': 'english', 'fr': 'french',
                'de': 'german', 'it': 'italian', 'pt': 'portuguese'
            }
            detected_lang = lang_map.get(args.language.lower(), args.language)
        else:
            # Try to detect language from first file if not specified
            md_files = find_all_markdown_files(args.folder)
            if md_files:
                try:
                    with open(md_files[0], 'r', encoding='utf-8') as f:
                        sample_text = f.read(1000)  # Just a sample
                    detected_lang = detect_language(sample_text)
                except:
                    detected_lang = 'english'
            else:
                detected_lang = 'english'
        
        spacy_nlp = load_spacy_model(detected_lang)
        if spacy_nlp:
            print(f"Using spaCy model for {detected_lang} lemmatization")
    
    # Generate KWIC table
    try:
        generate_kwic_table(
            folder_path=args.folder,
            keywords=args.keywords,
            output_file=args.output,
            context_size=args.context_size,
            case_sensitive=args.case_sensitive,
            max_results_per_file=args.max_per_file,
            vault_root=args.vault_root,
            lemmatize=args.lemmatize,
            language=args.language,
            spacy_lemmatizer=spacy_nlp
        )
    except Exception as e:
        print(f"Error during KWIC analysis: {str(e)}")
        import traceback
        traceback.print_exc()
        import sys
        sys.exit(1)


if __name__ == "__main__":
    main()

