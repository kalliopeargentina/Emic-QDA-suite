"""Allow running the CLI as: python -m obsidian_qda_suite <subcommand> ..."""
from .cli.main import main

if __name__ == "__main__":
    main()
