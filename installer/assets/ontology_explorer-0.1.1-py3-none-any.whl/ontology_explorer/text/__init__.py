"""Text utilities."""
