"""Sentiment analysis CLI. Env vars must be set before algorithms (transformers/pysentimiento) load."""
import os
os.environ["USE_TF"] = "0"
os.environ["USE_TORCH"] = "1"
os.environ["TF_ENABLE_ONEDNN_OPTS"] = "0"

import argparse
from pathlib import Path
from typing import Dict

from .config import DEFAULTS
from .corpus_processing import extract_documents_from_folder
from .text_processing import extract_text_from_markdown_content, split_sentences, split_paragraphs
from .algorithms import BACKENDS, _get_backend_class
from .algorithms.base import aggregate_labels, normalize_sentiment_label
from .visualizations import (
    create_sentiment_bar_chart, 
    create_sentiment_wordclouds,
    create_sentiment_sankey_diagram,
    create_sentiment_heatmap,
    create_corpus_sentiment_heatmap
)
from .explanations import get_sentiment_analysis_explanation
import torch

# Reusar detección de idioma existente
try:
    from ..topic_analysis.nlp_utils import detect_language
except Exception:
    # Fallback simple si no está disponible
    from langdetect import detect as _ld_detect

    def detect_language(text: str) -> str:
        try:
            code = _ld_detect(text[:1000] if len(text) > 1000 else text)
        except Exception:
            return "english"
        mapping = {"es": "spanish", "en": "english", "fr": "french", "de": "german", "it": "italian", "pt": "portuguese"}
        return mapping.get(code, "english")


def _load_backend(name: str, **params):
    cls = _get_backend_class(name)
    return cls(**params)


def _aggregate_mode(text: str, aggregate: str, backend, lang_hint: str | None) -> Dict:
    if aggregate == "document":
        # Detectar idioma a nivel documento
        lang = lang_hint
        if backend.name == "pysentimiento":
            # pysentimiento espera códigos cortos ('es','en',...); mapear desde nombres si vino mapeado
            lang_short = {"spanish": "es", "english": "en", "french": "fr", "german": "de", "italian": "it", "portuguese": "pt"}.get(lang or "spanish", "es")
            return backend.predict(text, lang=lang_short)
        else:
            return backend.predict(text, lang=lang)
    elif aggregate in ("sentence", "paragraph"):
        parts = split_sentences(text) if aggregate == "sentence" else split_paragraphs(text)
        results = []
        for part in parts:
            lang = detect_language(part)
            if backend.name == "pysentimiento":
                lang_short = {"spanish": "es", "english": "en", "french": "fr", "german": "de", "italian": "it", "portuguese": "pt"}.get(lang, "es")
                results.append(backend.predict(part, lang=lang_short))
            else:
                results.append(backend.predict(part, lang=lang))
        dist = aggregate_labels(results)
        label = max(dist.items(), key=lambda x: x[1])[0] if dist else "neutral"
        return {"label": label, "distribution": dist, "parts": len(parts)}
    else:
        raise ValueError("aggregate debe ser document|sentence|paragraph")


def run_file(md_file: Path, backend_name: str, params: Dict, aggregate: str) -> Dict:
    text = extract_text_from_markdown_content(md_file.read_text(encoding="utf-8"))
    backend = _load_backend(backend_name, **params)
    lang_name = detect_language(text)  # nombre largo para logging; backend puede necesitar corto
    return _aggregate_mode(text, aggregate, backend, lang_name)


def run_folder(folder: Path, backend_name: str, params: Dict, aggregate: str,
               recursive: bool, file_pattern: str, min_document_length: int) -> Dict:
    docs = extract_documents_from_folder(folder, recursive, file_pattern, min_document_length)
    backend = _load_backend(backend_name, **params)
    results = []
    for d in docs:
        lang_name = detect_language(d["clean_text"])
        res = _aggregate_mode(d["clean_text"], aggregate, backend, lang_name)
        results.append({"file_name": d["file_name"], **res, "detected_language": lang_name})
    # resumen corpus
    if aggregate == "document":
        corpus_dist = aggregate_labels(results)
    else:
        from collections import Counter
        acc = Counter()
        for r in results:
            for k, v in r["distribution"].items():
                acc[k] += v
        total = sum(acc.values()) or 1
        corpus_dist = {k: v / total for k, v in acc.items()}
    return {"results": results, "corpus_distribution": corpus_dist}


def main():
    p = argparse.ArgumentParser(description="Análisis de sentimientos para notas/carpeta Obsidian con detección automática de idioma")
    p.add_argument("input_path", type=str, help="Archivo .md o carpeta con .md")
    p.add_argument("--algo", type=lambda x: x.strip(), choices=["pysentimiento", "transformers"], default="pysentimiento")
    p.add_argument("--model", default=None, help="Nombre de modelo (opcional; ambos backends)")
    p.add_argument("--device", type=str, default=None, help="Dispositivo: 0/1... | cuda | cpu | -1 (transformers usa entero)")
    p.add_argument("--max-length", type=int, default=DEFAULTS["max_length"], help="Truncado de texto para transformers")
    p.add_argument("--aggregate", choices=["document", "sentence", "paragraph"], default=DEFAULTS["aggregate"])
    p.add_argument("--file-pattern", default="*.md")
    p.add_argument("--no-recursive", action="store_true")
    p.add_argument("--min-document-length", type=int, default=DEFAULTS["min_document_length"])
    p.add_argument("--output", type=str, default=None, help="Ruta del archivo Markdown o carpeta de salida para el informe")
    p.add_argument("--top-k", type=int, default=5, help="Número de párrafos por clase a incluir en el informe")
    p.add_argument("--min-score", type=float, default=0.0, help="Puntaje mínimo para incluir un párrafo (0.0-1.0, default: 0.0)")
    p.add_argument("--min-confidence", type=float, default=0.0, help="Confianza mínima de la etiqueta predicha (0.0-1.0, default: 0.0)")
    p.add_argument("--min-score-diff", type=float, default=0.0, help="Diferencia mínima entre la mejor y segunda mejor etiqueta (0.0-1.0, default: 0.0)")
    p.add_argument("--min-paragraph-length", type=int, default=20, help="Longitud mínima del párrafo en caracteres (default: 20)")
    p.add_argument("--corpus-report", action="store_true", help="Generar reporte consolidado del corpus completo (solo cuando se procesa una carpeta)")
    args = p.parse_args()

    path = Path(args.input_path)
    params = {}
    if args.algo == "pysentimiento":
        if args.model:
            params.update({"model": args.model})
        # Optional device handling similar to whisperx style
        if args.device is not None:
            dv = str(args.device).lower()
            if dv in ("cpu", "-1"):
                params["device"] = "cpu"
            elif dv in ("cuda", "gpu") or dv.isdigit():
                params["device"] = "cuda" if torch.cuda.is_available() else "cpu"
            else:
                params["device"] = "cuda" if torch.cuda.is_available() else "cpu"
    elif args.algo == "transformers":
        if args.model:
            params.update({"model": args.model})
        if args.device is not None:
            dv = str(args.device).lower()
            if dv in ("cpu", "-1"):
                params["device"] = -1
            elif dv in ("cuda", "gpu"):
                params["device"] = 0
            else:
                try:
                    params["device"] = int(args.device)
                except Exception:
                    params["device"] = 0 if torch.cuda.is_available() else -1
        params.update({"max_length": args.max_length})

    def _ensure_output_path(base_input: Path, output_opt: str | None, suffix: str) -> Path:
        if not output_opt:
            return base_input.with_suffix(suffix)
        outp = Path(output_opt)
        if outp.exists() and outp.is_dir():
            return outp / (base_input.stem + suffix)
        outp.parent.mkdir(parents=True, exist_ok=True)
        return outp

    def _generate_image_filename(base_path: Path, operation_type: str, chart_type: str, images_dir: Path | None = None) -> Path:
        """
        Genera un nombre corto para imágenes siguiendo el formato:
        primeros 10 caracteres del archivo + "_" + tipo operación + "_" + tipo gráfico
        
        Args:
            base_path: Path base del archivo (ej: "documento.md")
            operation_type: Tipo de operación ("sentiment" o "emotion")
            chart_type: Tipo de gráfico ("chart", "sankey", "heatmap", "radar", "wordcloud", etc.)
            images_dir: Directorio donde guardar la imagen (opcional, por defecto mismo directorio que el markdown)
        
        Returns:
            Path completo del archivo de imagen
        """
        # Obtener el nombre del archivo sin extensión y sin espacios
        stem = base_path.stem.replace(" ", "_")
        
        # Tomar primeros 10 caracteres (o menos si el nombre es más corto)
        short_name = stem[:10] if len(stem) > 10 else stem
        
        # Construir el nombre: short_name_operation_chart.png
        image_name = f"{short_name}_{operation_type}_{chart_type}.png"
        
        # Si se especifica un directorio de imágenes, usar ese; sino usar el directorio del markdown
        target_dir = images_dir if images_dir else base_path.parent
        
        return target_dir / image_name

    def _get_relative_path_str(image_path: Path, md_path: Path) -> str:
        """
        Obtiene la ruta relativa de una imagen respecto al markdown y la convierte a string
        con barras diagonales para compatibilidad con markdown.
        
        Args:
            image_path: Path completo de la imagen
            md_path: Path del archivo markdown
            
        Returns:
            String con la ruta relativa usando barras diagonales
        """
        try:
            rel_path = image_path.relative_to(md_path.parent)
            return str(rel_path).replace("\\", "/")
        except (ValueError, AttributeError):
            # Fallback: usar solo el nombre del archivo
            return image_path.name

    def _write_markdown_report(md_path: Path, doc_title: str, text: str, backend_name: str, params: dict, top_k: int, source_path: Path | None = None, min_score: float = 0.0, min_confidence: float = 0.0, min_score_diff: float = 0.0, min_paragraph_length: int = 20):
        backend = _load_backend(backend_name, **params)
        lang_name = detect_language(text)
        # Document-level prediction
        doc_pred = _aggregate_mode(text, "document", backend, lang_name)
        label = doc_pred.get("label")
        scores = doc_pred.get("scores") or doc_pred.get("distribution")
        # Paragraph-level scoring
        paragraphs = split_paragraphs(text)
        # Map paragraph indices to nearest section header for linking
        header_by_paragraph = {}
        try:
            # Prefer using topic_analysis rich header extractor if present
            from ..topic_analysis.text_processing import extract_sections_with_headers as _extract_sections
            if source_path and source_path.exists():
                secs = _extract_sections_with_clean(source_path)
            else:
                secs = []
        except Exception:
            secs = []
        if not secs:
            # fallback: single "Documento"
            secs = [{"header": "Documento", "paragraphs": paragraphs}]
        # Build mapping
        p_idx = 1
        for sec in secs:
            for _ in sec["paragraphs"]:
                header_by_paragraph[p_idx] = sec["header"]
                p_idx += 1
        # Determine available labels by sampling
        label_keys = set()
        for ptxt in paragraphs[: min(len(paragraphs), 10)]:
            clang = detect_language(ptxt)
            lang_arg = {"spanish":"es","english":"en","french":"fr","german":"de","italian":"it","portuguese":"pt"}.get(clang, "es")
            # Ensure lang_arg is supported by backend (fallback to "es" if not)
            if lang_arg not in ("es", "en", "it", "pt"):
                lang_arg = "es"
            pred = backend.predict(ptxt, lang=lang_arg)
            label_keys.update(pred["scores"].keys())
        # Normalize sentiment label names for transformers
        def normalize_label(l: str) -> str:
            return normalize_sentiment_label(l)
        # Score all paragraphs with filtering
        scored = []
        for idx, ptxt in enumerate(paragraphs, start=1):
            if not ptxt.strip():
                continue
            # Filter by minimum length
            if len(ptxt.strip()) < min_paragraph_length:
                continue
            
            clang = detect_language(ptxt)
            lang_arg = {"spanish":"es","english":"en","french":"fr","german":"de","italian":"it","portuguese":"pt"}.get(clang, "es")
            # Ensure lang_arg is supported by backend (fallback to "es" if not)
            if lang_arg not in ("es", "en", "it", "pt"):
                lang_arg = "es"
            pred = backend.predict(ptxt, lang=lang_arg)
            pscores = pred.get("scores", {})
            label = pred.get("label", "NEU")
            
            # Handle label if it's a list
            if isinstance(label, list):
                label = label[0] if label else "NEU"
            
            # Ensure pscores is a dict
            if not isinstance(pscores, dict):
                if isinstance(pscores, list):
                    pscores = {f"class_{i}": score for i, score in enumerate(pscores)}
                else:
                    pscores = {}
            
            # Get top two scores for difference check
            sorted_scores = sorted(pscores.items(), key=lambda x: x[1], reverse=True) if pscores else []
            top_score = sorted_scores[0][1] if sorted_scores else 0.0
            second_score = sorted_scores[1][1] if len(sorted_scores) > 1 else 0.0
            
            # Apply filters
            label_score = pscores.get(label, 0.0) if isinstance(pscores, dict) and isinstance(label, str) else 0.0
            
            # Check minimum score threshold
            if min_score > 0 and label_score < min_score:
                continue
            
            # Check minimum confidence (top score must be above threshold)
            if min_confidence > 0 and top_score < min_confidence:
                continue
            
            # Check minimum score difference
            if min_score_diff > 0 and (top_score - second_score) < min_score_diff:
                continue
            
            # Store with predicted label for word cloud generation
            scored.append((idx, ptxt, pscores, label))
        # Top-K per label
        selected = {}
        for lab in sorted(label_keys):
            lab_norm = normalize_label(lab) if backend_name in ("transformers",) else lab
            ranked = sorted(scored, key=lambda t: float(t[2].get(lab, 0.0)), reverse=True)
            # Apply min_score filter when selecting top-K per label
            top = [(i, p, float(s.get(lab, 0.0))) for i, p, s, _ in ranked[:top_k] 
                   if float(s.get(lab, 0.0)) > 0.0 and float(s.get(lab, 0.0)) >= min_score]
            if top:
                selected[lab_norm] = top
        # Build markdown
        lines = []
        lines.append(f"# Informe de análisis de sentimientos - {doc_title}")
        lines.append("")
        lines.append(f"- Backend: `{backend_name}`")
        lines.append(f"- Idioma detectado: `{lang_name}`")
        lines.append("")
        
        # Add methodology explanation
        model_name = params.get("model") or (backend.model_name if hasattr(backend, "model_name") else None)
        explanation_lines = get_sentiment_analysis_explanation(backend_name, model_name)
        lines.extend(explanation_lines)
        lines.append("")
        lines.append("---")
        lines.append("")
        
        # Create images directory for all visualizations (chart, sankey, heatmap, wordclouds)
        stem_short = md_path.stem.replace(" ", "_")[:10] if len(md_path.stem) > 10 else md_path.stem.replace(" ", "_")
        images_dir = md_path.parent / f"{stem_short}_sentiment_images"
        images_dir.mkdir(parents=True, exist_ok=True)
        
        lines.append("## Predicción a nivel documento")
        lines.append("")
        lines.append(f"- Etiqueta: **{label}**")
        if scores:
            lines.append("- Distribución:")
            for k, v in sorted(scores.items()):
                nk = normalize_label(k) if backend_name in ("transformers",) else k
                lines.append(f"  - {nk}: {v:.4f}")
            
            # Generate and include bar chart
            chart_path = _generate_image_filename(md_path, "sentiment", "chart", images_dir)
            chart_rel_path_str = _get_relative_path_str(chart_path, md_path)
            chart_created = create_sentiment_bar_chart(scores, chart_path, title=f"Distribución de Sentimientos - {doc_title}")
            if chart_created:
                lines.append("")
                lines.append("### Gráfico de Barras")
                lines.append("")
                lines.append("Este gráfico muestra la distribución proporcional de sentimientos en el documento completo. Cada barra representa la probabilidad o proporción de cada categoría de sentimiento (POS=Positivo, NEG=Negativo, NEU=Neutral). Los valores se muestran sobre cada barra para facilitar la lectura.")
                lines.append("")
                lines.append(f"![Distribución de Sentimientos]({chart_rel_path_str})")
        lines.append("")
        lines.append(f"## Top {top_k} párrafos por clase")
        lines.append("")
        for lab in sorted(selected.keys()):
            lines.append(f"### {lab}")
            for idx, ptxt, sc in selected[lab]:
                lines.append(f"- Párrafo {idx} (puntaje: {sc:.4f})")
                lines.append("")
                lines.append("> " + ptxt.strip().replace("\n", "\n> "))
                # Add link to original section if available
                if source_path:
                    header = header_by_paragraph.get(idx, "Documento")
                    anchor = header.strip().lower().replace(' ', '-')
                    lines.append("")
                    lines.append(f"[Abrir sección en documento original]({source_path}#{anchor})")
                lines.append("")
        
        # Generate word clouds for each sentiment (use all paragraphs that passed filters, grouped by predicted label)
        paragraphs_by_label = {}
        for idx, ptxt, pscores, pred_label in scored:
            if pred_label:
                lab_norm = normalize_label(pred_label) if backend_name in ("transformers",) else pred_label
                if lab_norm not in paragraphs_by_label:
                    paragraphs_by_label[lab_norm] = []
                paragraphs_by_label[lab_norm].append(ptxt)
        
        if paragraphs_by_label:
            # Use the same images directory for wordclouds
            wordcloud_paths = create_sentiment_wordclouds(paragraphs_by_label, images_dir, lang=lang_name)
            
            if any(wordcloud_paths.values()):
                lines.append("")
                lines.append("## Nubes de palabras por sentimiento")
                lines.append("")
                lines.append("Las nubes de palabras muestran las palabras más relevantes y específicas para cada categoría de sentimiento. El tamaño de cada palabra es proporcional a su frecuencia e importancia para ese sentimiento específico.")
                lines.append("")
                lines.append("**Metodología de filtrado inteligente:**")
                lines.append("- Se utiliza un enfoque similar a TF-IDF para calcular la especificidad de cada palabra a cada sentimiento")
                lines.append("- Las palabras que aparecen en múltiples categorías de sentimiento son filtradas o penalizadas")
                lines.append("- Solo se incluyen palabras con alta especificidad al sentimiento correspondiente")
                lines.append("- Esto asegura que cada nube de palabras muestre únicamente términos relevantes y distintivos para ese sentimiento")
                lines.append("")
                for lab in sorted(paragraphs_by_label.keys()):
                    if wordcloud_paths.get(lab) and wordcloud_paths[lab]:
                        try:
                            wc_rel_path = wordcloud_paths[lab].relative_to(md_path.parent)
                            # Convert to string with forward slashes for markdown compatibility
                            wc_rel_path_str = str(wc_rel_path).replace("\\", "/")
                        except (ValueError, AttributeError):
                            # Fallback: use the directory name + filename
                            wc_rel_path_str = f"{images_dir.name}/{wordcloud_paths[lab].name}".replace("\\", "/")
                        lines.append(f"### {lab}")
                        lines.append("")
                        lines.append(f"![Nube de palabras - {lab}]({wc_rel_path_str})")
                        lines.append("")
        
        # Generate temporal visualizations (Sankey and heatmap)
        if scored:
            # Sort by paragraph index to maintain temporal order
            sorted_scored = sorted(scored, key=lambda x: x[0])
            
            # Prepare data for Sankey diagram (paragraph labels in order)
            paragraph_labels = []
            for idx, ptxt, pscores, pred_label in sorted_scored:
                if pred_label:
                    lab_norm = normalize_label(pred_label) if backend_name in ("transformers",) else pred_label
                    paragraph_labels.append(lab_norm)
            
            if len(paragraph_labels) >= 2:
                # Create Sankey diagram
                sankey_path = _generate_image_filename(md_path, "sentiment", "sankey", images_dir)
                sankey_created = create_sentiment_sankey_diagram(paragraph_labels, sankey_path, title=f"Flujo de Sentimientos - {doc_title}")
                if sankey_created:
                    # Check if it's HTML or PNG
                    if str(sankey_created).endswith('.html'):
                        sankey_rel_path_str = _get_relative_path_str(sankey_created, md_path)
                        lines.append("")
                        lines.append("## Visualización Temporal de Sentimientos")
                        lines.append("")
                        lines.append("### Diagrama Sankey")
                        lines.append("")
                        lines.append("El diagrama Sankey muestra el flujo de sentimientos a lo largo del documento. Cada párrafo (P1, P2, P3...) está conectado a su sentimiento predicho (POS, NEG, NEU), permitiendo visualizar cómo cambia el sentimiento a medida que se avanza en la lectura del documento. El grosor de las conexiones indica la cantidad de párrafos con cada transición.")
                        lines.append("")
                        lines.append(f"[Ver diagrama Sankey interactivo]({sankey_rel_path_str})")
                        lines.append("")
                    else:
                        sankey_rel_path_str = _get_relative_path_str(sankey_created, md_path)
                        lines.append("")
                        lines.append("## Visualización Temporal de Sentimientos")
                        lines.append("")
                        lines.append("### Diagrama Sankey")
                        lines.append("")
                        lines.append("El diagrama Sankey muestra el flujo de sentimientos a lo largo del documento. Cada párrafo (P1, P2, P3...) está conectado a su sentimiento predicho (POS, NEG, NEU), permitiendo visualizar cómo cambia el sentimiento a medida que se avanza en la lectura del documento. El grosor de las conexiones indica la cantidad de párrafos con cada transición.")
                        lines.append("")
                        lines.append(f"![Flujo de Sentimientos]({sankey_rel_path_str})")
                        lines.append("")
            
            # Prepare data for heatmap
            paragraph_data = []
            for idx, ptxt, pscores, pred_label in sorted_scored:
                if pred_label:
                    lab_norm = normalize_label(pred_label) if backend_name in ("transformers",) else pred_label
                    paragraph_data.append({
                        'index': idx,
                        'label': lab_norm,
                        'scores': pscores
                    })
            
            if paragraph_data:
                # Create heatmap
                heatmap_path = _generate_image_filename(md_path, "sentiment", "heatmap", images_dir)
                heatmap_rel_path_str = _get_relative_path_str(heatmap_path, md_path)
                heatmap_created = create_sentiment_heatmap(paragraph_data, heatmap_path, title=f"Distribución de Sentimientos - {doc_title}")
                if heatmap_created:
                    if len(paragraph_labels) < 2:
                        lines.append("")
                        lines.append("## Visualización Temporal de Sentimientos")
                        lines.append("")
                    lines.append("### Heatmap")
                    lines.append("")
                    lines.append("El heatmap muestra la distribución de sentimientos a lo largo del documento de forma matricial. Cada fila representa un párrafo (ordenados secuencialmente) y cada columna representa una categoría de sentimiento (POS, NEG, NEU). Los colores indican la intensidad del sentimiento: verde para positivo, rojo para negativo, y amarillo para neutral. Los valores numéricos muestran los scores de confianza del modelo para cada sentimiento en cada párrafo.")
                    lines.append("")
                    lines.append(f"![Distribución de Sentimientos]({heatmap_rel_path_str})")
                    lines.append("")
        
        md_path.parent.mkdir(parents=True, exist_ok=True)
        md_path.write_text("\n".join(lines), encoding="utf-8")

    def _write_corpus_report(md_path: Path, corpus_name: str, docs: list, backend_name: str, params: dict, top_k: int, min_score: float = 0.0, min_confidence: float = 0.0, min_score_diff: float = 0.0, min_paragraph_length: int = 20):
        """Generate consolidated corpus report from multiple documents."""
        backend = _load_backend(backend_name, **params)
        
        # Combine all documents
        all_paragraphs = []
        for doc in docs:
            text = doc["clean_text"]
            paragraphs = split_paragraphs(text)
            for para in paragraphs:
                if para.strip() and len(para.strip()) >= min_paragraph_length:
                    all_paragraphs.append({
                        "text": para,
                        "doc_name": doc["file_name"],
                        "doc_path": doc.get("file_path")
                    })
        
        if not all_paragraphs:
            md_path.parent.mkdir(parents=True, exist_ok=True)
            md_path.write_text(f"# Informe consolidado de sentimientos - {corpus_name}\n\nNo se encontraron párrafos válidos.", encoding="utf-8")
            return
        
        # Corpus-level prediction (combine all text)
        combined_text = "\n\n".join([p["text"] for p in all_paragraphs])
        lang_name = detect_language(combined_text)
        corpus_pred = _aggregate_mode(combined_text, "document", backend, lang_name)
        corpus_label = corpus_pred.get("label")
        corpus_scores = corpus_pred.get("scores") or corpus_pred.get("distribution")
        
        # Score all paragraphs
        scored = []
        for para_info in all_paragraphs:
            ptxt = para_info["text"]
            clang = detect_language(ptxt)
            lang_arg = {"spanish":"es","english":"en","french":"fr","german":"de","italian":"it","portuguese":"pt"}.get(clang, "es")
            if lang_arg not in ("es", "en", "it", "pt"):
                lang_arg = "es"
            
            pred = backend.predict(ptxt, lang=lang_arg)
            scores = pred.get("scores", {})
            label = pred.get("label", "NEU")
            
            if isinstance(label, list):
                label = label[0] if label else "NEU"
            
            if not isinstance(scores, dict):
                if isinstance(scores, list):
                    scores = {f"class_{i}": score for i, score in enumerate(scores)}
                else:
                    scores = {}
            
            sorted_scores = sorted(scores.items(), key=lambda x: x[1], reverse=True) if scores else []
            top_score = sorted_scores[0][1] if sorted_scores else 0.0
            second_score = sorted_scores[1][1] if len(sorted_scores) > 1 else 0.0
            label_score = scores.get(label, 0.0) if isinstance(scores, dict) and isinstance(label, str) else 0.0
            
            # Apply filters
            if min_score > 0 and label_score < min_score:
                continue
            if min_confidence > 0 and top_score < min_confidence:
                continue
            if min_score_diff > 0 and (top_score - second_score) < min_score_diff:
                continue
            
            # Store with predicted label for word cloud generation
            scored.append((para_info, scores, label))
        
        # Discover label set
        label_keys = set()
        for _, scores, _ in scored[:min(len(scored), 20)]:
            label_keys.update(scores.keys())
        
        # Normalize sentiment label names
        def normalize_label(l: str) -> str:
            mapping = {"positive":"POS", "negative":"NEG", "neutral":"NEU"}
            return mapping.get(l, l)
        
        # Top-K per label across corpus
        selected = {}
        for lab in sorted(label_keys):
            lab_norm = normalize_label(lab) if backend_name in ("transformers",) else lab
            ranked = sorted(scored, key=lambda t: float(t[1].get(lab, 0.0)), reverse=True)
            top = [(para_info, float(s.get(lab, 0.0))) for para_info, s, _ in ranked[:top_k] 
                   if float(s.get(lab, 0.0)) > 0.0 and float(s.get(lab, 0.0)) >= min_score]
            if top:
                selected[lab_norm] = top
        
        # Calculate individual document predictions
        doc_predictions = []
        for doc in docs:
            doc_text = doc["clean_text"]
            doc_lang = detect_language(doc_text)
            doc_pred = _aggregate_mode(doc_text, "document", backend, doc_lang)
            doc_predictions.append({
                "name": doc["file_name"],
                "path": doc.get("file_path"),
                "label": doc_pred.get("label"),
                "scores": doc_pred.get("scores") or doc_pred.get("distribution")
            })
        
        # Build markdown
        lines = []
        lines.append(f"# Informe consolidado de análisis de sentimientos - {corpus_name}")
        lines.append("")
        lines.append(f"- Backend: `{backend_name}`")
        lines.append(f"- Total de documentos: {len(docs)}")
        lines.append(f"- Total de párrafos analizados: {len(all_paragraphs)}")
        lines.append(f"- Párrafos que pasaron los filtros: {len(scored)}")
        lines.append(f"- Idioma detectado: `{lang_name}`")
        lines.append("")
        
        # Add methodology explanation
        model_name = params.get("model") or (backend.model_name if hasattr(backend, "model_name") else None)
        explanation_lines = get_sentiment_analysis_explanation(backend_name, model_name)
        lines.extend(explanation_lines)
        lines.append("")
        lines.append("---")
        lines.append("")
        
        # Create images directory for all visualizations (chart, heatmap, wordclouds)
        stem_short = md_path.stem.replace(" ", "_")[:10] if len(md_path.stem) > 10 else md_path.stem.replace(" ", "_")
        images_dir = md_path.parent / f"{stem_short}_sentiment_images"
        images_dir.mkdir(parents=True, exist_ok=True)
        
        lines.append("## Predicción a nivel de corpus")
        lines.append("")
        lines.append(f"- Etiqueta: **{corpus_label}**")
        if corpus_scores:
            lines.append("- Distribución:")
            for k, v in sorted(corpus_scores.items()):
                nk = normalize_label(k) if backend_name in ("transformers",) else k
                lines.append(f"  - {nk}: {v:.4f}")
            
            # Generate and include bar chart for corpus
            chart_path = _generate_image_filename(md_path, "sentiment", "corpus_chart", images_dir)
            chart_rel_path_str = _get_relative_path_str(chart_path, md_path)
            chart_created = create_sentiment_bar_chart(corpus_scores, chart_path, title=f"Distribución de Sentimientos - Corpus {corpus_name}")
            if chart_created:
                lines.append("")
                lines.append("### Gráfico de Barras del Corpus")
                lines.append("")
                lines.append("Este gráfico muestra la distribución proporcional de sentimientos en todo el corpus. Cada barra representa la probabilidad o proporción de cada categoría de sentimiento (POS=Positivo, NEG=Negativo, NEU=Neutral) calculada a partir de todos los documentos analizados.")
                lines.append("")
                lines.append(f"![Distribución de Sentimientos del Corpus]({chart_rel_path_str})")
        lines.append("")
        lines.append("## Predicciones por documento")
        lines.append("")
        for doc_pred in doc_predictions:
            lines.append(f"### {doc_pred['name']}")
            lines.append("")
            lines.append(f"- Etiqueta: **{doc_pred['label']}**")
            if doc_pred['scores']:
                lines.append("- Distribución:")
                for k, v in sorted(doc_pred['scores'].items()):
                    nk = normalize_label(k) if backend_name in ("transformers",) else k
                    lines.append(f"  - {nk}: {v:.4f}")
            if doc_pred.get('path'):
                lines.append("")
                lines.append(f"[Abrir documento original]({doc_pred['path']})")
            lines.append("")
        lines.append("")
        lines.append(f"## Top {top_k} párrafos por clase (corpus completo)")
        lines.append("")
        for lab in sorted(selected.keys()):
            lines.append(f"### {lab}")
            for para_info, sc in selected[lab]:
                lines.append(f"- Párrafo de **{para_info['doc_name']}** (puntaje: {sc:.4f})")
                lines.append("")
                lines.append(f"> {para_info['text'].strip().replace(chr(10), chr(10) + '> ')}")
                if para_info.get("doc_path"):
                    lines.append("")
                    lines.append(f"[Abrir documento original]({para_info['doc_path']})")
                lines.append("")
        
        # Generate word clouds for corpus (use all paragraphs that passed filters, grouped by predicted label)
        paragraphs_by_label = {}
        for para_info, scores, pred_label in scored:
            if pred_label:
                lab_norm = normalize_label(pred_label) if backend_name in ("transformers",) else pred_label
                if lab_norm not in paragraphs_by_label:
                    paragraphs_by_label[lab_norm] = []
                paragraphs_by_label[lab_norm].append(para_info['text'])
        
        if paragraphs_by_label:
            # Use the same images directory for wordclouds
            wordcloud_paths = create_sentiment_wordclouds(paragraphs_by_label, images_dir, lang=lang_name)
            
            if any(wordcloud_paths.values()):
                lines.append("")
                lines.append("## Nubes de palabras por sentimiento (corpus completo)")
                lines.append("")
                lines.append("Las nubes de palabras muestran las palabras más relevantes y específicas para cada categoría de sentimiento en todo el corpus. El tamaño de cada palabra es proporcional a su frecuencia e importancia para ese sentimiento específico.")
                lines.append("")
                lines.append("**Metodología de filtrado inteligente:**")
                lines.append("- Se utiliza un enfoque similar a TF-IDF para calcular la especificidad de cada palabra a cada sentimiento")
                lines.append("- Las palabras que aparecen en múltiples categorías de sentimiento son filtradas o penalizadas")
                lines.append("- Solo se incluyen palabras con alta especificidad al sentimiento correspondiente")
                lines.append("- Esto asegura que cada nube de palabras muestre únicamente términos relevantes y distintivos para ese sentimiento")
                lines.append("")
                for lab in sorted(paragraphs_by_label.keys()):
                    if wordcloud_paths.get(lab) and wordcloud_paths[lab]:
                        try:
                            wc_rel_path = wordcloud_paths[lab].relative_to(md_path.parent)
                            # Convert to string with forward slashes for markdown compatibility
                            wc_rel_path_str = str(wc_rel_path).replace("\\", "/")
                        except (ValueError, AttributeError):
                            # Fallback: use the directory name + filename
                            wc_rel_path_str = f"{images_dir.name}/{wordcloud_paths[lab].name}".replace("\\", "/")
                        lines.append(f"### {lab}")
                        lines.append("")
                        lines.append(f"![Nube de palabras - {lab}]({wc_rel_path_str})")
                        lines.append("")
        
        # Generate corpus-level heatmap (sentiment distribution by document)
        if doc_predictions:
            document_data = []
            for doc_pred in doc_predictions:
                document_data.append({
                    'name': doc_pred['name'],
                    'scores': doc_pred.get('scores', {})
                })
            
            if document_data:
                heatmap_path = _generate_image_filename(md_path, "sentiment", "corpus_heatmap", images_dir)
                heatmap_rel_path_str = _get_relative_path_str(heatmap_path, md_path)
                heatmap_created = create_corpus_sentiment_heatmap(document_data, heatmap_path, title=f"Distribución de Sentimientos por Documento - {corpus_name}")
                if heatmap_created:
                    lines.append("")
                    lines.append("## Distribución de Sentimientos por Documento")
                    lines.append("")
                    lines.append("### Heatmap")
                    lines.append("")
                    lines.append("El heatmap muestra la distribución de sentimientos para cada documento del corpus. Cada fila representa un documento y cada columna representa una categoría de sentimiento (POS, NEG, NEU). Los colores indican la intensidad del sentimiento: verde para positivo, rojo para negativo, y amarillo para neutral. Los valores numéricos muestran los scores de confianza del modelo para cada sentimiento en cada documento. Esto permite comparar fácilmente el perfil de sentimientos entre diferentes documentos del corpus.")
                    lines.append("")
                    lines.append(f"![Distribución de Sentimientos por Documento]({heatmap_rel_path_str})")
                    lines.append("")
        
        md_path.parent.mkdir(parents=True, exist_ok=True)
        md_path.write_text("\n".join(lines), encoding="utf-8")

    def _extract_sections_with_clean(src_path: Path):
        # Use topic_analysis extractor and local cleaner to align paragraphs
        from ..topic_analysis.text_processing import extract_sections_with_headers as _extract_sections
        raw_secs = _extract_sections(src_path)
        out = []
        for s in raw_secs:
            clean = extract_text_from_markdown_content(s["raw_text"])
            paras = split_paragraphs(clean)
            out.append({"header": s["header"], "paragraphs": paras})
        return out

    if path.is_file():
        if args.output:
            out_md = _ensure_output_path(path, args.output, suffix=".sentiment.md")
            text = extract_text_from_markdown_content(path.read_text(encoding="utf-8"))
            _write_markdown_report(out_md, path.stem, text, args.algo, params, top_k=args.top_k, source_path=path, min_score=args.min_score, min_confidence=args.min_confidence, min_score_diff=args.min_score_diff, min_paragraph_length=args.min_paragraph_length)
            print(f"Wrote report: {out_md}")
        else:
            out = run_file(path, args.algo, params, args.aggregate)
            print(out)
    elif path.is_dir():
        if args.output:
            out_dir = Path(args.output)
            out_dir.mkdir(parents=True, exist_ok=True)
            docs = extract_documents_from_folder(path, recursive=not args.no_recursive, file_pattern=args.file_pattern, min_document_length=args.min_document_length)
            
            # Generate individual reports
            for d in docs:
                out_md = out_dir / f"{d['file_name']}.sentiment.md"
                _write_markdown_report(out_md, d["file_name"], d["clean_text"], args.algo, params, top_k=args.top_k, source_path=d["file_path"] if "file_path" in d else None, min_score=args.min_score, min_confidence=args.min_confidence, min_score_diff=args.min_score_diff, min_paragraph_length=args.min_paragraph_length)
            
            # Generate consolidated corpus report if requested
            if args.corpus_report:
                corpus_name = path.stem or "Corpus"
                corpus_md = out_dir / f"{corpus_name}.corpus.sentiment.md"
                _write_corpus_report(corpus_md, corpus_name, docs, args.algo, params, top_k=args.top_k, min_score=args.min_score, min_confidence=args.min_confidence, min_score_diff=args.min_score_diff, min_paragraph_length=args.min_paragraph_length)
                print(f"Wrote {len(docs)} individual reports and 1 consolidated corpus report to: {out_dir}")
            else:
                print(f"Wrote {len(docs)} reports to: {out_dir}")
        else:
            out = run_folder(path, args.algo, params, args.aggregate,
                             recursive=not args.no_recursive,
                             file_pattern=args.file_pattern,
                             min_document_length=args.min_document_length)
            print(out)
    else:
        raise SystemExit(f"No existe la ruta: {path}")


if __name__ == "__main__":
    main()


