"""Markdown exporter."""

from __future__ import annotations

from ontology_explorer.extraction.parse import _normalize_evidence


def generate_markdown_from_json(entities: list[list], relations: list[list]) -> str:
    """
    Genera markdown desde entidades y relaciones en formato JSON.
    Produce el mismo formato que se esperaba de PROMPT_OUTPUT_MARKDOWN.
    Completamente genérico, sin dependencias del dominio ni idioma.
    """
    # Agrupar entidades por tipo de forma genérica, sin secciones hardcodeadas
    entities_by_type: dict[str, list[tuple[str, str, list[dict]]]] = {}

    for ent in entities:
        if not isinstance(ent, list) or len(ent) < 2:
            continue

        name = ent[0]
        ent_type = ent[1]
        evidences = _normalize_evidence(ent[2] if len(ent) > 2 else None)

        if ent_type not in entities_by_type:
            entities_by_type[ent_type] = []
        entities_by_type[ent_type].append((name, ent_type, evidences))

    lines: list[str] = ["## Entidades", ""]

    # Ordenar tipos alfabéticamente para consistencia genérica
    for ent_type in sorted(entities_by_type.keys()):
        if entities_by_type[ent_type]:
            lines.append(f"### {ent_type}")
            for name, _, evidences in sorted(entities_by_type[ent_type], key=lambda x: x[0]):
                lines.append(f"- {name}")
                if evidences:
                    for ev in evidences:
                        doc = ev.get("document", "")
                        sent = ev.get("sentence", "")
                        lines.append(f'  - **Evidencia**: "{sent}" (Documento: {doc})')
                else:
                    lines.append("  - **Evidencia**: *(no proporcionada)*")
            lines.append("")

    lines.append("## Relaciones")
    if relations:
        for rel in relations:
            if not isinstance(rel, list) or len(rel) < 3:
                continue

            rel_type = rel[0]
            source = rel[1]
            target = rel[2]
            evidences = _normalize_evidence(rel[3] if len(rel) > 3 else None)

            lines.append(f"- **Relación**: {rel_type}")
            lines.append(f"  - Origen: {source}")
            lines.append(f"  - Destino: {target}")

            if evidences:
                for ev in evidences:
                    doc = ev.get("document", "")
                    sent = ev.get("sentence", "")
                    lines.append(f'  - **Evidencia**: "{sent}" (Documento: {doc})')
            else:
                lines.append("  - **Evidencia**: *(no proporcionada)*")
            lines.append("")
    else:
        lines.append("- *No se identificaron relaciones*")
        lines.append("")

    return "\n".join(lines).strip() + "\n"
