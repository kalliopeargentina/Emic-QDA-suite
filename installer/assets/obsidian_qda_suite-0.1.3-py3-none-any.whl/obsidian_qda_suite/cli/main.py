"""Main CLI with subcommands. Invoked as obsidianqda <subcommand> ..."""
import os
os.environ["TORCH_FORCE_NO_WEIGHTS_ONLY_LOAD"] = "1"
os.environ["USE_TF"] = "0"
os.environ["USE_TORCH"] = "1"
os.environ["TF_ENABLE_ONEDNN_OPTS"] = "0"

import sys


def main() -> None:
    from . import common
    common.setup_console_encoding()

    if len(sys.argv) < 2 or sys.argv[1] in ("-h", "--help"):
        _print_help()
        sys.exit(0 if len(sys.argv) < 2 else 0)

    subcommand = sys.argv[1].lower().replace("_", "-")
    rest = sys.argv[2:]

    dispatch = {
        "transcribe": _run_transcribe,
        "transcribex": _run_transcribex,
        "regenerate-srt": _run_regenerate_srt,
        "emotion": _run_emotion,
        "sentiment": _run_sentiment,
        "topic": _run_topic,
        "kwic": _run_kwic,
        "extract-audio": _run_extract_audio,
        "split-audio": _run_split_audio,
        "convert-compress-audio": _run_convert_compress_audio,
        "clean-audio": _run_clean_audio,
        "transcribe-youtube": _run_transcribe_youtube,
    }

    if subcommand not in dispatch:
        common.safe_print(f"Unknown subcommand: {subcommand}", file=sys.stderr)
        _print_help()
        sys.exit(1)

    sys.argv = [sys.argv[0]] + rest
    dispatch[subcommand]()


def _print_help() -> None:
    from . import common
    common.safe_print("Usage: obsidianqda <subcommand> [options]")
    common.safe_print("Subcommands: transcribe, transcribex, regenerate-srt, emotion, sentiment, topic,")
    common.safe_print("             kwic, extract-audio, split-audio, convert-compress-audio, clean-audio, transcribe-youtube")
    common.safe_print("Use obsidianqda <subcommand> --help for subcommand options.")


def _run_transcribe() -> None:
    from . import transcribe
    transcribe.main()


def _run_transcribex() -> None:
    from . import transcribex
    transcribex.main()


def _run_regenerate_srt() -> None:
    from . import regenerate_srt
    regenerate_srt.main()


def _run_emotion() -> None:
    from . import emotion
    emotion.main()


def _run_sentiment() -> None:
    from . import sentiment
    sentiment.main()


def _run_topic() -> None:
    from . import topic
    topic.main()


def _run_kwic() -> None:
    from . import kwic
    kwic.main()


def _run_extract_audio() -> None:
    from . import extract_audio
    extract_audio.main()


def _run_split_audio() -> None:
    from . import split_audio
    split_audio.main()


def _run_convert_compress_audio() -> None:
    from . import convert_compress_audio
    convert_compress_audio.main()


def _run_clean_audio() -> None:
    from . import clean_audio
    clean_audio.main()


def _run_transcribe_youtube() -> None:
    from . import transcribe_youtube
    transcribe_youtube.main()
