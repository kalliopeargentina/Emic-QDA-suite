"""
Text processing utilities for topic analysis.

This module provides markdown parsing, text extraction, preprocessing,
and text statistics analysis.
"""

import re
import numpy as np
from nltk.tokenize import word_tokenize
from nltk.stem import WordNetLemmatizer

# Handle both relative and absolute imports
try:
    from .config import DEFAULT_CONFIG
    from .nlp_utils import get_stopwords_set, lemmatize_word
except ImportError:
    # Fallback to absolute imports (when running directly)
    import sys
    from pathlib import Path
    current_file = Path(__file__).resolve()
    parent_dir = current_file.parent
    
    # Add parent directory to path if not already there
    if str(parent_dir) not in sys.path:
        sys.path.insert(0, str(parent_dir))
    
    from config import DEFAULT_CONFIG
    from nlp_utils import get_stopwords_set, lemmatize_word


def extract_sections_with_headers(file_path):
    """Extract text sections based on markdown headers BEFORE stripping formatting."""
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Remove YAML frontmatter
    content = re.sub(r'^---\n.*?\n---\n', '', content, flags=re.DOTALL)
    
    sections = []
    current_header = "Document"  # Default header for content before first header
    lines = content.split('\n')
    current_section_lines = []
    
    for line in lines:
        # Check if line is a markdown header (# Header, ## Header, etc.)
        header_match = re.match(r'^(#{1,6})\s+(.+)$', line.strip())
        if header_match:
            # Save previous section if it has content
            if current_section_lines:
                section_text = '\n'.join(current_section_lines).strip()
                if section_text:  # Only add non-empty sections
                    sections.append({
                        'header': current_header,
                        'raw_text': section_text  # Keep raw text for now
                    })
                current_section_lines = []
            
            # Extract header text
            header_text = header_match.group(2).strip()
            # Remove markdown formatting from header text only
            header_text = re.sub(r'\*\*([^\*]+)\*\*', r'\1', header_text)
            header_text = re.sub(r'\*([^\*]+)\*', r'\1', header_text)
            header_text = re.sub(r'`([^`]+)`', r'\1', header_text)
            header_text = re.sub(r'\[([^\]]+)\]\([^\)]+\)', r'\1', header_text)
            header_text = re.sub(r'\[\[([^\]]+)\]\]', lambda m: m.group(1).split('|')[-1], header_text)
            current_header = header_text
        else:
            # Add line to current section
            current_section_lines.append(line)
    
    # Add last section
    if current_section_lines:
        section_text = '\n'.join(current_section_lines).strip()
        if section_text:
            sections.append({
                'header': current_header,
                'raw_text': section_text
            })
    
    # If no headers found, create single section
    if not sections:
        sections.append({
            'header': "Document",
            'raw_text': content
        })
    
    return sections


def extract_text_from_markdown_content(content):
    """Extract clean text from markdown content string (same logic as extract_text_from_markdown)."""
    # Remove code blocks
    content = re.sub(r'```[\s\S]*?```', '', content)
    content = re.sub(r'~~~[\s\S]*?~~~', '', content)
    
    # Remove inline code but keep text
    content = re.sub(r'`([^`]+)`', r'\1', content)
    
    # Remove markdown images
    content = re.sub(r'!\[([^\]]*)\]\([^\)]+\)', r'\1', content)
    
    # Remove links but keep text
    content = re.sub(r'\[([^\]]+)\]\([^\)]+\)', r'\1', content)
    content = re.sub(r'\[\[([^\]]+)\]\]', lambda m: m.group(1).split('|')[-1], content)
    
    # Remove reference-style links
    content = re.sub(r'\[([^\]]+)\]\[[^\]]*\]', r'\1', content)
    content = re.sub(r'\[([^\]]+)\]', r'\1', content)
    
    # Remove formatting
    content = re.sub(r'\*\*([^\*]+)\*\*', r'\1', content)
    content = re.sub(r'__([^_]+)__', r'\1', content)
    content = re.sub(r'\*([^\*]+)\*', r'\1', content)
    content = re.sub(r'_([^_]+)_', r'\1', content)
    content = re.sub(r'~~([^~]+)~~', r'\1', content)
    
    # Remove headers (already extracted)
    content = re.sub(r'#{1,6}\s+', '', content)
    
    # Remove other markdown elements
    content = re.sub(r'^[\s]*[-*_]{3,}[\s]*$', '', content, flags=re.MULTILINE)
    content = re.sub(r'^>\s*', '', content, flags=re.MULTILINE)
    content = re.sub(r'^\s*[-*+]\s+', '', content, flags=re.MULTILINE)
    content = re.sub(r'^\s*\d+\.\s+', '', content, flags=re.MULTILINE)
    content = re.sub(r'^\s*[-*+]\s*\[[ xX]\]\s*', '', content, flags=re.MULTILINE)
    content = re.sub(r'\|', ' ', content)
    content = re.sub(r'^[\s:-\|]*$', '', content, flags=re.MULTILINE)
    
    # Remove URLs
    content = re.sub(r'https?://[^\s]+', '', content)
    content = re.sub(r'ftp://[^\s]+', '', content)
    content = re.sub(r'www\.[^\s]+', '', content)
    
    # Remove email
    content = re.sub(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b', '', content)
    
    # Remove timestamps
    content = re.sub(r'\d{1,2}:\d{2}(?::\d{2})?', '', content)
    content = re.sub(r'\d{4}-\d{2}-\d{2}[\sT]\d{2}:\d{2}:\d{2}', '', content)
    
    # Remove HTML
    content = re.sub(r'<[^>]+>', '', content)
    
    # Remove escape characters
    content = re.sub(r'\\(.)', r'\1', content)
    
    # Clean whitespace
    content = re.sub(r'\n\s*\n\s*\n+', '\n\n', content)
    content = re.sub(r' +', ' ', content)
    content = '\n'.join(line.strip() for line in content.split('\n'))
    
    return content.strip()


def extract_text_from_markdown(file_path):
    """Extract clean text content from markdown file, stripping all formatting and links."""
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Remove YAML frontmatter
    content = re.sub(r'^---\n.*?\n---\n', '', content, flags=re.DOTALL)
    
    # Remove code blocks (```...```) - must be done before other processing
    content = re.sub(r'```[\s\S]*?```', '', content)
    content = re.sub(r'~~~[\s\S]*?~~~', '', content)
    
    # Remove inline code but keep text: `code` -> code
    content = re.sub(r'`([^`]+)`', r'\1', content)
    
    # Remove markdown images: ![alt](url) or ![alt](url "title")
    content = re.sub(r'!\[([^\]]*)\]\([^\)]+\)', r'\1', content)
    
    # Remove markdown links but keep text: [text](url) -> text
    content = re.sub(r'\[([^\]]+)\]\([^\)]+\)', r'\1', content)
    
    # Remove reference-style links: [text][ref] or [text]
    content = re.sub(r'\[([^\]]+)\]\[[^\]]*\]', r'\1', content)
    content = re.sub(r'\[([^\]]+)\]', r'\1', content)
    
    # Remove Obsidian wikilinks: [[link|text]] or [[link]] -> text or link
    content = re.sub(r'\[\[([^\]]+)\]\]', lambda m: m.group(1).split('|')[-1], content)
    content = re.sub(r'\[\[([^\]]+)\|([^\]]+)\]\]', r'\2', content)
    
    # Remove markdown formatting - bold (**text** or __text__)
    content = re.sub(r'\*\*([^\*]+)\*\*', r'\1', content)
    content = re.sub(r'__([^_]+)__', r'\1', content)
    
    # Remove markdown formatting - italic (*text* or _text_)
    content = re.sub(r'\*([^\*]+)\*', r'\1', content)
    content = re.sub(r'_([^_]+)_', r'\1', content)
    
    # Remove strikethrough: ~~text~~
    content = re.sub(r'~~([^~]+)~~', r'\1', content)
    
    # Remove headers (# Header)
    content = re.sub(r'#{1,6}\s+', '', content)
    
    # Remove horizontal rules (---, ***, ___)
    content = re.sub(r'^[\s]*[-*_]{3,}[\s]*$', '', content, flags=re.MULTILINE)
    
    # Remove blockquotes (> text)
    content = re.sub(r'^>\s*', '', content, flags=re.MULTILINE)
    
    # Remove list markers (bullets and numbers)
    content = re.sub(r'^\s*[-*+]\s+', '', content, flags=re.MULTILINE)
    content = re.sub(r'^\s*\d+\.\s+', '', content, flags=re.MULTILINE)
    
    # Remove task list markers (- [ ] or - [x])
    content = re.sub(r'^\s*[-*+]\s*\[[ xX]\]\s*', '', content, flags=re.MULTILINE)
    
    # Remove table formatting (| col1 | col2 |)
    content = re.sub(r'\|', ' ', content)  # Replace pipe separators with space
    content = re.sub(r'^[\s:-\|]*$', '', content, flags=re.MULTILINE)  # Remove table separator rows
    
    # Remove URLs (http/https/ftp)
    content = re.sub(r'https?://[^\s]+', '', content)
    content = re.sub(r'ftp://[^\s]+', '', content)
    content = re.sub(r'www\.[^\s]+', '', content)
    
    # Remove email addresses
    content = re.sub(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b', '', content)
    
    # Remove timestamps in various formats
    content = re.sub(r'\d{1,2}:\d{2}(?::\d{2})?', '', content)
    content = re.sub(r'\d{4}-\d{2}-\d{2}[\sT]\d{2}:\d{2}:\d{2}', '', content)  # ISO format
    
    # Remove HTML tags if any
    content = re.sub(r'<[^>]+>', '', content)
    
    # Remove markdown escape characters (\)
    content = re.sub(r'\\(.)', r'\1', content)
    
    # Remove excessive whitespace
    content = re.sub(r'\n\s*\n\s*\n+', '\n\n', content)
    content = re.sub(r' +', ' ', content)
    
    # Remove leading/trailing whitespace from lines
    content = '\n'.join(line.strip() for line in content.split('\n'))
    
    return content.strip()


def preprocess_text(text, language='english', custom_stopwords=None, lemmatizer=None):
    """Preprocess text for topic modeling.
    
    Parameters:
    -----------
    text : str
        Text to preprocess
    language : str
        Language code ('english', 'spanish', etc.)
    custom_stopwords : set or None
        Custom stopwords to add
    lemmatizer : object or None
        spaCy model or WordNetLemmatizer instance. If None, uses WordNetLemmatizer.
    
    Returns:
    --------
    str
        Preprocessed text (space-separated tokens)
    """
    # Get stopwords using centralized function with cache
    stop_words = get_stopwords_set(language, custom_stopwords)
    
    # Initialize lemmatizer if not provided
    if lemmatizer is None:
        lemmatizer = WordNetLemmatizer()
    
    # Convert to lowercase
    text = text.lower()
    
    # Tokenize
    tokens = word_tokenize(text)
    
    # Get min word length from config
    min_word_len = DEFAULT_CONFIG['text_processing']['min_word_length']
    
    # Remove stopwords, punctuation, and short words, then lemmatize
    processed_tokens = []
    for token in tokens:
        token_normalized = token.lower().strip()
        
        # Check: must be alphanumeric, length > min_word_len, and not a stopword
        if token.isalnum() and len(token_normalized) > min_word_len and token_normalized not in stop_words:
            # Use the lemmatize_word function which handles both spaCy and NLTK
            lemmatized = lemmatize_word(token, lemmatizer, language)
            
            # Also check if lemmatized word is a stopword 
            # (sometimes lemmatization can change a word to a stopword)
            lemmatized_normalized = lemmatized.lower().strip()
            if lemmatized_normalized not in stop_words:
                processed_tokens.append(lemmatized)
    
    return ' '.join(processed_tokens)


def analyze_text_statistics(text):
    """Analyze basic text statistics."""
    sentences = re.split(r'[.!?]+', text)
    sentences = [s.strip() for s in sentences if len(s.strip()) > 0]
    
    words = re.findall(r'\b\w+\b', text.lower())
    
    paragraphs = [p.strip() for p in text.split('\n\n') if len(p.strip()) > 0]
    
    # Calculate readability metrics
    avg_sentence_length = np.mean([len(re.findall(r'\b\w+\b', s)) for s in sentences]) if sentences else 0
    avg_word_length = np.mean([len(w) for w in words]) if words else 0
    
    return {
        'total_words': len(words),
        'total_sentences': len(sentences),
        'total_paragraphs': len(paragraphs),
        'avg_sentence_length': avg_sentence_length,
        'avg_word_length': avg_word_length,
        'unique_words': len(set(words)),
        'vocabulary_richness': len(set(words)) / len(words) if words else 0
    }

