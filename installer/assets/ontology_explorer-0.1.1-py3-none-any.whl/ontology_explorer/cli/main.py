"""CLI entrypoint for OntologyExplorer."""

from __future__ import annotations

import argparse
import json
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from threading import Lock

from ontology_explorer.domain.normalize import load_domain_spec
from ontology_explorer.domain.spec import DomainSpec
from ontology_explorer.extraction.merge import merge_json_outputs
from ontology_explorer.extraction.parse import parse_json_output
from ontology_explorer.extraction.validate import validate_result
from ontology_explorer.exporters.graphml_export import generate_graph_graphml
from ontology_explorer.exporters.json_export import export_json
from ontology_explorer.exporters.markdown_export import generate_markdown_from_json
from ontology_explorer.exporters.ontology_export import (
    generate_ontology_json,
    generate_ontology_markdown,
)
from ontology_explorer.exporters.vault_markdown_export import (
    export_ontology_vault_markdown,
)
from ontology_explorer.io.cache import get_cache_path, load_cached_result, save_cached_result
from ontology_explorer.io.discovery import discover_files
from ontology_explorer.io.files import (
    OUTPUTS_DIR,
    read_article_text_safe,
    write_text_output,
    write_vault_output,
)
from ontology_explorer.prompt.builder import build_prompt
from ontology_explorer.prompt.schema import build_extraction_schema
from ontology_explorer.providers.base import ProviderConfig
from ontology_explorer.providers.registry import get_provider
from ontology_explorer.text.chunking import estimate_tokens, split_text_by_chars


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Consulta a un modelo (Ollama, Ollama Cloud, OpenAI o Gemini) para extraer entidades "
            "y relaciones de un artículo usando una definición de dominio simple (sin ontología). "
            "El resultado incluye el nombre del modelo para comparación. "
            "Acepta uno o más archivos, o un directorio con --input-dir."
        )
    )
    parser.add_argument(
        "archivo",
        type=Path,
        nargs="*",
        help="Uno o más archivos de texto a analizar. No usar junto con --input-dir.",
    )
    parser.add_argument(
        "--input-dir",
        type=Path,
        default=None,
        help="Carpeta desde la cual descubrir archivos .txt y .md (no recursivo). Excluye según .ontologyignore y --exclude.",
    )
    parser.add_argument(
        "--provider",
        choices=("ollama", "ollama-cloud", "openai", "gemini"),
        default="ollama",
        help="Proveedor a utilizar (por defecto: ollama).",
    )
    parser.add_argument(
        "--model",
        default=None,
        help=(
            "Nombre del modelo a utilizar. Por defecto usa 'llama3' para Ollama y Ollama Cloud, "
            "'gpt-4o' para OpenAI y 'gemini-1.5-pro' para Gemini."
        ),
    )
    parser.add_argument(
        "--api-key",
        help=(
            "Clave de API para el proveedor seleccionado (si aplica). "
            "Para OpenAI usa esta opción o la variable de entorno OPENAI_API_KEY. "
            "Para Gemini usa esta opción o la variable de entorno GEMINI_API_KEY. "
            "Para Ollama Cloud usa esta opción o la variable de entorno OLLAMA_API_KEY."
        ),
    )
    parser.add_argument(
        "--temperature",
        type=float,
        help=(
            "Temperatura a utilizar en la generación del modelo. "
            "Si no se especifica, se utiliza el valor por defecto del proveedor."
        ),
    )
    parser.add_argument(
        "--output-format",
        choices=("json", "markdown", "ontologia", "grafo"),
        default="json",
        help="Formato de salida: 'json' (por defecto), 'markdown', 'ontologia' o 'grafo'.",
    )
    parser.add_argument(
        "--output-name",
        type=str,
        default=None,
        help=(
            "Nombre base de salida (sin extensión). Si no se especifica, se usa el nombre "
            "por defecto basado en proveedor/modelo. Para vault crea un directorio con ese nombre."
        ),
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=None,
        help=(
            "Directorio base donde escribir la salida. Por defecto: 'outputs' (relativo al cwd). "
            "Si se especifica, los archivos y el vault se escriben dentro de este directorio."
        ),
    )
    parser.add_argument(
        "--ontology-format",
        choices=("markdown", "json", "vault"),
        default="markdown",
        help=(
            "Formato para ontología cuando --output-format es 'ontologia': "
            "'markdown' (por defecto), 'json' o 'vault' (directorio con un .md por entidad)."
        ),
    )
    parser.add_argument(
        "--max-tokens",
        type=int,
        help=(
            "Límite máximo estimado de tokens del prompt total. "
            "Se descuenta el overhead del prompt para ajustar el contexto del artículo."
        ),
    )
    parser.add_argument(
        "--chars-per-token",
        type=int,
        default=4,
        help=(
            "Estimación de caracteres por token (default: 4). "
            "Se usa para convertir tokens a caracteres al partir el texto."
        ),
    )
    parser.add_argument(
        "--domain",
        default="default",
        help=(
            "Nombre del dominio a usar (sin extensión .md). "
            "Por defecto: 'default'. Los dominios se cargan desde config/domains/."
        ),
    )
    parser.add_argument(
        "--role",
        default="default",
        help=(
            "Nombre del rol a usar (sin extensión .md). "
            "Por defecto: 'default'. Los roles se cargan desde config/roles/."
        ),
    )
    parser.add_argument(
        "--config-dir",
        type=Path,
        default=None,
        help=(
            "Directorio desde donde se cargan las definiciones de dominios y roles. "
            "Por defecto: 'config' (relativo a la raíz del proyecto). "
            "Debe contener subdirectorios 'domains/' y 'roles/'."
        ),
    )
    parser.add_argument(
        "--workers",
        type=int,
        default=1,
        help=(
            "Número máximo de archivos a procesar en paralelo (por defecto: 1). "
            "Valores altos pueden provocar rate limits en APIs remotas; se recomienda 3–5 para servicios externos."
        ),
    )
    parser.add_argument(
        "--no-cache",
        action="store_true",
        help="No usar ni escribir cache por archivo (reprocesar todo).",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Solo listar qué archivos se procesarían o se cargarían desde cache; no llamar al LLM ni escribir.",
    )
    parser.add_argument(
        "--exclude",
        type=str,
        action="append",
        default=None,
        metavar="PATTERN",
        help="Patrón glob para excluir archivos (puede repetirse). Se combina con .ontologyignore.",
    )
    parser.add_argument(
        "--delay",
        type=float,
        default=None,
        metavar="SECS",
        help="Segundos de espera entre envíos al modelo (puede ayudar ante rate limits).",
    )
    parser.add_argument(
        "--cache-dir",
        type=Path,
        default=None,
        help="Directorio de cache para resultados por archivo (por defecto: outputs/.cache).",
    )
    parser.add_argument(
        "--timeout",
        type=int,
        default=300,
        metavar="SECS",
        help="Timeout por request al proveedor en segundos (por defecto: 300).",
    )
    return parser.parse_args()


def _default_model_for(provider: str) -> str:
    if provider == "ollama":
        return "llama3"
    if provider == "ollama-cloud":
        return "llama3"
    if provider == "openai":
        return "gpt-4o"
    return "gemini-1.5-pro"


def process_one_file(
    article_path: Path,
    provider: object,
    config: ProviderConfig,
    model: str,
    domain_spec: DomainSpec | None,
    domain_name: str,
    role_name: str,
    config_dir: str | None,
    max_tokens: int | None,
    chars_per_token: int,
    provider_name: str,
    delay_sec: float | None,
) -> tuple[dict | None, str | None]:
    """
    Process a single file: read, chunk, call LLM per chunk, merge. Returns (result, None) on
    success, (None, error_message) on read/parse/API error. Exceptions (e.g. TimeoutError) are
    caught and converted to (None, str).
    """
    document_name = article_path.stem
    content, read_error = read_article_text_safe(article_path)
    if read_error is not None:
        return (None, read_error)
    article_text = content
    if not article_text.strip():
        return (None, "archivo vacío o sin texto utilizable")

    if max_tokens is not None:
        prompt_overhead_chars = len(
            build_prompt(
                "",
                model,
                document_name,
                domain_name,
                role_name,
                config_dir,
                domain_spec=domain_spec,
            )
        )
        prompt_overhead_tokens = estimate_tokens(
            prompt_overhead_chars, chars_per_token
        )
        max_context_tokens = max_tokens - prompt_overhead_tokens
        if max_context_tokens <= 0:
            return (
                None,
                f"--max-tokens ({max_tokens}) es menor o igual al overhead del prompt ({prompt_overhead_tokens})",
            )
        max_context_chars = max_context_tokens * chars_per_token
        segments = split_text_by_chars(article_text, max_context_chars)
    else:
        if provider_name == "ollama-cloud":
            max_context_chars = 60000
            segments = split_text_by_chars(article_text, max_context_chars)
        else:
            segments = [article_text]

    if not segments:
        return (None, "el artículo está vacío o no contiene texto utilizable")

    outputs: list[str] = []
    try:
        for segment in segments:
            if delay_sec is not None and delay_sec > 0:
                time.sleep(delay_sec)
            prompt = build_prompt(
                segment,
                model,
                document_name,
                domain_name,
                role_name,
                config_dir,
                domain_spec=domain_spec,
            )
            raw_output = provider.run(
                prompt=prompt,
                model=model,
                config=config,
            )
            outputs.append(raw_output)
    except Exception as e:
        return (None, str(e))

    results = [
        parse_json_output(out, model, domain_spec=domain_spec) for out in outputs
    ]
    consolidated = merge_json_outputs(results, model)
    return (consolidated, None)


def _resolve_file_list(args: argparse.Namespace) -> list[Path]:
    """Resolve list of files from --input-dir or positional archivo. Deterministic order."""
    if args.input_dir is not None:
        if not args.input_dir.is_dir():
            raise SystemExit(f"El directorio '{args.input_dir}' no existe o no es un directorio.")
        exclude = args.exclude if args.exclude else None
        files = discover_files(args.input_dir, exclude_patterns=exclude)
        if not files:
            raise SystemExit(
                f"No se encontraron archivos .txt ni .md en '{args.input_dir}' "
                "(o todos están excluidos por .ontologyignore / --exclude)."
            )
        return sorted(files, key=lambda p: str(p))
    if args.archivo:
        for p in args.archivo:
            if not p.exists():
                raise SystemExit(f"El archivo '{p}' no existe.")
            if not p.is_file():
                raise SystemExit(f"'{p}' no es un archivo válido.")
        return sorted(args.archivo, key=lambda p: str(p))
    raise SystemExit(
        "Indicá uno o más archivos como argumentos o usá --input-dir con un directorio."
    )


def main() -> None:
    args = parse_args()
    file_list = _resolve_file_list(args)
    output_format = args.output_format
    provider_name = args.provider
    model = args.model or _default_model_for(provider_name)
    domain_name = args.domain
    role_name = args.role
    config_dir = str(args.config_dir) if args.config_dir else None
    cache_dir = args.cache_dir if args.cache_dir is not None else OUTPUTS_DIR / ".cache"
    cache_dir = cache_dir.resolve()
    output_dir = args.output_dir.resolve() if args.output_dir else None
    progress_lock = Lock()

    # Dry-run: only list what would be done
    if args.dry_run:
        for i, path in enumerate(file_list, start=1):
            cache_path = get_cache_path(cache_dir, path)
            if not args.no_cache and load_cached_result(cache_path) is not None:
                print(f"[{i}/{len(file_list)}] Usaría cache para {path}", file=sys.stderr)
            else:
                print(f"[{i}/{len(file_list)}] Procesaría {path}", file=sys.stderr)
        return

    domain_spec = load_domain_spec(domain_name, config_dir)
    provider = get_provider(provider_name)
    config = ProviderConfig(
        api_key=args.api_key,
        temperature=args.temperature,
        response_schema=build_extraction_schema(),
        timeout=args.timeout,
    )
    max_tokens = args.max_tokens
    chars_per_token = args.chars_per_token
    delay_sec = args.delay

    # Results in same order as file_list; None placeholder for failed or not-yet-done
    results_by_index: list[dict | None] = [None] * len(file_list)
    failed: list[tuple[Path, str]] = []
    from_cache_count = 0
    processed_count = 0
    total = len(file_list)

    def task_for_file(index: int, path: Path) -> tuple[int, dict | None, str | None, bool]:
        """Returns (index, result, error_message, used_cache)."""
        cache_path = get_cache_path(cache_dir, path)
        if not args.no_cache:
            cached = load_cached_result(cache_path)
            if cached is not None:
                with progress_lock:
                    print(f"[{index + 1}/{total}] Usando cache para {path.name}", file=sys.stderr, flush=True)
                return (index, cached, None, True)
        with progress_lock:
            print(f"[{index + 1}/{total}] Procesando {path.name}...", file=sys.stderr, flush=True)
        result, err = process_one_file(
            path,
            provider,
            config,
            model,
            domain_spec,
            domain_name,
            role_name,
            config_dir,
            max_tokens,
            chars_per_token,
            provider_name,
            delay_sec,
        )
        if result is not None:
            if not args.no_cache:
                save_cached_result(cache_path, result)
            with progress_lock:
                print(f"[{index + 1}/{total}] Completado {path.name} (ok)", file=sys.stderr, flush=True)
            return (index, result, None, False)
        with progress_lock:
            print(f"[{index + 1}/{total}] Completado {path.name} (error)", file=sys.stderr, flush=True)
        return (index, None, err or "error desconocido", False)

    if args.workers <= 1:
        for idx, path in enumerate(file_list):
            _idx, result, err, used_cache = task_for_file(idx, path)
            if used_cache:
                from_cache_count += 1
            if result is not None:
                results_by_index[_idx] = result
                if not used_cache:
                    processed_count += 1
            else:
                failed.append((path, err or "error desconocido"))
    else:
        with ThreadPoolExecutor(max_workers=args.workers) as executor:
            futures = {
                executor.submit(task_for_file, idx, path): (idx, path)
                for idx, path in enumerate(file_list)
            }
            for future in as_completed(futures):
                _idx, result, err, used_cache = future.result()
                if used_cache:
                    from_cache_count += 1
                if result is not None:
                    results_by_index[_idx] = result
                    if not used_cache:
                        processed_count += 1
                else:
                    path = file_list[_idx]
                    failed.append((path, err or "error desconocido"))

    # Summary
    print(
        f"Procesados: {processed_count}, desde cache: {from_cache_count}, fallidos: {len(failed)}",
        file=sys.stderr,
        flush=True,
    )
    if failed:
        for path, msg in failed:
            print(f"  Fallido: {path} — {msg}", file=sys.stderr)

    # Merge all successful results (including from cache)
    collected = [r for r in results_by_index if r is not None]
    if not collected:
        raise SystemExit("No se obtuvo ningún resultado (todos los archivos fallaron o no había archivos).")

    consolidated = merge_json_outputs(collected, model)
    warnings = validate_result(consolidated)
    for warning in warnings:
        print(f"ADVERTENCIA: {warning}", file=sys.stderr, flush=True)

    safe_model_name = model.replace(":", "_").replace("/", "_").replace(".", "_")

    if output_format.lower() == "ontologia":
        if args.ontology_format.lower() == "json":
            ontology_data = generate_ontology_json(
                consolidated.get("entities", []),
                consolidated.get("relations", []),
                domain_name=domain_name,
                config_dir=config_dir,
            )
            base_name = args.output_name or f"ontologia_{provider_name}_{safe_model_name}"
            output_name = f"{base_name}.json"
            output_text = json.dumps(ontology_data, ensure_ascii=False, indent=2)
            write_text_output(output_text, output_name, output_dir=output_dir)
            print(output_text, flush=True)
        elif args.ontology_format.lower() == "vault":
            vault_files = export_ontology_vault_markdown(
                consolidated.get("entities", []),
                consolidated.get("relations", []),
                domain_name=domain_name,
                config_dir=config_dir,
            )
            base_dir_name = args.output_name or f"ontologia_vault_{provider_name}_{safe_model_name}"
            write_vault_output(vault_files, base_dir_name, output_dir=output_dir)
            for rel_path in sorted(vault_files.keys()):
                print(rel_path, flush=True)
        else:
            ontology_text = generate_ontology_markdown(
                consolidated.get("entities", []),
                consolidated.get("relations", []),
                domain_name=domain_name,
                config_dir=config_dir,
            )
            base_name = args.output_name or f"ontologia_{provider_name}_{safe_model_name}"
            output_name = f"{base_name}.md"
            write_text_output(ontology_text, output_name, output_dir=output_dir)
            print(ontology_text, flush=True)

    elif output_format.lower() == "grafo":
        graphml_content = generate_graph_graphml(
            consolidated.get("entities", []),
            consolidated.get("relations", []),
            domain_name=domain_name,
            config_dir=config_dir,
        )
        base_name = args.output_name or f"grafo_{provider_name}_{safe_model_name}"
        output_name = f"{base_name}.graphml"
        write_text_output(graphml_content, output_name, output_dir=output_dir)
        print(graphml_content, flush=True)

    elif output_format.lower() == "markdown":
        final_text = generate_markdown_from_json(
            consolidated.get("entities", []),
            consolidated.get("relations", []),
        )
        base_name = args.output_name or f"output_{provider_name}_{safe_model_name}"
        output_name = f"{base_name}.md"
        write_text_output(final_text, output_name, output_dir=output_dir)
        print(final_text, flush=True)

    else:
        output_json = export_json(consolidated)
        base_name = args.output_name or f"output_{provider_name}_{safe_model_name}"
        output_name = f"{base_name}.json"
        write_text_output(output_json, output_name, output_dir=output_dir)
        print(output_json, flush=True)

    if failed:
        sys.exit(1)


if __name__ == "__main__":
    main()
