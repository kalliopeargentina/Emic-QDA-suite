"""CLI for splitting audio into parts. Obsidian or direct args."""

import argparse
import os
import shutil
import sys
from datetime import datetime
from pathlib import Path

from . import common
from ..audio.ffmpeg_utils import get_ffmpeg_path
from ..audio.ffmpeg_utils import get_ffprobe_path
from ..audio.split import (
    get_duration,
    needs_conversion,
    convert_audio,
    split_audio as run_split_audio,
    compute_segment_time,
    probe_audio_file,
    LIMIT_BYTES,
)


def main() -> None:
    common.setup_console_encoding()
    parser = argparse.ArgumentParser(
        description="Split audio file into smaller parts (e.g. ≤ 20MB each)."
    )
    parser.add_argument("--vault-path", type=str, help="Obsidian vault path (Obsidian mode)")
    parser.add_argument("--file-path", type=str, help="Absolute path to audio file (Obsidian mode)")
    parser.add_argument("--file-name", type=str, help="Name of the audio file (Obsidian mode)")
    parser.add_argument("file", type=str, nargs="?", help="Audio file (direct mode)")
    parser.add_argument("--output-dir", type=str, help="Output directory for parts (direct mode)")
    args = parser.parse_args()

    vault_path = common.get_optional_param(args.vault_path)
    file_path_arg = common.get_optional_param(args.file_path)
    file_name_arg = common.get_optional_param(args.file_name)
    direct_file = common.get_optional_param(args.file)
    output_dir_arg = common.get_optional_param(args.output_dir)

    if vault_path and file_path_arg and file_name_arg:
        vault = common.fix_path(vault_path)
        file_abs = common.fix_path(file_path_arg)
        file_name = common.sanitize_name(file_name_arg)
        if not os.path.isdir(vault):
            common.safe_print(f"Error: Vault path not found: {vault}", file=sys.stderr)
            sys.exit(1)
        media_dir = os.path.join(vault, "Attachments", "Medios")
        backup_dir = os.path.join(media_dir, "pre-process-backup")
        stem = Path(file_name).stem
        out_dir = os.path.join(media_dir, stem)
        os.makedirs(backup_dir, exist_ok=True)
        os.makedirs(out_dir, exist_ok=True)
    elif direct_file:
        file_abs = common.fix_path(direct_file)
        if not os.path.isfile(file_abs):
            common.safe_print(f"Error: File not found: {file_abs}", file=sys.stderr)
            sys.exit(1)
        file_name = os.path.basename(file_abs)
        stem = Path(file_name).stem
        if output_dir_arg:
            out_dir = common.fix_path(output_dir_arg)
            backup_dir = out_dir
        else:
            out_dir = os.path.join(os.path.dirname(file_abs), stem)
            backup_dir = os.path.dirname(file_abs)
        os.makedirs(out_dir, exist_ok=True)
    else:
        common.safe_print(
            "Error: Use --vault-path, --file-path, --file-name (Obsidian) or pass audio file (direct).",
            file=sys.stderr,
        )
        parser.print_help(sys.stderr)
        sys.exit(1)

    if not os.path.isfile(file_abs):
        common.safe_print(f"Error: File not found: {file_abs}", file=sys.stderr)
        sys.exit(1)

    ext = Path(file_name).suffix if file_name else Path(file_abs).suffix or ".mp3"
    timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
    backup_file = os.path.join(backup_dir, f"{stem}_orig_{timestamp}{ext}")

    try:
        shutil.move(file_abs, backup_file)
    except Exception as e:
        common.safe_print(f"Error: Failed to create backup: {e}", file=sys.stderr)
        sys.exit(1)

    ffmpeg_bin = get_ffmpeg_path()
    ffprobe_bin = get_ffprobe_path()

    probe_data = probe_audio_file(backup_file, ffprobe_bin)
    duration = get_duration(backup_file, ffprobe_bin)
    if not duration or duration <= 0:
        try:
            shutil.move(backup_file, file_abs)
        except Exception:
            pass
        common.safe_print("Error: Could not get audio duration.", file=sys.stderr)
        sys.exit(1)

    work_file = backup_file
    temp_made = False
    if needs_conversion(probe_data):
        temp_made = True
        work_file = os.path.join(out_dir, f"{stem}_opt.mp3")
        if not convert_audio(backup_file, work_file, ffmpeg_bin):
            try:
                shutil.move(backup_file, file_abs)
            except Exception:
                pass
            common.safe_print("Error: Failed to convert audio.", file=sys.stderr)
            sys.exit(1)

    size_bytes = os.path.getsize(work_file)
    seg_time = compute_segment_time(duration, size_bytes)

    pattern = os.path.join(out_dir, f"{stem}_part%02d.mp3")
    if not run_split_audio(work_file, pattern, seg_time, ffmpeg_bin):
        if temp_made and os.path.isfile(work_file):
            try:
                os.remove(work_file)
            except Exception:
                pass
        try:
            shutil.move(backup_file, file_abs)
        except Exception:
            pass
        common.safe_print("Error: Failed to split audio.", file=sys.stderr)
        sys.exit(1)

    if temp_made and os.path.isfile(work_file):
        try:
            os.remove(work_file)
        except Exception:
            pass

    part_files = list(Path(out_dir).glob(f"{stem}_part*.mp3"))
    common.safe_print(f"Split complete: {len(part_files)} parts in {out_dir}")
    common.safe_print(f"Backup: {backup_file}")
